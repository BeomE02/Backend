package com.clink.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Assignment DTO - 과제 정보 (assignments 테이블과 연동)
 * 
 * 📋 테이블 구조:
 * - assignment_id: 과제 ID (PK)
 * - class_id: 수업 ID (FK)
 * - title: 과제 제목
 * - description: 과제 설명
 * - due_date: 마감일시
 * - max_score: 최대 점수
 * - is_active: 활성 상태
 * - created_at: 생성일시
 * - updated_at: 수정일시
 */
public class Assignment {
    
    // ========================================
    // 📋 기본 필드 (DB 컬럼)
    // ========================================
    private Long assignmentId;      // assignment_id
    private Long classId;           // class_id
    private String title;           // title
    private String description;     // description
    private Timestamp dueDate;      // due_date
    private Integer maxScore;       // max_score
    private Boolean isActive;       // is_active
    private Timestamp createdAt;    // created_at
    private Timestamp updatedAt;    // updated_at
    
    // ========================================
    // 📋 추가 정보 필드 (JOIN 결과)
    // ========================================
    private String className;       // 수업 이름 (classes.class_name)
    private String classCode;       // 수업 코드 (classes.class_code)
    private String professorName;   // 교수 이름 (users.name)
    private Integer submissionCount; // 제출된 과제 수
    private Integer totalStudents;  // 총 학생 수
    
    // ========================================
    // 📋 UI 관련 정보
    // ========================================
    private Boolean isSubmitted;    // 현재 사용자가 제출했는지
    private Boolean isOverdue;      // 마감일이 지났는지
    private Boolean canEdit;        // 수정 가능 여부
    private Boolean canDelete;      // 삭제 가능 여부
    private Integer userScore;      // 현재 사용자의 점수
    private String userFeedback;    // 현재 사용자의 피드백
    
    // ========================================
    // 🏗️ 생성자들
    // ========================================
    
    /**
     * 기본 생성자
     */
    public Assignment() {
        this.maxScore = 100;
        this.isActive = true;
        this.submissionCount = 0;
        this.totalStudents = 0;
        this.isSubmitted = false;
        this.isOverdue = false;
        this.canEdit = false;
        this.canDelete = false;
    }
    
    /**
     * 필수 필드 생성자
     */
    public Assignment(Long classId, String title, String description, Timestamp dueDate) {
        this();
        this.classId = classId;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
    }
    
    /**
     * 점수 포함 생성자
     */
    public Assignment(Long classId, String title, String description, Timestamp dueDate, Integer maxScore) {
        this(classId, title, description, dueDate);
        this.maxScore = maxScore;
    }
    
    // ========================================
    // 🔧 Getter & Setter
    // ========================================
    
    public Long getAssignmentId() {
        return assignmentId;
    }
    
    public void setAssignmentId(Long assignmentId) {
        this.assignmentId = assignmentId;
    }
    
    public Long getClassId() {
        return classId;
    }
    
    public void setClassId(Long classId) {
        this.classId = classId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Timestamp getDueDate() {
        return dueDate;
    }
    
    public void setDueDate(Timestamp dueDate) {
        this.dueDate = dueDate;
        // 마감일 설정 시 자동으로 overdue 상태 업데이트
        updateOverdueStatus();
    }
    
    public Integer getMaxScore() {
        return maxScore != null ? maxScore : 100;
    }
    
    public void setMaxScore(Integer maxScore) {
        this.maxScore = maxScore;
    }
    
    public Boolean isActive() {
        return isActive != null ? isActive : true;
    }
    
    public void setActive(Boolean active) {
        this.isActive = active;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public String getClassName() {
        return className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }
    
    public String getClassCode() {
        return classCode;
    }
    
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }
    
    public String getProfessorName() {
        return professorName;
    }
    
    public void setProfessorName(String professorName) {
        this.professorName = professorName;
    }
    
    public Integer getSubmissionCount() {
        return submissionCount != null ? submissionCount : 0;
    }
    
    public void setSubmissionCount(Integer submissionCount) {
        this.submissionCount = submissionCount;
    }
    
    public Integer getTotalStudents() {
        return totalStudents != null ? totalStudents : 0;
    }
    
    public void setTotalStudents(Integer totalStudents) {
        this.totalStudents = totalStudents;
    }
    
    public Boolean isSubmitted() {
        return isSubmitted != null ? isSubmitted : false;
    }
    
    public void setSubmitted(Boolean submitted) {
        this.isSubmitted = submitted;
    }
    
    public Boolean isOverdue() {
        return isOverdue != null ? isOverdue : false;
    }
    
    public void setOverdue(Boolean overdue) {
        this.isOverdue = overdue;
    }
    
    public Boolean isCanEdit() {
        return canEdit != null ? canEdit : false;
    }
    
    public void setCanEdit(Boolean canEdit) {
        this.canEdit = canEdit;
    }
    
    public Boolean isCanDelete() {
        return canDelete != null ? canDelete : false;
    }
    
    public void setCanDelete(Boolean canDelete) {
        this.canDelete = canDelete;
    }
    
    public Integer getUserScore() {
        return userScore;
    }
    
    public void setUserScore(Integer userScore) {
        this.userScore = userScore;
    }
    
    public String getUserFeedback() {
        return userFeedback;
    }
    
    public void setUserFeedback(String userFeedback) {
        this.userFeedback = userFeedback;
    }
    
    // ========================================
    // 🛠️ 유틸리티 메서드들
    // ========================================
    
    /**
     * 마감일 상태 업데이트
     */
    private void updateOverdueStatus() {
        if (dueDate != null) {
            this.isOverdue = dueDate.before(new Timestamp(System.currentTimeMillis()));
        } else {
            this.isOverdue = false;
        }
    }
    
    /**
     * 제출률 계산
     */
    public double getSubmissionRate() {
        if (totalStudents == null || totalStudents == 0) {
            return 0.0;
        }
        return (double) getSubmissionCount() / totalStudents * 100;
    }
    
    /**
     * 제출률 포맷팅 (소수점 1자리)
     */
    public String getFormattedSubmissionRate() {
        return String.format("%.1f%%", getSubmissionRate());
    }
    
    /**
     * 마감일시 포맷팅
     */
    public String getFormattedDueDate() {
        if (dueDate == null) return "";
        
        LocalDateTime ldt = dueDate.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return ldt.format(formatter);
    }
    
    /**
     * 마감일까지 남은 시간 계산
     */
    public String getTimeRemaining() {
        if (dueDate == null) return "마감일 없음";
        
        Timestamp now = new Timestamp(System.currentTimeMillis());
        long diffMillis = dueDate.getTime() - now.getTime();
        
        if (diffMillis <= 0) {
            return "마감됨";
        }
        
        long days = diffMillis / (24 * 60 * 60 * 1000);
        long hours = (diffMillis % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000);
        long minutes = (diffMillis % (60 * 60 * 1000)) / (60 * 1000);
        
        if (days > 0) {
            return String.format("%d일 %d시간", days, hours);
        } else if (hours > 0) {
            return String.format("%d시간 %d분", hours, minutes);
        } else {
            return String.format("%d분", minutes);
        }
    }
    
    /**
     * 생성일시 포맷팅
     */
    public String getFormattedCreatedAt() {
        if (createdAt == null) return "";
        
        LocalDateTime ldt = createdAt.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return ldt.format(formatter);
    }
    
    /**
     * 과제 설명 미리보기 (150자로 제한)
     */
    public String getPreviewDescription() {
        if (description == null || description.trim().isEmpty()) {
            return "설명이 없습니다.";
        }
        
        String text = description.trim();
        if (text.length() <= 150) {
            return text;
        }
        return text.substring(0, 150) + "...";
    }
    
    /**
     * 과제 상태 텍스트 반환
     */
    public String getStatusText() {
        if (!isActive()) {
            return "비활성";
        } else if (isOverdue()) {
            return "마감됨";
        } else {
            return "진행중";
        }
    }
    
    /**
     * 과제 상태에 따른 CSS 클래스 반환
     */
    public String getStatusClass() {
        if (!isActive()) {
            return "status-inactive";
        } else if (isOverdue()) {
            return "status-overdue";
        } else {
            return "status-active";
        }
    }
    
    /**
     * 사용자 점수 표시 (점수/최대점수)
     */
    public String getFormattedUserScore() {
        if (userScore == null) {
            return "미채점";
        }
        return String.format("%d/%d", userScore, getMaxScore());
    }
    
    /**
     * 제출 상태에 따른 CSS 클래스 반환
     */
    public String getSubmissionStatusClass() {
        if (isSubmitted()) {
            return userScore != null ? "submission-graded" : "submission-submitted";
        } else if (isOverdue()) {
            return "submission-overdue";
        } else {
            return "submission-pending";
        }
    }
    
    // ========================================
    // 🔧 Object 메서드 오버라이드
    // ========================================
    
    @Override
    public String toString() {
        return "Assignment{" +
                "assignmentId=" + assignmentId +
                ", classId=" + classId +
                ", title='" + title + "'" +
                ", maxScore=" + maxScore +
                ", dueDate=" + dueDate +
                ", isActive=" + isActive +
                ", isOverdue=" + isOverdue +
                ", submissionCount=" + submissionCount +
                ", totalStudents=" + totalStudents +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Assignment that = (Assignment) obj;
        return assignmentId != null && assignmentId.equals(that.assignmentId);
    }
    
    @Override
    public int hashCode() {
        return assignmentId != null ? assignmentId.hashCode() : 0;
    }
}