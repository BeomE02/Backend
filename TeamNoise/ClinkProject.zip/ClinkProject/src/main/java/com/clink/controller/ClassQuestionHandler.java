package com.clink.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.service.ClassService;
import com.clink.model.dao.QuestionDAO;
import com.clink.model.dto.User;
import com.clink.model.dto.Class;
import com.clink.model.dto.Question;

/**
 * ClassQuestionHandler - 질문/답변 기능 처리 전담
 * 
 * 🎯 담당 기능:
 * - /class/question/submit: 질문 제출
 * - /class/question/list: 질문 목록 조회
 * - /class/question/vote: 질문 투표
 * - /class/question/answer: 답변 제출 (교수만)
 * - /class/question/delete: 질문 삭제 (교수만)
 */
public class ClassQuestionHandler {
    
    private QuestionDAO questionDAO;
    private ClassService classService;
    
    /**
     * 생성자 - 의존성 주입
     */
    public ClassQuestionHandler(QuestionDAO questionDAO, ClassService classService) {
        this.questionDAO = questionDAO;
        this.classService = classService;
    }
    
    /**
     * 🎯 질문/답변 요청 라우터
     */
    public void handleQuestionRequest(HttpServletRequest request, HttpServletResponse response, String command) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("loginUser");
        
        if (user == null) {
            sendJsonResponse(response, false, "로그인이 필요합니다.", "redirectUrl:/login.do");
            return;
        }
        
        System.out.println("🙋‍♀️ 질문/답변 요청: " + command + " (user: " + user.getRole() + ")");
        
        try {
            switch (command) {
                case "/class/question/submit":
                    handleSubmitQuestion(request, response, user);
                    break;
                    
                case "/class/question/list":
                    handleGetQuestions(request, response, user);
                    break;
                    
                case "/class/question/vote":
                    handleVoteQuestion(request, response, user);
                    break;
                    
                case "/class/question/answer":
                    handleSubmitAnswer(request, response, user);
                    break;
                    
                case "/class/question/delete":
                    handleDeleteQuestion(request, response, user);
                    break;
                    
                default:
                    sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("💥 질문/답변 요청 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 📝 질문 제출
     */
    private void handleSubmitQuestion(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        String classCode = request.getParameter("classCode");
        String questionText = request.getParameter("questionText");
        boolean isAnonymous = "true".equals(request.getParameter("isAnonymous"));
        
        System.out.println("📝 질문 제출 요청: " + user.getName() + " → " + classCode);
        
        if (questionText == null || questionText.trim().isEmpty()) {
            sendJsonResponse(response, false, "질문을 입력해주세요.", null);
            return;
        }
        
        if (questionText.length() > 1000) {
            sendJsonResponse(response, false, "질문은 1000자 이내로 입력해주세요.", null);
            return;
        }
        
        try {
            // 수업 정보 조회
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            // 질문 생성
            Question question = new Question();
            question.setClassId(classInfo.getId());
            question.setStudentId((long) user.getUserId());
            question.setQuestionText(questionText.trim());
            question.setAnonymous(isAnonymous);
            
            boolean success = questionDAO.createQuestion(question);
            
            if (success) {
                System.out.println("✅ 질문 제출 성공: " + user.getName() + " → " + classCode);
                sendJsonResponse(response, true, "질문이 제출되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "질문 제출에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 질문 제출 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "질문 제출 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 📋 질문 목록 조회
     */
    private void handleGetQuestions(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        String classCode = request.getParameter("classCode");
        
        System.out.println("📋 질문 목록 조회: " + classCode);
        
        try {
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            List<Question> questions = questionDAO.getQuestionsByClass(classInfo.getId());
            
            // JSON 응답 생성
            StringBuilder json = new StringBuilder();
            json.append("{");
            json.append("\"success\":true,");
            json.append("\"questions\":[");
            
            for (int i = 0; i < questions.size(); i++) {
                Question q = questions.get(i);
                if (i > 0) json.append(",");
                
                json.append("{");
                json.append("\"id\":").append(q.getQuestionId()).append(",");
                json.append("\"questionText\":\"").append(escapeJson(q.getQuestionText())).append("\",");
                json.append("\"authorName\":\"").append(escapeJson(q.getAuthorName())).append("\",");
                json.append("\"isAnonymous\":").append(q.isAnonymous()).append(",");
                json.append("\"voteCount\":").append(q.getVoteCount()).append(",");
                json.append("\"userVoted\":").append(q.isUserVoted()).append(",");
                json.append("\"createdAt\":\"").append(q.getCreatedAt()).append("\"");
                if (q.getAnswerText() != null) {
                    json.append(",\"answerText\":\"").append(escapeJson(q.getAnswerText())).append("\"");
                }
                json.append("}");
            }
            
            json.append("]}");
            
            response.setContentType("application/json; charset=UTF-8");
            response.getWriter().write(json.toString());
            
            System.out.println("✅ 질문 목록 조회 완료: " + questions.size() + "개");
            
        } catch (Exception e) {
            System.err.println("💥 질문 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "질문 목록 조회 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 👍 질문 투표
     */
    private void handleVoteQuestion(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        System.out.println("👍 질문 투표 요청: " + user.getName());
        
        try {
            String questionIdStr = request.getParameter("questionId");
            
            if (questionIdStr == null) {
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다.", null);
                return;
            }
            
            long questionId;
            try {
                questionId = Long.parseLong(questionIdStr);
            } catch (NumberFormatException e) {
                sendJsonResponse(response, false, "잘못된 질문 ID입니다.", null);
                return;
            }
            
            // 질문 존재 확인
            Question question = questionDAO.getQuestionById(questionId);
            if (question == null) {
                sendJsonResponse(response, false, "질문을 찾을 수 없습니다.", null);
                return;
            }
            
            // 본인 질문 투표 방지
            if (question.getStudentId().equals((long) user.getUserId())) {
                sendJsonResponse(response, false, "본인의 질문에는 투표할 수 없습니다.", null);
                return;
            }
            
            // 🔧 실제 DAO 메서드 사용: toggleQuestionVote
            boolean success = questionDAO.toggleQuestionVote(questionId, (long) user.getUserId());
            
            if (success) {
                // 업데이트된 질문 정보 다시 조회
                Question updatedQuestion = questionDAO.getQuestionById(questionId);
                int newVoteCount = updatedQuestion != null ? updatedQuestion.getVoteCount() : 0;
                
                System.out.println("✅ 질문 투표 성공: " + questionId + " (새 투표수: " + newVoteCount + ")");
                sendJsonResponse(response, true, "투표가 처리되었습니다.", "\"voteCount\":" + newVoteCount);
            } else {
                sendJsonResponse(response, false, "투표 처리에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 질문 투표 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "투표 처리 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 💬 답변 제출 (교수만)
     */
    private void handleSubmitAnswer(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        if (!"professor".equals(user.getRole())) {
            sendJsonResponse(response, false, "교수만 답변할 수 있습니다.", null);
            return;
        }
        
        System.out.println("💬 답변 제출 요청: " + user.getName());
        
        try {
            String questionIdStr = request.getParameter("questionId");
            String answerText = request.getParameter("answerText");
            
            if (questionIdStr == null || answerText == null || answerText.trim().isEmpty()) {
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다.", null);
                return;
            }
            
            long questionId;
            try {
                questionId = Long.parseLong(questionIdStr);
            } catch (NumberFormatException e) {
                sendJsonResponse(response, false, "잘못된 질문 ID입니다.", null);
                return;
            }
            
            // 질문 존재 확인
            Question question = questionDAO.getQuestionById(questionId);
            if (question == null) {
                sendJsonResponse(response, false, "질문을 찾을 수 없습니다.", null);
                return;
            }
            
            // 답변 길이 검증
            if (answerText.length() > 2000) {
                sendJsonResponse(response, false, "답변은 2000자 이내로 입력해주세요.", null);
                return;
            }
            
            // 🔧 실제 DAO 메서드 사용: addAnswer
            boolean success = questionDAO.addAnswer(questionId, (long) user.getUserId(), answerText.trim());
            
            if (success) {
                System.out.println("✅ 답변 제출 성공: 질문ID " + questionId);
                sendJsonResponse(response, true, "답변이 제출되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "답변 제출에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 답변 제출 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "답변 제출 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🗑️ 질문 삭제 (교수만)
     */
    private void handleDeleteQuestion(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        System.out.println("🗑️ 질문 삭제 요청: " + user.getName());
        
        try {
            String questionIdStr = request.getParameter("questionId");
            
            if (questionIdStr == null) {
                sendJsonResponse(response, false, "질문 ID가 필요합니다.", null);
                return;
            }
            
            long questionId;
            try {
                questionId = Long.parseLong(questionIdStr);
            } catch (NumberFormatException e) {
                sendJsonResponse(response, false, "잘못된 질문 ID입니다.", null);
                return;
            }
            
            // 질문 존재 확인
            Question question = questionDAO.getQuestionById(questionId);
            if (question == null) {
                sendJsonResponse(response, false, "질문을 찾을 수 없습니다.", null);
                return;
            }
            
            boolean success = false;
            
            if ("professor".equals(user.getRole())) {
                // 🔧 교수인 경우: deleteQuestion(questionId, professorId) 사용
                success = questionDAO.deleteQuestion(questionId, (long) user.getUserId());
            } else if (question.getStudentId().equals((long) user.getUserId())) {
                // 학생 본인 질문 삭제는 별도 구현 필요 (현재 DAO에 없음)
                sendJsonResponse(response, false, "학생은 질문을 삭제할 수 없습니다.", null);
                return;
            } else {
                sendJsonResponse(response, false, "삭제 권한이 없습니다.", null);
                return;
            }
            
            if (success) {
                System.out.println("✅ 질문 삭제 성공: " + questionId);
                sendJsonResponse(response, true, "질문이 삭제되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "질문 삭제에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 질문 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "질문 삭제 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * JSON 응답 전송
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, 
                                String message, String data) throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null && !data.isEmpty()) {
            if (data.startsWith("redirectUrl:")) {
                json.append(",\"redirectUrl\":\"").append(escapeJson(data.substring(12))).append("\"");
            } else {
                json.append(",\"data\":{").append(data).append("}");
            }
        }
        
        json.append("}");
        
        PrintWriter out = response.getWriter();
        out.print(json.toString());
        out.flush();
        
        System.out.println("📤 질문 JSON 응답: " + (success ? "SUCCESS" : "ERROR") + " - " + message);
    }
    
    /**
     * JSON 문자열 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}