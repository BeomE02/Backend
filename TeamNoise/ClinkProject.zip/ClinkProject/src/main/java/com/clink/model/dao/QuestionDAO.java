package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Question;
import com.clink.util.DBConnection;

/**
 * QuestionDAO - 질문/답변 데이터 접근 객체 (완성 버전)
 * 
 * 📋 연동 테이블:
 * - questions: 질문 정보
 * - question_votes: 질문 투표
 * - users: 사용자 정보 (JOIN)
 * - classes: 수업 정보 (JOIN)
 */
public class QuestionDAO {
    
    /**
     * 🔍 수업별 질문 목록 조회 (상세 정보 포함)
     */
    public List<Question> getQuestionsByClass(Long classId) {
        List<Question> questions = new ArrayList<>();
        
        String sql = "SELECT q.question_id, q.class_id, q.student_id, q.question_text, " +
                    "q.answer_text, q.professor_id, q.vote_count, q.is_anonymous, " +
                    "q.status, q.created_at, q.answered_at, " +
                    "s.name as student_name, p.name as professor_name, " +
                    "c.class_name, c.class_code " +
                    "FROM questions q " +
                    "LEFT JOIN users s ON q.student_id = s.user_id " +
                    "LEFT JOIN users p ON q.professor_id = p.user_id " +
                    "LEFT JOIN classes c ON q.class_id = c.class_id " +
                    "WHERE q.class_id = ? " +
                    "ORDER BY q.vote_count DESC, q.created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Question question = mapResultSetToQuestion(rs);
                    questions.add(question);
                }
            }
            
            System.out.println("✅ 수업별 질문 목록 조회 성공: " + questions.size() + "개 (수업 ID: " + classId + ")");
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 질문 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return questions;
    }
    
    /**
     * 🔍 질문 ID로 조회
     */
    public Question getQuestionById(Long questionId) {
        String sql = "SELECT q.question_id, q.class_id, q.student_id, q.question_text, " +
                    "q.answer_text, q.professor_id, q.vote_count, q.is_anonymous, " +
                    "q.status, q.created_at, q.answered_at, " +
                    "s.name as student_name, p.name as professor_name, " +
                    "c.class_name, c.class_code " +
                    "FROM questions q " +
                    "LEFT JOIN users s ON q.student_id = s.user_id " +
                    "LEFT JOIN users p ON q.professor_id = p.user_id " +
                    "LEFT JOIN classes c ON q.class_id = c.class_id " +
                    "WHERE q.question_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, questionId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Question question = mapResultSetToQuestion(rs);
                    System.out.println("✅ 질문 조회 성공: ID " + questionId);
                    return question;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문 조회 실패 (ID: " + questionId + "): " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("⚠️ 질문을 찾을 수 없음: ID " + questionId);
        return null;
    }
    
    /**
     * 🆕 질문 생성
     */
    public boolean createQuestion(Question question) {
        String sql = "INSERT INTO questions (class_id, student_id, question_text, is_anonymous, status, created_at) " +
                    "VALUES (?, ?, ?, ?, ?, NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setLong(1, question.getClassId());
            pstmt.setLong(2, question.getStudentId());
            pstmt.setString(3, question.getQuestionText());
            pstmt.setBoolean(4, question.isAnonymous());
            pstmt.setString(5, question.getStatus() != null ? question.getStatus() : "pending");
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                // 생성된 ID 설정
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        question.setQuestionId(rs.getLong(1));
                    }
                }
                
                System.out.println("✅ 질문 생성 성공: ID " + question.getQuestionId());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문 생성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 💬 답변 추가/수정
     */
    public boolean addAnswer(Long questionId, Long professorId, String answerText) {
        String sql = "UPDATE questions SET answer_text = ?, professor_id = ?, status = 'answered', answered_at = NOW() " +
                    "WHERE question_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, answerText);
            pstmt.setLong(2, professorId);
            pstmt.setLong(3, questionId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 답변 추가 성공: 질문 ID " + questionId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 답변 추가 실패 (질문 ID: " + questionId + "): " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 👍 질문 투표 토글 (추천/추천 취소)
     */
    public boolean toggleQuestionVote(Long questionId, Long userId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 기존 투표 확인
                String checkSql = "SELECT vote_id FROM question_votes WHERE question_id = ? AND user_id = ?";
                boolean hasVoted = false;
                
                try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                    checkStmt.setLong(1, questionId);
                    checkStmt.setLong(2, userId);
                    
                    try (ResultSet rs = checkStmt.executeQuery()) {
                        hasVoted = rs.next();
                    }
                }
                
                if (hasVoted) {
                    // 기존 투표 삭제
                    String deleteSql = "DELETE FROM question_votes WHERE question_id = ? AND user_id = ?";
                    try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                        deleteStmt.setLong(1, questionId);
                        deleteStmt.setLong(2, userId);
                        deleteStmt.executeUpdate();
                    }
                    
                    // 투표 수 감소
                    String updateSql = "UPDATE questions SET vote_count = vote_count - 1 WHERE question_id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setLong(1, questionId);
                        updateStmt.executeUpdate();
                    }
                    
                    System.out.println("✅ 질문 투표 취소 성공: 질문 ID " + questionId + ", 사용자 ID " + userId);
                    
                } else {
                    // 새 투표 추가
                    String insertSql = "INSERT INTO question_votes (question_id, user_id, created_at) VALUES (?, ?, NOW())";
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                        insertStmt.setLong(1, questionId);
                        insertStmt.setLong(2, userId);
                        insertStmt.executeUpdate();
                    }
                    
                    // 투표 수 증가
                    String updateSql = "UPDATE questions SET vote_count = vote_count + 1 WHERE question_id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setLong(1, questionId);
                        updateStmt.executeUpdate();
                    }
                    
                    System.out.println("✅ 질문 투표 추가 성공: 질문 ID " + questionId + ", 사용자 ID " + userId);
                }
                
                conn.commit();
                return true;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문 투표 토글 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔍 사용자가 특정 질문에 투표했는지 확인
     */
    public boolean hasUserVoted(Long questionId, Long userId) {
        String sql = "SELECT 1 FROM question_votes WHERE question_id = ? AND user_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, questionId);
            pstmt.setLong(2, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 여부 확인 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🗑️ 질문 삭제 (교수만 가능)
     */
    public boolean deleteQuestion(Long questionId, Long professorId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 질문이 해당 교수의 수업에 속하는지 확인
                String checkSql = "SELECT q.question_id FROM questions q " +
                                 "JOIN classes c ON q.class_id = c.class_id " +
                                 "WHERE q.question_id = ? AND c.professor_id = ?";
                
                boolean canDelete = false;
                try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                    checkStmt.setLong(1, questionId);
                    checkStmt.setLong(2, professorId);
                    
                    try (ResultSet rs = checkStmt.executeQuery()) {
                        canDelete = rs.next();
                    }
                }
                
                if (!canDelete) {
                    System.out.println("⚠️ 질문 삭제 권한 없음: 질문 ID " + questionId + ", 교수 ID " + professorId);
                    return false;
                }
                
                // 관련 투표 먼저 삭제
                String deleteVotesSql = "DELETE FROM question_votes WHERE question_id = ?";
                try (PreparedStatement deleteVotesStmt = conn.prepareStatement(deleteVotesSql)) {
                    deleteVotesStmt.setLong(1, questionId);
                    deleteVotesStmt.executeUpdate();
                }
                
                // 질문 삭제
                String deleteQuestionSql = "DELETE FROM questions WHERE question_id = ?";
                try (PreparedStatement deleteStmt = conn.prepareStatement(deleteQuestionSql)) {
                    deleteStmt.setLong(1, questionId);
                    int result = deleteStmt.executeUpdate();
                    
                    if (result > 0) {
                        conn.commit();
                        System.out.println("✅ 질문 삭제 성공: ID " + questionId);
                        return true;
                    }
                }
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * ✏️ 질문 수정 (학생 본인만 가능, 답변 전에만)
     */
    public boolean updateQuestion(Long questionId, Long studentId, String questionText) {
        String sql = "UPDATE questions SET question_text = ? " +
                    "WHERE question_id = ? AND student_id = ? AND status = 'pending'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, questionText);
            pstmt.setLong(2, questionId);
            pstmt.setLong(3, studentId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 질문 수정 성공: ID " + questionId);
                return true;
            } else {
                System.out.println("⚠️ 질문 수정 실패: 권한 없음 또는 이미 답변됨 (ID: " + questionId + ")");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 📊 수업별 질문 통계 조회
     */
    public int getQuestionCountByClass(Long classId) {
        String sql = "SELECT COUNT(*) FROM questions WHERE class_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    System.out.println("✅ 수업별 질문 수 조회 성공: " + count + "개 (수업 ID: " + classId + ")");
                    return count;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 질문 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    /**
     * 📊 답변되지 않은 질문 수 조회
     */
    public int getPendingQuestionCountByClass(Long classId) {
        String sql = "SELECT COUNT(*) FROM questions WHERE class_id = ? AND status = 'pending'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 답변 대기 질문 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🛠️ 헬퍼 메서드들
    // ========================================
    
    /**
     * ResultSet을 Question 객체로 매핑
     */
    private Question mapResultSetToQuestion(ResultSet rs) throws SQLException {
        Question question = new Question();
        
        // 기본 필드
        question.setQuestionId(rs.getLong("question_id"));
        question.setClassId(rs.getLong("class_id"));
        question.setStudentId(rs.getLong("student_id"));
        question.setQuestionText(rs.getString("question_text"));
        question.setAnswerText(rs.getString("answer_text"));
        
        Long professorId = rs.getLong("professor_id");
        if (!rs.wasNull()) {
            question.setProfessorId(professorId);
        }
        
        question.setVoteCount(rs.getInt("vote_count"));
        question.setAnonymous(rs.getBoolean("is_anonymous"));
        question.setStatus(rs.getString("status"));
        question.setCreatedAt(rs.getTimestamp("created_at"));
        question.setAnsweredAt(rs.getTimestamp("answered_at"));
        
        // 추가 정보
        question.setAuthorName(rs.getString("student_name"));
        question.setProfessorName(rs.getString("professor_name"));
        question.setClassName(rs.getString("class_name"));
        question.setClassCode(rs.getString("class_code"));
        
        return question;
    }
}