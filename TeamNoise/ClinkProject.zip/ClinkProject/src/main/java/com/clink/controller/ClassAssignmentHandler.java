package com.clink.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.service.ClassService;
import com.clink.model.dao.AssignmentDAO;
import com.clink.model.dto.User;
import com.clink.model.dto.Class;
import com.clink.model.dto.Assignment;

/**
 * ClassAssignmentHandler - 과제 기능 처리 전담
 * 
 * 🎯 담당 기능:
 * - /class/assignment/create: 과제 생성 (교수만)
 * - /class/assignment/list: 과제 목록 조회
 * - /class/assignment/submit: 과제 제출 (학생)
 */
public class ClassAssignmentHandler {
    
    private AssignmentDAO assignmentDAO;
    private ClassService classService;
    
    /**
     * 생성자 - 의존성 주입
     */
    public ClassAssignmentHandler(AssignmentDAO assignmentDAO, ClassService classService) {
        this.assignmentDAO = assignmentDAO;
        this.classService = classService;
    }
    
    /**
     * 🎯 과제 요청 라우터
     */
    public void handleAssignmentRequest(HttpServletRequest request, HttpServletResponse response, String command) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("loginUser");
        
        System.out.println("📝 과제 요청: " + command + " (user: " + user.getRole() + ")");
        
        try {
            switch (command) {
                case "/class/assignment/create":
                    handleCreateAssignment(request, response, user);
                    break;
                    
                case "/class/assignment/list":
                    handleGetAssignments(request, response, user);
                    break;
                    
                case "/class/assignment/submit":
                    handleSubmitAssignment(request, response, user);
                    break;
                    
                default:
                    sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("💥 과제 요청 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🆕 과제 생성 (교수만)
     */
    private void handleCreateAssignment(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        if (!"professor".equals(user.getRole())) {
            sendJsonResponse(response, false, "교수만 과제를 생성할 수 있습니다.", null);
            return;
        }
        
        System.out.println("📝 과제 생성 요청: " + user.getName());
        
        try {
            String classCode = request.getParameter("classCode");
            String title = request.getParameter("assignmentTitle");
            String description = request.getParameter("assignmentDescription");
            String dueDateStr = request.getParameter("assignmentDueDate");
            String maxScoreStr = request.getParameter("assignmentMaxScore");
            
            if (title == null || title.trim().isEmpty() || dueDateStr == null) {
                sendJsonResponse(response, false, "제목과 마감일은 필수입니다.", null);
                return;
            }
            
            // 수업 정보 조회
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            // 권한 확인
            if (!classInfo.getProfessorId().equals((long) user.getUserId())) {
                sendJsonResponse(response, false, "과제 생성 권한이 없습니다.", null);
                return;
            }
            
            // 최대 점수 파싱
            int maxScore = 100; // 기본값
            if (maxScoreStr != null && !maxScoreStr.trim().isEmpty()) {
                try {
                    maxScore = Integer.parseInt(maxScoreStr);
                    if (maxScore < 1 || maxScore > 1000) {
                        sendJsonResponse(response, false, "최대 점수는 1~1000점 사이여야 합니다.", null);
                        return;
                    }
                } catch (NumberFormatException e) {
                    sendJsonResponse(response, false, "최대 점수가 올바르지 않습니다.", null);
                    return;
                }
            }
            
            // Assignment 객체 생성
            Assignment assignment = new Assignment();
            assignment.setClassId(classInfo.getId());
            assignment.setTitle(title.trim());
            assignment.setDescription(description != null ? description.trim() : "");
            assignment.setDueDate(java.sql.Timestamp.valueOf(dueDateStr.replace("T", " ") + ":00"));
            assignment.setMaxScore(maxScore);
            assignment.setActive(true);
            
            // 과제 생성 실행
            boolean success = assignmentDAO.createAssignment(assignment);
            
            if (success) {
                System.out.println("✅ 과제 생성 성공: " + title);
                sendJsonResponse(response, true, "과제가 생성되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "과제 생성에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 과제 생성 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "과제 생성 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 📋 과제 목록 조회
     */
    private void handleGetAssignments(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        String classCode = request.getParameter("classCode");
        
        System.out.println("📋 과제 목록 조회: " + classCode);
        
        try {
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            List<Assignment> assignments = assignmentDAO.getAssignmentsByClass(classInfo.getId());
            
            // JSON 응답 생성
            StringBuilder json = new StringBuilder();
            json.append("{");
            json.append("\"success\":true,");
            json.append("\"assignments\":[");
            
            for (int i = 0; i < assignments.size(); i++) {
                Assignment a = assignments.get(i);
                if (i > 0) json.append(",");
                
                json.append("{");
                json.append("\"id\":").append(a.getAssignmentId()).append(",");
                json.append("\"title\":\"").append(escapeJson(a.getTitle())).append("\",");
                json.append("\"description\":\"").append(escapeJson(a.getDescription())).append("\",");
                json.append("\"dueDate\":\"").append(a.getDueDate()).append("\",");
                json.append("\"maxScore\":").append(a.getMaxScore()).append(",");
                json.append("\"isActive\":").append(a.isActive());
                json.append("}");
            }
            
            json.append("]}");
            
            response.setContentType("application/json; charset=UTF-8");
            response.getWriter().write(json.toString());
            
            System.out.println("✅ 과제 목록 조회 완료: " + assignments.size() + "개");
            
        } catch (Exception e) {
            System.err.println("💥 과제 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "과제 목록 조회 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 📤 과제 제출 (학생)
     */
    private void handleSubmitAssignment(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        if (!"student".equals(user.getRole())) {
            sendJsonResponse(response, false, "학생만 과제를 제출할 수 있습니다.", null);
            return;
        }
        
        System.out.println("📤 과제 제출 요청: " + user.getName());
        
        try {
            String assignmentIdStr = request.getParameter("assignmentId");
            String submissionText = request.getParameter("submissionText");
            
            if (assignmentIdStr == null) {
                sendJsonResponse(response, false, "과제 ID가 필요합니다.", null);
                return;
            }
            
            long assignmentId;
            try {
                assignmentId = Long.parseLong(assignmentIdStr);
            } catch (NumberFormatException e) {
                sendJsonResponse(response, false, "잘못된 과제 ID입니다.", null);
                return;
            }
            
            // 과제 존재 확인
            Assignment assignment = assignmentDAO.getAssignmentById(assignmentId);
            if (assignment == null) {
                sendJsonResponse(response, false, "과제를 찾을 수 없습니다.", null);
                return;
            }
            
            // 과제 활성 상태 확인
            if (!assignment.isActive()) {
                sendJsonResponse(response, false, "비활성화된 과제입니다.", null);
                return;
            }
            
            // 마감일 확인
            if (assignment.getDueDate().before(new java.util.Date())) {
                sendJsonResponse(response, false, "과제 마감일이 지났습니다.", null);
                return;
            }
            
            // 제출 내용 검증
            if (submissionText == null || submissionText.trim().isEmpty()) {
                sendJsonResponse(response, false, "제출 내용을 입력해주세요.", null);
                return;
            }
            
            if (submissionText.length() > 5000) {
                sendJsonResponse(response, false, "제출 내용은 5000자 이내로 입력해주세요.", null);
                return;
            }
            
            // TODO: 과제 제출 로직 구현 (AssignmentDAO에 submitAssignment 메서드 필요)
            // boolean success = assignmentDAO.submitAssignment(assignmentId, (long) user.getUserId(), submissionText.trim());
            
            // 임시로 성공 처리
            boolean success = true;
            
            if (success) {
                System.out.println("✅ 과제 제출 성공: 과제ID " + assignmentId);
                sendJsonResponse(response, true, "과제가 제출되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "과제 제출에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 과제 제출 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "과제 제출 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * JSON 응답 전송
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, 
                                String message, String data) throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null && !data.isEmpty()) {
            if (data.startsWith("redirectUrl:")) {
                json.append(",\"redirectUrl\":\"").append(escapeJson(data.substring(12))).append("\"");
            } else {
                json.append(",\"data\":").append(data);
            }
        }
        
        json.append("}");
        
        PrintWriter out = response.getWriter();
        out.print(json.toString());
        out.flush();
        
        System.out.println("📤 과제 JSON 응답: " + (success ? "SUCCESS" : "ERROR") + " - " + message);
    }
    
    /**
     * JSON 문자열 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}