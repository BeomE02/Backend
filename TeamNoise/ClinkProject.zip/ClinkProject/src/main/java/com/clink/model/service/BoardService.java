package com.clink.model.service;

import java.util.List;
import java.util.ArrayList;
import com.clink.model.dao.BoardDAO;      // 범용 게시판
import com.clink.model.dao.FreeBoardDAO;  // 자유게시판 전용
import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;

/**
 * BoardService - 하이브리드 방식 (프로젝트 개요 준수)
 * 자유게시판 → FreeBoardDAO 사용 (최적화)
 * 다른 게시판 → BoardDAO 사용 (범용)
 */
public class BoardService {
    
    private BoardDAO boardDAO;          // 범용 게시판 DAO
    private FreeBoardDAO freeBoardDAO;  // 자유게시판 전용 DAO
    
    /**
     * 생성자 - 두 DAO 모두 초기화
     */
    public BoardService() {
        try {
            this.boardDAO = new BoardDAO();
            this.freeBoardDAO = new FreeBoardDAO();
            System.out.println("✅ BoardService 하이브리드 초기화 성공");
            System.out.println("   - BoardDAO: 범용 게시판 지원");
            System.out.println("   - FreeBoardDAO: 자유게시판 최적화");
        } catch (Exception e) {
            System.err.println("❌ BoardService 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            this.boardDAO = null;
            this.freeBoardDAO = null;
        }
    }
    
    /**
     * DAO 유효성 체크
     */
    private boolean isDAOValid() {
        if (boardDAO == null || freeBoardDAO == null) {
            System.err.println("❌ DAO가 초기화되지 않았습니다.");
            return false;
        }
        return true;
    }
    
    // ========================================
    // 🎯 하이브리드 메서드들 (카테고리별 라우팅)
    // ========================================
    
    /**
     * 게시글 목록 조회 - 🔄 하이브리드 라우팅
     */
    public List<Post> getPostList(String categoryCode, Integer classId, int page, int pageSize, String searchType, String keyword) {
        System.out.println("🔍 BoardService.getPostList (하이브리드) - category: " + categoryCode);
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        // 파라미터 기본값 설정
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            categoryCode = "free";
        }
        if (page <= 0) page = 1;
        if (pageSize <= 0) pageSize = 10;
        
        try {
            List<Post> postList;
            
            // 🎯 카테고리별 라우팅
            if ("free".equals(categoryCode)) {
                System.out.println("→ 자유게시판: FreeBoardDAO 사용");
                postList = freeBoardDAO.getFreePostList(classId, page, pageSize, searchType, keyword);
            } else {
                System.out.println("→ " + categoryCode + "게시판: BoardDAO 사용");
                postList = boardDAO.getPostList(categoryCode, classId, page, pageSize, searchType, keyword);
            }
            
            if (postList == null) {
                postList = new ArrayList<>();
            }
            
            System.out.println("✅ 게시글 목록 조회 완료: " + postList.size() + "개");
            return postList;
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 게시글 개수 조회 - 🔄 하이브리드 라우팅
     */
    public int getPostCount(String categoryCode, Integer classId, String searchType, String keyword) {
        System.out.println("🔍 BoardService.getPostCount (하이브리드) - category: " + categoryCode);
        
        if (!isDAOValid()) {
            return 0;
        }
        
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            categoryCode = "free";
        }
        
        try {
            int count;
            
            // 🎯 카테고리별 라우팅
            if ("free".equals(categoryCode)) {
                System.out.println("→ 자유게시판: FreeBoardDAO 사용");
                count = freeBoardDAO.getFreePostCount(classId, searchType, keyword);
            } else {
                System.out.println("→ " + categoryCode + "게시판: BoardDAO 사용");
                count = boardDAO.getPostCount(categoryCode, classId, searchType, keyword);
            }
            
            System.out.println("✅ 게시글 개수 조회 완료: " + count + "개");
            return count;
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 개수 조회 오류: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * 게시글 상세 조회 - 🔄 하이브리드 라우팅
     */
    public Post getPost(int postId) {
        System.out.println("🔍 BoardService.getPost (하이브리드) - postId: " + postId);
        
        if (!isDAOValid() || postId <= 0) {
            return null;
        }
        
        try {
            // 먼저 범용 DAO로 카테고리 확인
            Post post = boardDAO.getPost(postId);
            
            if (post != null && "free".equals(post.getCategoryCode())) {
                System.out.println("→ 자유게시판 글: FreeBoardDAO로 다시 조회");
                post = freeBoardDAO.getFreePost(postId);
            }
            
            if (post != null) {
                System.out.println("✅ 게시글 조회 성공: " + post.getTitle());
            }
            
            return post;
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 조회 오류: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 조회수 증가 - 🔄 하이브리드 라우팅
     */
    public void increaseViewCount(int postId) {
        if (!isDAOValid() || postId <= 0) {
            return;
        }
        
        try {
            // 게시글 정보로 카테고리 확인
            Post post = boardDAO.getPost(postId);
            
            if (post != null && "free".equals(post.getCategoryCode())) {
                System.out.println("→ 자유게시판 조회수 증가: FreeBoardDAO 사용");
                freeBoardDAO.increaseViewCount(postId);
            } else {
                System.out.println("→ 범용 조회수 증가: BoardDAO 사용");
                boardDAO.increaseViewCount(postId);
            }
            
        } catch (Exception e) {
            System.err.println("❌ 조회수 증가 오류: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 게시글 작성 - 🔄 하이브리드 라우팅
     */
    public boolean createPost(Post post) {
        System.out.println("🔍 BoardService.createPost (하이브리드)");
        
        if (!isDAOValid() || post == null) {
            return false;
        }
        
        try {
            boolean result;
            String categoryCode = post.getCategoryCode();
            
            // 🎯 카테고리별 라우팅
            if ("free".equals(categoryCode)) {
                System.out.println("→ 자유게시판 글 작성: FreeBoardDAO 사용");
                result = freeBoardDAO.insertFreePost(post);
            } else {
                System.out.println("→ " + categoryCode + "게시판 글 작성: BoardDAO 사용");
                result = boardDAO.insertPost(post);
            }
            
            if (result) {
                System.out.println("✅ 게시글 작성 성공");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 작성 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 게시글 수정 - 🔄 하이브리드 라우팅
     */
    public boolean updatePost(Post post) {
        if (!isDAOValid() || post == null) {
            return false;
        }
        
        try {
            boolean result;
            String categoryCode = post.getCategoryCode();
            
            if ("free".equals(categoryCode)) {
                result = freeBoardDAO.updateFreePost(post);
            } else {
                result = boardDAO.updatePost(post);
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 수정 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 게시글 삭제 - 🔄 하이브리드 라우팅
     */
    public boolean deletePost(int postId, int authorId) {
        if (!isDAOValid() || postId <= 0 || authorId <= 0) {
            return false;
        }
        
        try {
            // 게시글 정보로 카테고리 확인
            Post post = boardDAO.getPost(postId);
            
            if (post != null && "free".equals(post.getCategoryCode())) {
                return freeBoardDAO.deleteFreePost(postId, authorId);
            } else {
                return boardDAO.deletePost(postId, authorId);
            }
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // ========================================
    // 댓글 관련 메서드들 (범용 DAO 사용)
    // ========================================
    
    /**
     * 댓글 목록 조회
     */
    public List<Comment> getCommentList(int postId) {
        if (!isDAOValid() || postId <= 0) {
            return new ArrayList<>();
        }
        
        try {
            // 댓글은 범용 DAO 사용 (카테고리 무관)
            List<Comment> comments = boardDAO.getCommentList(postId);
            return comments != null ? comments : new ArrayList<>();
            
        } catch (Exception e) {
            System.err.println("❌ 댓글 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 댓글 작성
     */
    public boolean createComment(Comment comment) {
        if (!isDAOValid() || comment == null) {
            return false;
        }
        
        try {
            return boardDAO.insertComment(comment);
        } catch (Exception e) {
            System.err.println("❌ 댓글 작성 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 댓글 수정
     */
    public boolean updateComment(int commentId, int authorId, String content) {
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            return boardDAO.updateComment(commentId, authorId, content);
        } catch (Exception e) {
            System.err.println("❌ 댓글 수정 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 댓글 삭제
     */
    public boolean deleteComment(int commentId, int authorId) {
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            return boardDAO.deleteComment(commentId, authorId);
        } catch (Exception e) {
            System.err.println("❌ 댓글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // ========================================
    // 🔮 확장용 메서드들 (특별 기능)
    // ========================================
    
    /**
     * 인기 게시글 조회
     */
    public List<Post> getPopularPosts(String categoryCode, int limit) {
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        try {
            if ("free".equals(categoryCode)) {
                return freeBoardDAO.getPopularFreePosts(limit);
            } else {
                return boardDAO.getPopularPosts(categoryCode, limit);
            }
        } catch (Exception e) {
            System.err.println("❌ 인기 게시글 조회 오류: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * 최근 게시글 조회
     */
    public List<Post> getRecentPosts(String categoryCode, int limit) {
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        try {
            if ("free".equals(categoryCode)) {
                return freeBoardDAO.getRecentFreePosts(limit);
            } else {
                return boardDAO.getRecentPosts(categoryCode, limit);
            }
        } catch (Exception e) {
            System.err.println("❌ 최근 게시글 조회 오류: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * 공지사항 조회
     */
    public List<Post> getNotices(String categoryCode, int limit) {
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        try {
            if ("free".equals(categoryCode)) {
                return freeBoardDAO.getFreeNotices(limit);
            } else {
                return boardDAO.getNotices(categoryCode, limit);
            }
        } catch (Exception e) {
            System.err.println("❌ 공지사항 조회 오류: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * 카테고리별 통계
     */
    public int getCategoryPostCount(String categoryCode) {
        if (!isDAOValid()) {
            return 0;
        }
        
        try {
            if ("free".equals(categoryCode)) {
                return freeBoardDAO.getTotalFreePostCount();
            } else {
                return boardDAO.getCategoryPostCount(categoryCode);
            }
        } catch (Exception e) {
            System.err.println("❌ 카테고리 통계 조회 오류: " + e.getMessage());
            return 0;
        }
    }
    
    // ========================================
    // 유틸리티 메서드들
    // ========================================
    
    /**
     * 서비스 상태 체크
     */
    public boolean isServiceHealthy() {
        return isDAOValid() && boardDAO.testConnection();
    }
    
    /**
     * 디버그 정보
     */
    public void printDebugInfo() {
        System.out.println("=== BoardService 하이브리드 디버그 ===");
        System.out.println("BoardDAO: " + (boardDAO != null ? "정상" : "null"));
        System.out.println("FreeBoardDAO: " + (freeBoardDAO != null ? "정상" : "null"));
        System.out.println("서비스 상태: " + (isServiceHealthy() ? "정상" : "오류"));
        System.out.println("=======================================");
    }
    
    /**
     * 카테고리 코드 유효성 검사
     */
    public boolean isValidCategory(String categoryCode) {
        return categoryCode != null && 
               (categoryCode.equals("free") || categoryCode.equals("question") || 
                categoryCode.equals("photo") || categoryCode.equals("data"));
    }
    
    /**
     * 검색 타입 유효성 검사
     */
    public boolean isValidSearchType(String searchType) {
        return searchType != null && 
               (searchType.equals("all") || searchType.equals("title") || 
                searchType.equals("content") || searchType.equals("author"));
    }


    // FreeBoardService.java에 추가할 메서드:

    /**
     * 🔥 관리자 권한으로 자유게시판 글 삭제 (교수용)
     * @param postId 게시글 ID
     * @return 성공시 true, 실패시 false
     */
    public boolean deletePostByAdmin(int postId) {
        if (!isDAOValid() || postId <= 0) {
            return false;
        }
        
        try {
            System.out.println("👨‍🏫 관리자 권한으로 자유게시판 글 삭제: " + postId);
            return freeBoardDAO.deletePostByAdmin(postId);
            
        } catch (Exception e) {
            System.err.println("❌ 관리자 자유게시판 글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 🔥 관리자 권한으로 댓글 삭제 (교수용)
     * @param commentId 댓글 ID
     * @return 성공시 true, 실패시 false
     */
    public boolean deleteCommentByAdmin(int commentId) {
        if (!isDAOValid() || commentId <= 0) {
            return false;
        }
        
        try {
            System.out.println("👨‍🏫 관리자 권한으로 댓글 삭제: " + commentId);
            return boardDAO.deleteCommentByAdmin(commentId);
            
        } catch (Exception e) {
            System.err.println("❌ 관리자 댓글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}