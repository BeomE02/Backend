package com.clink.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.service.ClassService;
import com.clink.model.dao.PollDAO;
import com.clink.model.dto.User;
import com.clink.model.dto.Class;
import com.clink.model.dto.Poll;

/**
 * ClassPollHandler - 투표 기능 처리 전담
 * 
 * 🎯 담당 기능:
 * - /class/poll/vote: 투표 참여
 * - /class/poll/create: 투표 생성 (교수만)
 * - /class/poll/list: 투표 목록 조회
 */
public class ClassPollHandler {
    
    private PollDAO pollDAO;
    private ClassService classService;
    
    /**
     * 생성자 - 의존성 주입
     */
    public ClassPollHandler(PollDAO pollDAO, ClassService classService) {
        this.pollDAO = pollDAO;
        this.classService = classService;
    }
    
    /**
     * 🎯 투표 요청 라우터
     */
    public void handlePollRequest(HttpServletRequest request, HttpServletResponse response, String command) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("loginUser");
        
        System.out.println("🗳️ 투표 요청: " + command + " (user: " + user.getRole() + ")");
        
        try {
            switch (command) {
                case "/class/poll/vote":
                    handleVotePoll(request, response, user);
                    break;
                    
                case "/class/poll/create":
                    handleCreatePoll(request, response, user);
                    break;
                    
                case "/class/poll/list":
                    handleGetPolls(request, response, user);
                    break;
                    
                default:
                    sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("💥 투표 요청 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🗳️ 투표 참여
     */
    private void handleVotePoll(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        System.out.println("🗳️ 투표 참여 요청: " + user.getName());
        
        try {
            String pollIdStr = request.getParameter("pollId");
            String optionIdStr = request.getParameter("optionId");
            
            if (pollIdStr == null || optionIdStr == null) {
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다.", null);
                return;
            }
            
            long pollId, optionId;
            try {
                pollId = Long.parseLong(pollIdStr);
                optionId = Long.parseLong(optionIdStr);
            } catch (NumberFormatException e) {
                sendJsonResponse(response, false, "잘못된 투표 정보입니다.", null);
                return;
            }
            
            // 투표 존재 확인
            Poll poll = pollDAO.getPollById(pollId);
            if (poll == null) {
                sendJsonResponse(response, false, "투표를 찾을 수 없습니다.", null);
                return;
            }
            
            // 투표 활성 상태 확인
            if (!poll.isActive()) {
                sendJsonResponse(response, false, "종료된 투표입니다.", null);
                return;
            }
            
            // 🔧 실제 DAO 메서드 사용: getUserSelectedOption으로 중복 확인
            Long existingVote = pollDAO.getUserSelectedOption(pollId, (long) user.getUserId());
            if (existingVote != null && !poll.isMultipleChoice()) {
                sendJsonResponse(response, false, "이미 투표에 참여했습니다.", null);
                return;
            }
            
            // 🔧 실제 DAO 메서드 사용: voteOnPoll
            boolean success = pollDAO.voteOnPoll(pollId, optionId, (long) user.getUserId());
            
            if (success) {
                System.out.println("✅ 투표 참여 성공: 투표ID " + pollId + ", 옵션ID " + optionId);
                
                // 업데이트된 투표 정보 다시 조회
                Poll updatedPoll = pollDAO.getPollById(pollId);
                int totalVotes = updatedPoll != null ? updatedPoll.getTotalVotes() : 0;
                
                sendJsonResponse(response, true, "투표에 참여했습니다.", "\"totalVotes\":" + totalVotes);
            } else {
                sendJsonResponse(response, false, "투표 참여에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 투표 참여 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "투표 참여 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🆕 투표 생성 (교수만)
     */
    private void handleCreatePoll(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        if (!"professor".equals(user.getRole())) {
            sendJsonResponse(response, false, "교수만 투표를 생성할 수 있습니다.", null);
            return;
        }
        
        System.out.println("🗳️ 투표 생성 요청: " + user.getName());
        
        try {
            String classCode = request.getParameter("classCode");
            String title = request.getParameter("pollTitle");
            String description = request.getParameter("pollDescription");
            String isMultipleStr = request.getParameter("isMultipleChoice");
            String isAnonymousStr = request.getParameter("isAnonymous");
            String[] options = request.getParameterValues("pollOptions");
            
            if (title == null || title.trim().isEmpty() || options == null || options.length < 2) {
                sendJsonResponse(response, false, "제목과 최소 2개의 선택지가 필요합니다.", null);
                return;
            }
            
            // 수업 정보 조회
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            // 권한 확인
            if (!classInfo.getProfessorId().equals((long) user.getUserId())) {
                sendJsonResponse(response, false, "투표 생성 권한이 없습니다.", null);
                return;
            }
            
            boolean isMultipleChoice = "true".equals(isMultipleStr);
            boolean isAnonymous = "true".equals(isAnonymousStr);
            
            // Poll 객체 생성
            Poll poll = new Poll();
            poll.setClassId(classInfo.getId());
            poll.setProfessorId((long) user.getUserId());
            poll.setTitle(title.trim());
            poll.setDescription(description != null ? description.trim() : "");
            poll.setMultipleChoice(isMultipleChoice);
            poll.setAnonymous(isAnonymous);
            poll.setActive(true);
            
            // 투표 옵션 설정
            java.util.List<Poll.PollOption> pollOptions = new java.util.ArrayList<>();
            for (int i = 0; i < options.length; i++) {
                if (options[i] != null && !options[i].trim().isEmpty()) {
                    Poll.PollOption option = new Poll.PollOption();
                    option.setOptionText(options[i].trim());
                    option.setOptionOrder(i + 1);
                    pollOptions.add(option);
                }
            }
            
            poll.setOptions(pollOptions);
            
            // 투표 생성 실행
            boolean success = pollDAO.createPoll(poll);
            
            if (success) {
                System.out.println("✅ 투표 생성 성공: " + title);
                sendJsonResponse(response, true, "투표가 생성되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "투표 생성에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 투표 생성 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "투표 생성 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 📋 투표 목록 조회
     */
    private void handleGetPolls(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        String classCode = request.getParameter("classCode");
        
        try {
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            List<Poll> polls = pollDAO.getPollsByClass(classInfo.getId());
            
            // JSON 응답 생성
            StringBuilder json = new StringBuilder();
            json.append("{");
            json.append("\"success\":true,");
            json.append("\"polls\":[");
            
            for (int i = 0; i < polls.size(); i++) {
                Poll p = polls.get(i);
                if (i > 0) json.append(",");
                
                json.append("{");
                json.append("\"id\":").append(p.getPollId()).append(",");
                json.append("\"title\":\"").append(escapeJson(p.getTitle())).append("\",");
                json.append("\"description\":\"").append(escapeJson(p.getDescription())).append("\",");
                json.append("\"isMultipleChoice\":").append(p.isMultipleChoice()).append(",");
                json.append("\"isAnonymous\":").append(p.isAnonymous()).append(",");
                json.append("\"isActive\":").append(p.isActive()).append(",");
                json.append("\"totalVotes\":").append(p.getTotalVotes());
                json.append("}");
            }
            
            json.append("]}");
            
            response.setContentType("application/json; charset=UTF-8");
            response.getWriter().write(json.toString());
            
            System.out.println("✅ 투표 목록 조회 완료: " + polls.size() + "개");
            
        } catch (Exception e) {
            System.err.println("💥 투표 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "투표 목록 조회 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * JSON 응답 전송
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, 
                                String message, String data) throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null && !data.isEmpty()) {
            if (data.startsWith("redirectUrl:")) {
                json.append(",\"redirectUrl\":\"").append(escapeJson(data.substring(12))).append("\"");
            } else {
                json.append(",\"data\":").append(data);
            }
        }
        
        json.append("}");
        
        PrintWriter out = response.getWriter();
        out.print(json.toString());
        out.flush();
        
        System.out.println("📤 투표 JSON 응답: " + (success ? "SUCCESS" : "ERROR") + " - " + message);
    }
    
    /**
     * JSON 문자열 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}