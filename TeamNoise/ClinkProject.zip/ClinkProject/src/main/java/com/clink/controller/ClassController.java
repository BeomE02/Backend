package com.clink.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.dao.ClassDAO;
import com.clink.model.dao.QuestionDAO;
import com.clink.model.dao.AssignmentDAO;
import com.clink.model.dao.PollDAO;
import com.clink.model.service.ClassService;
import com.clink.model.service.FileService;
import com.clink.model.dto.User;
import com.clink.model.dto.Class;
import com.clink.model.dto.Question;
import com.clink.model.dto.Assignment;
import com.clink.model.dto.Poll;
import com.clink.model.dto.FileInfo;

/**
 * ========================================
 * ClassController - 수업 관리 메인 컨트롤러
 * ========================================
 * 
 * 🎯 교수 수업 참여 완성 버전
 * 
 * 역할별 분할 구조:
 * - ClassController: 메인 라우터 + 초기화 (이 파일)
 * - ClassPageHandler: 페이지 요청 처리 (.do 요청)
 * - ClassAjaxHandler: AJAX 요청 처리 (/class/* API)
 * - ClassQuestionHandler: 질문/답변 처리
 * - ClassPollHandler: 투표 처리
 * - ClassAssignmentHandler: 과제 처리
 * 
 * 📡 URL 매핑:
 * - *.do → MainController에서 위임 (enterClass.do, classJoin.do 등)
 * - /class/* → 직접 처리 (AJAX API)
 */
public class ClassController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // ========================================
    // 🔧 서비스 및 DAO 인스턴스들
    // ========================================
    private ClassDAO classDAO;
    private ClassService classService;
    private QuestionDAO questionDAO;
    private AssignmentDAO assignmentDAO;
    private PollDAO pollDAO;
    private FileService fileService;
    
    // ========================================
    // 🎯 핸들러들 (분할된 기능)
    // ========================================
    private ClassPageHandler pageHandler;
    private ClassAjaxHandler ajaxHandler;
    private ClassQuestionHandler questionHandler;
    private ClassPollHandler pollHandler;
    private ClassAssignmentHandler assignmentHandler;

    /**
     * 🚀 초기화 - 모든 서비스/DAO/핸들러 생성
     */
    @Override
    public void init() throws ServletException {
        super.init();
        
        System.out.println("🚀 ClassController 초기화 시작...");
        
        try {
            // ========================================
            // 1️⃣ DAO/Service 계층 초기화
            // ========================================
            this.classDAO = new ClassDAO();
            this.classService = new ClassService();
            this.questionDAO = new QuestionDAO();
            this.assignmentDAO = new AssignmentDAO();
            this.pollDAO = new PollDAO();
            this.fileService = new FileService();
            
            System.out.println("✅ DAO/Service 계층 초기화 완료");
            
            // ========================================
            // 2️⃣ 핸들러 계층 초기화 (의존성 주입)
            // ========================================
            this.pageHandler = new ClassPageHandler(
                classService, questionDAO, assignmentDAO, pollDAO, fileService
            );
            
            this.ajaxHandler = new ClassAjaxHandler(classService);
            
            this.questionHandler = new ClassQuestionHandler(questionDAO, classService);
            
            this.pollHandler = new ClassPollHandler(pollDAO, classService);
            
            this.assignmentHandler = new ClassAssignmentHandler(assignmentDAO, classService);
            
            System.out.println("✅ 핸들러 계층 초기화 완료");
            
            // ========================================
            // 3️⃣ 초기화 완료 로그
            // ========================================
            System.out.println("========================================");
            System.out.println("🎉 ClassController 분할 버전 초기화 성공!");
            System.out.println("========================================");
            System.out.println("📋 구성 요소:");
            System.out.println("   - 메인 컨트롤러: 라우팅 담당");
            System.out.println("   - PageHandler: 페이지 요청 처리 (.do)");
            System.out.println("   - AjaxHandler: AJAX API 처리 (/class/*)");
            System.out.println("   - QuestionHandler: 질문/답변 처리");
            System.out.println("   - PollHandler: 투표 처리");
            System.out.println("   - AssignmentHandler: 과제 처리");
            System.out.println("========================================");
            
        } catch (Exception e) {
            System.err.println("❌ ClassController 초기화 실패!");
            System.err.println("🔥 오류 내용: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("ClassController 초기화 실패", e);
        }
    }

    /**
     * 📥 GET 요청 처리
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * 📤 POST 요청 처리
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * ========================================
     * 🎯 메인 요청 처리 라우터
     * ========================================
     * 
     * 모든 요청을 적절한 핸들러로 위임하는 핵심 메서드
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // ========================================
        // 1️⃣ 기본 설정
        // ========================================
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        // URL 명령어 추출
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String command = uri.substring(contextPath.length());
        
        System.out.println("========================================");
        System.out.println("🎯 ClassController 요청 수신");
        System.out.println("   - URI: " + uri);
        System.out.println("   - Command: " + command);
        System.out.println("   - Method: " + request.getMethod());
        System.out.println("========================================");

        try {
            // ========================================
            // 2️⃣ 로그인 체크
            // ========================================
            if (!checkLogin(request, response, command)) {
                return;
            }
            
            String viewPath = null;
            
            // ========================================
            // 3️⃣ 요청별 핸들러 위임
            // ========================================
            switch (command) {
                
                // 📄 페이지 요청들 → PageHandler
                case "/enterRoom.do":
                case "/enterClass.do":
                case "/classJoin.do":
                case "/classStatistics.do":
                case "/classArchive.do":
                    System.out.println("📄 페이지 요청 → PageHandler");
                    viewPath = pageHandler.handlePageRequest(request, response, command);
                    break;
                    
                // 🔧 수업 관리 AJAX → AjaxHandler
                case "/class/create":
                case "/class/update":
                case "/class/delete":
                case "/class/info":
                case "/class/join":
                case "/class/leave":
                    System.out.println("🔧 수업 관리 AJAX → AjaxHandler");
                    ajaxHandler.handleAjaxRequest(request, response, command);
                    return; // JSON 응답이므로 return
                    
                // 🗳️ 투표 관련 → PollHandler
                case "/class/poll/vote":
                case "/class/poll/create":
                case "/class/poll/list":
                    System.out.println("🗳️ 투표 요청 → PollHandler");
                    pollHandler.handlePollRequest(request, response, command);
                    return; // JSON 응답이므로 return
                    
                // 🙋‍♀️ 질문/답변 관련 → QuestionHandler
                case "/class/question/submit":
                case "/class/question/list":
                case "/class/question/vote":
                case "/class/question/answer":
                case "/class/question/delete":
                    System.out.println("🙋‍♀️ 질문/답변 요청 → QuestionHandler");
                    questionHandler.handleQuestionRequest(request, response, command);
                    return; // JSON 응답이므로 return
                    
                // 📝 과제 관련 → AssignmentHandler
                case "/class/assignment/create":
                case "/class/assignment/list":
                case "/class/assignment/submit":
                    System.out.println("📝 과제 요청 → AssignmentHandler");
                    assignmentHandler.handleAssignmentRequest(request, response, command);
                    return; // JSON 응답이므로 return
                    
                // 📁 파일 관련 (간단 처리)
                case "/class/files":
                    System.out.println("📁 파일 요청 → 직접 처리");
                    handleGetFiles(request, response);
                    return; // JSON 응답이므로 return
                    
                // ❓ 알 수 없는 요청
                default:
                    System.out.println("⚠️ 알 수 없는 명령어: " + command);
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "요청한 리소스를 찾을 수 없습니다.");
                    return;
            }
            
            // ========================================
            // 4️⃣ 뷰로 포워딩 (페이지 요청인 경우)
            // ========================================
            if (viewPath != null && !response.isCommitted()) {
                System.out.println("📄 JSP 포워딩: " + viewPath);
                request.getRequestDispatcher(viewPath).forward(request, response);
            } else if (viewPath == null) {
                System.out.println("⚠️ viewPath가 null입니다. 처리되지 않은 요청일 수 있습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("💥 ClassController 처리 중 예외 발생!");
            System.err.println("🔥 오류 내용: " + e.getMessage());
            e.printStackTrace();
            
            // AJAX 요청인지 페이지 요청인지에 따라 다른 오류 처리
            if (isAjaxRequest(request)) {
                sendJsonError(response, "서버 오류가 발생했습니다.");
            } else {
                request.setAttribute("errorMessage", "처리 중 오류가 발생했습니다.");
                request.getRequestDispatcher("/WEB-INF/views/error/error.jsp").forward(request, response);
            }
        }
    }
    
    /**
     * ========================================
     * 📁 파일 목록 조회 (간단 처리)
     * ========================================
     */
    private void handleGetFiles(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        String classCode = request.getParameter("classCode");
        System.out.println("📁 파일 목록 조회 요청: " + classCode);
        
        try {
            // 수업 정보 조회
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonError(response, "존재하지 않는 수업입니다.");
                return;
            }
            
            // 파일 목록 조회
            List<FileInfo> files = fileService.getFilesByClass(classInfo.getId());
            
            // JSON 응답 생성
            StringBuilder json = new StringBuilder();
            json.append("{\"success\":true,\"files\":[");
            
            for (int i = 0; i < files.size(); i++) {
                FileInfo f = files.get(i);
                if (i > 0) json.append(",");
                
                json.append("{");
                json.append("\"id\":").append(f.getAttachmentId()).append(",");
                json.append("\"filename\":\"").append(escapeJson(f.getOriginalFilename())).append("\",");
                json.append("\"fileSize\":").append(f.getFileSize()).append(",");
                json.append("\"fileType\":\"").append(escapeJson(f.getFileType())).append("\"");
                json.append("}");
            }
            
            json.append("]}");
            
            // 응답 전송
            response.setContentType("application/json; charset=UTF-8");
            response.getWriter().write(json.toString());
            
            System.out.println("✅ 파일 목록 조회 완료: " + files.size() + "개");
            
        } catch (Exception e) {
            System.err.println("💥 파일 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonError(response, "파일 목록 조회 중 오류가 발생했습니다.");
        }
    }

    // ========================================
    // 🛠️ 헬퍼 메서드들
    // ========================================

    /**
     * 🔐 로그인 체크
     */
    private boolean checkLogin(HttpServletRequest request, HttpServletResponse response, String command) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("loginUser");
        
        if (user == null) {
            System.out.println("⚠️ 로그인되지 않은 사용자 접근 시도: " + command);
            
            if (isAjaxRequest(request)) {
                sendJsonError(response, "로그인이 필요합니다.");
            } else {
                response.sendRedirect(request.getContextPath() + "/login.do");
            }
            return false;
        }
        
        System.out.println("✅ 로그인 확인: " + user.getName() + " (" + user.getRole() + ")");
        return true;
    }
    
    /**
     * 🔍 AJAX 요청인지 확인
     */
    private boolean isAjaxRequest(HttpServletRequest request) {
        String xRequestedWith = request.getHeader("X-Requested-With");
        String contentType = request.getContentType();
        String uri = request.getRequestURI();
        
        boolean isAjax = "XMLHttpRequest".equals(xRequestedWith) || 
                        (contentType != null && contentType.contains("application/json")) ||
                        uri.contains("/class/"); // /class/* 경로는 모두 AJAX 요청으로 간주
        
        System.out.println("🔍 AJAX 요청 확인: " + isAjax + " (URI: " + uri + ")");
        return isAjax;
    }
    
    /**
     * 📤 JSON 성공 응답 전송
     */
    private void sendJsonSuccess(HttpServletResponse response, String message, String data) throws IOException {
        sendJsonResponse(response, true, message, data);
    }
    
    /**
     * 📤 JSON 오류 응답 전송
     */
    private void sendJsonError(HttpServletResponse response, String message) throws IOException {
        sendJsonResponse(response, false, message, null);
    }
    
    /**
     * 📤 JSON 응답 전송 (공통)
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, 
                                String message, String data) throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null && !data.isEmpty()) {
            if (data.startsWith("redirectUrl:")) {
                json.append(",\"redirectUrl\":\"").append(escapeJson(data.substring(12))).append("\"");
            } else {
                json.append(",\"data\":").append(data);
            }
        }
        
        json.append("}");
        
        PrintWriter out = response.getWriter();
        out.print(json.toString());
        out.flush();
        
        String statusText = success ? "SUCCESS" : "ERROR";
        System.out.println("📤 JSON 응답 전송: " + statusText + " - " + message);
    }
    
    /**
     * 🛡️ JSON 문자열 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
    
    /**
     * 🗑️ 리소스 정리
     */
    @Override
    public void destroy() {
        System.out.println("🗑️ ClassController 리소스 정리 시작...");
        
        // 각 핸들러들이 리소스를 가지고 있다면 정리
        // (현재는 특별한 리소스 정리가 필요하지 않음)
        
        System.out.println("✅ ClassController 리소스 정리 완료");
        super.destroy();
    }
}