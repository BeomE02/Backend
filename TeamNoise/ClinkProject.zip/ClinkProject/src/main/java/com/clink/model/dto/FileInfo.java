package com.clink.model.dto;

import java.time.LocalDateTime;
import java.sql.Timestamp;

/**
 * 파일 정보 DTO 클래스 - 완전한 버전 (모든 호환성 포함)
 * FileController, FileDAO, FileService, ClassController, BoardController와 완전 호환
 * attachments 테이블과 정확히 매핑 + 추가 정보 필드 포함
 * 
 * 🚀 최신화 내용:
 * - 기존 메서드명 모두 유지 (호환성)
 * - ClassController용 추가 필드 (postTitle, uploaderName 등)
 * - 완전한 getter/setter 메서드
 * - 한글 파일명 완전 지원
 */
public class FileInfo {
    
    // ===== 기본 속성 (attachments 테이블과 매핑) =====
    private Integer attachmentId;          // attachment_id (Primary Key)
    private Integer postId;                // post_id (Foreign Key, nullable)
    private String originalName;           // original_filename (한글 지원)
    private String savedName;              // stored_filename (서버 저장명)
    private String filePath;               // file_path (전체 경로)
    private Long fileSize;                 // file_size (바이트)
    private String fileType;               // file_type (확장자)
    private String mimeType;               // mime_type (MIME 타입)
    private Integer downloadCount;         // download_count (다운로드 횟수)
    private LocalDateTime uploadDate;      // uploaded_at을 LocalDateTime으로 변환
    
    // ===== 추가 속성 (비즈니스 로직용) =====
    private String status;                 // 파일 상태 (active, deleted 등)
    private String description;            // 파일 설명 (또는 게시글 제목)
    
    // ===== 조인 결과용 추가 정보 (ClassController, BoardController용) =====
    private String uploaderName;           // 업로더 이름 (users 테이블 조인)
    private String uploaderRole;           // 업로더 역할 (users.role)
    private Integer uploaderId;            // 업로더 ID (posts.author_id)
    private String className;              // 수업 이름 (classes 테이블 조인)
    private Integer classId;               // 수업 ID (posts.class_id)
    private String postTitle;              // 게시글 제목 (posts.title)

    /**
     * 기본 생성자
     */
    public FileInfo() {
        this.downloadCount = 0;
        this.status = "active";
        this.uploadDate = LocalDateTime.now();
    }
    
    /**
     * 필수 정보 생성자 (파일 업로드용)
     */
    public FileInfo(String originalName, String savedName, String filePath, 
                   Long fileSize, String fileType) {
        this();
        this.originalName = originalName;
        this.savedName = savedName;
        this.filePath = filePath;
        this.fileSize = fileSize;
        this.fileType = fileType;
        this.mimeType = determineMimeType(fileType);
    }
    
    // ========================================
    // 🔥 기본 필드 Getter/Setter (모든 호환성 보장)
    // ========================================
    
    /**
     * 파일 ID (Primary Key) - 다양한 호환성 메서드
     */
    public Integer getId() {
        return attachmentId;
    }
    
    public void setId(Integer id) {
        this.attachmentId = id;
    }
    
    public Integer getAttachmentId() {
        return attachmentId;
    }
    
    public void setAttachmentId(Integer attachmentId) {
        this.attachmentId = attachmentId;
    }
    
    /**
     * 게시글 ID
     */
    public Integer getPostId() {
        return postId;
    }
    
    public void setPostId(Integer postId) {
        this.postId = postId;
    }
    
    /**
     * 원본 파일명 - 다양한 호환성 메서드
     */
    public String getOriginalName() {
        return originalName;
    }
    
    public void setOriginalName(String originalName) {
        this.originalName = originalName;
    }
    
    public String getOriginalFilename() {
        return originalName;
    }
    
    public void setOriginalFilename(String originalFilename) {
        this.originalName = originalFilename;
    }
    
    /**
     * 저장된 파일명 - 다양한 호환성 메서드
     */
    public String getSavedName() {
        return savedName;
    }
    
    public void setSavedName(String savedName) {
        this.savedName = savedName;
    }
    
    public String getStoredFilename() {
        return savedName;
    }
    
    public void setStoredFilename(String storedFilename) {
        this.savedName = storedFilename;
    }
    
    /**
     * 파일 저장 경로
     */
    public String getFilePath() {
        return filePath;
    }
    
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    /**
     * 파일 크기 (바이트)
     */
    public Long getFileSize() {
        return fileSize;
    }
    
    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }
    
    /**
     * 파일 확장자
     */
    public String getFileType() {
        return fileType;
    }
    
    public void setFileType(String fileType) {
        this.fileType = fileType;
        // 파일 타입이 설정되면 MIME 타입도 자동 업데이트
        if (this.mimeType == null) {
            this.mimeType = determineMimeType(fileType);
        }
    }
    
    /**
     * MIME 타입
     */
    public String getMimeType() {
        if (mimeType == null && fileType != null) {
            mimeType = determineMimeType(fileType);
        }
        return mimeType;
    }
    
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }
    
    /**
     * 다운로드 횟수
     */
    public Integer getDownloadCount() {
        return downloadCount;
    }
    
    public void setDownloadCount(Integer downloadCount) {
        this.downloadCount = downloadCount;
    }
    
    /**
     * 업로드 일시 (LocalDateTime)
     */
    public LocalDateTime getUploadDate() {
        return uploadDate;
    }
    
    public void setUploadDate(LocalDateTime uploadDate) {
        this.uploadDate = uploadDate;
    }
    
    /**
     * 업로드 일시 (Timestamp) - FileController 호환성
     */
    public Timestamp getUploadedAt() {
        if (uploadDate != null) {
            return Timestamp.valueOf(uploadDate);
        }
        return null;
    }
    
    public void setUploadedAt(Timestamp uploadedAt) {
        if (uploadedAt != null) {
            this.uploadDate = uploadedAt.toLocalDateTime();
        }
    }
    
    // ========================================
    // 🔥 추가 정보 필드 Getter/Setter
    // ========================================
    
    /**
     * 파일 상태
     */
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * 파일 설명 (또는 게시글 제목)
     */
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    /**
     * 업로더 이름 (조인 결과)
     */
    public String getUploaderName() {
        return uploaderName;
    }
    
    public void setUploaderName(String uploaderName) {
        this.uploaderName = uploaderName;
    }
    
    /**
     * 업로더 역할 (조인 결과)
     */
    public String getUploaderRole() {
        return uploaderRole;
    }
    
    public void setUploaderRole(String uploaderRole) {
        this.uploaderRole = uploaderRole;
    }
    
    /**
     * 업로더 ID (조인 결과)
     */
    public Integer getUploaderId() {
        return uploaderId;
    }
    
    public void setUploaderId(Integer uploaderId) {
        this.uploaderId = uploaderId;
    }
    
    /**
     * 수업 이름 (조인 결과)
     */
    public String getClassName() {
        return className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }
    
    /**
     * 수업 ID
     */
    public Integer getClassId() {
        return classId;
    }
    
    public void setClassId(Integer classId) {
        this.classId = classId;
    }
    
    /**
     * 게시글 제목 (조인 결과)
     */
    public String getPostTitle() {
        return postTitle;
    }
    
    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }
    
    // ========================================
    // 🔥 유틸리티 메서드
    // ========================================
    
    /**
     * 파일 크기를 사람이 읽기 쉬운 형태로 반환
     */
    public String getFormattedFileSize() {
        if (fileSize == null || fileSize <= 0) {
            return "0 B";
        }
        
        final String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unitIndex = 0;
        double size = fileSize.doubleValue();
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return String.format("%.1f %s", size, units[unitIndex]);
    }
    
    /**
     * 파일 확장자 추출
     */
    public String getFileExtension() {
        if (originalName == null || !originalName.contains(".")) {
            return "";
        }
        return originalName.substring(originalName.lastIndexOf(".") + 1).toLowerCase();
    }
    
    /**
     * 확장자 제외한 파일명 추출
     */
    public String getFilenameWithoutExtension() {
        if (originalName == null || !originalName.contains(".")) {
            return originalName;
        }
        return originalName.substring(0, originalName.lastIndexOf("."));
    }
    
    /**
     * 이미지 파일인지 확인
     */
    public boolean isImage() {
        if (fileType == null) return false;
        String type = fileType.toLowerCase();
        return type.equals("jpg") || type.equals("jpeg") || type.equals("png") || 
               type.equals("gif") || type.equals("bmp") || type.equals("webp");
    }
    
    /**
     * 이미지 파일인지 확인 (호환성)
     */
    public boolean isImageFile() {
        return isImage();
    }
    
    /**
     * 문서 파일인지 확인
     */
    public boolean isDocument() {
        if (fileType == null) return false;
        String type = fileType.toLowerCase();
        return type.equals("pdf") || type.equals("doc") || type.equals("docx") || 
               type.equals("ppt") || type.equals("pptx") || type.equals("xls") || 
               type.equals("xlsx") || type.equals("hwp") || type.equals("txt");
    }
    
    /**
     * 문서 파일인지 확인 (호환성)
     */
    public boolean isDocumentFile() {
        return isDocument();
    }
    
    /**
     * 압축파일인지 확인
     */
    public boolean isArchive() {
        if (fileType == null) return false;
        String type = fileType.toLowerCase();
        return type.equals("zip") || type.equals("rar") || type.equals("7z") || 
               type.equals("tar") || type.equals("gz");
    }
    
    /**
     * 압축파일인지 확인 (호환성)
     */
    public boolean isArchiveFile() {
        return isArchive();
    }
    
    /**
     * 파일 타입에 따른 CSS 클래스 반환 (UI용)
     */
    public String getFileTypeClass() {
        if (isImage()) return "file-image";
        if (isDocument()) return "file-document";
        if (isArchive()) return "file-archive";
        return "file-other";
    }
    
    /**
     * 파일 타입 아이콘 CSS 클래스 반환 (ClassController용)
     */
    public String getFileIconClass() {
        if (isImageFile()) {
            return "file-icon-image";
        } else if (isDocumentFile()) {
            String extension = getFileExtension().toLowerCase();
            switch (extension) {
                case "pdf": return "file-icon-pdf";
                case "doc":
                case "docx": return "file-icon-word";
                case "ppt":
                case "pptx": return "file-icon-powerpoint";
                case "xls":
                case "xlsx": return "file-icon-excel";
                case "hwp": return "file-icon-hwp";
                default: return "file-icon-document";
            }
        } else if (isArchiveFile()) {
            return "file-icon-archive";
        } else {
            return "file-icon-default";
        }
    }
    
    /**
     * 파일 타입에 따른 아이콘 이름 반환 (UI용)
     */
    public String getFileIcon() {
        if (fileType == null) return "file-o";
        
        String type = fileType.toLowerCase();
        switch (type) {
            case "pdf": return "file-pdf-o";
            case "doc": case "docx": return "file-word-o";
            case "ppt": case "pptx": return "file-powerpoint-o";
            case "xls": case "xlsx": return "file-excel-o";
            case "jpg": case "jpeg": case "png": case "gif": return "file-image-o";
            case "zip": case "rar": case "7z": return "file-archive-o";
            case "txt": return "file-text-o";
            case "hwp": return "file-o";
            default: return "file-o";
        }
    }
    
    /**
     * 업로더 정보 요약 (역할 포함)
     */
    public String getUploaderInfo() {
        if (uploaderName == null) {
            return "알 수 없음";
        }
        
        String name = uploaderName;
        String role = "";
        
        if ("professor".equals(uploaderRole)) {
            role = " (교수)";
        } else if ("student".equals(uploaderRole)) {
            role = " (학생)";
        }
        
        return name + role;
    }
    
    /**
     * 업로드 시간 포맷팅
     */
    public String getFormattedUploadTime() {
        if (uploadDate == null) {
            return "";
        }
        
        java.time.format.DateTimeFormatter formatter = 
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return uploadDate.format(formatter);
    }
    
    /**
     * 파일 다운로드 URL 생성
     */
    public String getDownloadUrl() {
        if (attachmentId == null) {
            return "#";
        }
        return "/file/download/" + attachmentId;
    }
    
    /**
     * 파일 정보 요약 (디버깅용)
     */
    public String getSummary() {
        return String.format("FileInfo{id=%d, filename='%s', size=%s, type='%s', uploader='%s'}",
                           attachmentId, originalName, getFormattedFileSize(), 
                           fileType, getUploaderInfo());
    }
    
    /**
     * 유효한 파일 정보인지 확인
     */
    public boolean isValid() {
        return originalName != null && !originalName.trim().isEmpty() &&
               savedName != null && !savedName.trim().isEmpty() &&
               filePath != null && !filePath.trim().isEmpty() &&
               fileSize != null && fileSize > 0;
    }
    
    /**
     * 파일 확장자를 기반으로 MIME 타입 결정
     */
    private String determineMimeType(String fileType) {
        if (fileType == null) return "application/octet-stream";
        
        String type = fileType.toLowerCase();
        switch (type) {
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "ppt": return "application/vnd.ms-powerpoint";
            case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "hwp": return "application/x-hwp";
            case "zip": return "application/zip";
            case "rar": return "application/x-rar-compressed";
            case "7z": return "application/x-7z-compressed";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "bmp": return "image/bmp";
            case "webp": return "image/webp";
            case "txt": return "text/plain";
            case "html": return "text/html";
            case "css": return "text/css";
            case "js": return "application/javascript";
            case "json": return "application/json";
            case "xml": return "application/xml";
            default: return "application/octet-stream";
        }
    }
    
    // ========================================
    // Object 메서드 오버라이드
    // ========================================
    
    @Override
    public String toString() {
        return "FileInfo{" +
                "attachmentId=" + attachmentId +
                ", postId=" + postId +
                ", originalName='" + originalName + '\'' +
                ", savedName='" + savedName + '\'' +
                ", fileSize=" + fileSize +
                ", fileType='" + fileType + '\'' +
                ", downloadCount=" + downloadCount +
                ", uploadDate=" + uploadDate +
                ", uploaderName='" + uploaderName + '\'' +
                ", postTitle='" + postTitle + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        FileInfo fileInfo = (FileInfo) obj;
        return attachmentId != null ? attachmentId.equals(fileInfo.attachmentId) : fileInfo.attachmentId == null;
    }
    
    @Override
    public int hashCode() {
        return attachmentId != null ? attachmentId.hashCode() : 0;
    }
}