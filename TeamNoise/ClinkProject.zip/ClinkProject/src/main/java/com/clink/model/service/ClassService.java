package com.clink.model.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.ArrayList;

import com.clink.model.dao.ClassDAO;
import com.clink.model.dto.Class;

/**
 * ClassService - 수업 관리 서비스 (완성 버전)
 * 
 * 🎯 담당 기능:
 * - 수업 생성/수정/삭제 (교수)
 * - 수업 목록 조회 (교수/학생별)
 * - 수업 참여/탈퇴 (학생)
 * - 수업 정보 조회 및 검증
 * - 수업 코드 관리
 * - 수업 상태 관리 및 자동 업데이트
 */
public class ClassService {
    
    private ClassDAO classDAO;
    
    /**
     * 생성자
     */
    public ClassService() {
        try {
            this.classDAO = new ClassDAO();
            System.out.println("✅ ClassService 초기화 성공");
        } catch (Exception e) {
            System.err.println("❌ ClassService 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            this.classDAO = null;
        }
    }
    
    /**
     * DAO 유효성 체크
     */
    private boolean isDAOValid() {
        if (classDAO == null) {
            System.err.println("❌ ClassDAO가 초기화되지 않았습니다.");
            return false;
        }
        return true;
    }
    
    /**
     * 🆕 수업 생성
     */
    public boolean createClass(String className, String description, Long professorId, 
                              String startDate, String endDate, String startTime, String endTime,
                              String classDays, String maxStudentsStr) {
        
        System.out.println("🆕 수업 생성 요청: " + className + " (교수 ID: " + professorId + ")");
        
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            // 입력값 검증
            if (!validateClassInput(className, startDate, endDate, startTime, endTime, classDays)) {
                return false;
            }
            
            if (professorId == null || professorId <= 0) {
                System.out.println("❌ 수업 생성 실패: 유효하지 않은 교수 ID");
                return false;
            }
            
            // 최대 학생 수 파싱
            int maxStudents = 50; // 기본값
            if (maxStudentsStr != null && !maxStudentsStr.trim().isEmpty()) {
                try {
                    maxStudents = Integer.parseInt(maxStudentsStr.trim());
                    if (maxStudents < 1 || maxStudents > 200) {
                        System.out.println("❌ 수업 생성 실패: 최대 학생 수는 1~200명 사이여야 합니다.");
                        return false;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("❌ 수업 생성 실패: 최대 학생 수는 숫자여야 합니다.");
                    return false;
                }
            }
            
            // Class 객체 생성
            Class newClass = new Class();
            newClass.setClassName(className.trim());
            newClass.setDescription(description != null ? description.trim() : "");
            newClass.setProfessorId(professorId);
            newClass.setStartDate(LocalDate.parse(startDate));
            newClass.setEndDate(LocalDate.parse(endDate));
            newClass.setStartTime(LocalTime.parse(startTime));
            newClass.setEndTime(LocalTime.parse(endTime));
            newClass.setClassDays(classDays.trim());
            newClass.setMaxStudents(maxStudents);
            newClass.setStatus("scheduled");
            
            // 수업 상태 자동 설정
            updateClassStatus(newClass);
            
            // 데이터베이스에 저장
            boolean result = classDAO.createClass(newClass);
            
            if (result) {
                System.out.println("✅ 수업 생성 성공: " + className + " (코드: " + newClass.getClassCode() + ")");
            } else {
                System.out.println("❌ 수업 생성 실패: 데이터베이스 저장 오류");
            }
            
            return result;
            
        } catch (DateTimeParseException e) {
            System.out.println("❌ 수업 생성 실패: 날짜/시간 형식이 올바르지 않습니다. (" + e.getMessage() + ")");
            return false;
        } catch (Exception e) {
            System.err.println("❌ 수업 생성 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ✏️ 수업 정보 수정
     */
    public boolean updateClass(Long classId, Long professorId, String className, String description,
                              String startDate, String endDate, String startTime, String endTime,
                              String classDays, String maxStudentsStr, String status) {
        
        System.out.println("✏️ 수업 수정 요청: ID " + classId + " (교수 ID: " + professorId + ")");
        
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            // 기존 수업 조회
            Class existingClass = classDAO.getClassById(classId);
            if (existingClass == null) {
                System.out.println("❌ 수업 수정 실패: 존재하지 않는 수업입니다.");
                return false;
            }
            
            // 권한 확인
            if (!existingClass.getProfessorId().equals(professorId)) {
                System.out.println("❌ 수업 수정 실패: 수정 권한이 없습니다.");
                return false;
            }
            
            // 입력값 검증
            if (!validateClassInput(className, startDate, endDate, startTime, endTime, classDays)) {
                return false;
            }
            
            // 최대 학생 수 파싱
            int maxStudents = existingClass.getMaxStudents();
            if (maxStudentsStr != null && !maxStudentsStr.trim().isEmpty()) {
                try {
                    maxStudents = Integer.parseInt(maxStudentsStr.trim());
                    if (maxStudents < 1 || maxStudents > 200) {
                        System.out.println("❌ 수업 수정 실패: 최대 학생 수는 1~200명 사이여야 합니다.");
                        return false;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("❌ 수업 수정 실패: 최대 학생 수는 숫자여야 합니다.");
                    return false;
                }
            }
            
            // 현재 참여 학생 수 확인
            int currentStudents = classDAO.getEnrolledStudentCount(classId);
            if (maxStudents < currentStudents) {
                System.out.println("❌ 수업 수정 실패: 최대 학생 수는 현재 참여 학생 수(" + currentStudents + "명)보다 적을 수 없습니다.");
                return false;
            }
            
            // 수업 정보 업데이트
            existingClass.setClassName(className.trim());
            existingClass.setDescription(description != null ? description.trim() : "");
            existingClass.setStartDate(LocalDate.parse(startDate));
            existingClass.setEndDate(LocalDate.parse(endDate));
            existingClass.setStartTime(LocalTime.parse(startTime));
            existingClass.setEndTime(LocalTime.parse(endTime));
            existingClass.setClassDays(classDays.trim());
            existingClass.setMaxStudents(maxStudents);
            
            // 상태 업데이트 (제공된 경우)
            if (status != null && !status.trim().isEmpty()) {
                existingClass.setStatus(status.trim());
            } else {
                // 자동 상태 업데이트
                updateClassStatus(existingClass);
            }
            
            // 데이터베이스 업데이트
            boolean result = classDAO.updateClass(existingClass);
            
            if (result) {
                System.out.println("✅ 수업 수정 성공: " + className);
            } else {
                System.out.println("❌ 수업 수정 실패: 데이터베이스 업데이트 오류");
            }
            
            return result;
            
        } catch (DateTimeParseException e) {
            System.out.println("❌ 수업 수정 실패: 날짜/시간 형식이 올바르지 않습니다. (" + e.getMessage() + ")");
            return false;
        } catch (Exception e) {
            System.err.println("❌ 수업 수정 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 🗑️ 수업 삭제
     */
    public boolean deleteClass(Long classId, Long professorId) {
        System.out.println("🗑️ 수업 삭제 요청: ID " + classId + " (교수 ID: " + professorId + ")");
        
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            // 기존 수업 조회
            Class existingClass = classDAO.getClassById(classId);
            if (existingClass == null) {
                System.out.println("❌ 수업 삭제 실패: 존재하지 않는 수업입니다.");
                return false;
            }
            
            // 권한 확인
            if (!existingClass.getProfessorId().equals(professorId)) {
                System.out.println("❌ 수업 삭제 실패: 삭제 권한이 없습니다.");
                return false;
            }
            
            // 진행 중인 수업 삭제 방지
            if ("active".equals(existingClass.getStatus())) {
                System.out.println("❌ 수업 삭제 실패: 진행 중인 수업은 삭제할 수 없습니다.");
                return false;
            }
            
            // 참여 학생이 있는 경우 확인
            int enrolledCount = classDAO.getEnrolledStudentCount(classId);
            if (enrolledCount > 0) {
                System.out.println("⚠️ 참여 학생이 있는 수업 삭제: " + enrolledCount + "명의 학생이 참여 중입니다.");
                // 필요시 여기서 추가 확인 로직 구현
            }
            
            // 데이터베이스에서 삭제
            boolean result = classDAO.deleteClass(classId);
            
            if (result) {
                System.out.println("✅ 수업 삭제 성공: " + existingClass.getClassName());
            } else {
                System.out.println("❌ 수업 삭제 실패: 데이터베이스 삭제 오류");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 수업 삭제 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 🔍 수업 코드로 수업 조회
     */
    public Class getClassByCode(String classCode) {
        if (!isDAOValid()) {
            return null;
        }
        
        if (classCode == null || classCode.trim().isEmpty()) {
            System.out.println("❌ 수업 조회 실패: 수업 코드가 비어있습니다.");
            return null;
        }
        
        try {
            Class classInfo = classDAO.getClassByCode(classCode.trim().toUpperCase());
            
            if (classInfo != null) {
                // 수업 상태 자동 업데이트
                updateClassStatus(classInfo);
                System.out.println("✅ 수업 조회 성공: " + classInfo.getClassName() + " (코드: " + classCode + ")");
            } else {
                System.out.println("⚠️ 수업을 찾을 수 없음: 코드 " + classCode);
            }
            
            return classInfo;
            
        } catch (Exception e) {
            System.err.println("❌ 수업 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 🔍 수업 ID로 수업 조회
     */
    public Class getClassById(Long classId) {
        if (!isDAOValid()) {
            return null;
        }
        
        if (classId == null || classId <= 0) {
            System.out.println("❌ 수업 조회 실패: 유효하지 않은 수업 ID");
            return null;
        }
        
        try {
            Class classInfo = classDAO.getClassById(classId);
            
            if (classInfo != null) {
                // 수업 상태 자동 업데이트
                updateClassStatus(classInfo);
                System.out.println("✅ 수업 조회 성공: " + classInfo.getClassName() + " (ID: " + classId + ")");
            } else {
                System.out.println("⚠️ 수업을 찾을 수 없음: ID " + classId);
            }
            
            return classInfo;
            
        } catch (Exception e) {
            System.err.println("❌ 수업 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 📋 교수의 수업 목록 조회
     */
    public List<Class> getProfessorClasses(Long professorId, String status) {
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        if (professorId == null || professorId <= 0) {
            System.out.println("❌ 교수 수업 목록 조회 실패: 유효하지 않은 교수 ID");
            return new ArrayList<>();
        }
        
        try {
            List<Class> classList = classDAO.getClassesByProfessor(professorId, status);
            
            // 수업 상태 자동 업데이트
            updateClassStatuses(classList);
            
            System.out.println("✅ 교수 수업 목록 조회 성공: " + classList.size() + "개 (교수 ID: " + professorId + ", 상태: " + status + ")");
            return classList;
            
        } catch (Exception e) {
            System.err.println("❌ 교수 수업 목록 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 📋 학생의 수업 목록 조회
     */
    public List<Class> getStudentClasses(Long studentId, String status) {
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        if (studentId == null || studentId <= 0) {
            System.out.println("❌ 학생 수업 목록 조회 실패: 유효하지 않은 학생 ID");
            return new ArrayList<>();
        }
        
        try {
            List<Class> classList = classDAO.getStudentClasses(studentId, status);
            
            // 수업 상태 자동 업데이트
            updateClassStatuses(classList);
            
            System.out.println("✅ 학생 수업 목록 조회 성공: " + classList.size() + "개 (학생 ID: " + studentId + ", 상태: " + status + ")");
            return classList;
            
        } catch (Exception e) {
            System.err.println("❌ 학생 수업 목록 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 🔗 수업 참여 (학생)
     */
    public boolean joinClass(String classCode, Long studentId) {
        if (!isDAOValid()) {
            return false;
        }
        
        System.out.println("🔗 수업 참여 요청: 코드 " + classCode + " (학생 ID: " + studentId + ")");
        
        try {
            // 입력값 검증
            if (classCode == null || classCode.trim().isEmpty()) {
                System.out.println("❌ 수업 참여 실패: 수업 코드를 입력해주세요.");
                return false;
            }
            
            if (studentId == null || studentId <= 0) {
                System.out.println("❌ 수업 참여 실패: 유효하지 않은 학생 ID");
                return false;
            }
            
            // 수업 존재 여부 확인
            Class classInfo = getClassByCode(classCode);
            if (classInfo == null) {
                System.out.println("❌ 수업 참여 실패: 존재하지 않는 수업 코드입니다.");
                return false;
            }
            
            // 참여 가능 여부 확인
            if (!canJoinClass(classInfo)) {
                System.out.println("❌ 수업 참여 실패: 참여할 수 없는 수업입니다. (상태: " + classInfo.getStatusKorean() + ")");
                return false;
            }
            
            // 이미 참여 중인지 확인
            if (classDAO.isStudentEnrolled(classInfo.getId(), studentId)) {
                System.out.println("❌ 수업 참여 실패: 이미 참여 중인 수업입니다.");
                return false;
            }
            
            // 인원 제한 확인
            int currentStudents = classDAO.getEnrolledStudentCount(classInfo.getId());
            if (currentStudents >= classInfo.getMaxStudents()) {
                System.out.println("❌ 수업 참여 실패: 수업 정원이 가득 찼습니다. (" + currentStudents + "/" + classInfo.getMaxStudents() + ")");
                return false;
            }
            
            // 수업 참여 처리
            boolean result = classDAO.enrollStudent(classCode.trim().toUpperCase(), studentId);
            
            if (result) {
                System.out.println("✅ 수업 참여 성공: " + classInfo.getClassName() + " (코드: " + classCode + ")");
            } else {
                System.out.println("❌ 수업 참여 실패: 데이터베이스 처리 오류");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 수업 참여 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 🚪 수업 탈퇴 (학생)
     */
    public boolean leaveClass(Long classId, Long studentId) {
        if (!isDAOValid()) {
            return false;
        }
        
        System.out.println("🚪 수업 탈퇴 요청: 수업 ID " + classId + " (학생 ID: " + studentId + ")");
        
        try {
            // 입력값 검증
            if (classId == null || classId <= 0 || studentId == null || studentId <= 0) {
                System.out.println("❌ 수업 탈퇴 실패: 유효하지 않은 ID입니다.");
                return false;
            }
            
            // 수업 존재 여부 확인
            Class classInfo = getClassById(classId);
            if (classInfo == null) {
                System.out.println("❌ 수업 탈퇴 실패: 존재하지 않는 수업입니다.");
                return false;
            }
            
            // 참여 중인지 확인
            if (!classDAO.isStudentEnrolled(classId, studentId)) {
                System.out.println("❌ 수업 탈퇴 실패: 참여하지 않은 수업입니다.");
                return false;
            }
            
            // 진행 중인 수업 탈퇴 제한 (필요시)
            if ("active".equals(classInfo.getStatus())) {
                System.out.println("⚠️ 진행 중인 수업 탈퇴: " + classInfo.getClassName());
                // 필요시 여기서 추가 제한 로직 구현
            }
            
            // 수업 탈퇴 처리
            boolean result = classDAO.unenrollStudent(classId, studentId);
            
            if (result) {
                System.out.println("✅ 수업 탈퇴 성공: " + classInfo.getClassName());
            } else {
                System.out.println("❌ 수업 탈퇴 실패: 데이터베이스 처리 오류");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 수업 탈퇴 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // ========================================
    // 🛠️ 헬퍼 메서드들
    // ========================================
    
    /**
     * 수업 입력값 검증
     */
    private boolean validateClassInput(String className, String startDate, String endDate,
                                     String startTime, String endTime, String classDays) {
        
        // 수업명 검증
        if (className == null || className.trim().isEmpty()) {
            System.out.println("❌ 입력값 검증 실패: 수업명을 입력해주세요.");
            return false;
        }
        
        if (className.trim().length() > 200) {
            System.out.println("❌ 입력값 검증 실패: 수업명은 200자 이내로 입력해주세요.");
            return false;
        }
        
        // 날짜 검증
        if (startDate == null || startDate.trim().isEmpty() ||
            endDate == null || endDate.trim().isEmpty()) {
            System.out.println("❌ 입력값 검증 실패: 시작일과 종료일을 입력해주세요.");
            return false;
        }
        
        try {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            
            if (end.isBefore(start)) {
                System.out.println("❌ 입력값 검증 실패: 종료일은 시작일보다 늦어야 합니다.");
                return false;
            }
            
            if (start.isBefore(LocalDate.now().minusDays(1))) {
                System.out.println("❌ 입력값 검증 실패: 시작일은 과거일 수 없습니다.");
                return false;
            }
            
        } catch (DateTimeParseException e) {
            System.out.println("❌ 입력값 검증 실패: 날짜 형식이 올바르지 않습니다. (YYYY-MM-DD)");
            return false;
        }
        
        // 시간 검증
        if (startTime == null || startTime.trim().isEmpty() ||
            endTime == null || endTime.trim().isEmpty()) {
            System.out.println("❌ 입력값 검증 실패: 시작 시간과 종료 시간을 입력해주세요.");
            return false;
        }
        
        try {
            LocalTime start = LocalTime.parse(startTime);
            LocalTime end = LocalTime.parse(endTime);
            
            if (end.isBefore(start) || end.equals(start)) {
                System.out.println("❌ 입력값 검증 실패: 종료 시간은 시작 시간보다 늦어야 합니다.");
                return false;
            }
            
        } catch (DateTimeParseException e) {
            System.out.println("❌ 입력값 검증 실패: 시간 형식이 올바르지 않습니다. (HH:MM)");
            return false;
        }
        
        // 수업 요일 검증
        if (classDays == null || classDays.trim().isEmpty()) {
            System.out.println("❌ 입력값 검증 실패: 수업 요일을 입력해주세요.");
            return false;
        }
        
        return true;
    }
    
    /**
     * 수업 상태 자동 업데이트 (단일)
     */
    private void updateClassStatus(Class classInfo) {
        if (classInfo == null) return;
        
        LocalDate now = LocalDate.now();
        LocalDate startDate = classInfo.getStartDate();
        LocalDate endDate = classInfo.getEndDate();
        
        if (now.isBefore(startDate)) {
            classInfo.setStatus("scheduled");
        } else if (now.isAfter(endDate)) {
            classInfo.setStatus("ended");
        } else {
            classInfo.setStatus("active");
        }
    }
    
    /**
     * 수업 상태 자동 업데이트 (목록)
     */
    private void updateClassStatuses(List<Class> classList) {
        if (classList != null) {
            for (Class classInfo : classList) {
                updateClassStatus(classInfo);
            }
        }
    }
    
    /**
     * 수업 참여 가능 여부 확인
     */
    private boolean canJoinClass(Class classInfo) {
        if (classInfo == null) return false;
        
        // 종료된 수업은 참여 불가
        if ("ended".equals(classInfo.getStatus())) {
            return false;
        }
        
        // 정원 확인
        int currentStudents = classDAO.getEnrolledStudentCount(classInfo.getId());
        if (currentStudents >= classInfo.getMaxStudents()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 서비스 상태 체크
     */
    public boolean isServiceHealthy() {
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            // 간단한 테스트로 DAO 상태 확인
            return true;
        } catch (Exception e) {
            System.err.println("❌ ClassService 상태 체크 실패: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 수업 통계 정보 조회
     */
    public int getTotalClassCount(Long professorId) {
        if (!isDAOValid() || professorId == null || professorId <= 0) {
            return 0;
        }
        
        try {
            return classDAO.getClassCountByProfessor(professorId);
        } catch (Exception e) {
            System.err.println("❌ 수업 통계 조회 실패: " + e.getMessage());
            return 0;
        }
    }
    
    /**
     * 활성 수업 수 조회
     */
    public int getActiveClassCount(Long professorId) {
        if (!isDAOValid() || professorId == null || professorId <= 0) {
            return 0;
        }
        
        try {
            List<Class> activeClasses = getProfessorClasses(professorId, "active");
            return activeClasses.size();
        } catch (Exception e) {
            System.err.println("❌ 활성 수업 수 조회 실패: " + e.getMessage());
            return 0;
        }
    }
}