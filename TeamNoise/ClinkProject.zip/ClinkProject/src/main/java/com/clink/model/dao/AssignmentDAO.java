package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Assignment;
import com.clink.util.DBConnection;

/**
 * AssignmentDAO - 과제 데이터 접근 객체 (완성 버전)
 * 
 * 📋 연동 테이블:
 * - assignments: 과제 정보
 * - assignment_submissions: 과제 제출
 * - users: 사용자 정보 (JOIN)
 * - classes: 수업 정보 (JOIN)
 */
public class AssignmentDAO {
    
    /**
     * 🔍 수업별 과제 목록 조회 (상세 정보 포함)
     */
    public List<Assignment> getAssignmentsByClass(Long classId) {
        List<Assignment> assignments = new ArrayList<>();
        
        String sql = "SELECT a.assignment_id, a.class_id, a.title, a.description, " +
                    "a.due_date, a.max_score, a.is_active, a.created_at, a.updated_at, " +
                    "c.class_name, c.class_code, u.name as professor_name, " +
                    "COUNT(s.submission_id) as submission_count, " +
                    "COUNT(e.student_id) as total_students " +
                    "FROM assignments a " +
                    "LEFT JOIN classes c ON a.class_id = c.class_id " +
                    "LEFT JOIN users u ON c.professor_id = u.user_id " +
                    "LEFT JOIN assignment_submissions s ON a.assignment_id = s.assignment_id " +
                    "LEFT JOIN class_enrollments e ON a.class_id = e.class_id AND e.is_active = TRUE " +
                    "WHERE a.class_id = ? " +
                    "GROUP BY a.assignment_id, a.class_id, a.title, a.description, " +
                    "a.due_date, a.max_score, a.is_active, a.created_at, a.updated_at, " +
                    "c.class_name, c.class_code, u.name " +
                    "ORDER BY a.due_date ASC, a.created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Assignment assignment = mapResultSetToAssignment(rs);
                    assignments.add(assignment);
                }
            }
            
            System.out.println("✅ 수업별 과제 목록 조회 성공: " + assignments.size() + "개 (수업 ID: " + classId + ")");
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 과제 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return assignments;
    }
    
    /**
     * 🔍 과제 ID로 조회
     */
    public Assignment getAssignmentById(Long assignmentId) {
        String sql = "SELECT a.assignment_id, a.class_id, a.title, a.description, " +
                    "a.due_date, a.max_score, a.is_active, a.created_at, a.updated_at, " +
                    "c.class_name, c.class_code, u.name as professor_name, " +
                    "COUNT(s.submission_id) as submission_count, " +
                    "COUNT(e.student_id) as total_students " +
                    "FROM assignments a " +
                    "LEFT JOIN classes c ON a.class_id = c.class_id " +
                    "LEFT JOIN users u ON c.professor_id = u.user_id " +
                    "LEFT JOIN assignment_submissions s ON a.assignment_id = s.assignment_id " +
                    "LEFT JOIN class_enrollments e ON a.class_id = e.class_id AND e.is_active = TRUE " +
                    "WHERE a.assignment_id = ? " +
                    "GROUP BY a.assignment_id, a.class_id, a.title, a.description, " +
                    "a.due_date, a.max_score, a.is_active, a.created_at, a.updated_at, " +
                    "c.class_name, c.class_code, u.name";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, assignmentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Assignment assignment = mapResultSetToAssignment(rs);
                    System.out.println("✅ 과제 조회 성공: ID " + assignmentId);
                    return assignment;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 조회 실패 (ID: " + assignmentId + "): " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("⚠️ 과제를 찾을 수 없음: ID " + assignmentId);
        return null;
    }
    
    /**
     * 🆕 과제 생성
     */
    public boolean createAssignment(Assignment assignment) {
        String sql = "INSERT INTO assignments (class_id, title, description, due_date, max_score, is_active, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setLong(1, assignment.getClassId());
            pstmt.setString(2, assignment.getTitle());
            pstmt.setString(3, assignment.getDescription());
            pstmt.setTimestamp(4, assignment.getDueDate());
            pstmt.setInt(5, assignment.getMaxScore());
            pstmt.setBoolean(6, assignment.isActive());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                // 생성된 ID 설정
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        assignment.setAssignmentId(rs.getLong(1));
                    }
                }
                
                System.out.println("✅ 과제 생성 성공: ID " + assignment.getAssignmentId() + " (" + assignment.getTitle() + ")");
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 생성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * ✏️ 과제 수정
     */
    public boolean updateAssignment(Assignment assignment) {
        String sql = "UPDATE assignments SET title = ?, description = ?, due_date = ?, " +
                    "max_score = ?, is_active = ?, updated_at = NOW() " +
                    "WHERE assignment_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, assignment.getTitle());
            pstmt.setString(2, assignment.getDescription());
            pstmt.setTimestamp(3, assignment.getDueDate());
            pstmt.setInt(4, assignment.getMaxScore());
            pstmt.setBoolean(5, assignment.isActive());
            pstmt.setLong(6, assignment.getAssignmentId());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 과제 수정 성공: ID " + assignment.getAssignmentId());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🗑️ 과제 삭제
     */
    public boolean deleteAssignment(Long assignmentId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 관련 제출물 먼저 삭제
                String deleteSubmissionsSql = "DELETE FROM assignment_submissions WHERE assignment_id = ?";
                try (PreparedStatement deleteSubmissionsStmt = conn.prepareStatement(deleteSubmissionsSql)) {
                    deleteSubmissionsStmt.setLong(1, assignmentId);
                    deleteSubmissionsStmt.executeUpdate();
                }
                
                // 과제 삭제
                String deleteAssignmentSql = "DELETE FROM assignments WHERE assignment_id = ?";
                try (PreparedStatement deleteStmt = conn.prepareStatement(deleteAssignmentSql)) {
                    deleteStmt.setLong(1, assignmentId);
                    int result = deleteStmt.executeUpdate();
                    
                    if (result > 0) {
                        conn.commit();
                        System.out.println("✅ 과제 삭제 성공: ID " + assignmentId);
                        return true;
                    }
                }
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 📝 과제 제출
     */
    public boolean submitAssignment(Long assignmentId, Long studentId, String submissionText) {
        return submitAssignment(assignmentId, studentId, submissionText, null);
    }
    
    /**
     * 📝 과제 제출 (파일 경로 포함)
     */
    public boolean submitAssignment(Long assignmentId, Long studentId, String submissionText, String filePath) {
        // 기존 제출물이 있는지 확인
        if (hasSubmission(assignmentId, studentId)) {
            // 기존 제출물 업데이트
            return updateSubmission(assignmentId, studentId, submissionText, filePath);
        } else {
            // 새 제출물 생성
            return createSubmission(assignmentId, studentId, submissionText, filePath);
        }
    }
    
    /**
     * 🔍 제출 여부 확인
     */
    public boolean hasSubmission(Long assignmentId, Long studentId) {
        String sql = "SELECT 1 FROM assignment_submissions WHERE assignment_id = ? AND student_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, assignmentId);
            pstmt.setLong(2, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 제출 여부 확인 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🆕 새 제출물 생성
     */
    private boolean createSubmission(Long assignmentId, Long studentId, String submissionText, String filePath) {
        String sql = "INSERT INTO assignment_submissions (assignment_id, student_id, submission_text, file_path, submitted_at, status) " +
                    "VALUES (?, ?, ?, ?, NOW(), ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, assignmentId);
            pstmt.setLong(2, studentId);
            pstmt.setString(3, submissionText);
            pstmt.setString(4, filePath);
            
            // 마감일 확인하여 상태 설정
            Assignment assignment = getAssignmentById(assignmentId);
            boolean isLate = assignment != null && assignment.getDueDate() != null && 
                           assignment.getDueDate().before(new Timestamp(System.currentTimeMillis()));
            pstmt.setString(5, isLate ? "late" : "submitted");
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 과제 제출 성공: 과제 ID " + assignmentId + ", 학생 ID " + studentId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 제출 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * ✏️ 기존 제출물 업데이트
     */
    private boolean updateSubmission(Long assignmentId, Long studentId, String submissionText, String filePath) {
        String sql = "UPDATE assignment_submissions SET submission_text = ?, file_path = ?, submitted_at = NOW(), status = ? " +
                    "WHERE assignment_id = ? AND student_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, submissionText);
            pstmt.setString(2, filePath);
            
            // 마감일 확인하여 상태 설정
            Assignment assignment = getAssignmentById(assignmentId);
            boolean isLate = assignment != null && assignment.getDueDate() != null && 
                           assignment.getDueDate().before(new Timestamp(System.currentTimeMillis()));
            pstmt.setString(3, isLate ? "late" : "submitted");
            
            pstmt.setLong(4, assignmentId);
            pstmt.setLong(5, studentId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 과제 재제출 성공: 과제 ID " + assignmentId + ", 학생 ID " + studentId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 재제출 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 📊 과제 채점
     */
    public boolean gradeAssignment(Long assignmentId, Long studentId, Integer score, String feedback) {
        String sql = "UPDATE assignment_submissions SET score = ?, feedback = ?, graded_at = NOW(), status = 'graded' " +
                    "WHERE assignment_id = ? AND student_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, score);
            pstmt.setString(2, feedback);
            pstmt.setLong(3, assignmentId);
            pstmt.setLong(4, studentId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 과제 채점 성공: 과제 ID " + assignmentId + ", 학생 ID " + studentId + ", 점수: " + score);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 과제 채점 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔍 학생의 특정 과제 제출물 조회
     */
    public Assignment getStudentSubmission(Long assignmentId, Long studentId) {
        String sql = "SELECT a.assignment_id, a.class_id, a.title, a.description, " +
                    "a.due_date, a.max_score, a.is_active, a.created_at, a.updated_at, " +
                    "c.class_name, c.class_code, u.name as professor_name, " +
                    "s.submission_text, s.file_path, s.score, s.feedback, s.submitted_at, s.graded_at, s.status " +
                    "FROM assignments a " +
                    "LEFT JOIN classes c ON a.class_id = c.class_id " +
                    "LEFT JOIN users u ON c.professor_id = u.user_id " +
                    "LEFT JOIN assignment_submissions s ON a.assignment_id = s.assignment_id AND s.student_id = ? " +
                    "WHERE a.assignment_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, studentId);
            pstmt.setLong(2, assignmentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Assignment assignment = mapResultSetToAssignment(rs);
                    
                    // 제출 정보 설정
                    if (rs.getString("submission_text") != null) {
                        assignment.setSubmitted(true);
                        assignment.setUserScore(rs.getInt("score"));
                        if (rs.wasNull()) {
                            assignment.setUserScore(null);
                        }
                        assignment.setUserFeedback(rs.getString("feedback"));
                    }
                    
                    return assignment;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 학생 제출물 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * 📊 수업별 과제 수 조회
     */
    public int getAssignmentCountByClass(Long classId) {
        String sql = "SELECT COUNT(*) FROM assignments WHERE class_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 과제 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    /**
     * 📊 마감된 과제 수 조회
     */
    public int getOverdueAssignmentCountByClass(Long classId) {
        String sql = "SELECT COUNT(*) FROM assignments WHERE class_id = ? AND is_active = TRUE AND due_date < NOW()";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 마감된 과제 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🛠️ 헬퍼 메서드들
    // ========================================
    
    /**
     * ResultSet을 Assignment 객체로 매핑
     */
    private Assignment mapResultSetToAssignment(ResultSet rs) throws SQLException {
        Assignment assignment = new Assignment();
        
        // 기본 필드
        assignment.setAssignmentId(rs.getLong("assignment_id"));
        assignment.setClassId(rs.getLong("class_id"));
        assignment.setTitle(rs.getString("title"));
        assignment.setDescription(rs.getString("description"));
        assignment.setDueDate(rs.getTimestamp("due_date"));
        assignment.setMaxScore(rs.getInt("max_score"));
        assignment.setActive(rs.getBoolean("is_active"));
        assignment.setCreatedAt(rs.getTimestamp("created_at"));
        assignment.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        // 추가 정보
        assignment.setClassName(rs.getString("class_name"));
        assignment.setClassCode(rs.getString("class_code"));
        assignment.setProfessorName(rs.getString("professor_name"));
        assignment.setSubmissionCount(rs.getInt("submission_count"));
        assignment.setTotalStudents(rs.getInt("total_students"));
        
        // 마감일 상태 업데이트
        if (assignment.getDueDate() != null) {
            assignment.setOverdue(assignment.getDueDate().before(new Timestamp(System.currentTimeMillis())));
        }
        
        return assignment;
    }
}