package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Class;
import com.clink.util.DBConnection;

/**
 * ClassDAO - 수업 데이터 접근 객체 (완성 버전)
 * 
 * 📋 연동 테이블:
 * - classes: 수업 정보
 * - class_enrollments: 수업 참여 정보
 * - users: 사용자 정보 (JOIN)
 * 
 * 🎯 주요 기능:
 * - 수업 CRUD (생성/조회/수정/삭제)
 * - 수업 참여 관리 (등록/탈퇴)
 * - 교수/학생별 수업 목록 조회
 * - 수업 코드 자동 생성
 * - 참여 학생 수 통계
 */
public class ClassDAO {
    
    /**
     * 🆕 새 수업 생성
     */
    public boolean createClass(Class classInfo) {
        String sql = "INSERT INTO classes (class_code, class_name, description, professor_id, " +
                    "start_date, end_date, start_time, end_time, class_days, " +
                    "max_students, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection()) {
            
            // 고유한 수업 코드 생성
            String classCode = generateUniqueClassCode(conn);
            classInfo.setClassCode(classCode);
            
            try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, classInfo.getClassCode());
                pstmt.setString(2, classInfo.getClassName());
                pstmt.setString(3, classInfo.getDescription());
                pstmt.setLong(4, classInfo.getProfessorId());
                pstmt.setDate(5, Date.valueOf(classInfo.getStartDate()));
                pstmt.setDate(6, Date.valueOf(classInfo.getEndDate()));
                pstmt.setTime(7, Time.valueOf(classInfo.getStartTime()));
                pstmt.setTime(8, Time.valueOf(classInfo.getEndTime()));
                pstmt.setString(9, classInfo.getClassDays());
                pstmt.setInt(10, classInfo.getMaxStudents());
                pstmt.setString(11, classInfo.getStatus());
                
                int result = pstmt.executeUpdate();
                
                if (result > 0) {
                    try (ResultSet rs = pstmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            classInfo.setId(rs.getLong(1));
                        }
                    }
                    
                    System.out.println("✅ 수업 생성 성공: " + classInfo.getClassName() + " (코드: " + classCode + ")");
                    return true;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 생성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * ✏️ 수업 정보 수정
     */
    public boolean updateClass(Class classInfo) {
        String sql = "UPDATE classes SET class_name = ?, description = ?, " +
                    "start_date = ?, end_date = ?, start_time = ?, end_time = ?, " +
                    "class_days = ?, max_students = ?, status = ?, updated_at = NOW() " +
                    "WHERE class_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, classInfo.getClassName());
            pstmt.setString(2, classInfo.getDescription());
            pstmt.setDate(3, Date.valueOf(classInfo.getStartDate()));
            pstmt.setDate(4, Date.valueOf(classInfo.getEndDate()));
            pstmt.setTime(5, Time.valueOf(classInfo.getStartTime()));
            pstmt.setTime(6, Time.valueOf(classInfo.getEndTime()));
            pstmt.setString(7, classInfo.getClassDays());
            pstmt.setInt(8, classInfo.getMaxStudents());
            pstmt.setString(9, classInfo.getStatus());
            pstmt.setLong(10, classInfo.getId());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 수업 수정 성공: " + classInfo.getClassName());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🗑️ 수업 삭제
     */
    public boolean deleteClass(Long classId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 관련 데이터 먼저 삭제 (외래키 제약조건 고려)
                // 1. 수업 참여 정보 삭제
                String deleteEnrollmentsSql = "DELETE FROM class_enrollments WHERE class_id = ?";
                try (PreparedStatement deleteEnrollmentsStmt = conn.prepareStatement(deleteEnrollmentsSql)) {
                    deleteEnrollmentsStmt.setLong(1, classId);
                    deleteEnrollmentsStmt.executeUpdate();
                }
                
                // 2. 수업 관련 게시글 삭제 (posts 테이블)
                String deletePostsSql = "DELETE FROM posts WHERE class_id = ?";
                try (PreparedStatement deletePostsStmt = conn.prepareStatement(deletePostsSql)) {
                    deletePostsStmt.setLong(1, classId);
                    deletePostsStmt.executeUpdate();
                }
                
                // 3. 수업 관련 질문 삭제 (questions 테이블)
                String deleteQuestionsSql = "DELETE FROM questions WHERE class_id = ?";
                try (PreparedStatement deleteQuestionsStmt = conn.prepareStatement(deleteQuestionsSql)) {
                    deleteQuestionsStmt.setLong(1, classId);
                    deleteQuestionsStmt.executeUpdate();
                }
                
                // 4. 수업 관련 과제 삭제 (assignments 테이블)
                String deleteAssignmentsSql = "DELETE FROM assignments WHERE class_id = ?";
                try (PreparedStatement deleteAssignmentsStmt = conn.prepareStatement(deleteAssignmentsSql)) {
                    deleteAssignmentsStmt.setLong(1, classId);
                    deleteAssignmentsStmt.executeUpdate();
                }
                
                // 5. 수업 관련 투표 삭제 (polls 테이블)
                String deletePollsSql = "DELETE FROM polls WHERE class_id = ?";
                try (PreparedStatement deletePollsStmt = conn.prepareStatement(deletePollsSql)) {
                    deletePollsStmt.setLong(1, classId);
                    deletePollsStmt.executeUpdate();
                }
                
                // 6. 마지막으로 수업 삭제
                String deleteClassSql = "DELETE FROM classes WHERE class_id = ?";
                try (PreparedStatement deleteClassStmt = conn.prepareStatement(deleteClassSql)) {
                    deleteClassStmt.setLong(1, classId);
                    int result = deleteClassStmt.executeUpdate();
                    
                    if (result > 0) {
                        conn.commit();
                        System.out.println("✅ 수업 삭제 성공: ID " + classId);
                        return true;
                    }
                }
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔍 수업 ID로 조회
     */
    public Class getClassById(Long classId) {
        String sql = "SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, " +
                    "c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, " +
                    "c.max_students, c.status, c.created_at, c.updated_at, " +
                    "u.name as professor_name, " +
                    "(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students " +
                    "FROM classes c " +
                    "LEFT JOIN users u ON c.professor_id = u.user_id " +
                    "WHERE c.class_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("✅ 수업 ID 조회 성공: " + classId);
                    return mapResultSetToClass(rs);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 ID 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("⚠️ 수업을 찾을 수 없음: ID " + classId);
        return null;
    }
    
    /**
     * 🔍 수업 코드로 조회
     */
    public Class getClassByCode(String classCode) {
        String sql = "SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, " +
                    "c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, " +
                    "c.max_students, c.status, c.created_at, c.updated_at, " +
                    "u.name as professor_name, " +
                    "(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students " +
                    "FROM classes c " +
                    "LEFT JOIN users u ON c.professor_id = u.user_id " +
                    "WHERE c.class_code = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, classCode.toUpperCase());
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("✅ 수업 코드 조회 성공: " + classCode);
                    return mapResultSetToClass(rs);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 코드 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("⚠️ 수업을 찾을 수 없음: 코드 " + classCode);
        return null;
    }
    
    /**
     * 📋 교수의 수업 목록 조회
     */
    public List<Class> getClassesByProfessor(Long professorId, String status) {
        List<Class> classList = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, ");
        sql.append("c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, ");
        sql.append("c.max_students, c.status, c.created_at, c.updated_at, ");
        sql.append("u.name as professor_name, ");
        sql.append("(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students ");
        sql.append("FROM classes c ");
        sql.append("LEFT JOIN users u ON c.professor_id = u.user_id ");
        sql.append("WHERE c.professor_id = ? ");
        
        if (status != null && !status.isEmpty() && !"all".equals(status)) {
            sql.append("AND c.status = ? ");
        }
        
        sql.append("ORDER BY c.created_at DESC");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setLong(1, professorId);
            
            if (status != null && !status.isEmpty() && !"all".equals(status)) {
                pstmt.setString(2, status);
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Class classInfo = mapResultSetToClass(rs);
                    classList.add(classInfo);
                }
            }
            
            System.out.println("✅ 교수 수업 목록 조회 성공: " + classList.size() + "개 (교수 ID: " + professorId + ", 상태: " + status + ")");
            
        } catch (SQLException e) {
            System.err.println("❌ 교수 수업 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return classList;
    }
    
    /**
     * 📋 학생이 참여한 수업 목록 조회
     */
    public List<Class> getStudentClasses(Long studentId, String status) {
        List<Class> classList = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, ");
        sql.append("c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, ");
        sql.append("c.max_students, c.status, c.created_at, c.updated_at, ");
        sql.append("u.name as professor_name, ce.enrolled_at, ");
        sql.append("(SELECT COUNT(*) FROM class_enrollments ce2 WHERE ce2.class_id = c.class_id AND ce2.is_active = TRUE) as current_students ");
        sql.append("FROM classes c ");
        sql.append("LEFT JOIN users u ON c.professor_id = u.user_id ");
        sql.append("JOIN class_enrollments ce ON c.class_id = ce.class_id ");
        sql.append("WHERE ce.student_id = ? AND ce.is_active = TRUE ");
        
        if (status != null && !status.isEmpty() && !"all".equals(status)) {
            sql.append("AND c.status = ? ");
        }
        
        sql.append("ORDER BY ce.enrolled_at DESC");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setLong(1, studentId);
            
            if (status != null && !status.isEmpty() && !"all".equals(status)) {
                pstmt.setString(2, status);
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Class classInfo = mapResultSetToClass(rs);
                    classList.add(classInfo);
                }
            }
            
            System.out.println("✅ 학생 수업 목록 조회 성공: " + classList.size() + "개 (학생 ID: " + studentId + ", 상태: " + status + ")");
            
        } catch (SQLException e) {
            System.err.println("❌ 학생 수업 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return classList;
    }
    
    /**
     * 🔗 수업 참여 (학생 등록)
     */
    public boolean enrollStudent(String classCode, Long studentId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 수업 정보 조회
                Class classInfo = getClassByCodeInternal(classCode, conn);
                if (classInfo == null) {
                    System.out.println("❌ 수업 참여 실패: 존재하지 않는 수업 코드");
                    return false;
                }
                
                // 이미 등록된 학생인지 확인
                if (isStudentEnrolledInternal(classInfo.getId(), studentId, conn)) {
                    System.out.println("❌ 수업 참여 실패: 이미 참여 중인 수업");
                    return false;
                }
                
                // 수업 정원 확인
                int currentStudents = getEnrolledStudentCountInternal(classInfo.getId(), conn);
                if (currentStudents >= classInfo.getMaxStudents()) {
                    System.out.println("❌ 수업 참여 실패: 수업 정원 초과 (" + currentStudents + "/" + classInfo.getMaxStudents() + ")");
                    return false;
                }
                
                // 학생 등록
                String enrollSql = "INSERT INTO class_enrollments (class_id, student_id, enrolled_at, is_active) VALUES (?, ?, NOW(), TRUE)";
                try (PreparedStatement enrollStmt = conn.prepareStatement(enrollSql)) {
                    enrollStmt.setLong(1, classInfo.getId());
                    enrollStmt.setLong(2, studentId);
                    
                    int result = enrollStmt.executeUpdate();
                    if (result > 0) {
                        conn.commit();
                        System.out.println("✅ 수업 참여 성공: " + classInfo.getClassName() + " (학생 ID: " + studentId + ")");
                        return true;
                    }
                }
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 참여 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🚪 수업 탈퇴 (학생 등록 해제)
     */
    public boolean unenrollStudent(Long classId, Long studentId) {
        String sql = "UPDATE class_enrollments SET is_active = FALSE WHERE class_id = ? AND student_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            pstmt.setLong(2, studentId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 수업 탈퇴 성공: 수업 ID " + classId + ", 학생 ID " + studentId);
                return true;
            } else {
                System.out.println("⚠️ 수업 탈퇴 실패: 참여하지 않은 수업이거나 이미 탈퇴한 수업");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업 탈퇴 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔍 학생이 특정 수업에 참여 중인지 확인
     */
    public boolean isStudentEnrolled(Long classId, Long studentId) {
        String sql = "SELECT 1 FROM class_enrollments WHERE class_id = ? AND student_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            pstmt.setLong(2, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 학생 등록 확인 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 📊 수업별 참여 학생 수 조회
     */
    public int getEnrolledStudentCount(Long classId) {
        String sql = "SELECT COUNT(*) FROM class_enrollments WHERE class_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 참여 학생 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    /**
     * 📊 교수별 수업 수 조회
     */
    public int getClassCountByProfessor(Long professorId) {
        String sql = "SELECT COUNT(*) FROM classes WHERE professor_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, professorId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 교수별 수업 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🛠️ 헬퍼 메서드들
    // ========================================
    
    /**
     * 고유한 수업 코드 생성 (3글자 + 3숫자 형식)
     */
    private String generateUniqueClassCode(Connection conn) throws SQLException {
        String classCode;
        String checkSql = "SELECT COUNT(*) FROM classes WHERE class_code = ?";
        
        do {
            // ABC123 형식으로 생성
            classCode = generateRandomLetters(3) + generateRandomNumbers(3);
            
            try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setString(1, classCode);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    rs.next();
                    int count = rs.getInt(1);
                    
                    if (count == 0) {
                        break;
                    }
                }
            }
        } while (true);
        
        return classCode;
    }
    
    /**
     * 랜덤 영문자 생성
     */
    private String generateRandomLetters(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = (char) ('A' + (int) (Math.random() * 26));
            sb.append(c);
        }
        return sb.toString();
    }
    
    /**
     * 랜덤 숫자 생성
     */
    private String generateRandomNumbers(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int n = (int) (Math.random() * 10);
            sb.append(n);
        }
        return sb.toString();
    }
    
    /**
     * Connection을 포함한 수업 정보 조회 (내부용)
     */
    private Class getClassByCodeInternal(String classCode, Connection conn) throws SQLException {
        String sql = "SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, " +
                    "c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, " +
                    "c.max_students, c.status, c.created_at, c.updated_at, " +
                    "u.name as professor_name, " +
                    "(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students " +
                    "FROM classes c " +
                    "LEFT JOIN users u ON c.professor_id = u.user_id " +
                    "WHERE c.class_code = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, classCode.toUpperCase());
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToClass(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * 학생 등록 여부 확인 (내부용)
     */
    private boolean isStudentEnrolledInternal(Long classId, Long studentId, Connection conn) throws SQLException {
        String sql = "SELECT 1 FROM class_enrollments WHERE class_id = ? AND student_id = ? AND is_active = TRUE";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, classId);
            pstmt.setLong(2, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }
    
    /**
     * 참여 학생 수 조회 (내부용)
     */
    private int getEnrolledStudentCountInternal(Long classId, Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM class_enrollments WHERE class_id = ? AND is_active = TRUE";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        
        return 0;
    }
    
    /**
     * ResultSet을 Class 객체로 매핑
     */
    private Class mapResultSetToClass(ResultSet rs) throws SQLException {
        Class classInfo = new Class();
        
        // 기본 필드
        classInfo.setId(rs.getLong("class_id"));
        classInfo.setClassCode(rs.getString("class_code"));
        classInfo.setClassName(rs.getString("class_name"));
        classInfo.setDescription(rs.getString("description"));
        classInfo.setProfessorId(rs.getLong("professor_id"));
        
        // 날짜/시간 필드
        Date startDate = rs.getDate("start_date");
        if (startDate != null) {
            classInfo.setStartDate(startDate.toLocalDate());
        }
        
        Date endDate = rs.getDate("end_date");
        if (endDate != null) {
            classInfo.setEndDate(endDate.toLocalDate());
        }
        
        Time startTime = rs.getTime("start_time");
        if (startTime != null) {
            classInfo.setStartTime(startTime.toLocalTime());
        }
        
        Time endTime = rs.getTime("end_time");
        if (endTime != null) {
            classInfo.setEndTime(endTime.toLocalTime());
        }
        
        classInfo.setClassDays(rs.getString("class_days"));
        classInfo.setMaxStudents(rs.getInt("max_students"));
        classInfo.setStatus(rs.getString("status"));
        
        // 타임스탬프 필드
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            classInfo.setCreatedAt(createdAt);
        }
        
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) {
            classInfo.setUpdatedAt(updatedAt);
        }
        
        // 추가 정보
        classInfo.setProfessorName(rs.getString("professor_name"));
        classInfo.setCurrentStudents(rs.getInt("current_students"));
        
        return classInfo;
    }
}