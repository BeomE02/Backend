package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Poll;
import com.clink.model.dto.Poll.PollOption;
import com.clink.util.DBConnection;

/**
 * PollDAO - 투표 데이터 접근 객체 (완성 버전)
 * 
 * 📋 연동 테이블:
 * - polls: 투표 정보
 * - poll_options: 투표 선택지
 * - poll_responses: 투표 응답
 * - users: 사용자 정보 (JOIN)
 * - classes: 수업 정보 (JOIN)
 */
public class PollDAO {
    
    /**
     * 🔍 수업별 투표 목록 조회 (상세 정보 포함)
     */
    public List<Poll> getPollsByClass(Long classId) {
        List<Poll> polls = new ArrayList<>();
        
        String sql = "SELECT p.poll_id, p.class_id, p.professor_id, p.title, p.description, " +
                    "p.is_multiple_choice, p.is_anonymous, p.is_active, p.created_at, p.expires_at, " +
                    "c.class_name, c.class_code, u.name as professor_name " +
                    "FROM polls p " +
                    "LEFT JOIN classes c ON p.class_id = c.class_id " +
                    "LEFT JOIN users u ON p.professor_id = u.user_id " +
                    "WHERE p.class_id = ? " +
                    "ORDER BY p.created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Poll poll = mapResultSetToPoll(rs);
                    
                    // 투표 옵션들 조회
                    List<PollOption> options = getPollOptions(poll.getPollId());
                    poll.setOptions(options);
                    
                    // 총 투표 수 계산
                    int totalVotes = options.stream().mapToInt(PollOption::getVoteCount).sum();
                    poll.setTotalVotes(totalVotes);
                    
                    // 각 옵션별 비율 계산
                    for (PollOption option : options) {
                        option.calculatePercentage(totalVotes);
                    }
                    
                    polls.add(poll);
                }
            }
            
            System.out.println("✅ 수업별 투표 목록 조회 성공: " + polls.size() + "개 (수업 ID: " + classId + ")");
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 투표 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return polls;
    }
    
    /**
     * 🔍 투표 ID로 조회
     */
    public Poll getPollById(Long pollId) {
        String sql = "SELECT p.poll_id, p.class_id, p.professor_id, p.title, p.description, " +
                    "p.is_multiple_choice, p.is_anonymous, p.is_active, p.created_at, p.expires_at, " +
                    "c.class_name, c.class_code, u.name as professor_name " +
                    "FROM polls p " +
                    "LEFT JOIN classes c ON p.class_id = c.class_id " +
                    "LEFT JOIN users u ON p.professor_id = u.user_id " +
                    "WHERE p.poll_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, pollId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Poll poll = mapResultSetToPoll(rs);
                    
                    // 투표 옵션들 조회
                    List<PollOption> options = getPollOptions(pollId);
                    poll.setOptions(options);
                    
                    // 총 투표 수 계산
                    int totalVotes = options.stream().mapToInt(PollOption::getVoteCount).sum();
                    poll.setTotalVotes(totalVotes);
                    
                    // 각 옵션별 비율 계산
                    for (PollOption option : options) {
                        option.calculatePercentage(totalVotes);
                    }
                    
                    System.out.println("✅ 투표 조회 성공: ID " + pollId);
                    return poll;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 조회 실패 (ID: " + pollId + "): " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("⚠️ 투표를 찾을 수 없음: ID " + pollId);
        return null;
    }
    
    /**
     * 🆕 투표 생성
     */
    public boolean createPoll(Poll poll) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 투표 기본 정보 삽입
                String pollSql = "INSERT INTO polls (class_id, professor_id, title, description, " +
                               "is_multiple_choice, is_anonymous, is_active, created_at, expires_at) " +
                               "VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
                
                Long generatedPollId = null;
                
                try (PreparedStatement pollStmt = conn.prepareStatement(pollSql, Statement.RETURN_GENERATED_KEYS)) {
                    pollStmt.setLong(1, poll.getClassId());
                    pollStmt.setLong(2, poll.getProfessorId());
                    pollStmt.setString(3, poll.getTitle());
                    pollStmt.setString(4, poll.getDescription());
                    pollStmt.setBoolean(5, poll.isMultipleChoice());
                    pollStmt.setBoolean(6, poll.isAnonymous());
                    pollStmt.setBoolean(7, poll.isActive());
                    pollStmt.setTimestamp(8, poll.getExpiresAt());
                    
                    int result = pollStmt.executeUpdate();
                    
                    if (result > 0) {
                        try (ResultSet rs = pollStmt.getGeneratedKeys()) {
                            if (rs.next()) {
                                generatedPollId = rs.getLong(1);
                                poll.setPollId(generatedPollId);
                            }
                        }
                    }
                }
                
                if (generatedPollId == null) {
                    throw new SQLException("투표 생성 실패: ID를 가져올 수 없음");
                }
                
                // 투표 옵션들 삽입
                if (poll.getOptions() != null && !poll.getOptions().isEmpty()) {
                    String optionSql = "INSERT INTO poll_options (poll_id, option_text, option_order) VALUES (?, ?, ?)";
                    
                    try (PreparedStatement optionStmt = conn.prepareStatement(optionSql)) {
                        for (PollOption option : poll.getOptions()) {
                            optionStmt.setLong(1, generatedPollId);
                            optionStmt.setString(2, option.getOptionText());
                            optionStmt.setInt(3, option.getOptionOrder());
                            optionStmt.addBatch();
                        }
                        
                        optionStmt.executeBatch();
                    }
                }
                
                conn.commit();
                System.out.println("✅ 투표 생성 성공: ID " + generatedPollId + " (" + poll.getTitle() + ")");
                return true;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 생성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🗳️ 투표 참여
     */
    public boolean voteOnPoll(Long pollId, Long optionId, Long userId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 투표 정보 확인
                Poll poll = getPollById(pollId);
                if (poll == null || !poll.isActive()) {
                    System.out.println("⚠️ 투표할 수 없음: 투표가 존재하지 않거나 비활성 상태");
                    return false;
                }
                
                // 만료일 확인
                if (poll.getExpiresAt() != null && poll.getExpiresAt().before(new Timestamp(System.currentTimeMillis()))) {
                    System.out.println("⚠️ 투표할 수 없음: 투표가 만료됨");
                    return false;
                }
                
                // 기존 투표 확인 (단일 선택인 경우)
                if (!poll.isMultipleChoice()) {
                    String checkSql = "SELECT 1 FROM poll_responses WHERE poll_id = ? AND user_id = ?";
                    try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                        checkStmt.setLong(1, pollId);
                        checkStmt.setLong(2, userId);
                        
                        try (ResultSet rs = checkStmt.executeQuery()) {
                            if (rs.next()) {
                                System.out.println("⚠️ 투표할 수 없음: 이미 투표에 참여함 (단일 선택)");
                                return false;
                            }
                        }
                    }
                }
                
                // 동일한 옵션에 중복 투표 확인
                String duplicateCheckSql = "SELECT 1 FROM poll_responses WHERE poll_id = ? AND option_id = ? AND user_id = ?";
                try (PreparedStatement dupCheckStmt = conn.prepareStatement(duplicateCheckSql)) {
                    dupCheckStmt.setLong(1, pollId);
                    dupCheckStmt.setLong(2, optionId);
                    dupCheckStmt.setLong(3, userId);
                    
                    try (ResultSet rs = dupCheckStmt.executeQuery()) {
                        if (rs.next()) {
                            System.out.println("⚠️ 투표할 수 없음: 동일한 옵션에 이미 투표함");
                            return false;
                        }
                    }
                }
                
                // 투표 응답 삽입
                String responseSql = "INSERT INTO poll_responses (poll_id, option_id, user_id, created_at) VALUES (?, ?, ?, NOW())";
                try (PreparedStatement responseStmt = conn.prepareStatement(responseSql)) {
                    responseStmt.setLong(1, pollId);
                    responseStmt.setLong(2, optionId);
                    responseStmt.setLong(3, userId);
                    responseStmt.executeUpdate();
                }
                
                // 옵션 투표 수 증가
                String updateOptionSql = "UPDATE poll_options SET vote_count = vote_count + 1 WHERE option_id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateOptionSql)) {
                    updateStmt.setLong(1, optionId);
                    updateStmt.executeUpdate();
                }
                
                conn.commit();
                System.out.println("✅ 투표 참여 성공: 투표 ID " + pollId + ", 옵션 ID " + optionId + ", 사용자 ID " + userId);
                return true;
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 참여 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔍 사용자가 선택한 옵션 조회
     */
    public Long getUserSelectedOption(Long pollId, Long userId) {
        String sql = "SELECT option_id FROM poll_responses WHERE poll_id = ? AND user_id = ? LIMIT 1";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, pollId);
            pstmt.setLong(2, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("option_id");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 사용자 선택 옵션 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * 🔍 사용자가 투표했는지 확인
     */
    public boolean hasUserVoted(Long pollId, Long userId) {
        return getUserSelectedOption(pollId, userId) != null;
    }
    
    /**
     * ✏️ 투표 수정
     */
    public boolean updatePoll(Poll poll) {
        String sql = "UPDATE polls SET title = ?, description = ?, is_multiple_choice = ?, " +
                    "is_anonymous = ?, is_active = ?, expires_at = ? " +
                    "WHERE poll_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, poll.getTitle());
            pstmt.setString(2, poll.getDescription());
            pstmt.setBoolean(3, poll.isMultipleChoice());
            pstmt.setBoolean(4, poll.isAnonymous());
            pstmt.setBoolean(5, poll.isActive());
            pstmt.setTimestamp(6, poll.getExpiresAt());
            pstmt.setLong(7, poll.getPollId());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 투표 수정 성공: ID " + poll.getPollId());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🗑️ 투표 삭제
     */
    public boolean deletePoll(Long pollId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // 투표 응답 삭제
                String deleteResponsesSql = "DELETE FROM poll_responses WHERE poll_id = ?";
                try (PreparedStatement deleteResponsesStmt = conn.prepareStatement(deleteResponsesSql)) {
                    deleteResponsesStmt.setLong(1, pollId);
                    deleteResponsesStmt.executeUpdate();
                }
                
                // 투표 옵션 삭제
                String deleteOptionsSql = "DELETE FROM poll_options WHERE poll_id = ?";
                try (PreparedStatement deleteOptionsStmt = conn.prepareStatement(deleteOptionsSql)) {
                    deleteOptionsStmt.setLong(1, pollId);
                    deleteOptionsStmt.executeUpdate();
                }
                
                // 투표 삭제
                String deletePollSql = "DELETE FROM polls WHERE poll_id = ?";
                try (PreparedStatement deletePollStmt = conn.prepareStatement(deletePollSql)) {
                    deletePollStmt.setLong(1, pollId);
                    int result = deletePollStmt.executeUpdate();
                    
                    if (result > 0) {
                        conn.commit();
                        System.out.println("✅ 투표 삭제 성공: ID " + pollId);
                        return true;
                    }
                }
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔍 투표 옵션들 조회
     */
    public List<PollOption> getPollOptions(Long pollId) {
        List<PollOption> options = new ArrayList<>();
        
        String sql = "SELECT option_id, poll_id, option_text, vote_count, option_order " +
                    "FROM poll_options " +
                    "WHERE poll_id = ? " +
                    "ORDER BY option_order ASC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, pollId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    PollOption option = new PollOption();
                    option.setOptionId(rs.getLong("option_id"));
                    option.setPollId(rs.getLong("poll_id"));
                    option.setOptionText(rs.getString("option_text"));
                    option.setVoteCount(rs.getInt("vote_count"));
                    option.setOptionOrder(rs.getInt("option_order"));
                    
                    options.add(option);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 투표 옵션 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return options;
    }
    
    /**
     * 📊 수업별 투표 수 조회
     */
    public int getPollCountByClass(Long classId) {
        String sql = "SELECT COUNT(*) FROM polls WHERE class_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 투표 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    /**
     * 📊 활성 투표 수 조회
     */
    public int getActivePollCountByClass(Long classId) {
        String sql = "SELECT COUNT(*) FROM polls WHERE class_id = ? AND is_active = TRUE " +
                    "AND (expires_at IS NULL OR expires_at > NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 활성 투표 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🛠️ 헬퍼 메서드들
    // ========================================
    
    /**
     * ResultSet을 Poll 객체로 매핑
     */
    private Poll mapResultSetToPoll(ResultSet rs) throws SQLException {
        Poll poll = new Poll();
        
        // 기본 필드
        poll.setPollId(rs.getLong("poll_id"));
        poll.setClassId(rs.getLong("class_id"));
        poll.setProfessorId(rs.getLong("professor_id"));
        poll.setTitle(rs.getString("title"));
        poll.setDescription(rs.getString("description"));
        poll.setMultipleChoice(rs.getBoolean("is_multiple_choice"));
        poll.setAnonymous(rs.getBoolean("is_anonymous"));
        poll.setActive(rs.getBoolean("is_active"));
        poll.setCreatedAt(rs.getTimestamp("created_at"));
        poll.setExpiresAt(rs.getTimestamp("expires_at"));
        
        // 추가 정보
        poll.setClassName(rs.getString("class_name"));
        poll.setClassCode(rs.getString("class_code"));
        poll.setProfessorName(rs.getString("professor_name"));
        
        // 만료 상태 업데이트
        if (poll.getExpiresAt() != null) {
            poll.setExpired(poll.getExpiresAt().before(new Timestamp(System.currentTimeMillis())));
        }
        
        return poll;
    }
}