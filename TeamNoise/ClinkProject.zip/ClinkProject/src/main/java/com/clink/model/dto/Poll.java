package com.clink.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;

/**
 * Poll DTO - 투표 정보 (polls, poll_options, poll_responses 테이블과 연동)
 * 
 * 📋 테이블 구조:
 * - polls: 투표 기본 정보
 * - poll_options: 투표 선택지
 * - poll_responses: 투표 응답
 */
public class Poll {
    
    // ========================================
    // 📋 기본 필드 (polls 테이블)
    // ========================================
    private Long pollId;            // poll_id
    private Long classId;           // class_id
    private Long professorId;       // professor_id
    private String title;           // title
    private String description;     // description
    private Boolean isMultipleChoice; // is_multiple_choice
    private Boolean isAnonymous;    // is_anonymous
    private Boolean isActive;       // is_active
    private Timestamp createdAt;    // created_at
    private Timestamp expiresAt;    // expires_at
    
    // ========================================
    // 📋 추가 정보 필드
    // ========================================
    private String className;       // 수업 이름
    private String classCode;       // 수업 코드
    private String professorName;   // 교수 이름
    private Integer totalVotes;     // 총 투표 수
    private List<PollOption> options; // 투표 선택지들
    
    // ========================================
    // 📋 UI 관련 정보
    // ========================================
    private Boolean userVoted;     // 현재 사용자가 투표했는지
    private Long userSelectedOption; // 현재 사용자가 선택한 옵션 ID
    private Boolean canEdit;       // 수정 가능 여부
    private Boolean canDelete;     // 삭제 가능 여부
    private Boolean isExpired;     // 만료 여부
    
    // ========================================
    // 🏗️ 생성자들
    // ========================================
    
    /**
     * 기본 생성자
     */
    public Poll() {
        this.isMultipleChoice = false;
        this.isAnonymous = true;
        this.isActive = true;
        this.totalVotes = 0;
        this.options = new ArrayList<>();
        this.userVoted = false;
        this.canEdit = false;
        this.canDelete = false;
        this.isExpired = false;
    }
    
    /**
     * 필수 필드 생성자
     */
    public Poll(Long classId, Long professorId, String title) {
        this();
        this.classId = classId;
        this.professorId = professorId;
        this.title = title;
    }
    
    /**
     * 설명 포함 생성자
     */
    public Poll(Long classId, Long professorId, String title, String description) {
        this(classId, professorId, title);
        this.description = description;
    }
    
    // ========================================
    // 🔧 Getter & Setter
    // ========================================
    
    public Long getPollId() {
        return pollId;
    }
    
    public void setPollId(Long pollId) {
        this.pollId = pollId;
    }
    
    public Long getClassId() {
        return classId;
    }
    
    public void setClassId(Long classId) {
        this.classId = classId;
    }
    
    public Long getProfessorId() {
        return professorId;
    }
    
    public void setProfessorId(Long professorId) {
        this.professorId = professorId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Boolean isMultipleChoice() {
        return isMultipleChoice != null ? isMultipleChoice : false;
    }
    
    public void setMultipleChoice(Boolean multipleChoice) {
        this.isMultipleChoice = multipleChoice;
    }
    
    public Boolean isAnonymous() {
        return isAnonymous != null ? isAnonymous : true;
    }
    
    public void setAnonymous(Boolean anonymous) {
        this.isAnonymous = anonymous;
    }
    
    public Boolean isActive() {
        return isActive != null ? isActive : true;
    }
    
    public void setActive(Boolean active) {
        this.isActive = active;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getExpiresAt() {
        return expiresAt;
    }
    
    public void setExpiresAt(Timestamp expiresAt) {
        this.expiresAt = expiresAt;
        // 만료일 설정 시 자동으로 expired 상태 업데이트
        updateExpiredStatus();
    }
    
    public String getClassName() {
        return className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }
    
    public String getClassCode() {
        return classCode;
    }
    
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }
    
    public String getProfessorName() {
        return professorName;
    }
    
    public void setProfessorName(String professorName) {
        this.professorName = professorName;
    }
    
    public Integer getTotalVotes() {
        return totalVotes != null ? totalVotes : 0;
    }
    
    public void setTotalVotes(Integer totalVotes) {
        this.totalVotes = totalVotes;
    }
    
    public List<PollOption> getOptions() {
        return options != null ? options : new ArrayList<>();
    }
    
    public void setOptions(List<PollOption> options) {
        this.options = options;
        // 옵션 설정 시 총 투표 수 재계산
        if (options != null) {
            this.totalVotes = options.stream().mapToInt(PollOption::getVoteCount).sum();
        }
    }
    
    public Boolean isUserVoted() {
        return userVoted != null ? userVoted : false;
    }
    
    public void setUserVoted(Boolean userVoted) {
        this.userVoted = userVoted;
    }
    
    public Long getUserSelectedOption() {
        return userSelectedOption;
    }
    
    public void setUserSelectedOption(Long userSelectedOption) {
        this.userSelectedOption = userSelectedOption;
    }
    
    public Boolean isCanEdit() {
        return canEdit != null ? canEdit : false;
    }
    
    public void setCanEdit(Boolean canEdit) {
        this.canEdit = canEdit;
    }
    
    public Boolean isCanDelete() {
        return canDelete != null ? canDelete : false;
    }
    
    public void setCanDelete(Boolean canDelete) {
        this.canDelete = canDelete;
    }
    
    public Boolean isExpired() {
        return isExpired != null ? isExpired : false;
    }
    
    public void setExpired(Boolean expired) {
        this.isExpired = expired;
    }
    
    // ========================================
    // 🛠️ 유틸리티 메서드들
    // ========================================
    
    /**
     * 만료 상태 업데이트
     */
    private void updateExpiredStatus() {
        if (expiresAt != null) {
            this.isExpired = expiresAt.before(new Timestamp(System.currentTimeMillis()));
        } else {
            this.isExpired = false;
        }
    }
    
    /**
     * 투표 가능 여부 확인
     */
    public boolean canVote() {
        return isActive() && !isExpired() && !isUserVoted();
    }
    
    /**
     * 투표 옵션 추가
     */
    public void addOption(PollOption option) {
        if (options == null) {
            options = new ArrayList<>();
        }
        options.add(option);
    }
    
    /**
     * 특정 옵션 조회
     */
    public PollOption getOptionById(Long optionId) {
        if (options == null || optionId == null) return null;
        
        return options.stream()
                .filter(option -> optionId.equals(option.getOptionId()))
                .findFirst()
                .orElse(null);
    }
    
    /**
     * 생성일시 포맷팅
     */
    public String getFormattedCreatedAt() {
        if (createdAt == null) return "";
        
        LocalDateTime ldt = createdAt.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return ldt.format(formatter);
    }
    
    /**
     * 만료일시 포맷팅
     */
    public String getFormattedExpiresAt() {
        if (expiresAt == null) return "만료일 없음";
        
        LocalDateTime ldt = expiresAt.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return ldt.format(formatter);
    }
    
    /**
     * 투표 상태 텍스트 반환
     */
    public String getStatusText() {
        if (!isActive()) {
            return "비활성";
        } else if (isExpired()) {
            return "만료됨";
        } else {
            return "진행중";
        }
    }
    
    /**
     * 투표 상태에 따른 CSS 클래스 반환
     */
    public String getStatusClass() {
        if (!isActive()) {
            return "poll-inactive";
        } else if (isExpired()) {
            return "poll-expired";
        } else {
            return "poll-active";
        }
    }
    
    /**
     * 투표 설명 미리보기 (100자로 제한)
     */
    public String getPreviewDescription() {
        if (description == null || description.trim().isEmpty()) {
            return "설명이 없습니다.";
        }
        
        String text = description.trim();
        if (text.length() <= 100) {
            return text;
        }
        return text.substring(0, 100) + "...";
    }
    
    // ========================================
    // 🔧 Object 메서드 오버라이드
    // ========================================
    
    @Override
    public String toString() {
        return "Poll{" +
                "pollId=" + pollId +
                ", classId=" + classId +
                ", title='" + title + "'" +
                ", isMultipleChoice=" + isMultipleChoice +
                ", isAnonymous=" + isAnonymous +
                ", isActive=" + isActive +
                ", totalVotes=" + totalVotes +
                ", optionsCount=" + (options != null ? options.size() : 0) +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Poll poll = (Poll) obj;
        return pollId != null && pollId.equals(poll.pollId);
    }
    
    @Override
    public int hashCode() {
        return pollId != null ? pollId.hashCode() : 0;
    }
    
    // ========================================
    // 📋 내부 클래스: PollOption
    // ========================================
    
    /**
     * 투표 선택지 클래스 (poll_options 테이블)
     */
    public static class PollOption {
        private Long optionId;          // option_id
        private Long pollId;            // poll_id
        private String optionText;      // option_text
        private Integer voteCount;      // vote_count
        private Integer optionOrder;    // option_order
        
        // UI 관련
        private Double percentage;      // 투표 비율
        private Boolean isUserSelected; // 현재 사용자가 선택했는지
        
        // 기본 생성자
        public PollOption() {
            this.voteCount = 0;
            this.optionOrder = 0;
            this.percentage = 0.0;
            this.isUserSelected = false;
        }
        
        // 생성자
        public PollOption(String optionText) {
            this();
            this.optionText = optionText;
        }
        
        public PollOption(String optionText, Integer optionOrder) {
            this(optionText);
            this.optionOrder = optionOrder;
        }
        
        // Getter & Setter
        public Long getOptionId() {
            return optionId;
        }
        
        public void setOptionId(Long optionId) {
            this.optionId = optionId;
        }
        
        public Long getPollId() {
            return pollId;
        }
        
        public void setPollId(Long pollId) {
            this.pollId = pollId;
        }
        
        public String getOptionText() {
            return optionText;
        }
        
        public void setOptionText(String optionText) {
            this.optionText = optionText;
        }
        
        public Integer getVoteCount() {
            return voteCount != null ? voteCount : 0;
        }
        
        public void setVoteCount(Integer voteCount) {
            this.voteCount = voteCount;
        }
        
        public Integer getOptionOrder() {
            return optionOrder != null ? optionOrder : 0;
        }
        
        public void setOptionOrder(Integer optionOrder) {
            this.optionOrder = optionOrder;
        }
        
        public Double getPercentage() {
            return percentage != null ? percentage : 0.0;
        }
        
        public void setPercentage(Double percentage) {
            this.percentage = percentage;
        }
        
        public Boolean isUserSelected() {
            return isUserSelected != null ? isUserSelected : false;
        }
        
        public void setUserSelected(Boolean userSelected) {
            this.isUserSelected = userSelected;
        }
        
        /**
         * 투표 비율 계산
         */
        public void calculatePercentage(int totalVotes) {
            if (totalVotes == 0) {
                this.percentage = 0.0;
            } else {
                this.percentage = (double) getVoteCount() / totalVotes * 100;
            }
        }
        
        /**
         * 투표 비율 포맷팅
         */
        public String getFormattedPercentage() {
            return String.format("%.1f%%", getPercentage());
        }
        
        @Override
        public String toString() {
            return "PollOption{" +
                    "optionId=" + optionId +
                    ", optionText='" + optionText + "'" +
                    ", voteCount=" + voteCount +
                    ", percentage=" + percentage +
                    '}';
        }
        
        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            
            PollOption that = (PollOption) obj;
            return optionId != null && optionId.equals(that.optionId);
        }
        
        @Override
        public int hashCode() {
            return optionId != null ? optionId.hashCode() : 0;
        }
    }
}