package com.clink.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.service.ClassService;
import com.clink.model.dto.User;
import com.clink.model.dto.Class;

// JSON 파싱을 위한 간단한 JSON 파서 (Jackson 없이)
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

/**
 * ClassAjaxHandler - 수업 관리 AJAX 요청 처리 전담 (강화된 JSON 지원)
 * 
 * 🎯 담당 기능:
 * - /class/create: 수업 생성
 * - /class/update: 수업 정보 수정
 * - /class/delete: 수업 삭제
 * - /class/info: 수업 정보 조회
 * - /class/join: 수업 참여
 * - /class/leave: 수업 나가기
 */
public class ClassAjaxHandler {
    
    private ClassService classService;
    
    /**
     * 생성자 - 의존성 주입
     */
    public ClassAjaxHandler(ClassService classService) {
        this.classService = classService;
    }
    
    /**
     * 🎯 AJAX 요청 라우터
     */
    public void handleAjaxRequest(HttpServletRequest request, HttpServletResponse response, String command) 
            throws IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("loginUser");
        
        System.out.println("📡 AJAX 요청: " + command + " (user: " + user.getRole() + ")");
        
        try {
            switch (command) {
                case "/class/create":
                    handleCreateClass(request, response, user);
                    break;
                    
                case "/class/update":
                    handleUpdateClass(request, response, user);
                    break;
                    
                case "/class/delete":
                    handleDeleteClass(request, response, user);
                    break;
                    
                case "/class/info":
                    handleGetClassInfo(request, response, user);
                    break;
                    
                case "/class/join":
                    handleJoinClass(request, response, user);
                    break;
                    
                case "/class/leave":
                    handleLeaveClass(request, response, user);
                    break;
                    
                default:
                    sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("💥 AJAX 요청 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🆕 수업 생성 (JSON 요청 처리)
     */
    private void handleCreateClass(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        // 교수만 가능
        if (!"professor".equals(user.getRole())) {
            sendJsonResponse(response, false, "교수만 수업을 생성할 수 있습니다.", null);
            return;
        }
        
        System.out.println("🆕 수업 생성 요청: " + user.getName());
        
        try {
            // JSON 요청 데이터 파싱
            Map<String, Object> jsonData = parseJsonRequest(request);
            
            if (jsonData == null) {
                sendJsonResponse(response, false, "잘못된 요청 데이터입니다.", null);
                return;
            }
            
            // JSON에서 데이터 추출
            String className = (String) jsonData.get("className");
            String description = (String) jsonData.get("description");
            String startDate = (String) jsonData.get("startDate");
            String endDate = (String) jsonData.get("endDate");
            String startTime = (String) jsonData.get("startTime");
            String endTime = (String) jsonData.get("endTime");
            String classDays = (String) jsonData.get("classDays");
            String maxStudentsStr = (String) jsonData.get("maxStudents");
            String classCode = (String) jsonData.get("classCode");
            
            System.out.println("📋 수집된 데이터:");
            System.out.println("   - 수업명: " + className);
            System.out.println("   - 시작일: " + startDate);
            System.out.println("   - 종료일: " + endDate);
            System.out.println("   - 수업요일: " + classDays);
            System.out.println("   - 수업코드: " + classCode);
            
            // 필수 값 검증
            if (className == null || className.trim().isEmpty() ||
                startDate == null || endDate == null ||
                startTime == null || endTime == null ||
                classDays == null || classDays.trim().isEmpty()) {
                
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다.", null);
                return;
            }
            
            // 🔧 실제 ClassService 메서드 사용
            boolean success = classService.createClass(
                className.trim(),
                description != null ? description.trim() : "",
                (long) user.getUserId(),
                startDate,
                endDate,
                startTime,
                endTime,
                classDays,
                maxStudentsStr != null ? maxStudentsStr : "50"
            );
            
            if (success) {
                System.out.println("✅ 수업 생성 성공: " + className);
                sendJsonResponse(response, true, "수업이 성공적으로 생성되었습니다!", null);
            } else {
                sendJsonResponse(response, false, "수업 생성에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 수업 생성 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "수업 생성 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * ✏️ 수업 정보 수정
     */
    private void handleUpdateClass(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        // 교수만 가능
        if (!"professor".equals(user.getRole())) {
            sendJsonResponse(response, false, "교수만 수업 정보를 수정할 수 있습니다.", null);
            return;
        }
        
        System.out.println("✏️ 수업 수정 요청: " + user.getName());
        
        try {
            // JSON 요청 데이터 파싱
            Map<String, Object> jsonData = parseJsonRequest(request);
            
            if (jsonData == null) {
                sendJsonResponse(response, false, "잘못된 요청 데이터입니다.", null);
                return;
            }
            
            String classIdStr = (String) jsonData.get("classId");
            String className = (String) jsonData.get("className");
            String description = (String) jsonData.get("description");
            String startDate = (String) jsonData.get("startDate");
            String endDate = (String) jsonData.get("endDate");
            String startTime = (String) jsonData.get("startTime");
            String endTime = (String) jsonData.get("endTime");
            String maxStudentsStr = (String) jsonData.get("maxStudents");
            String status = (String) jsonData.get("status");
            String classDays = (String) jsonData.get("classDays");
            
            if (classIdStr == null || className == null) {
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다.", null);
                return;
            }
            
            // 수업 ID 파싱
            long classId;
            try {
                classId = Long.parseLong(classIdStr);
            } catch (NumberFormatException e) {
                sendJsonResponse(response, false, "잘못된 수업 ID입니다.", null);
                return;
            }
            
            // 🔧 실제 ClassService 메서드 사용
            boolean success = classService.updateClass(
                classId,
                (long) user.getUserId(),
                className.trim(),
                description != null ? description.trim() : "",
                startDate,
                endDate,
                startTime,
                endTime,
                classDays != null ? classDays : "",
                maxStudentsStr,
                status != null ? status : "scheduled"
            );
            
            if (success) {
                System.out.println("✅ 수업 수정 성공: " + className);
                sendJsonResponse(response, true, "수업 정보가 수정되었습니다!", null);
            } else {
                sendJsonResponse(response, false, "수업 수정에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 수업 수정 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "수업 수정 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🗑️ 수업 삭제
     */
    private void handleDeleteClass(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        // 교수만 가능
        if (!"professor".equals(user.getRole())) {
            sendJsonResponse(response, false, "교수만 수업을 삭제할 수 있습니다.", null);
            return;
        }
        
        System.out.println("🗑️ 수업 삭제 요청: " + user.getName());
        
        try {
            // JSON 요청 데이터 파싱
            Map<String, Object> jsonData = parseJsonRequest(request);
            
            if (jsonData == null) {
                sendJsonResponse(response, false, "잘못된 요청 데이터입니다.", null);
                return;
            }
            
            String classCode = (String) jsonData.get("classCode");
            
            if (classCode == null || classCode.trim().isEmpty()) {
                sendJsonResponse(response, false, "삭제할 수업 코드가 필요합니다.", null);
                return;
            }
            
            // 수업 정보 조회
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo == null) {
                sendJsonResponse(response, false, "존재하지 않는 수업입니다.", null);
                return;
            }
            
            // 권한 확인
            if (!classInfo.getProfessorId().equals((long) user.getUserId())) {
                sendJsonResponse(response, false, "삭제 권한이 없습니다.", null);
                return;
            }
            
            // 🔧 실제 ClassService 메서드 사용
            boolean success = classService.deleteClass(classInfo.getId(), (long) user.getUserId());
            
            if (success) {
                System.out.println("✅ 수업 삭제 성공: " + classCode);
                sendJsonResponse(response, true, "수업이 삭제되었습니다.", null);
            } else {
                sendJsonResponse(response, false, "수업 삭제에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 수업 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "수업 삭제 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🔍 수업 정보 조회
     */
    private void handleGetClassInfo(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        String classCode = request.getParameter("code");
        
        if (classCode == null || classCode.trim().isEmpty()) {
            sendJsonResponse(response, false, "수업 코드가 필요합니다.", null);
            return;
        }
        
        try {
            Class classInfo = classService.getClassByCode(classCode);
            if (classInfo != null) {
                // 간단한 수업 정보 JSON 생성
                String classData = String.format(
                    "{\"classCode\":\"%s\",\"className\":\"%s\",\"status\":\"%s\",\"maxStudents\":%d}",
                    escapeJson(classInfo.getClassCode()),
                    escapeJson(classInfo.getClassName()),
                    escapeJson(classInfo.getStatus()),
                    classInfo.getMaxStudents()
                );
                
                sendJsonResponse(response, true, "수업 정보 조회 성공", classData);
            } else {
                sendJsonResponse(response, false, "수업을 찾을 수 없습니다.", null);
            }
        } catch (Exception e) {
            System.err.println("💥 수업 정보 조회 오류: " + e.getMessage());
            sendJsonResponse(response, false, "수업 정보 조회 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🔗 수업 참여
     */
    private void handleJoinClass(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        // 학생만 가능
        if (!"student".equals(user.getRole())) {
            sendJsonResponse(response, false, "학생만 수업에 참여할 수 있습니다.", null);
            return;
        }
        
        String classCode = request.getParameter("classCode");
        
        if (classCode == null || classCode.trim().isEmpty()) {
            sendJsonResponse(response, false, "수업 코드가 필요합니다.", null);
            return;
        }
        
        try {
            boolean success = classService.joinClass(classCode, (long) user.getUserId());
            
            if (success) {
                System.out.println("✅ 수업 참여 성공: " + user.getName() + " → " + classCode);
                sendJsonResponse(response, true, "수업에 참여했습니다!", null);
            } else {
                sendJsonResponse(response, false, "수업 참여에 실패했습니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("💥 수업 참여 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "수업 참여 중 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 🚪 수업 나가기
     */
    private void handleLeaveClass(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        
        // 학생만 가능
        if (!"student".equals(user.getRole())) {
            sendJsonResponse(response, false, "학생만 수업을 나갈 수 있습니다.", null);
            return;
        }
        
        // TODO: 실제 수업 나가기 로직 구현
        sendJsonResponse(response, false, "수업 나가기 기능은 준비 중입니다.", null);
    }
    
    // ==========================================
    // 🛠️ 강화된 JSON 파싱 헬퍼 메서드들
    // ==========================================
    
    /**
     * 강화된 JSON 파싱 (Jackson 없이) - 오류 처리 개선
     */
    private Map<String, Object> parseJsonRequest(HttpServletRequest request) throws IOException {
        BufferedReader reader = request.getReader();
        StringBuilder jsonString = new StringBuilder();
        String line;
        
        while ((line = reader.readLine()) != null) {
            jsonString.append(line);
        }
        
        String json = jsonString.toString().trim();
        System.out.println("📥 받은 JSON: " + json);
        
        // 빈 문자열 체크
        if (json.isEmpty()) {
            System.out.println("⚠️ 빈 JSON 문자열");
            return new HashMap<>();
        }
        
        // 기본 JSON 형식 체크
        if (!json.startsWith("{") || !json.endsWith("}")) {
            System.out.println("⚠️ 잘못된 JSON 형식: " + json);
            return null;
        }
        
        // 간단한 JSON 파싱 (개선된 버전)
        Map<String, Object> result = new HashMap<>();
        
        try {
            // {}를 제거
            json = json.substring(1, json.length() - 1).trim();
            
            if (json.isEmpty()) {
                return result; // 빈 객체 {} 처리
            }
            
            // 문자열 내부의 쉼표와 실제 구분자 쉼표를 구분하여 파싱
            List<String> pairs = parseJsonPairs(json);
            
            for (String pair : pairs) {
                String[] keyValue = pair.split(":", 2);
                if (keyValue.length == 2) {
                    String key = cleanJsonString(keyValue[0].trim());
                    String value = cleanJsonString(keyValue[1].trim());
                    result.put(key, value);
                }
            }
            
            System.out.println("✅ JSON 파싱 성공: " + result.size() + "개 키");
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ JSON 파싱 오류: " + e.getMessage());
            System.err.println("원본 JSON: " + jsonString.toString());
            return null;
        }
    }
    
    /**
     * JSON 쌍들을 안전하게 파싱 (문자열 내부의 쉼표 고려)
     */
    private List<String> parseJsonPairs(String json) {
        List<String> pairs = new ArrayList<>();
        StringBuilder currentPair = new StringBuilder();
        boolean inString = false;
        boolean escaped = false;
        
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            
            if (escaped) {
                currentPair.append(c);
                escaped = false;
                continue;
            }
            
            if (c == '\\') {
                escaped = true;
                currentPair.append(c);
                continue;
            }
            
            if (c == '"') {
                inString = !inString;
                currentPair.append(c);
                continue;
            }
            
            if (c == ',' && !inString) {
                // 실제 구분자 쉼표
                pairs.add(currentPair.toString().trim());
                currentPair = new StringBuilder();
            } else {
                currentPair.append(c);
            }
        }
        
        // 마지막 쌍 추가
        if (currentPair.length() > 0) {
            pairs.add(currentPair.toString().trim());
        }
        
        return pairs;
    }
    
    /**
     * JSON 문자열에서 따옴표 제거 및 정리
     */
    private String cleanJsonString(String str) {
        if (str == null) return "";
        
        str = str.trim();
        
        // 따옴표로 둘러싸인 경우 제거
        if (str.startsWith("\"") && str.endsWith("\"") && str.length() > 1) {
            str = str.substring(1, str.length() - 1);
        }
        
        // 이스케이프 문자 처리
        str = str.replace("\\\"", "\"")
                 .replace("\\\\", "\\")
                 .replace("\\n", "\n")
                 .replace("\\r", "\r")
                 .replace("\\t", "\t");
        
        return str;
    }
    
    /**
     * JSON 응답 전송
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, 
                                String message, String data) throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null && !data.isEmpty()) {
            if (data.startsWith("redirectUrl:")) {
                json.append(",\"redirectUrl\":\"").append(escapeJson(data.substring(12))).append("\"");
            } else {
                json.append(",\"data\":").append(data);
            }
        }
        
        json.append("}");
        
        PrintWriter out = response.getWriter();
        out.print(json.toString());
        out.flush();
        
        System.out.println("📤 AJAX JSON 응답: " + (success ? "SUCCESS" : "ERROR") + " - " + message);
    }
    
    /**
     * JSON 문자열 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}