package com.clink.model.dto;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Question DTO - 질문/답변 정보 (questions 테이블과 연동)
 * 
 * 📋 테이블 구조:
 * - question_id: 질문 ID (PK)
 * - class_id: 수업 ID (FK)
 * - student_id: 학생 ID (FK)
 * - question_text: 질문 내용
 * - answer_text: 답변 내용 (nullable)
 * - professor_id: 답변한 교수 ID (nullable)
 * - vote_count: 투표 수
 * - is_anonymous: 익명 여부
 * - status: 상태 ('pending', 'answered', 'archived')
 * - created_at: 생성일시
 * - answered_at: 답변일시 (nullable)
 */
public class Question {
    
    // ========================================
    // 📋 기본 필드 (DB 컬럼)
    // ========================================
    private Long questionId;        // question_id
    private Long classId;           // class_id
    private Long studentId;         // student_id
    private String questionText;    // question_text
    private String answerText;      // answer_text
    private Long professorId;       // professor_id
    private Integer voteCount;      // vote_count
    private Boolean isAnonymous;    // is_anonymous
    private String status;          // status
    private Timestamp createdAt;    // created_at
    private Timestamp answeredAt;   // answered_at
    
    // ========================================
    // 📋 추가 정보 필드 (JOIN 결과)
    // ========================================
    private String authorName;      // 질문자 이름 (users.name)
    private String professorName;   // 답변한 교수 이름 (users.name)
    private String className;       // 수업 이름 (classes.class_name)
    private String classCode;       // 수업 코드 (classes.class_code)
    
    // ========================================
    // 📋 UI 관련 정보
    // ========================================
    private Boolean userVoted;     // 현재 사용자가 투표했는지
    private Boolean canEdit;       // 수정 가능 여부
    private Boolean canDelete;     // 삭제 가능 여부
    
    // ========================================
    // 🏗️ 생성자들
    // ========================================
    
    /**
     * 기본 생성자
     */
    public Question() {
        this.voteCount = 0;
        this.isAnonymous = false;
        this.status = "pending";
        this.userVoted = false;
        this.canEdit = false;
        this.canDelete = false;
    }
    
    /**
     * 필수 필드 생성자
     */
    public Question(Long classId, Long studentId, String questionText) {
        this();
        this.classId = classId;
        this.studentId = studentId;
        this.questionText = questionText;
    }
    
    /**
     * 익명 설정 생성자
     */
    public Question(Long classId, Long studentId, String questionText, Boolean isAnonymous) {
        this(classId, studentId, questionText);
        this.isAnonymous = isAnonymous;
    }
    
    // ========================================
    // 🔧 Getter & Setter
    // ========================================
    
    public Long getQuestionId() {
        return questionId;
    }
    
    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }
    
    public Long getClassId() {
        return classId;
    }
    
    public void setClassId(Long classId) {
        this.classId = classId;
    }
    
    public Long getStudentId() {
        return studentId;
    }
    
    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }
    
    public String getQuestionText() {
        return questionText;
    }
    
    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }
    
    public String getAnswerText() {
        return answerText;
    }
    
    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }
    
    public Long getProfessorId() {
        return professorId;
    }
    
    public void setProfessorId(Long professorId) {
        this.professorId = professorId;
    }
    
    public Integer getVoteCount() {
        return voteCount != null ? voteCount : 0;
    }
    
    public void setVoteCount(Integer voteCount) {
        this.voteCount = voteCount;
    }
    
    public Boolean isAnonymous() {
        return isAnonymous != null ? isAnonymous : false;
    }
    
    public void setAnonymous(Boolean anonymous) {
        this.isAnonymous = anonymous;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getAnsweredAt() {
        return answeredAt;
    }
    
    public void setAnsweredAt(Timestamp answeredAt) {
        this.answeredAt = answeredAt;
    }
    
    public String getAuthorName() {
        return authorName;
    }
    
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    
    public String getProfessorName() {
        return professorName;
    }
    
    public void setProfessorName(String professorName) {
        this.professorName = professorName;
    }
    
    public String getClassName() {
        return className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }
    
    public String getClassCode() {
        return classCode;
    }
    
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }
    
    public Boolean isUserVoted() {
        return userVoted != null ? userVoted : false;
    }
    
    public void setUserVoted(Boolean userVoted) {
        this.userVoted = userVoted;
    }
    
    public Boolean isCanEdit() {
        return canEdit != null ? canEdit : false;
    }
    
    public void setCanEdit(Boolean canEdit) {
        this.canEdit = canEdit;
    }
    
    public Boolean isCanDelete() {
        return canDelete != null ? canDelete : false;
    }
    
    public void setCanDelete(Boolean canDelete) {
        this.canDelete = canDelete;
    }
    
    // ========================================
    // 🛠️ 유틸리티 메서드들
    // ========================================
    
    /**
     * 답변이 있는지 확인
     */
    public boolean hasAnswer() {
        return answerText != null && !answerText.trim().isEmpty();
    }
    
    /**
     * 질문이 답변됨 상태인지 확인
     */
    public boolean isAnswered() {
        return "answered".equals(status) && hasAnswer();
    }
    
    /**
     * 질문이 대기 중인지 확인
     */
    public boolean isPending() {
        return "pending".equals(status);
    }
    
    /**
     * 질문이 아카이브됨인지 확인
     */
    public boolean isArchived() {
        return "archived".equals(status);
    }
    
    /**
     * 표시할 작성자 이름 반환 (익명 처리)
     */
    public String getDisplayAuthorName() {
        if (isAnonymous != null && isAnonymous) {
            return "익명";
        }
        return authorName != null ? authorName : "알 수 없음";
    }
    
    /**
     * 생성일시 포맷팅
     */
    public String getFormattedCreatedAt() {
        if (createdAt == null) return "";
        
        LocalDateTime ldt = createdAt.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return ldt.format(formatter);
    }
    
    /**
     * 답변일시 포맷팅
     */
    public String getFormattedAnsweredAt() {
        if (answeredAt == null) return "";
        
        LocalDateTime ldt = answeredAt.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return ldt.format(formatter);
    }
    
    /**
     * 상태 한글명 반환
     */
    public String getStatusDisplayName() {
        if (status == null) return "알 수 없음";
        
        switch (status) {
            case "pending": return "답변 대기중";
            case "answered": return "답변 완료";
            case "archived": return "보관됨";
            default: return status;
        }
    }
    
    /**
     * 질문 미리보기 텍스트 (100자로 제한)
     */
    public String getPreviewText() {
        if (questionText == null) return "";
        
        String text = questionText.trim();
        if (text.length() <= 100) {
            return text;
        }
        return text.substring(0, 100) + "...";
    }
    
    // ========================================
    // 🔧 Object 메서드 오버라이드
    // ========================================
    
    @Override
    public String toString() {
        return "Question{" +
                "questionId=" + questionId +
                ", classId=" + classId +
                ", studentId=" + studentId +
                ", questionText='" + (questionText != null ? questionText.substring(0, Math.min(50, questionText.length())) : null) + "'" +
                ", hasAnswer=" + hasAnswer() +
                ", voteCount=" + voteCount +
                ", isAnonymous=" + isAnonymous +
                ", status='" + status + "'" +
                ", createdAt=" + createdAt +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Question question = (Question) obj;
        return questionId != null && questionId.equals(question.questionId);
    }
    
    @Override
    public int hashCode() {
        return questionId != null ? questionId.hashCode() : 0;
    }
}