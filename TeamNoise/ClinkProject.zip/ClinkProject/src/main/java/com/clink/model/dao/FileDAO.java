package com.clink.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.FileInfo;
import com.clink.util.DBConnection;

/**
 * 파일 정보 DAO - 한글 깨짐 완전 해결 + selectFilesByClass 추가 버전
 * attachments 테이블과 연동하여 파일 정보를 저장/조회
 * UTF-8 인코딩 완전 지원으로 한글 파일명 보장
 * ClassController와 BoardController 완전 연동
 */
public class FileDAO {
    
    /**
     * 파일 정보 저장 (한글 파일명 완전 지원)
     */
    public boolean insertFile(FileInfo fileInfo) {
        String sql = "INSERT INTO attachments " +
                    "(post_id, original_filename, stored_filename, file_path, " +
                    "file_size, file_type, mime_type, download_count, uploaded_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            
            // 🔥 핵심 수정: Connection에 UTF-8 설정 강제 적용
            if (conn != null) {
                Statement stmt = conn.createStatement();
                stmt.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                stmt.execute("SET CHARACTER SET utf8mb4");
                stmt.close();
                System.out.println("✅ 데이터베이스 UTF-8 인코딩 설정 완료");
            }
            
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            
            pstmt.setObject(1, fileInfo.getPostId());
            
            // 🔥 한글 파일명 UTF-8 인코딩 보장
            String originalFilename = fileInfo.getOriginalName();
            if (originalFilename != null) {
                // UTF-8 바이트로 변환 후 다시 문자열로 변환하여 인코딩 보장
                byte[] utf8Bytes = originalFilename.getBytes("UTF-8");
                originalFilename = new String(utf8Bytes, "UTF-8");
                System.out.println("🔍 원본 파일명 UTF-8 처리: " + originalFilename);
            }
            pstmt.setString(2, originalFilename);
            
            pstmt.setString(3, fileInfo.getSavedName());
            pstmt.setString(4, fileInfo.getFilePath());
            pstmt.setLong(5, fileInfo.getFileSize());
            pstmt.setString(6, fileInfo.getFileType());
            pstmt.setString(7, fileInfo.getMimeType());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                // 생성된 키 가져오기
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    fileInfo.setAttachmentId(rs.getInt(1));
                    System.out.println("✅ 파일 정보 저장 성공 - ID: " + fileInfo.getAttachmentId() + 
                                     ", 파일명: " + originalFilename);
                }
                rs.close();
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("❌ 파일 정보 저장 실패: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.err.println("❌ 파일 정보 저장 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("❌ 리소스 해제 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 🆕 수업별 파일 목록 조회 (ClassController용)
     * posts 테이블과 attachments 테이블을 JOIN하여 해당 수업의 모든 파일 조회
     */
    public List<FileInfo> selectFilesByClass(Long classId) {
        // posts 테이블과 attachments 테이블을 JOIN하는 SQL
        String sql = "SELECT a.attachment_id, a.post_id, a.original_filename, a.stored_filename, " +
                    "a.file_path, a.file_size, a.file_type, a.mime_type, a.download_count, a.uploaded_at, " +
                    "p.title as post_title, p.author_id, u.name as author_name, u.role as author_role " +
                    "FROM attachments a " +
                    "INNER JOIN posts p ON a.post_id = p.post_id " +
                    "INNER JOIN users u ON p.author_id = u.user_id " +
                    "WHERE p.class_id = ? AND p.status = 'active' " +
                    "ORDER BY a.uploaded_at DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<FileInfo> fileList = new ArrayList<>();
        
        try {
            conn = DBConnection.getConnection();
            
            // UTF-8 설정 적용
            if (conn != null) {
                Statement stmt = conn.createStatement();
                stmt.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                stmt.execute("SET CHARACTER SET utf8mb4");
                stmt.close();
            }
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, classId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                FileInfo fileInfo = new FileInfo();
                fileInfo.setAttachmentId(rs.getInt("attachment_id"));
                fileInfo.setPostId(rs.getInt("post_id"));
                
                // 한글 파일명 처리
                String originalFilename = rs.getString("original_filename");
                if (originalFilename != null) {
                    if (containsGarbledCharacters(originalFilename)) {
                        try {
                            // 깨진 문자 복구 시도
                            String decoded = new String(originalFilename.getBytes("ISO-8859-1"), "UTF-8");
                            if (isValidKorean(decoded)) {
                                originalFilename = decoded;
                            }
                        } catch (Exception e) {
                            // 복구 실패 시 원본 사용
                            System.err.println("⚠️ 파일명 복구 실패: " + e.getMessage());
                        }
                    }
                }
                
                fileInfo.setOriginalName(originalFilename);
                fileInfo.setSavedName(rs.getString("stored_filename"));
                fileInfo.setFilePath(rs.getString("file_path"));
                fileInfo.setFileSize(rs.getLong("file_size"));
                fileInfo.setFileType(rs.getString("file_type"));
                fileInfo.setMimeType(rs.getString("mime_type"));
                fileInfo.setDownloadCount(rs.getInt("download_count"));
                fileInfo.setUploadedAt(rs.getTimestamp("uploaded_at"));
                
                // 추가 정보 설정 (게시글 제목, 업로더 정보)
                fileInfo.setDescription(rs.getString("post_title")); // post_title을 description에 저장
                fileInfo.setUploaderName(rs.getString("author_name"));
                
                fileList.add(fileInfo);
            }
            
            System.out.println("✅ 수업별 파일 조회 성공 - classId: " + classId + ", 파일 수: " + fileList.size());
            return fileList;
            
        } catch (SQLException e) {
            System.err.println("❌ 수업별 파일 조회 실패: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        } catch (Exception e) {
            System.err.println("❌ 수업별 파일 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("❌ 리소스 해제 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 🆕 게시글별 파일 목록 조회 (기존 메서드명 통일)
     */
    public List<FileInfo> selectFilesByPost(Integer postId) {
        return selectFilesByPostId(postId);
    }
    
    /**
     * 🆕 문자열에 깨진 문자(? 등)가 포함되어 있는지 확인
     */
    private boolean containsGarbledCharacters(String text) {
        if (text == null) return false;
        
        // '?' 문자가 많이 포함되어 있으면 깨진 것으로 판단
        int questionMarks = 0;
        for (char c : text.toCharArray()) {
            if (c == '?') {
                questionMarks++;
            }
        }
        
        // 전체 길이의 30% 이상이 ?라면 깨진 것으로 판단
        return questionMarks > text.length() * 0.3;
    }
    
    /**
     * 🆕 문자열에 유효한 한글이 포함되어 있는지 확인
     */
    private boolean isValidKorean(String text) {
        if (text == null) return false;
        
        // 한글 유니코드 범위: AC00-D7AF (가-힣), 3131-318E (ㄱ-ㅎ, ㅏ-ㅣ)
        for (char c : text.toCharArray()) {
            if ((c >= 0xAC00 && c <= 0xD7AF) || (c >= 0x3131 && c <= 0x318E)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 파일 정보 조회 by ID (한글 파일명 완전 지원)
     */
    public FileInfo selectFileById(Integer attachmentId) {
        String sql = "SELECT attachment_id, post_id, original_filename, stored_filename, " +
                    "file_path, file_size, file_type, mime_type, download_count, uploaded_at " +
                    "FROM attachments WHERE attachment_id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            // 🔥 핵심 수정: UTF-8 설정 적용
            if (conn != null) {
                Statement stmt = conn.createStatement();
                stmt.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                stmt.execute("SET CHARACTER SET utf8mb4");
                stmt.close();
            }
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, attachmentId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                FileInfo fileInfo = new FileInfo();
                fileInfo.setAttachmentId(rs.getInt("attachment_id"));
                fileInfo.setPostId(rs.getObject("post_id", Integer.class));
                
                // 🔥 한글 파일명 UTF-8 디코딩 보장
                String originalFilename = rs.getString("original_filename");
                if (originalFilename != null) {
                    // UTF-8 바이트로 재변환하여 인코딩 문제 해결
                    byte[] utf8Bytes = originalFilename.getBytes("ISO-8859-1");
                    originalFilename = new String(utf8Bytes, "UTF-8");
                    System.out.println("🔍 조회된 파일명 UTF-8 처리: " + originalFilename);
                }
                fileInfo.setOriginalName(originalFilename);
                
                fileInfo.setSavedName(rs.getString("stored_filename"));
                fileInfo.setFilePath(rs.getString("file_path"));
                fileInfo.setFileSize(rs.getLong("file_size"));
                fileInfo.setFileType(rs.getString("file_type"));
                fileInfo.setMimeType(rs.getString("mime_type"));
                fileInfo.setDownloadCount(rs.getInt("download_count"));
                fileInfo.setUploadedAt(rs.getTimestamp("uploaded_at"));
                
                System.out.println("✅ 파일 정보 조회 성공: " + originalFilename);
                return fileInfo;
            }
            
            System.out.println("❌ 파일을 찾을 수 없음 - ID: " + attachmentId);
            return null;
            
        } catch (SQLException e) {
            System.err.println("❌ 파일 정보 조회 실패: " + e.getMessage());
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            System.err.println("❌ 파일 정보 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("❌ 리소스 해제 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 게시글별 첨부파일 목록 조회 (한글 파일명 완전 지원)
     */
    public List<FileInfo> selectFilesByPostId(Integer postId) {
        String sql = "SELECT attachment_id, post_id, original_filename, stored_filename, " +
                    "file_path, file_size, file_type, mime_type, download_count, uploaded_at " +
                    "FROM attachments WHERE post_id = ? ORDER BY uploaded_at ASC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<FileInfo> fileList = new ArrayList<>();
        
        try {
            conn = DBConnection.getConnection();
            
            // 🔥 핵심 수정: UTF-8 설정 적용
            if (conn != null) {
                Statement stmt = conn.createStatement();
                stmt.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                stmt.execute("SET CHARACTER SET utf8mb4");
                stmt.close();
            }
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, postId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                FileInfo fileInfo = new FileInfo();
                fileInfo.setAttachmentId(rs.getInt("attachment_id"));
                fileInfo.setPostId(rs.getInt("post_id"));
                
                // 🔥 한글 파일명 UTF-8 디코딩 보장 - 수정된 방식
                String originalFilename = rs.getString("original_filename");
                if (originalFilename != null) {
                    // 🔥 핵심 수정: 데이터베이스에서 이미 UTF-8로 저장되어 있다면 그대로 사용
                    // 만약 깨져있다면 다양한 방식으로 복구 시도
                    if (containsGarbledCharacters(originalFilename)) {
                        try {
                            // 방법 1: ISO-8859-1로 바이트를 가져와서 UTF-8로 재해석
                            byte[] bytes = originalFilename.getBytes("ISO-8859-1");
                            String recovered = new String(bytes, "UTF-8");
                            if (isValidKorean(recovered)) {
                                originalFilename = recovered;
                                System.out.println("🔧 파일명 복구 성공 (ISO-8859-1 → UTF-8): " + originalFilename);
                            } else {
                                // 방법 2: EUC-KR 시도
                                recovered = new String(bytes, "EUC-KR");
                                if (isValidKorean(recovered)) {
                                    originalFilename = recovered;
                                    System.out.println("🔧 파일명 복구 성공 (ISO-8859-1 → EUC-KR): " + originalFilename);
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("⚠️ 파일명 복구 실패, 원본 사용: " + originalFilename);
                        }
                    }
                    System.out.println("🔍 최종 조회된 파일명: " + originalFilename);
                }
                fileInfo.setOriginalName(originalFilename);
                
                fileInfo.setSavedName(rs.getString("stored_filename"));
                fileInfo.setFilePath(rs.getString("file_path"));
                fileInfo.setFileSize(rs.getLong("file_size"));
                fileInfo.setFileType(rs.getString("file_type"));
                fileInfo.setMimeType(rs.getString("mime_type"));
                fileInfo.setDownloadCount(rs.getInt("download_count"));
                fileInfo.setUploadedAt(rs.getTimestamp("uploaded_at"));
                
                fileList.add(fileInfo);
                System.out.println("✅ 파일 목록 추가: " + originalFilename);
            }
            
            System.out.println("✅ 게시글 " + postId + "의 첨부파일 " + fileList.size() + "개 조회 완료");
            return fileList;
            
        } catch (SQLException e) {
            System.err.println("❌ 파일 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
            return fileList;
        } catch (Exception e) {
            System.err.println("❌ 파일 목록 조회 중 예외 발생: " + e.getMessage());
            e.printStackTrace();
            return fileList;
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("❌ 리소스 해제 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 다운로드 수 증가
     */
    public boolean incrementDownloadCount(Integer attachmentId) {
        String sql = "UPDATE attachments SET download_count = download_count + 1 WHERE attachment_id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, attachmentId);
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                System.out.println("✅ 다운로드 수 증가 완료 - 파일 ID: " + attachmentId);
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("❌ 다운로드 수 증가 실패: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("❌ 리소스 해제 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 파일 정보 삭제
     */
    public boolean deleteFile(Integer attachmentId) {
        String sql = "DELETE FROM attachments WHERE attachment_id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, attachmentId);
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                System.out.println("✅ 파일 정보 삭제 완료 - 파일 ID: " + attachmentId);
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("❌ 파일 정보 삭제 실패: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("❌ 리소스 해제 실패: " + e.getMessage());
            }
        }
    }
}