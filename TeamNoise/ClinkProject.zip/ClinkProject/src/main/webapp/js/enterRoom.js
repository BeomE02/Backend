/* ========================================== */
/* enterRoom.js - 방 코드 입력 페이지 JavaScript */
/* ========================================== */

// DOM이 로드되면 초기화
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎯 enterRoom.js 로드 완료');
    initEnterRoom();
});

/**
 * 방 코드 입력 페이지 초기화
 */
function initEnterRoom() {
    console.log('🚀 enterRoom 페이지 초기화 시작...');
    
    // DOM 요소 가져오기
    const form = document.getElementById('enterRoomForm');
    const input = document.getElementById('classCodeInput');
    const submitBtn = document.getElementById('submitBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const codeForm = document.querySelector('.code-form');
    
    // 요소 존재 확인
    if (!form || !input || !submitBtn) {
        console.error('❌ 필수 DOM 요소를 찾을 수 없습니다.');
        return;
    }
    
    console.log('✅ DOM 요소 초기화 완료');
    
    // 이벤트 리스너 등록
    setupEventListeners(form, input, submitBtn, loadingSpinner, codeForm);
    
    // 초기 포커스 설정
    setTimeout(() => {
        input.focus();
    }, 100);
    
    // URL 파라미터에서 에러 확인 및 처리
    handleUrlParams();
    
    console.log('🎉 enterRoom 페이지 초기화 완료');
}

/**
 * 이벤트 리스너 설정
 */
function setupEventListeners(form, input, submitBtn, loadingSpinner, codeForm) {
    // 폼 제출 이벤트
    form.addEventListener('submit', function(e) {
        handleFormSubmit(e, input, submitBtn, loadingSpinner, codeForm);
    });
    
    // 입력 필드 실시간 검증
    input.addEventListener('input', function(e) {
        handleInputChange(e, codeForm);
    });
    
    // 입력 필드 포커스/블러 이벤트
    input.addEventListener('focus', function() {
        codeForm.classList.remove('invalid');
        codeForm.classList.remove('shake');
    });
    
    input.addEventListener('blur', function() {
        validateCodeInput(input.value.trim(), codeForm, false);
    });
    
    // 엔터 키 처리
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            form.dispatchEvent(new Event('submit', { cancelable: true }));
        }
    });
    
    // 버튼 호버 효과
    submitBtn.addEventListener('mouseenter', function() {
        if (!submitBtn.disabled) {
            submitBtn.style.transform = 'scale(1.05)';
        }
    });
    
    submitBtn.addEventListener('mouseleave', function() {
        if (!submitBtn.disabled) {
            submitBtn.style.transform = 'scale(1)';
        }
    });
    
    console.log('✅ 이벤트 리스너 설정 완료');
}

/**
 * 폼 제출 처리
 */
function handleFormSubmit(e, input, submitBtn, loadingSpinner, codeForm) {
    e.preventDefault();
    
    const classCode = input.value.trim().toUpperCase();
    console.log('📝 폼 제출 시도:', classCode);
    
    // 입력값 검증
    if (!validateCodeInput(classCode, codeForm, true)) {
        console.log('❌ 입력값 검증 실패');
        return;
    }
    
    // 중복 제출 방지
    if (submitBtn.disabled) {
        console.log('⚠️ 이미 제출 중입니다.');
        return;
    }
    
    // UI 상태 변경
    setSubmittingState(true, submitBtn, loadingSpinner);
    
    // 서버로 데이터 전송
    submitClassCode(classCode, input)
        .then(response => {
            console.log('✅ 서버 응답:', response);
            handleSubmitSuccess(response, classCode);
        })
        .catch(error => {
            console.error('❌ 제출 실패:', error);
            handleSubmitError(error, codeForm);
        })
        .finally(() => {
            setSubmittingState(false, submitBtn, loadingSpinner);
        });
}

/**
 * 입력값 실시간 변경 처리
 */
function handleInputChange(e, codeForm) {
    const value = e.target.value.trim();
    
    // 대문자로 자동 변환
    if (value !== e.target.value.toUpperCase()) {
        e.target.value = value.toUpperCase();
    }
    
    // 실시간 검증 (너무 짧거나 긴 경우만)
    if (value.length > 0) {
        codeForm.classList.remove('invalid');
        if (value.length >= 3 && value.length <= 10) {
            codeForm.classList.add('valid');
        } else {
            codeForm.classList.remove('valid');
        }
    } else {
        codeForm.classList.remove('valid', 'invalid');
    }
}

/**
 * 수업 코드 입력값 검증
 */
function validateCodeInput(classCode, codeForm, showMessage = false) {
    console.log('🔍 코드 검증:', classCode);
    
    // 빈 값 체크
    if (!classCode) {
        if (showMessage) {
            showErrorMessage('수업 코드를 입력해주세요.');
            shakeForm(codeForm);
        }
        codeForm.classList.add('invalid');
        codeForm.classList.remove('valid');
        return false;
    }
    
    // 길이 체크 (3-10자)
    if (classCode.length < 3 || classCode.length > 10) {
        if (showMessage) {
            showErrorMessage('수업 코드는 3-10자 사이여야 합니다.');
            shakeForm(codeForm);
        }
        codeForm.classList.add('invalid');
        codeForm.classList.remove('valid');
        return false;
    }
    
    // 문자와 숫자만 허용
    const codePattern = /^[A-Z0-9]+$/;
    if (!codePattern.test(classCode)) {
        if (showMessage) {
            showErrorMessage('수업 코드는 영문 대문자와 숫자만 사용할 수 있습니다.');
            shakeForm(codeForm);
        }
        codeForm.classList.add('invalid');
        codeForm.classList.remove('valid');
        return false;
    }
    
    // 검증 통과
    codeForm.classList.remove('invalid');
    codeForm.classList.add('valid');
    console.log('✅ 코드 검증 통과');
    return true;
}

/**
 * 서버로 수업 코드 제출
 */
async function submitClassCode(classCode, input) {
    console.log('🌐 서버로 수업 코드 전송:', classCode);
    
    try {
        const response = await fetch('/ClinkProject/enterRoom.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: `action=join&classCode=${encodeURIComponent(classCode)}`
        });
        
        console.log('📡 Response status:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const contentType = response.headers.get('content-type');
        
        // JSON 응답 처리
        if (contentType && contentType.includes('application/json')) {
            const data = await response.json();
            console.log('📄 JSON 응답:', data);
            return data;
        }
        
        // HTML 응답 처리 (리다이렉트된 경우)
        const html = await response.text();
        console.log('📄 HTML 응답 수신');
        
        // 성공적인 리다이렉트로 간주
        return {
            success: true,
            message: '수업에 성공적으로 참여했습니다.',
            redirectUrl: `/ClinkProject/classJoin.do?classCode=${classCode}`
        };
        
    } catch (error) {
        console.error('🚨 네트워크 오류:', error);
        throw new Error('네트워크 연결에 문제가 발생했습니다. 다시 시도해주세요.');
    }
}

/**
 * 제출 성공 처리
 */
function handleSubmitSuccess(response, classCode) {
    console.log('🎉 제출 성공 처리:', response);
    
    if (response.success) {
        showSuccessMessage(response.message || '수업에 참여했습니다!');
        
        // 1.5초 후 수업 페이지로 이동
        setTimeout(() => {
            const redirectUrl = response.redirectUrl || `/ClinkProject/classJoin.do?classCode=${classCode}`;
            console.log('🔄 페이지 이동:', redirectUrl);
            window.location.href = redirectUrl;
        }, 1500);
        
    } else {
        // 서버에서 실패 응답
        throw new Error(response.message || '수업 참여에 실패했습니다.');
    }
}

/**
 * 제출 실패 처리
 */
function handleSubmitError(error, codeForm) {
    console.error('💥 제출 실패 처리:', error);
    
    let errorMessage = '수업 참여 중 오류가 발생했습니다.';
    
    if (error.message.includes('존재하지 않는')) {
        errorMessage = '존재하지 않는 수업 코드입니다. 다시 확인해주세요.';
    } else if (error.message.includes('이미 참여')) {
        errorMessage = '이미 참여 중인 수업입니다.';
    } else if (error.message.includes('정원')) {
        errorMessage = '수업 정원이 초과되었습니다.';
    } else if (error.message.includes('네트워크')) {
        errorMessage = error.message;
    }
    
    showErrorMessage(errorMessage);
    shakeForm(codeForm);
}

/**
 * 제출 상태 UI 변경
 */
function setSubmittingState(isSubmitting, submitBtn, loadingSpinner) {
    if (isSubmitting) {
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.7';
        if (loadingSpinner) {
            loadingSpinner.classList.add('show');
        }
        console.log('🔄 제출 중 상태 활성화');
    } else {
        submitBtn.disabled = false;
        submitBtn.style.opacity = '1';
        if (loadingSpinner) {
            loadingSpinner.classList.remove('show');
        }
        console.log('✅ 제출 중 상태 해제');
    }
}

/**
 * 폼 흔들기 애니메이션
 */
function shakeForm(codeForm) {
    codeForm.classList.add('shake');
    setTimeout(() => {
        codeForm.classList.remove('shake');
    }, 500);
}

/**
 * 에러 메시지 표시
 */
function showErrorMessage(message) {
    console.log('❌ 에러 메시지 표시:', message);
    
    // 기존 메시지 제거
    removeExistingMessages();
    
    // 새 에러 메시지 생성
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        ${message}
    `;
    
    // 코드 컨테이너에 삽입
    const codeContainer = document.querySelector('.code-container');
    const codeForm = document.querySelector('.code-form');
    codeContainer.insertBefore(errorDiv, codeForm);
    
    // 3초 후 자동 제거
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.remove();
        }
    }, 5000);
}

/**
 * 성공 메시지 표시
 */
function showSuccessMessage(message) {
    console.log('✅ 성공 메시지 표시:', message);
    
    // 기존 메시지 제거
    removeExistingMessages();
    
    // 새 성공 메시지 생성
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        ${message}
    `;
    
    // 코드 컨테이너에 삽입
    const codeContainer = document.querySelector('.code-container');
    const codeForm = document.querySelector('.code-form');
    codeContainer.insertBefore(successDiv, codeForm);
}

/**
 * 기존 메시지 제거
 */
function removeExistingMessages() {
    const existingMessages = document.querySelectorAll('.error-message, .success-message');
    existingMessages.forEach(msg => {
        if (msg.parentNode) {
            msg.remove();
        }
    });
}

/**
 * URL 파라미터 처리
 */
function handleUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    const success = urlParams.get('success');
    const classCode = urlParams.get('classCode');
    
    if (error) {
        console.log('🔗 URL에서 에러 파라미터 감지:', error);
        let errorMessage = '오류가 발생했습니다.';
        
        switch (error) {
            case 'invalid_code':
                errorMessage = '잘못된 수업 코드입니다.';
                break;
            case 'not_found':
                errorMessage = '존재하지 않는 수업 코드입니다.';
                break;
            case 'already_joined':
                errorMessage = '이미 참여 중인 수업입니다.';
                break;
            case 'full':
                errorMessage = '수업 정원이 초과되었습니다.';
                break;
            case 'login_required':
                errorMessage = '로그인이 필요합니다.';
                break;
        }
        
        showErrorMessage(errorMessage);
    }
    
    if (success) {
        console.log('🔗 URL에서 성공 파라미터 감지:', success);
        showSuccessMessage('수업에 성공적으로 참여했습니다!');
    }
    
    if (classCode) {
        console.log('🔗 URL에서 클래스 코드 파라미터 감지:', classCode);
        const input = document.getElementById('classCodeInput');
        if (input) {
            input.value = classCode.toUpperCase();
            input.focus();
        }
    }
}

// 전역 함수로 내보내기 (다른 스크립트에서 사용 가능)
window.EnterRoom = {
    validateCodeInput,
    showErrorMessage,
    showSuccessMessage,
    removeExistingMessages
};	