/**
 * enterClass.js - 교수용 수업관리 완전 작동 JavaScript
 * 🎯 새 수업 만들기, 탭 전환, 모달 관리, 수업 삭제 기능
 */

console.log('🏫 enterClass.js 로드 시작...');

// 전역 변수
let isSubmitting = false; // 중복 제출 방지
let deleteTargetCode = null; // 삭제할 수업 코드

// DOM 로드 완료 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    console.log('🏫 교수용 대시보드 초기화 시작');
    
    // 초기화 함수들 실행
    initTabSystem();
    initModals();
    initFormValidation();
    initClassCodeGeneration();
    initDeleteModal();
    
    console.log('✅ 교수용 대시보드 초기화 완료');
});

// ============================================
// 탭 시스템 관리
// ============================================

/**
 * 탭 시스템 초기화
 */
function initTabSystem() {
    console.log('📋 탭 시스템 초기화');
    
    const tabs = document.querySelectorAll('.tab');
    const classLists = document.querySelectorAll('.class-list');
    
    if (tabs.length === 0) {
        console.warn('⚠️ 탭 요소를 찾을 수 없습니다');
        return;
    }
    
    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            const targetTab = this.dataset.tab;
            console.log('📋 탭 전환:', targetTab);
            
            // 모든 탭에서 active 클래스 제거
            tabs.forEach(function(t) {
                t.classList.remove('active');
            });
            
            // 클릭된 탭에 active 클래스 추가
            this.classList.add('active');
            
            // 모든 수업 목록 숨기기
            classLists.forEach(function(list) {
                list.classList.add('hidden');
            });
            
            // 선택된 탭에 해당하는 수업 목록 표시
            const targetList = document.getElementById(targetTab + 'Classes');
            if (targetList) {
                targetList.classList.remove('hidden');
            }
        });
    });
}

// ============================================
// 모달 시스템 관리
// ============================================

/**
 * 모달 시스템 초기화
 */
function initModals() {
    console.log('🔧 모달 시스템 초기화');
    
    // 새 수업 추가 모달
    const addClassBtn = document.getElementById('openAddClassModal');
    const addClassModal = document.getElementById('addClassModal');
    const closeModalBtn = document.getElementById('closeModal');
    const cancelModalBtn = document.getElementById('cancelModal');
    
    if (addClassBtn && addClassModal) {
        // 모달 열기
        addClassBtn.addEventListener('click', function() {
            console.log('➕ 새 수업 추가 모달 열기');
            openModal(addClassModal);
            generateClassCode(); // 모달 열 때마다 새 코드 생성
        });
        
        // 모달 닫기
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', function() {
                closeModal(addClassModal);
            });
        }
        
        if (cancelModalBtn) {
            cancelModalBtn.addEventListener('click', function() {
                closeModal(addClassModal);
            });
        }
        
        // 모달 바깥 클릭시 닫기
        addClassModal.addEventListener('click', function(e) {
            if (e.target === addClassModal) {
                closeModal(addClassModal);
            }
        });
    }
}

/**
 * 모달 열기
 */
function openModal(modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

/**
 * 모달 닫기
 */
function closeModal(modal) {
    modal.classList.remove('show');
    document.body.style.overflow = '';
    
    // 폼 초기화
    const form = modal.querySelector('form');
    if (form) {
        form.reset();
        clearFormErrors(form);
    }
    
    // 제출 상태 초기화
    isSubmitting = false;
    const saveBtn = document.getElementById('saveClass');
    if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = '저장';
    }
}

// ============================================
// 폼 검증 시스템
// ============================================

/**
 * 폼 검증 시스템 초기화
 */
function initFormValidation() {
    console.log('✅ 폼 검증 시스템 초기화');
    
    const saveClassBtn = document.getElementById('saveClass');
    const newClassForm = document.getElementById('newClassForm');
    
    if (saveClassBtn && newClassForm) {
        saveClassBtn.addEventListener('click', function() {
            handleFormSubmit();
        });
        
        // 실시간 검증
        setupRealTimeValidation(newClassForm);
    }
}

/**
 * 실시간 검증 설정
 */
function setupRealTimeValidation(form) {
    // 수업명 검증
    const classNameInput = form.querySelector('#className');
    if (classNameInput) {
        classNameInput.addEventListener('blur', function() {
            validateClassName(this.value);
        });
    }
    
    // 날짜 검증
    const startDateInput = form.querySelector('#classStartDate');
    const endDateInput = form.querySelector('#classEndDate');
    
    if (startDateInput && endDateInput) {
        startDateInput.addEventListener('change', function() {
            validateDateRange(startDateInput.value, endDateInput.value);
        });
        
        endDateInput.addEventListener('change', function() {
            validateDateRange(startDateInput.value, endDateInput.value);
        });
    }
    
    // 시간 검증
    const startTimeInput = form.querySelector('#classStartTime');
    const endTimeInput = form.querySelector('#classEndTime');
    
    if (startTimeInput && endTimeInput) {
        startTimeInput.addEventListener('change', function() {
            validateTimeRange(startTimeInput.value, endTimeInput.value);
        });
        
        endTimeInput.addEventListener('change', function() {
            validateTimeRange(startTimeInput.value, endTimeInput.value);
        });
    }
}

/**
 * 수업명 검증
 */
function validateClassName(className) {
    const trimmed = className.trim();
    
    if (trimmed.length < 2) {
        showFieldError('className', '수업명은 2자 이상 입력해주세요.');
        return false;
    }
    
    if (trimmed.length > 100) {
        showFieldError('className', '수업명은 100자 이하로 입력해주세요.');
        return false;
    }
    
    clearFieldError('className');
    return true;
}

/**
 * 날짜 범위 검증
 */
function validateDateRange(startDate, endDate) {
    if (!startDate || !endDate) return true;
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (start < today) {
        showFieldError('classStartDate', '시작일은 오늘 이후로 설정해주세요.');
        return false;
    }
    
    if (end <= start) {
        showFieldError('classEndDate', '종료일은 시작일보다 늦은 날짜로 설정해주세요.');
        return false;
    }
    
    // 수업 기간이 너무 긴지 확인 (1년 이내)
    const oneYear = 365 * 24 * 60 * 60 * 1000;
    if (end - start > oneYear) {
        showFieldError('classEndDate', '수업 기간은 1년을 초과할 수 없습니다.');
        return false;
    }
    
    clearFieldError('classStartDate');
    clearFieldError('classEndDate');
    return true;
}

/**
 * 시간 범위 검증
 */
function validateTimeRange(startTime, endTime) {
    if (!startTime || !endTime) return true;
    
    const start = new Date('2000-01-01 ' + startTime);
    const end = new Date('2000-01-01 ' + endTime);
    
    if (end <= start) {
        showFieldError('classEndTime', '종료 시간은 시작 시간보다 늦은 시간으로 설정해주세요.');
        return false;
    }
    
    // 수업 시간이 너무 긴지 확인 (8시간 이내)
    const maxDuration = 8 * 60 * 60 * 1000; // 8시간
    if (end - start > maxDuration) {
        showFieldError('classEndTime', '수업 시간은 8시간을 초과할 수 없습니다.');
        return false;
    }
    
    clearFieldError('classStartTime');
    clearFieldError('classEndTime');
    return true;
}

/**
 * 수업 요일 검증
 */
function validateClassDays() {
    const checkboxes = document.querySelectorAll('input[name="classDays"]:checked');
    
    if (checkboxes.length === 0) {
        showFieldError('classDays', '최소 하나의 수업 요일을 선택해주세요.');
        return false;
    }
    
    clearFieldError('classDays');
    return true;
}

/**
 * 필드 에러 표시
 */
function showFieldError(fieldName, message) {
    const field = document.getElementById(fieldName) || document.querySelector(`input[name="${fieldName}"]`);
    if (!field) return;
    
    // 기존 에러 메시지 제거
    clearFieldError(fieldName);
    
    // 필드에 에러 스타일 추가
    field.style.borderColor = '#FF5252';
    
    // 에러 메시지 생성
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.style.color = '#FF5252';
    errorDiv.style.fontSize = '12px';
    errorDiv.style.marginTop = '5px';
    errorDiv.textContent = message;
    
    // 에러 메시지 삽입
    const formGroup = field.closest('.form-group');
    if (formGroup) {
        formGroup.appendChild(errorDiv);
    }
}

/**
 * 필드 에러 제거
 */
function clearFieldError(fieldName) {
    const field = document.getElementById(fieldName) || document.querySelector(`input[name="${fieldName}"]`);
    if (!field) return;
    
    // 필드 스타일 초기화
    field.style.borderColor = '';
    
    // 에러 메시지 제거
    const formGroup = field.closest('.form-group');
    if (formGroup) {
        const errorDiv = formGroup.querySelector('.field-error');
        if (errorDiv) {
            errorDiv.remove();
        }
    }
}

/**
 * 모든 폼 에러 제거
 */
function clearFormErrors(form) {
    const errorDivs = form.querySelectorAll('.field-error');
    errorDivs.forEach(div => div.remove());
    
    const inputs = form.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        input.style.borderColor = '';
    });
}

// ============================================
// 수업 코드 생성
// ============================================

/**
 * 수업 코드 생성 시스템 초기화
 */
function initClassCodeGeneration() {
    console.log('🔢 수업 코드 생성 시스템 초기화');
    
    const classNameInput = document.getElementById('className');
    if (classNameInput) {
        classNameInput.addEventListener('input', function() {
            generateClassCode();
        });
    }
}

/**
 * 수업 코드 자동 생성
 */
function generateClassCode() {
    const classNameInput = document.getElementById('className');
    const classCodeInput = document.getElementById('classCode');
    
    if (!classNameInput || !classCodeInput) return;
    
    const className = classNameInput.value.trim();
    let code = '';
    
    if (className.length > 0) {
        // 수업명에서 알파벳만 추출
        const alphabets = className.match(/[A-Za-z]/g);
        
        if (alphabets && alphabets.length >= 3) {
            // 처음 3글자 사용
            code = alphabets.slice(0, 3).join('').toUpperCase();
        } else if (alphabets) {
            // 알파벳이 3개 미만이면 반복하여 3자리 만들기
            while (code.length < 3) {
                code += alphabets.join('').toUpperCase();
            }
            code = code.substring(0, 3);
        } else {
            // 알파벳이 없으면 기본값
            code = 'CLS';
        }
        
        // 3자리 숫자 추가
        const randomNum = Math.floor(Math.random() * 900) + 100; // 100-999
        code += randomNum;
    } else {
        // 기본 코드
        const randomNum = Math.floor(Math.random() * 900) + 100;
        code = 'CLS' + randomNum;
    }
    
    classCodeInput.value = code;
    console.log('🔢 생성된 수업 코드:', code);
}

// ============================================
// 폼 제출 처리
// ============================================

/**
 * 폼 제출 처리
 */
async function handleFormSubmit() {
    if (isSubmitting) {
        console.log('⚠️ 이미 제출 중입니다.');
        return;
    }
    
    console.log('📤 새 수업 생성 폼 제출 시작');
    
    // 폼 검증
    if (!validateForm()) {
        console.log('❌ 폼 검증 실패');
        return;
    }
    
    // 제출 상태 설정
    isSubmitting = true;
    const saveBtn = document.getElementById('saveClass');
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.textContent = '저장 중...';
    }
    
    try {
        const formData = collectFormData();
        console.log('📋 수집된 폼 데이터:', formData);
        
        const response = await submitNewClass(formData);
        console.log('✅ 서버 응답:', response);
        
        if (response.success) {
            showSuccessMessage('새 수업이 성공적으로 생성되었습니다!');
            
            // 모달 닫기
            setTimeout(() => {
                const modal = document.getElementById('addClassModal');
                closeModal(modal);
                
                // 페이지 새로고침
                window.location.reload();
            }, 1500);
        } else {
            throw new Error(response.message || '수업 생성에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('💥 수업 생성 실패:', error);
        showErrorMessage(error.message || '수업 생성 중 오류가 발생했습니다.');
    } finally {
        // 제출 상태 초기화
        isSubmitting = false;
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.textContent = '저장';
        }
    }
}

/**
 * 전체 폼 검증
 */
function validateForm() {
    const form = document.getElementById('newClassForm');
    if (!form) return false;
    
    let isValid = true;
    
    // 개별 필드 검증
    const className = form.querySelector('#className').value.trim();
    const startDate = form.querySelector('#classStartDate').value;
    const endDate = form.querySelector('#classEndDate').value;
    const startTime = form.querySelector('#classStartTime').value;
    const endTime = form.querySelector('#classEndTime').value;
    
    if (!validateClassName(className)) isValid = false;
    if (!validateDateRange(startDate, endDate)) isValid = false;
    if (!validateTimeRange(startTime, endTime)) isValid = false;
    if (!validateClassDays()) isValid = false;
    
    // 필수 필드 확인
    const requiredFields = [
        { id: 'className', name: '수업명' },
        { id: 'classStartDate', name: '시작일' },
        { id: 'classEndDate', name: '종료일' },
        { id: 'classStartTime', name: '시작 시간' },
        { id: 'classEndTime', name: '종료 시간' }
    ];
    
    requiredFields.forEach(field => {
        const input = form.querySelector('#' + field.id);
        if (!input.value.trim()) {
            showFieldError(field.id, field.name + '을(를) 입력해주세요.');
            isValid = false;
        }
    });
    
    return isValid;
}

/**
 * 폼 데이터 수집
 */
function collectFormData() {
    const form = document.getElementById('newClassForm');
    const formData = new FormData(form);
    
    // 수업 요일 처리
    const selectedDays = [];
    const dayCheckboxes = form.querySelectorAll('input[name="classDays"]:checked');
    dayCheckboxes.forEach(checkbox => {
        selectedDays.push(checkbox.value);
    });
    
    // JavaScript 객체로 변환
    const data = {
        className: formData.get('className').trim(),
        description: formData.get('description') ? formData.get('description').trim() : '',
        startDate: formData.get('startDate'),
        endDate: formData.get('endDate'),
        startTime: formData.get('startTime'),
        endTime: formData.get('endTime'),
        classDays: selectedDays.join(','),
        maxStudents: formData.get('maxStudents') || '50',
        classCode: formData.get('classCode')
    };
    
    return data;
}

/**
 * 서버로 새 수업 데이터 전송
 */
async function submitNewClass(data) {
    const response = await fetch('/ClinkProject/class/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(data)
    });
    
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
        return await response.json();
    } else {
        // JSON이 아닌 응답의 경우
        const text = await response.text();
        console.log('서버 응답 (텍스트):', text);
        
        // 성공으로 간주
        return {
            success: true,
            message: '수업이 성공적으로 생성되었습니다.'
        };
    }
}

// ============================================
// 수업 삭제 기능
// ============================================

/**
 * 삭제 모달 초기화
 */
function initDeleteModal() {
    console.log('🗑️ 삭제 모달 시스템 초기화');
    
    const deleteModal = document.getElementById('deleteClassModal');
    const deleteClassName = document.getElementById('deleteClassName');
    const cancelDeleteBtn = document.getElementById('cancelDelete');
    const confirmDeleteBtn = document.getElementById('confirmDelete');
    
    // 삭제 버튼들에 이벤트 리스너 추가
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('delete-btn') || e.target.closest('.delete-btn')) {
            const deleteBtn = e.target.classList.contains('delete-btn') ? e.target : e.target.closest('.delete-btn');
            const classNameToDelete = deleteBtn.getAttribute('data-class-name');
            const classCodeToDelete = deleteBtn.getAttribute('data-class-code');
            
            if (classNameToDelete && classCodeToDelete) {
                showDeleteModal(classNameToDelete, classCodeToDelete);
            }
        }
    });
    
    // 삭제 취소
    if (cancelDeleteBtn) {
        cancelDeleteBtn.addEventListener('click', function() {
            closeDeleteModal();
        });
    }
    
    // 삭제 확인
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener('click', function() {
            handleClassDelete();
        });
    }
    
    // 모달 바깥 클릭시 닫기
    if (deleteModal) {
        deleteModal.addEventListener('click', function(e) {
            if (e.target === deleteModal) {
                closeDeleteModal();
            }
        });
    }
}

/**
 * 삭제 모달 표시
 */
function showDeleteModal(className, classCode) {
    console.log('🗑️ 삭제 모달 표시:', className, classCode);
    
    const deleteModal = document.getElementById('deleteClassModal');
    const deleteClassName = document.getElementById('deleteClassName');
    
    if (deleteModal && deleteClassName) {
        deleteClassName.textContent = className;
        deleteTargetCode = classCode;
        deleteModal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

/**
 * 삭제 모달 닫기
 */
function closeDeleteModal() {
    const deleteModal = document.getElementById('deleteClassModal');
    if (deleteModal) {
        deleteModal.classList.remove('show');
        document.body.style.overflow = '';
        deleteTargetCode = null;
    }
}

/**
 * 수업 삭제 처리
 */
async function handleClassDelete() {
    if (!deleteTargetCode) {
        console.error('❌ 삭제할 수업 코드가 없습니다.');
        return;
    }
    
    const confirmBtn = document.getElementById('confirmDelete');
    
    try {
        // 버튼 상태 변경
        if (confirmBtn) {
            confirmBtn.disabled = true;
            confirmBtn.textContent = '삭제 중...';
        }
        
        console.log('🗑️ 수업 삭제 요청:', deleteTargetCode);
        
        const response = await fetch(`/ClinkProject/class/delete`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ classCode: deleteTargetCode })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            showSuccessMessage('수업이 성공적으로 삭제되었습니다.');
            closeDeleteModal();
            
            // 페이지 새로고침
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            throw new Error(result.message || '수업 삭제에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('💥 수업 삭제 실패:', error);
        showErrorMessage(error.message || '수업 삭제 중 오류가 발생했습니다.');
    } finally {
        // 버튼 상태 복원
        if (confirmBtn) {
            confirmBtn.disabled = false;
            confirmBtn.textContent = '삭제';
        }
    }
}

// ============================================
// 수업 코드 복사 기능
// ============================================

/**
 * 수업 코드 클립보드에 복사
 */
function copyClassCode(classCode) {
    if (!classCode) return;
    
    if (navigator.clipboard && navigator.clipboard.writeText) {
        // 최신 브라우저
        navigator.clipboard.writeText(classCode).then(function() {
            showSuccessMessage(`수업 코드 "${classCode}"가 클립보드에 복사되었습니다.`);
        }).catch(function(error) {
            console.error('클립보드 복사 실패:', error);
            fallbackCopyToClipboard(classCode);
        });
    } else {
        // 폴백 방법
        fallbackCopyToClipboard(classCode);
    }
}

/**
 * 폴백 클립보드 복사
 */
function fallbackCopyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.left = '-999999px';
    textarea.style.top = '-999999px';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    try {
        const successful = document.execCommand('copy');
        if (successful) {
            showSuccessMessage(`수업 코드 "${text}"가 클립보드에 복사되었습니다.`);
        } else {
            showErrorMessage('클립보드 복사에 실패했습니다.');
        }
    } catch (error) {
        console.error('폴백 복사 실패:', error);
        showErrorMessage('클립보드 복사에 실패했습니다.');
    }
    
    document.body.removeChild(textarea);
}

// ============================================
// 메시지 표시 함수들
// ============================================

/**
 * 성공 메시지 표시
 */
function showSuccessMessage(message) {
    console.log('✅ 성공:', message);
    
    // 기존 메시지 제거
    removeExistingMessages();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
    
    // 페이지 제목 아래에 삽입
    const pageTitle = document.querySelector('.page-title');
    if (pageTitle) {
        pageTitle.insertAdjacentElement('afterend', messageDiv);
    }
    
    // 3초 후 자동 제거
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 3000);
}

/**
 * 에러 메시지 표시
 */
function showErrorMessage(message) {
    console.error('❌ 에러:', message);
    
    // 기존 메시지 제거
    removeExistingMessages();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'error-message';
    messageDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
    
    // 페이지 제목 아래에 삽입
    const pageTitle = document.querySelector('.page-title');
    if (pageTitle) {
        pageTitle.insertAdjacentElement('afterend', messageDiv);
    }
    
    // 5초 후 자동 제거
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 5000);
}

/**
 * 기존 메시지 제거
 */
function removeExistingMessages() {
    const existingMessages = document.querySelectorAll('.success-message, .error-message');
    existingMessages.forEach(msg => {
        if (msg.parentNode) {
            msg.remove();
        }
    });
}

// ============================================
// 전역 함수 노출
// ============================================

// 전역 스코프에 함수 노출 (JSP에서 호출 가능)
window.copyClassCode = copyClassCode;
window.showSuccessMessage = showSuccessMessage;
window.showErrorMessage = showErrorMessage;

// ============================================
// 디버깅 및 개발자 도구
// ============================================

// 개발 모드에서만 사용
if (window.location.hostname === 'localhost') {
    window.enterClassDebug = {
        generateClassCode,
        validateForm,
        collectFormData,
        showDeleteModal,
        copyClassCode
    };
    
    console.log('🔧 개발자 도구 사용 가능: window.enterClassDebug');
}

console.log('✅ enterClass.js 로드 완료');