/* ========================================== */
/* classJoin.js - 수업 참여 페이지 JavaScript (최종 완성 버전) */
/* ========================================== */

// 전역 변수
let currentTab = 'qa';
let classData = {};
let questionPolling = null;
let isSubmitting = false;

// DOM이 로드되면 초기화
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎯 classJoin.js 로드 완료');
    initClassJoin();
});

/**
 * 수업 참여 페이지 초기화
 */
function initClassJoin() {
    console.log('🚀 classJoin 페이지 초기화 시작...');
    
    // 전역 데이터 확인
    if (window.classData) {
        classData = window.classData;
        console.log('📋 수업 데이터:', classData);
    } else {
        console.error('❌ 수업 데이터를 찾을 수 없습니다.');
        showError('수업 정보를 불러올 수 없습니다.');
        return;
    }
    
    // 이벤트 리스너 설정
    setupEventListeners();
    
    // 초기 탭 설정
    initializeTabs();
    
    // Q&A 기능 초기화
    initializeQA();
    
    // 과제/투표 기능 초기화
    initializeAssignments();
    
    // 파일 기능 초기화
    initializeFiles();
    
    // 실시간 업데이트 시작
    startRealTimeUpdates();
    
    console.log('🎉 classJoin 페이지 초기화 완료');
}

/**
 * 이벤트 리스너 설정
 */
function setupEventListeners() {
    console.log('🔧 이벤트 리스너 설정 시작...');
    
    // 탭 전환
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });
    
    // Q&A 관련
    const questionInput = document.getElementById('questionInput');
    const submitQuestionBtn = document.getElementById('submitQuestion');
    
    if (questionInput && submitQuestionBtn) {
        questionInput.addEventListener('input', function() {
            const isEmpty = this.value.trim().length === 0;
            submitQuestionBtn.disabled = isEmpty;
        });
        
        submitQuestionBtn.addEventListener('click', submitQuestion);
        
        // 엔터 키로 질문 제출 (Ctrl+Enter)
        questionInput.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                if (!submitQuestionBtn.disabled) {
                    submitQuestion();
                }
            }
        });
    }
    
    // 파일 업로드 관련
    const fileInput = document.getElementById('fileInput');
    const uploadZone = document.getElementById('uploadZone');
    
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
        console.log('✅ 파일 입력 이벤트 설정됨');
    }
    
    if (uploadZone) {
        // 드래그 앤 드롭
        uploadZone.addEventListener('dragover', handleDragOver);
        uploadZone.addEventListener('dragleave', handleDragLeave);
        uploadZone.addEventListener('drop', handleFileDrop);
        
        // 클릭으로 파일 선택
        uploadZone.addEventListener('click', function() {
            if (fileInput) {
                fileInput.click();
            }
        });
        
        console.log('✅ 업로드 존 이벤트 설정됨');
    }
    
    console.log('✅ 이벤트 리스너 설정 완료');
}

/**
 * 탭 초기화
 */
function initializeTabs() {
    console.log('📑 탭 초기화...');
    // 첫 번째 탭을 활성화
    switchTab('qa');
}

/**
 * 탭 전환
 */
function switchTab(tabName) {
    console.log('🔄 탭 전환:', tabName);
    
    // 모든 탭 버튼에서 active 클래스 제거
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(function(btn) {
        btn.classList.remove('active');
    });
    
    // 모든 섹션 숨김
    const sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active');
    });
    
    // 선택된 탭과 섹션 활성화
    const selectedTab = document.querySelector('[data-tab="' + tabName + '"]');
    const selectedSection = document.getElementById(tabName + '-section');
    
    if (selectedTab && selectedSection) {
        selectedTab.classList.add('active');
        selectedSection.classList.add('active');
        currentTab = tabName;
        
        // 탭별 초기화 로직
        switch (tabName) {
            case 'qa':
                refreshQuestions();
                break;
            case 'assignment':
                refreshAssignments();
                break;
            case 'files':
                refreshFiles();
                break;
        }
    } else {
        console.warn('⚠️ 탭 요소를 찾을 수 없습니다:', tabName);
    }
}

/**
 * Q&A 기능 초기화
 */
function initializeQA() {
    console.log('📝 Q&A 기능 초기화...');
    
    // 교수용 필터 이벤트
    const questionFilter = document.getElementById('questionFilter');
    if (questionFilter) {
        questionFilter.addEventListener('change', function() {
            filterQuestions(this.value);
        });
    }
}

/**
 * 질문 제출
 */
async function submitQuestion() {
    if (isSubmitting) {
        console.log('⚠️ 이미 제출 중입니다');
        return;
    }
    
    const questionInput = document.getElementById('questionInput');
    const anonymousCheck = document.getElementById('anonymousCheck');
    const submitBtn = document.getElementById('submitQuestion');
    
    if (!questionInput || !submitBtn) {
        console.error('❌ 질문 입력 요소를 찾을 수 없습니다');
        showError('페이지 오류가 발생했습니다.');
        return;
    }
    
    const questionText = questionInput.value.trim();
    const isAnonymous = anonymousCheck ? anonymousCheck.checked : false;
    
    if (!questionText) {
        showError('질문을 입력해주세요.');
        questionInput.focus();
        return;
    }
    
    if (questionText.length > 1000) {
        showError('질문은 1000자 이내로 입력해주세요.');
        return;
    }
    
    console.log('📤 질문 제출 시도:', { questionText: questionText, isAnonymous: isAnonymous });
    
    try {
        isSubmitting = true;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 제출 중...';
        
        const response = await fetch(classData.contextPath + '/classJoin.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                action: 'submitQuestion',
                classCode: classData.classCode,
                questionText: questionText,
                isAnonymous: isAnonymous
            })
        });
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status + ': ' + response.statusText);
        }
        
        const result = await response.json();
        
        if (result.success) {
            console.log('✅ 질문 제출 성공');
            showSuccess('질문이 제출되었습니다.');
            
            // 폼 초기화
            questionInput.value = '';
            if (anonymousCheck) anonymousCheck.checked = false;
            
            // 질문 목록 새로고침
            await refreshQuestions();
            
        } else {
            throw new Error(result.message || '질문 제출에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 질문 제출 실패:', error);
        showError(error.message || '질문 제출 중 오류가 발생했습니다.');
    } finally {
        isSubmitting = false;
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> 질문 제출';
    }
}

/**
 * 질문 목록 새로고침
 */
async function refreshQuestions() {
    console.log('🔄 질문 목록 새로고침...');
    
    try {
        const response = await fetch(classData.contextPath + '/classJoin.do?action=getQuestions&classCode=' + classData.classCode, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        
        if (result.success) {
            updateQuestionsList(result.questions || []);
        } else {
            console.error('질문 목록 조회 실패:', result.message);
        }
        
    } catch (error) {
        console.error('❌ 질문 목록 새로고침 실패:', error);
    }
}

/**
 * 질문 목록 UI 업데이트
 */
function updateQuestionsList(questions) {
    const questionsList = document.getElementById('questionsList');
    if (!questionsList) {
        console.warn('⚠️ questionsList 요소를 찾을 수 없습니다');
        return;
    }
    
    console.log('📋 질문 목록 업데이트:', questions.length + '개');
    
    questionsList.innerHTML = '';
    
    if (questions.length === 0) {
        questionsList.innerHTML = 
            '<div class="empty-state">' +
                '<i class="fas fa-comments"></i>' +
                '<p>아직 질문이 없습니다.</p>' +
                '<p>궁금한 점이 있으면 언제든지 질문해 주세요!</p>' +
            '</div>';
        return;
    }
    
    questions.forEach(function(question) {
        const questionElement = createQuestionElement(question);
        questionsList.appendChild(questionElement);
    });
}

/**
 * 질문 요소 생성
 */
function createQuestionElement(question) {
    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-item';
    questionDiv.dataset.questionId = question.id;
    
    const authorName = question.isAnonymous ? '익명' : (question.authorName || '사용자');
    const authorIcon = question.isAnonymous ? 'fas fa-user-secret' : 'fas fa-user-circle';
    
    var html = '<div class="question-header">' +
        '<div class="question-author">' +
            '<i class="' + authorIcon + '"></i>' +
            '<span class="author-name">' + escapeHtml(authorName) + '</span>' +
            '<span class="question-time">' + formatTimeAgo(question.createdAt) + '</span>' +
        '</div>' +
        '<div class="question-meta">' +
            '<button class="vote-btn ' + (question.userVoted ? 'voted' : '') + '" data-votes="' + (question.voteCount || 0) + '" onclick="toggleQuestionVote(this, ' + question.id + ')">' +
                '<i class="fas fa-thumbs-up"></i>' +
                '<span>' + (question.voteCount || 0) + '</span>' +
            '</button>';
    
    if (classData.userRole === 'professor') {
        if (!question.answer) {
            html += '<button class="reply-btn" onclick="showAnswerForm(' + question.id + ')">' +
                        '<i class="fas fa-reply"></i> 답변' +
                    '</button>';
        }
        html += '<button class="delete-question-btn" onclick="deleteQuestion(' + question.id + ')">' +
                    '<i class="fas fa-times"></i>' +
                '</button>';
    }
    
    html += '</div>' +
        '</div>' +
        '<div class="question-text">' + escapeHtml(question.questionText || '') + '</div>';
    
    if (question.answer) {
        html += '<div class="answer">' +
            '<div class="answer-header">' +
                '<i class="fas fa-chalkboard-teacher"></i>' +
                '<span class="professor-name">' + escapeHtml(question.answer.professorName || '교수님') + '의 답변</span>' +
                '<span class="answer-time">' + formatTimeAgo(question.answer.createdAt) + '</span>' +
            '</div>' +
            '<div class="answer-text">' + escapeHtml(question.answer.answerText || '') + '</div>';
        
        if (classData.userRole === 'professor') {
            html += '<div class="answer-actions">' +
                '<button class="edit-answer-btn" onclick="editAnswer(' + question.id + ')">' +
                    '<i class="fas fa-edit"></i> 수정' +
                '</button>' +
                '<button class="delete-answer-btn" onclick="deleteAnswer(' + question.id + ')">' +
                    '<i class="fas fa-trash"></i> 삭제' +
                '</button>' +
            '</div>';
        }
        
        html += '</div>';
    }
    
    if (classData.userRole === 'professor') {
        html += '<div class="answer-form" style="display: none;" id="answerForm' + question.id + '">' +
            '<textarea class="answer-input" placeholder="답변을 입력하세요..." maxlength="2000"></textarea>' +
            '<div class="answer-form-actions">' +
                '<button class="cancel-answer-btn" onclick="cancelAnswer(' + question.id + ')">취소</button>' +
                '<button class="submit-answer-btn" onclick="submitAnswer(' + question.id + ')">답변 제출</button>' +
            '</div>' +
        '</div>';
    }
    
    questionDiv.innerHTML = html;
    
    return questionDiv;
}

/**
 * 질문 투표 토글
 */
async function toggleQuestionVote(button, questionId) {
    if (!button || !questionId) {
        console.error('❌ 투표 파라미터 누락');
        return;
    }
    
    const isVoted = button.classList.contains('voted');
    const voteCountSpan = button.querySelector('span');
    let currentCount = parseInt(voteCountSpan.textContent) || 0;
    
    try {
        // UI 즉시 업데이트 (낙관적 업데이트)
        if (isVoted) {
            button.classList.remove('voted');
            voteCountSpan.textContent = Math.max(0, currentCount - 1);
        } else {
            button.classList.add('voted');
            voteCountSpan.textContent = currentCount + 1;
        }
        
        const response = await fetch(classData.contextPath + '/classJoin.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                action: 'voteQuestion',
                questionId: questionId,
                classCode: classData.classCode
            })
        });
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        
        if (result.success) {
            // 서버 응답으로 정확한 투표 수 업데이트
            voteCountSpan.textContent = result.voteCount || 0;
            if (result.userVoted) {
                button.classList.add('voted');
            } else {
                button.classList.remove('voted');
            }
        } else {
            // 실패 시 원상 복구
            if (isVoted) {
                button.classList.add('voted');
                voteCountSpan.textContent = currentCount;
            } else {
                button.classList.remove('voted');
                voteCountSpan.textContent = currentCount;
            }
            showError(result.message || '투표 처리에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 질문 투표 실패:', error);
        
        // 실패 시 원상 복구
        if (isVoted) {
            button.classList.add('voted');
            voteCountSpan.textContent = currentCount;
        } else {
            button.classList.remove('voted');
            voteCountSpan.textContent = currentCount;
        }
        
        showError('투표 처리 중 오류가 발생했습니다.');
    }
}

/**
 * 답변 폼 표시 (교수용)
 */
function showAnswerForm(questionId) {
    const answerForm = document.getElementById('answerForm' + questionId);
    if (answerForm) {
        answerForm.style.display = 'block';
        const textarea = answerForm.querySelector('.answer-input');
        if (textarea) {
            textarea.focus();
        }
    }
}

/**
 * 답변 폼 취소 (교수용)
 */
function cancelAnswer(questionId) {
    const answerForm = document.getElementById('answerForm' + questionId);
    if (answerForm) {
        answerForm.style.display = 'none';
        const textarea = answerForm.querySelector('.answer-input');
        if (textarea) {
            textarea.value = '';
        }
    }
}

/**
 * 답변 제출 (교수용)
 */
async function submitAnswer(questionId) {
    const answerForm = document.getElementById('answerForm' + questionId);
    if (!answerForm) return;
    
    const textarea = answerForm.querySelector('.answer-input');
    const answerText = textarea.value.trim();
    
    if (!answerText) {
        showError('답변을 입력해주세요.');
        textarea.focus();
        return;
    }
    
    if (answerText.length > 2000) {
        showError('답변은 2000자 이내로 입력해주세요.');
        return;
    }
    
    const submitBtn = answerForm.querySelector('.submit-answer-btn');
    
    try {
        submitBtn.disabled = true;
        submitBtn.textContent = '제출 중...';
        
        const response = await fetch(classData.contextPath + '/classJoin.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                action: 'submitAnswer',
                questionId: questionId,
                answerText: answerText,
                classCode: classData.classCode
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('답변이 제출되었습니다.');
            await refreshQuestions();
        } else {
            throw new Error(result.message || '답변 제출에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 답변 제출 실패:', error);
        showError(error.message || '답변 제출 중 오류가 발생했습니다.');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = '답변 제출';
    }
}

/**
 * 질문 삭제 (교수용)
 */
async function deleteQuestion(questionId) {
    if (!confirm('이 질문을 삭제하시겠습니까?')) {
        return;
    }
    
    try {
        const response = await fetch(classData.contextPath + '/classJoin.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                action: 'deleteQuestion',
                questionId: questionId,
                classCode: classData.classCode
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('질문이 삭제되었습니다.');
            await refreshQuestions();
        } else {
            throw new Error(result.message || '질문 삭제에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 질문 삭제 실패:', error);
        showError(error.message || '질문 삭제 중 오류가 발생했습니다.');
    }
}

/**
 * 과제/투표 기능 초기화
 */
function initializeAssignments() {
    console.log('📊 과제/투표 기능 초기화...');
}

/**
 * 과제/투표 목록 새로고침
 */
async function refreshAssignments() {
    console.log('🔄 과제/투표 목록 새로고침...');
    
    try {
        const response = await fetch(classData.contextPath + '/classJoin.do?action=getAssignments&classCode=' + classData.classCode, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        
        if (result.success) {
            updateAssignmentsList(result.assignments || []);
            updatePollsList(result.polls || []);
        }
        
    } catch (error) {
        console.error('❌ 과제/투표 목록 새로고침 실패:', error);
    }
}

/**
 * 과제 목록 업데이트
 */
function updateAssignmentsList(assignments) {
    console.log('📋 과제 목록 업데이트:', assignments.length + '개');
    // TODO: 과제 목록 UI 업데이트 구현
}

/**
 * 투표 목록 업데이트
 */
function updatePollsList(polls) {
    console.log('📋 투표 목록 업데이트:', polls.length + '개');
    // TODO: 투표 목록 UI 업데이트 구현
}

/**
 * 투표 옵션 선택
 */
async function selectPollOption(optionElement) {
    const pollCard = optionElement.closest('.poll-card');
    if (!pollCard) return;
    
    const pollId = pollCard.dataset.pollId;
    const optionId = optionElement.dataset.option;
    
    // 같은 투표 내에서 다른 옵션들의 selected 클래스 제거
    pollCard.querySelectorAll('.poll-option').forEach(function(opt) {
        opt.classList.remove('selected');
    });
    
    // 선택된 옵션에 selected 클래스 추가
    optionElement.classList.add('selected');
    
    try {
        const response = await fetch(classData.contextPath + '/classJoin.do', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                action: 'votePoll',
                pollId: pollId,
                optionId: optionId,
                classCode: classData.classCode
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            updatePollResults(pollCard, result.pollResults || []);
            showSuccess('투표가 완료되었습니다.');
        } else {
            throw new Error(result.message || '투표에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 투표 실패:', error);
        showError(error.message || '투표 처리 중 오류가 발생했습니다.');
    }
}

/**
 * 투표 결과 업데이트
 */
function updatePollResults(pollCard, results) {
    const options = pollCard.querySelectorAll('.poll-option');
    const totalVotes = results.reduce(function(sum, result) {
        return sum + (result.votes || 0);
    }, 0);
    
    options.forEach(function(option, index) {
        if (results[index]) {
            const result = results[index];
            const percentage = totalVotes > 0 ? Math.round(((result.votes || 0) / totalVotes) * 100) : 0;
            
            const resultBar = option.querySelector('.poll-result-bar');
            const percentageSpan = option.querySelector('.option-percentage');
            
            if (resultBar) resultBar.style.width = percentage + '%';
            if (percentageSpan) percentageSpan.textContent = percentage + '%';
        }
    });
}

/**
 * 파일 기능 초기화
 */
function initializeFiles() {
    console.log('📁 파일 기능 초기화...');
}

/**
 * 파일 목록 새로고침 - 디버깅 강화 버전
 */
async function refreshFiles() {
    console.log('🔄 파일 목록 새로고침 시작...');
    console.log('현재 탭:', currentTab);
    console.log('classData:', classData);
    
    try {
        const url = classData.contextPath + '/classJoin.do?action=getFiles&classCode=' + classData.classCode;
        console.log('요청 URL:', url);
        
        const response = await fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        console.log('응답 상태:', response.status, response.statusText);
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        console.log('서버 응답 전체:', result);
        console.log('파일 데이터:', result.files);
        
        if (result.success) {
            console.log('✅ 서버에서 파일 목록 수신:', (result.files || []).length + '개');
            updateFilesList(result.files || []);
        } else {
            console.error('❌ 서버 오류:', result.message);
        }
        
    } catch (error) {
        console.error('❌ 파일 목록 새로고침 실패:', error);
    }
}

/**
 * 파일 목록 UI 업데이트 - 디버깅 강화 버전
 */
function updateFilesList(files) {
    console.log('📋 updateFilesList 호출됨');
    console.log('파일 데이터:', files);
    console.log('파일 개수:', files ? files.length : 'undefined');
    
    const filesList = document.getElementById('filesList');
    console.log('filesList 요소:', filesList);
    
    if (!filesList) {
        console.error('❌ filesList 요소를 찾을 수 없습니다!');
        
        // 다른 가능한 ID들 확인
        const alternatives = ['files-list', 'file-list', 'filesGrid', 'files-grid'];
        alternatives.forEach(function(id) {
            const element = document.getElementById(id);
            if (element) {
                console.log('대안 요소 발견:', id, element);
            }
        });
        
        return;
    }
    
    console.log('filesList 현재 내용:', filesList.innerHTML);
    
    // 기존 파일 목록 지우기
    filesList.innerHTML = '';
    console.log('기존 내용 지움');
    
    if (!files || files.length === 0) {
        const emptyHtml = 
            '<div class="empty-state" style="grid-column: 1 / -1; text-align: center; padding: 40px;">' +
                '<i class="fas fa-folder-open" style="font-size: 48px; color: #ccc; margin-bottom: 16px;"></i>' +
                '<p style="margin: 8px 0; color: #666;">공유된 자료가 없습니다.</p>' +
                (classData.userRole === 'professor' ? 
                    '<p style="margin: 8px 0; color: #999;">위의 업로드 영역을 통해 자료를 공유해보세요.</p>' : '') +
            '</div>';
        
        filesList.innerHTML = emptyHtml;
        console.log('빈 상태 HTML 설정 완료');
        return;
    }
    
    console.log('파일 카드 생성 시작...');
    
    // 각 파일에 대해 카드 생성
    files.forEach(function(file, index) {
        console.log('파일 ' + (index + 1) + ':', file);
        
        try {
            const fileCard = createFileCard(file);
            filesList.appendChild(fileCard);
            console.log('파일 카드 추가 완료:', file.originalFilename || file.filename);
        } catch (error) {
            console.error('파일 카드 생성 실패:', error);
        }
    });
    
    console.log('✅ 파일 목록 UI 업데이트 완료');
}

/**
 * 파일 카드 생성
 */
function createFileCard(file) {
    const fileCard = document.createElement('div');
    fileCard.className = 'file-card';
    fileCard.dataset.fileId = file.attachmentId || file.id;
    
    // 파일 확장자에 따른 아이콘 결정
    const fileExtension = getFileExtension(file.originalFilename || file.filename);
    const iconClass = getFileIconClass(fileExtension);
    const fileTypeClass = getFileTypeClass(fileExtension);
    
    // 파일 크기 포맷팅
    const fileSizeFormatted = formatFileSize(file.fileSize || file.size);
    
    // 업로드 날짜 포맷팅
    const uploadDate = formatDate(file.uploadedAt || file.createdAt);
    
    var html = 
        '<div class="file-icon ' + fileTypeClass + '">' +
            '<i class="fas ' + iconClass + '"></i>' +
        '</div>' +
        '<div class="file-info">' +
            '<div class="file-name" title="' + escapeHtml(file.originalFilename || file.filename) + '">' +
                escapeHtml(file.originalFilename || file.filename) +
            '</div>' +
            '<div class="file-meta">' +
                '<span class="file-size">' + fileSizeFormatted + '</span>' +
                '<span class="file-date">' + uploadDate + '</span>' +
            '</div>' +
            '<div class="file-stats">' +
                '<i class="fas fa-download"></i> ' + (file.downloadCount || 0) + '회' +
            '</div>' +
        '</div>' +
        '<div class="file-actions">' +
            '<button class="action-btn download" onclick="downloadFile(' + (file.attachmentId || file.id) + ')" title="다운로드">' +
                '<i class="fas fa-download"></i>' +
            '</button>';
    
    // 교수만 삭제 버튼 표시
    if (classData.userRole === 'professor') {
        html += '<button class="action-btn delete" onclick="deleteFile(' + (file.attachmentId || file.id) + ')" title="삭제">' +
                    '<i class="fas fa-trash"></i>' +
                '</button>';
    }
    
    html += '</div>';
    
    fileCard.innerHTML = html;
    
    return fileCard;
}

/**
 * 파일 확장자 추출
 */
function getFileExtension(filename) {
    if (!filename) return '';
    return filename.split('.').pop().toLowerCase();
}

/**
 * 파일 타입별 아이콘 클래스
 */
function getFileIconClass(extension) {
    const iconMap = {
        'pdf': 'fa-file-pdf',
        'doc': 'fa-file-word',
        'docx': 'fa-file-word',
        'ppt': 'fa-file-powerpoint',
        'pptx': 'fa-file-powerpoint',
        'xls': 'fa-file-excel',
        'xlsx': 'fa-file-excel',
        'zip': 'fa-file-archive',
        'rar': 'fa-file-archive',
        '7z': 'fa-file-archive',
        'jpg': 'fa-file-image',
        'jpeg': 'fa-file-image',
        'png': 'fa-file-image',
        'gif': 'fa-file-image',
        'txt': 'fa-file-alt',
        'hwp': 'fa-file-alt'
    };
    
    return iconMap[extension] || 'fa-file';
}

/**
 * 파일 타입별 CSS 클래스
 */
function getFileTypeClass(extension) {
    const typeMap = {
        'pdf': 'pdf',
        'doc': 'word',
        'docx': 'word',
        'ppt': 'powerpoint',
        'pptx': 'powerpoint',
        'xls': 'excel',
        'xlsx': 'excel',
        'zip': 'archive',
        'rar': 'archive',
        '7z': 'archive',
        'jpg': 'image',
        'jpeg': 'image',
        'png': 'image',
        'gif': 'image',
        'txt': 'text',
        'hwp': 'text'
    };
    
    return typeMap[extension] || 'default';
}

/**
 * 파일 크기 포맷팅
 */
function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
}

/**
 * 날짜 포맷팅
 */
function formatDate(dateString) {
    if (!dateString) return '';
    
    try {
        const date = new Date(dateString);
        return date.getFullYear() + '.' + 
               String(date.getMonth() + 1).padStart(2, '0') + '.' +
               String(date.getDate()).padStart(2, '0');
    } catch (error) {
        return '';
    }
}

/**
 * 파일 선택 처리
 */
function handleFileSelect(event) {
    const files = event.target.files;
    if (files && files.length > 0) {
        console.log('📁 파일 선택됨:', files.length + '개');
        uploadFiles(files);
    }
}

/**
 * 드래그 오버 처리
 */
function handleDragOver(event) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.add('dragover');
}

/**
 * 드래그 떠남 처리
 */
function handleDragLeave(event) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.remove('dragover');
}

/**
 * 파일 드롭 처리
 */
function handleFileDrop(event) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.remove('dragover');
    
    const files = event.dataTransfer.files;
    if (files && files.length > 0) {
        console.log('📁 파일 드롭됨:', files.length + '개');
        uploadFiles(files);
    }
}

/**
 * 파일 업로드 - classId 문제 해결 버전
 */
async function uploadFiles(files) {
    console.log('🔍 uploadFiles 함수 시작');
    console.log('🔍 files 객체:', files);
    console.log('🔍 files.length:', files ? files.length : 'undefined');
    console.log('🔍 classData.userRole:', classData.userRole);
    
    if (classData.userRole !== 'professor') {
        showError('파일 업로드는 교수만 가능합니다.');
        return;
    }
    
    if (!files || files.length === 0) {
        console.error('❌ files가 비어있음:', files);
        showError('업로드할 파일을 선택해주세요.');
        return;
    }
    
    console.log('📤 파일 업로드 시작:', files.length + '개');
    console.log('🔍 classData:', classData);
    
    // 각 파일 정보 로깅
    for (let i = 0; i < files.length; i++) {
        let file = files[i];
        console.log('📁 파일 ' + (i + 1) + ':', {
            name: file.name,
            size: file.size,
            type: file.type
        });
    }
    
    const formData = new FormData();
    formData.append('action', 'uploadFile');
    formData.append('classCode', classData.classCode);
    formData.append('userId', classData.userId);
    
    console.log('🔍 FormData 기본 정보 추가 완료');
    console.log('🔍 classCode:', classData.classCode);
    console.log('🔍 userId:', classData.userId);
    
    // 🔥 핵심 추가: classId 파라미터 얻기
    try {
        console.log('🔍 classId 조회 시작...');
        
        // ClassController를 통해 classId를 얻기
        const classInfoResponse = await fetch(classData.contextPath + '/classJoin.do?action=getClassInfo&classCode=' + classData.classCode, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (classInfoResponse.ok) {
            const classInfoResult = await classInfoResponse.json();
            console.log('🔍 classInfo 응답:', classInfoResult);
            
            if (classInfoResult.success && classInfoResult.classId) {
                formData.append('classId', classInfoResult.classId);
                console.log('✅ classId 추가:', classInfoResult.classId);
            } else {
                console.warn('⚠️ classId를 가져올 수 없습니다. classCode만 사용합니다.');
            }
        } else {
            console.warn('⚠️ classInfo 요청 실패. classCode만 사용합니다.');
        }
    } catch (error) {
        console.warn('⚠️ classId 조회 실패, classCode만 사용:', error);
    }
    
    // 파일들을 FormData에 추가
    for (let file of files) {
        formData.append('file', file);
        console.log('📎 FormData에 파일 추가:', file.name);
    }
    
    // FormData 내용 확인
    console.log('🔍 FormData 전체 내용:');
    for (let pair of formData.entries()) {
        if (pair[1] instanceof File) {
            console.log('  ' + pair[0] + ': File(' + pair[1].name + ', ' + pair[1].size + 'bytes)');
        } else {
            console.log('  ' + pair[0] + ': ' + pair[1]);
        }
    }
    
    try {
        showLoading(true);
        
        console.log('🌐 fetch 요청 시작...');
        const response = await fetch(classData.contextPath + '/file/upload', {
            method: 'POST',
            body: formData
        });
        
        console.log('🌐 응답 상태:', response.status, response.statusText);
        console.log('🌐 응답 헤더:', Array.from(response.headers.entries()));
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status + ': ' + response.statusText);
        }
        
        const result = await response.json();
        console.log('🌐 응답 데이터:', result);
        
        if (result.success) {
            console.log('✅ 파일 업로드 성공');
            showSuccess(files.length + '개 파일이 업로드되었습니다.');
            
            // 3초 후 파일 목록 새로고침 (DB 저장 시간 고려)
            setTimeout(function() {
                console.log('🔄 3초 후 파일 목록 새로고침 시작');
                refreshFiles();
            }, 3000);
        } else {
            throw new Error(result.message || '파일 업로드에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 파일 업로드 실패:', error);
        showError(error.message || '파일 업로드 중 오류가 발생했습니다.');
    } finally {
        showLoading(false);
        
        // 파일 입력 초기화
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.value = '';
        }
    }
}

/**
 * 파일 다운로드
 */
async function downloadFile(fileId) {
    if (!fileId) {
        showError('파일 ID가 없습니다.');
        return;
    }
    
    try {
        const url = classData.contextPath + '/file/download/' + fileId;
        
        // 새 창에서 다운로드
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        console.log('📥 파일 다운로드 시작:', fileId);
        
    } catch (error) {
        console.error('❌ 파일 다운로드 실패:', error);
        showError('파일 다운로드 중 오류가 발생했습니다.');
    }
}

/**
 * 파일 삭제 (교수용)
 */
async function deleteFile(fileId) {
    if (!fileId) {
        showError('파일 ID가 없습니다.');
        return;
    }
    
    if (!confirm('이 파일을 삭제하시겠습니까?')) {
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch(classData.contextPath + '/file/delete/' + fileId, {
            method: 'DELETE',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('파일이 삭제되었습니다.');
            await refreshFiles();
        } else {
            throw new Error(result.message || '파일 삭제에 실패했습니다.');
        }
        
    } catch (error) {
        console.error('❌ 파일 삭제 실패:', error);
        showError(error.message || '파일 삭제 중 오류가 발생했습니다.');
    } finally {
        showLoading(false);
    }
}

/**
 * 실시간 업데이트 시작
 */
function startRealTimeUpdates() {
    console.log('🔄 실시간 업데이트 시작...');
    
    // 30초마다 현재 탭 데이터 새로고침
    setInterval(function() {
        if (document.visibilityState === 'visible' && classData.classCode) {
            switch (currentTab) {
                case 'qa':
                    refreshQuestions();
                    break;
                case 'assignment':
                    refreshAssignments();
                    break;
                case 'files':
                    refreshFiles();
                    break;
            }
        }
    }, 30000);
}

/**
 * 질문 필터링 (교수용)
 */
function filterQuestions(filterType) {
    console.log('🔍 질문 필터링:', filterType);
    
    const questions = document.querySelectorAll('.question-item');
    
    questions.forEach(function(question) {
        const hasAnswer = question.querySelector('.answer') !== null;
        var shouldShow = true;
        
        switch (filterType) {
            case 'all':
                shouldShow = true;
                break;
            case 'answered':
                shouldShow = hasAnswer;
                break;
            case 'unanswered':
                shouldShow = !hasAnswer;
                break;
        }
        
        question.style.display = shouldShow ? 'block' : 'none';
    });
}

/**
 * 로딩 표시/숨김
 */
function showLoading(show) {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        if (show) {
            loadingOverlay.classList.add('show');
        } else {
            loadingOverlay.classList.remove('show');
        }
    }
}

/**
 * 에러 메시지 표시
 */
function showError(message) {
    console.error('❌', message);
    
    // 더 나은 알림 UI가 있다면 사용, 없으면 alert
    if (typeof showNotification === 'function') {
        showNotification(message, 'error');
    } else {
        alert('오류: ' + message);
    }
}

/**
 * 성공 메시지 표시
 */
function showSuccess(message) {
    console.log('✅', message);
    
    // 더 나은 알림 UI가 있다면 사용, 없으면 alert
    if (typeof showNotification === 'function') {
        showNotification(message, 'success');
    } else {
        alert('성공: ' + message);
    }
}

/**
 * 시간 포맷팅 (몇 분 전 형태)
 */
function formatTimeAgo(dateString) {
    if (!dateString) return '알 수 없음';
    
    try {
        const now = new Date();
        const date = new Date(dateString);
        
        if (isNaN(date.getTime())) {
            return '알 수 없음';
        }
        
        const diffInMinutes = Math.floor((now - date) / (1000 * 60));
        
        if (diffInMinutes < 1) return '방금 전';
        if (diffInMinutes < 60) return diffInMinutes + '분 전';
        
        const diffInHours = Math.floor(diffInMinutes / 60);
        if (diffInHours < 24) return diffInHours + '시간 전';
        
        const diffInDays = Math.floor(diffInHours / 24);
        if (diffInDays < 7) return diffInDays + '일 전';
        
        return date.toLocaleDateString('ko-KR');
    } catch (error) {
        console.error('시간 포맷팅 오류:', error);
        return '알 수 없음';
    }
}

/**
 * HTML 이스케이프
 */
function escapeHtml(text) {
    if (!text) return '';
    
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    
    return String(text).replace(/[&<>"']/g, function(m) {
        return map[m];
    });
}

// ========================================
// 전역 함수들 (HTML에서 직접 호출용)
// ========================================

window.showStatistics = function() {
    if (classData.classCode) {
        window.location.href = classData.contextPath + '/classStatistics.do?classCode=' + classData.classCode;
    }
};

window.manageClass = function() {
    window.location.href = classData.contextPath + '/enterClass.do';
};

window.endClass = function() {
    if (confirm('수업을 종료하시겠습니까?')) {
        // TODO: 수업 종료 로직 구현
        showSuccess('수업이 종료되었습니다.');
    }
};

window.leaveClass = function() {
    if (confirm('수업에서 나가시겠습니까?')) {
        window.location.href = classData.contextPath + '/main.do';
    }
};

window.createAssignment = function() {
    // TODO: 과제 생성 모달 표시
    showError('과제 생성 기능은 준비 중입니다.');
};

window.createPoll = function() {
    // TODO: 투표 생성 모달 표시
    showError('투표 생성 기능은 준비 중입니다.');
};

window.clearAllQuestions = function() {
    if (confirm('모든 질문을 삭제하시겠습니까?')) {
        // TODO: 모든 질문 삭제 로직
        showSuccess('모든 질문이 삭제되었습니다.');
    }
};

// 전역 함수로 노출 (HTML onclick에서 사용)
window.toggleQuestionVote = toggleQuestionVote;
window.showAnswerForm = showAnswerForm;
window.cancelAnswer = cancelAnswer;
window.submitAnswer = submitAnswer;
window.deleteQuestion = deleteQuestion;
window.downloadFile = downloadFile;
window.deleteFile = deleteFile;
window.selectPollOption = selectPollOption;

console.log('🎉 classJoin.js 전체 로드 완료');