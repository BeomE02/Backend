/**
 * photoPage.js - 사진게시판 JavaScript 모듈 (완전한 버전)
 * 모든 UI 상호작용, 이벤트 처리, 유틸리티 기능을 담당
 */

(function() {
    'use strict';

    // ===== 전역 변수 =====
    let pageData = window.pageData || {
        currentPage: 1,
        totalPages: 1,
        searchType: '',
        keyword: '',
        contextPath: ''
    };
    
    let autoRefreshTimer = null;
    let searchTimeout = null;
    let isLoading = false;
    let clickedButtons = new Set();

    // ===== DOM 요소들 =====
    const elements = {};

    // ===== DOM이 로드된 후 실행 =====
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🚀 사진게시판 페이지 초기화 시작');
        
        try {
            initElements();
            initEventListeners();
            initKeyboardShortcuts();
            initAnimations();
            initAutoRefresh();
            showMessages();
            restoreScrollPosition();
            highlightSearchKeyword();
            addDynamicStyles();
            
            console.log('✅ 사진게시판 페이지 초기화 완료');
        } catch (error) {
            console.error('❌ 초기화 중 오류:', error);
        }
    });

    // ===== DOM 요소 초기화 =====
    function initElements() {
        elements.searchForm = document.querySelector('.search-form');
        elements.searchInput = document.querySelector('.search-input');
        elements.searchSelect = document.querySelector('.search-select');
        elements.searchBtn = document.querySelector('.search-btn');
        elements.writeButtons = document.querySelectorAll('.write-btn');
        elements.postLinks = document.querySelectorAll('.post-link');
        elements.pageButtons = document.querySelectorAll('.page-btn');
        elements.boardRows = document.querySelectorAll('.board-row');
        elements.boardWrapper = document.querySelector('.board-wrapper');
        elements.newBadges = document.querySelectorAll('.new-badge');
        elements.hotBadges = document.querySelectorAll('.hot-badge');
        elements.attachmentIcons = document.querySelectorAll('.attachment-icon');

        console.log('🔧 DOM 요소 초기화 완료:', {
            postCount: elements.postLinks.length,
            pageButtons: elements.pageButtons.length
        });
    }

    // ===== 이벤트 리스너 초기화 =====
    function initEventListeners() {
        // 검색 폼 이벤트
        if (elements.searchForm) {
            elements.searchForm.addEventListener('submit', handleSearchSubmit);
        }

        // 검색 입력 필드 이벤트
        if (elements.searchInput) {
            elements.searchInput.addEventListener('input', handleSearchInput);
            elements.searchInput.addEventListener('focus', handleSearchFocus);
            elements.searchInput.addEventListener('keypress', handleSearchKeypress);
        }

        // 게시글 링크 이벤트
        elements.postLinks.forEach(function(link) {
            link.addEventListener('click', handlePostClick);
        });

        // 글쓰기 버튼 이벤트
        elements.writeButtons.forEach(function(button) {
            button.addEventListener('click', handleWriteClick);
        });

        // 페이지네이션 버튼 이벤트
        elements.pageButtons.forEach(function(button) {
            button.addEventListener('click', handlePageClick);
        });

        // 게시글 행 hover 이벤트
        elements.boardRows.forEach(function(row) {
            row.addEventListener('mouseenter', handleRowHover);
            row.addEventListener('mouseleave', handleRowLeave);
        });

        // 파일 첨부 아이콘 툴팁
        elements.attachmentIcons.forEach(function(icon) {
            icon.addEventListener('mouseenter', showAttachmentTooltip);
            icon.addEventListener('mouseleave', hideAttachmentTooltip);
        });

        // 페이지 언로드 시 정리
        window.addEventListener('beforeunload', handlePageUnload);
        window.addEventListener('popstate', handlePopState);

        console.log('📌 이벤트 리스너 등록 완료');
    }

    // ===== 검색 이벤트 처리 =====
    function handleSearchSubmit(e) {
        if (isLoading) {
            e.preventDefault();
            return false;
        }

        var keyword = elements.searchInput.value.trim();
        if (keyword.length > 0 && keyword.length < 2) {
            e.preventDefault();
            showToast('검색어는 2글자 이상 입력해주세요.', 'warning');
            elements.searchInput.focus();
            return false;
        }

        if (keyword.length === 0) {
            // 빈 검색어인 경우 전체 목록으로 이동
            e.preventDefault();
            window.location.href = 'photoPage.do';
            return false;
        }

        setLoading(true);
        saveScrollPosition();
        
        console.log('🔍 사진게시판 검색 실행:', keyword);
    }

    function handleSearchInput(e) {
        clearTimeout(searchTimeout);
        
        searchTimeout = setTimeout(function() {
            var keyword = e.target.value.trim();
            
            if (keyword.length === 0) {
                // 검색어가 모두 지워진 경우 즉시 전체 목록으로
                window.location.href = 'photoPage.do';
            }
        }, 1000);
    }

    function handleSearchFocus(e) {
        e.target.select();
    }

    function handleSearchKeypress(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            elements.searchForm.dispatchEvent(new Event('submit'));
        }
    }

    // ===== 게시글 이벤트 처리 =====
    function handlePostClick(e) {
        if (isLoading) {
            e.preventDefault();
            return false;
        }

        var postId = e.currentTarget.dataset.postId;
        if (!postId) {
            e.preventDefault();
            showToast('게시글 정보를 찾을 수 없습니다.', 'error');
            return false;
        }

        setLoading(true);
        saveScrollPosition();
        
        // 게시글 클릭 시 category=photo 파라미터 확인
        var href = e.currentTarget.href;
        if (href && !href.includes('category=photo')) {
            e.preventDefault();
            window.location.href = 'viewPost.do?postId=' + postId + '&category=photo';
            return false;
        }

        console.log('📝 사진게시판 게시글 클릭:', postId);
    }

    // ===== 글쓰기 이벤트 처리 =====
    function handleWriteClick(e) {
        if (isLoading) {
            e.preventDefault();
            return false;
        }

        var button = e.currentTarget;
        if (clickedButtons.has(button)) {
            e.preventDefault();
            return false;
        }

        clickedButtons.add(button);
        setLoading(true);
        saveScrollPosition();
        
        // 글쓰기 버튼 클릭 시 category=photo 파라미터 확인
        var href = button.closest('a').href;
        if (href && !href.includes('category=photo')) {
            e.preventDefault();
            window.location.href = 'writePost.do?category=photo';
            return false;
        }

        setTimeout(function() {
            clickedButtons.delete(button);
        }, 3000);

        console.log('✏️ 사진게시판 글쓰기 클릭');
    }

    // ===== 페이지네이션 이벤트 처리 =====
    function handlePageClick(e) {
        if (isLoading) {
            e.preventDefault();
            return false;
        }

        var button = e.currentTarget;
        if (button.classList.contains('current') || button.classList.contains('disabled')) {
            e.preventDefault();
            return false;
        }

        setLoading(true);
        saveScrollPosition();

        console.log('📄 사진게시판 페이지 이동:', button.textContent);
    }

    // ===== 행 hover 이벤트 =====
    function handleRowHover(e) {
        e.currentTarget.style.backgroundColor = '#f8f9fa';
        e.currentTarget.style.transform = 'translateY(-1px)';
        e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    }

    function handleRowLeave(e) {
        e.currentTarget.style.backgroundColor = '';
        e.currentTarget.style.transform = '';
        e.currentTarget.style.boxShadow = '';
    }

    // ===== 첨부파일 툴팁 =====
    function showAttachmentTooltip(e) {
        var tooltip = document.createElement('div');
        tooltip.textContent = '사진 첨부파일이 있습니다';
        tooltip.style.cssText = 'position: absolute; background: #333; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px; z-index: 1000; pointer-events: none;';
        
        document.body.appendChild(tooltip);
        
        var rect = e.target.getBoundingClientRect();
        tooltip.style.left = (rect.left + rect.width / 2 - tooltip.offsetWidth / 2) + 'px';
        tooltip.style.top = (rect.top - tooltip.offsetHeight - 5) + 'px';
        
        e.target._tooltip = tooltip;
    }

    function hideAttachmentTooltip(e) {
        if (e.target._tooltip) {
            document.body.removeChild(e.target._tooltip);
            e.target._tooltip = null;
        }
    }

    // ===== 키보드 단축키 =====
    function initKeyboardShortcuts() {
        document.addEventListener('keydown', function(e) {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }

            switch(e.key) {
                case '/':
                    e.preventDefault();
                    if (elements.searchInput) {
                        elements.searchInput.focus();
                    }
                    break;
                case 'n':
                case 'N':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        var writeBtn = document.querySelector('.write-btn');
                        if (writeBtn) {
                            window.location.href = 'writePost.do?category=photo';
                        }
                    }
                    break;
                case 'r':
                case 'R':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        location.reload();
                    }
                    break;
            }
        });

        console.log('⌨️ 키보드 단축키 등록 완료');
    }

    // ===== 애니메이션 =====
    function initAnimations() {
        // 게시글 행에 stagger 애니메이션 적용
        elements.boardRows.forEach(function(row, index) {
            row.style.opacity = '0';
            row.style.transform = 'translateY(20px)';
            
            setTimeout(function() {
                row.style.transition = 'all 0.4s ease';
                row.style.opacity = '1';
                row.style.transform = 'translateY(0)';
            }, index * 50);
        });

        // 새 글, 인기 글 배지 반짝임 효과
        elements.newBadges.forEach(function(badge) {
            badge.style.animation = 'pulse 2s infinite';
        });

        elements.hotBadges.forEach(function(badge) {
            badge.style.animation = 'bounce 1s infinite alternate';
        });

        console.log('🎨 애니메이션 초기화 완료');
    }

    // ===== 자동 새로고침 =====
    function initAutoRefresh() {
        // 5분마다 새 게시글 확인
        autoRefreshTimer = setInterval(function() {
            checkNewPosts();
        }, 5 * 60 * 1000);

        console.log('🔄 자동 새로고침 활성화 (5분 간격)');
    }

    function checkNewPosts() {
        // 간단한 AJAX 요청으로 새 게시글 확인
        fetch('photoPage.do?ajax=true&latest=true')
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.hasNewPosts) {
                    showNewPostNotification(data.newPostCount);
                }
            })
            .catch(function(error) {
                console.log('새 게시글 확인 실패:', error);
            });
    }

    function showNewPostNotification(count) {
        var notification = document.createElement('div');
        notification.className = 'new-post-notification';
        notification.innerHTML = 
            '<span>새로운 사진 ' + count + '개가 등록되었습니다</span>' +
            '<button class="refresh-btn">새로고침</button>' +
            '<button class="close-btn">×</button>';
        
        notification.style.cssText = 'position: fixed; top: 80px; right: 20px; background: #007bff; color: white; padding: 12px 16px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; animation: slideInRight 0.3s ease;';
        
        document.body.appendChild(notification);
        
        // 새로고침 버튼
        notification.querySelector('.refresh-btn').addEventListener('click', function() {
            location.reload();
        });
        
        // 닫기 버튼
        notification.querySelector('.close-btn').addEventListener('click', function() {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(function() {
                if (notification.parentNode) {
                    document.body.removeChild(notification);
                }
            }, 300);
        });
        
        // 10초 후 자동 제거
        setTimeout(function() {
            if (notification.parentNode) {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(function() {
                    if (notification.parentNode) {
                        document.body.removeChild(notification);
                    }
                }, 300);
            }
        }, 10000);
    }

    function stopAutoRefresh() {
        if (autoRefreshTimer) {
            clearInterval(autoRefreshTimer);
            autoRefreshTimer = null;
        }
    }

    // ===== 메시지 표시 =====
    function showMessages() {
        // URL 파라미터에서 메시지 확인
        var urlParams = new URLSearchParams(window.location.search);
        var message = urlParams.get('message');
        var messageType = urlParams.get('messageType') || 'info';
        
        if (message) {
            showToast(decodeURIComponent(message), messageType);
            
            // URL에서 메시지 파라미터 제거
            var newUrl = window.location.pathname;
            var remainingParams = [];
            
            urlParams.forEach(function(value, key) {
                if (key !== 'message' && key !== 'messageType') {
                    remainingParams.push(key + '=' + value);
                }
            });
            
            if (remainingParams.length > 0) {
                newUrl += '?' + remainingParams.join('&');
            }
            
            history.replaceState(null, '', newUrl);
        }
    }

    // ===== 토스트 메시지 =====
    function showToast(message, type, duration) {
        type = type || 'info';
        duration = duration || 3000;
        
        var toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.textContent = message;
        
        toast.style.cssText = 'position: fixed; top: 20px; right: 20px; padding: 12px 24px; border-radius: 8px; color: white; font-weight: 500; z-index: 10000; transform: translateX(100%); transition: transform 0.3s ease;';
        
        switch(type) {
            case 'success':
                toast.style.backgroundColor = '#28a745';
                break;
            case 'error':
                toast.style.backgroundColor = '#dc3545';
                break;
            case 'warning':
                toast.style.backgroundColor = '#ffc107';
                toast.style.color = '#212529';
                break;
            default:
                toast.style.backgroundColor = '#17a2b8';
        }
        
        document.body.appendChild(toast);
        
        setTimeout(function() {
            toast.style.transform = 'translateX(0)';
        }, 100);
        
        setTimeout(function() {
            toast.style.transform = 'translateX(100%)';
            setTimeout(function() {
                if (toast.parentNode) {
                    document.body.removeChild(toast);
                }
            }, 300);
        }, duration);
    }

    // ===== 로딩 상태 관리 =====
    function setLoading(loading) {
        isLoading = loading;
        
        if (loading) {
            document.body.style.cursor = 'wait';
            elements.searchBtn && (elements.searchBtn.disabled = true);
            elements.writeButtons.forEach(function(btn) {
                btn.disabled = true;
            });
        } else {
            document.body.style.cursor = 'default';
            elements.searchBtn && (elements.searchBtn.disabled = false);
            elements.writeButtons.forEach(function(btn) {
                btn.disabled = false;
            });
        }
    }

    // ===== 페이지네이션 유틸리티 =====
    function navigateToPage(page) {
        if (isLoading || page < 1) return;
        
        var url = new URL(window.location);
        url.searchParams.set('page', page);
        
        setLoading(true);
        saveScrollPosition();
        window.location.href = url.toString();
    }

    function getCurrentPage() {
        var urlParams = new URLSearchParams(window.location.search);
        return parseInt(urlParams.get('page')) || 1;
    }

    // ===== 스크롤 위치 관리 =====
    function saveScrollPosition() {
        sessionStorage.setItem('photoPage_scrollY', window.scrollY.toString());
    }

    function restoreScrollPosition() {
        var savedY = sessionStorage.getItem('photoPage_scrollY');
        if (savedY) {
            window.scrollTo(0, parseInt(savedY));
            sessionStorage.removeItem('photoPage_scrollY');
        }
    }

    // ===== 검색어 하이라이트 =====
    function highlightSearchKeyword() {
        var urlParams = new URLSearchParams(window.location.search);
        var keyword = urlParams.get('keyword');
        
        if (keyword && keyword.trim()) {
            var titleCells = document.querySelectorAll('.title-cell .post-title');
            titleCells.forEach(function(cell) {
                var text = cell.textContent;
                var highlightedText = text.replace(
                    new RegExp(escapeRegExp(keyword.trim()), 'gi'),
                    '<mark style="background: #ffeb3b; padding: 1px 2px;">$&</mark>'
                );
                if (highlightedText !== text) {
                    cell.innerHTML = highlightedText;
                }
            });
        }
    }

    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    // ===== 페이지 이벤트 =====
    function handlePageUnload() {
        stopAutoRefresh();
        
        // 진행 중인 요청들 정리
        if (searchTimeout) {
            clearTimeout(searchTimeout);
        }
    }

    function handlePopState() {
        // 뒤로가기 시 페이지 새로고침
        location.reload();
    }

    // ===== CSS 애니메이션 동적 추가 =====
    function addDynamicStyles() {
        if (document.getElementById('photoPage-dynamic-styles')) {
            return; // 이미 추가됨
        }
        
        var style = document.createElement('style');
        style.id = 'photoPage-dynamic-styles';
        style.textContent = 
            '@keyframes slideInRight {' +
                'from { transform: translateX(100%); opacity: 0; }' +
                'to { transform: translateX(0); opacity: 1; }' +
            '}' +
            '@keyframes slideOutRight {' +
                'from { transform: translateX(0); opacity: 1; }' +
                'to { transform: translateX(100%); opacity: 0; }' +
            '}' +
            '.new-post-notification .refresh-btn,' +
            '.new-post-notification .close-btn {' +
                'background: #1a1a1a;' +
                'color: white;' +
                'border: none;' +
                'padding: 4px 8px;' +
                'border-radius: 4px;' +
                'cursor: pointer;' +
                'font-size: 12px;' +
                'transition: background 0.2s ease;' +
            '}' +
            '.new-post-notification .refresh-btn:hover,' +
            '.new-post-notification .close-btn:hover {' +
                'background: #333;' +
            '}' +
            '.new-post-notification .close-btn {' +
                'width: 24px;' +
                'height: 24px;' +
                'border-radius: 50%;' +
                'display: flex;' +
                'align-items: center;' +
                'justify-content: center;' +
                'font-weight: bold;' +
            '}';
        
        document.head.appendChild(style);
    }

    // ===== 에러 처리 =====
    window.addEventListener('error', function(e) {
        console.error('JavaScript 에러:', e.error);
        showToast('페이지에 오류가 발생했습니다.', 'error');
    });

    // ===== 공개 API =====
    window.PhotoPage = {
        refreshPage: function() { 
            location.reload(); 
        },
        navigateToPage: navigateToPage,
        showToast: showToast,
        getCurrentPage: getCurrentPage,
        saveScrollPosition: saveScrollPosition,
        restoreScrollPosition: restoreScrollPosition
    };

    // ===== 최종 초기화 (페이지 로드 완료 후) =====
    window.addEventListener('load', function() {
        setTimeout(function() {
            // 페이지 로드 완료 이벤트 발생
            var loadEvent = new Event('photoPageLoaded');
            document.dispatchEvent(loadEvent);
            
            console.log('🎉 사진게시판 모든 기능 로드 완료');
        }, 100);
    });

})();