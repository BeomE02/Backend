// login.js - 로그인 페이지 전용 JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('로그인 페이지 로드 완료');
    
    // 폼 요소들
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginButton = document.getElementById('loginButton');
    const passwordToggle = document.getElementById('passwordToggle');
    const rememberMeCheckbox = document.getElementById('rememberMe');
    
    // 초기화
    initializeLoginPage();
    initializeFormValidation();
    initializePasswordToggle();
    initializeTestAccounts();
    initializeRememberMe();
    
    // 폼 제출 이벤트
    loginForm.addEventListener('submit', handleFormSubmit);
    
    // 엔터키 처리
    usernameInput.addEventListener('keypress', handleEnterKey);
    passwordInput.addEventListener('keypress', handleEnterKey);
});

/**
 * 로그인 페이지 초기화
 */
function initializeLoginPage() {
    // 페이지 애니메이션
    const container = document.querySelector('.login-container');
    container.style.opacity = '0';
    container.style.transform = 'translateY(30px)';
    
    setTimeout(() => {
        container.style.transition = 'all 0.6s ease-out';
        container.style.opacity = '1';
        container.style.transform = 'translateY(0)';
    }, 100);
    
    // 첫 번째 입력 필드에 포커스
    setTimeout(() => {
        const usernameInput = document.getElementById('username');
        if (usernameInput && !usernameInput.value) {
            usernameInput.focus();
        }
    }, 700);
    
    // 저장된 로그인 정보 복원
    restoreSavedLoginInfo();
}

/**
 * 폼 검증 초기화
 */
function initializeFormValidation() {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    // 실시간 검증
    usernameInput.addEventListener('input', function() {
        validateUsername(this.value);
        updateSubmitButton();
    });
    
    usernameInput.addEventListener('blur', function() {
        validateUsername(this.value);
    });
    
    passwordInput.addEventListener('input', function() {
        validatePassword(this.value);
        updateSubmitButton();
    });
    
    passwordInput.addEventListener('blur', function() {
        validatePassword(this.value);
    });
}

/**
 * 비밀번호 토글 초기화
 */
function initializePasswordToggle() {
    const passwordInput = document.getElementById('password');
    const passwordToggle = document.getElementById('passwordToggle');
    const eyeIcon = passwordToggle.querySelector('.eye-icon');
    
    passwordToggle.addEventListener('click', function() {
        const isPassword = passwordInput.type === 'password';
        
        passwordInput.type = isPassword ? 'text' : 'password';
        eyeIcon.textContent = isPassword ? '🙈' : '👁';
        
        // 버튼 애니메이션
        this.style.transform = 'scale(0.9)';
        setTimeout(() => {
            this.style.transform = 'scale(1)';
        }, 100);
        
        // 포커스 유지
        passwordInput.focus();
    });
}

/**
 * 테스트 계정 초기화
 */
function initializeTestAccounts() {
    const testButtons = document.querySelectorAll('.test-btn');
    
    testButtons.forEach(button => {
        button.addEventListener('click', function() {
            const username = this.getAttribute('data-username');
            const password = this.getAttribute('data-password');
            
            fillLoginForm(username, password);
            
            // 버튼 효과
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });
}

/**
 * 로그인 정보 기억하기 초기화
 */
function initializeRememberMe() {
    const checkbox = document.getElementById('rememberMe');
    
    checkbox.addEventListener('change', function() {
        if (!this.checked) {
            // 체크 해제 시 저장된 정보 삭제
            clearSavedLoginInfo();
        }
    });
}

/**
 * 폼 제출 처리
 */
function handleFormSubmit(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    
    // 검증
    if (!validateForm(username, password)) {
        return;
    }
    
    // 로그인 정보 저장 (기억하기 체크된 경우)
    if (document.getElementById('rememberMe').checked) {
        saveLoginInfo(username);
    } else {
        clearSavedLoginInfo();
    }
    
    // 로딩 상태 표시
    showLoadingState();
    
    // 폼 제출
    document.getElementById('loginForm').submit();
}

/**
 * 엔터키 처리
 */
function handleEnterKey(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        
        if (e.target.id === 'username') {
            // 사용자명에서 엔터 -> 비밀번호로 이동
            document.getElementById('password').focus();
        } else if (e.target.id === 'password') {
            // 비밀번호에서 엔터 -> 로그인 시도
            document.getElementById('loginForm').dispatchEvent(new Event('submit'));
        }
    }
}

/**
 * 사용자명 검증
 */
function validateUsername(username) {
    const errorElement = document.getElementById('usernameError');
    const inputElement = document.getElementById('username');
    
    if (!username) {
        showFieldError(inputElement, errorElement, '아이디를 입력해주세요.');
        return false;
    }
    
    if (username.length < 3) {
        showFieldError(inputElement, errorElement, '아이디는 3자 이상이어야 합니다.');
        return false;
    }
    
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        showFieldError(inputElement, errorElement, '아이디는 영문, 숫자, 언더스코어만 사용 가능합니다.');
        return false;
    }
    
    clearFieldError(inputElement, errorElement);
    return true;
}

/**
 * 비밀번호 검증
 */
function validatePassword(password) {
    const errorElement = document.getElementById('passwordError');
    const inputElement = document.getElementById('password');
    
    if (!password) {
        showFieldError(inputElement, errorElement, '비밀번호를 입력해주세요.');
        return false;
    }
    
    if (password.length < 4) {
        showFieldError(inputElement, errorElement, '비밀번호는 4자 이상이어야 합니다.');
        return false;
    }
    
    clearFieldError(inputElement, errorElement);
    return true;
}

/**
 * 전체 폼 검증
 */
function validateForm(username, password) {
    const isUsernameValid = validateUsername(username);
    const isPasswordValid = validatePassword(password);
    
    return isUsernameValid && isPasswordValid;
}

/**
 * 필드 에러 표시
 */
function showFieldError(inputElement, errorElement, message) {
    inputElement.classList.add('error');
    errorElement.textContent = message;
    errorElement.style.opacity = '1';
}

/**
 * 필드 에러 제거
 */
function clearFieldError(inputElement, errorElement) {
    inputElement.classList.remove('error');
    errorElement.textContent = '';
    errorElement.style.opacity = '0';
}

/**
 * 제출 버튼 상태 업데이트
 */
function updateSubmitButton() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const loginButton = document.getElementById('loginButton');
    
    const isValid = username.length >= 3 && password.length >= 4;
    
    if (isValid) {
        loginButton.style.opacity = '1';
        loginButton.style.cursor = 'pointer';
    } else {
        loginButton.style.opacity = '0.7';
        loginButton.style.cursor = 'not-allowed';
    }
}

/**
 * 로딩 상태 표시
 */
function showLoadingState() {
    const loginButton = document.getElementById('loginButton');
    const btnText = loginButton.querySelector('.btn-text');
    const btnLoading = loginButton.querySelector('.btn-loading');
    
    loginButton.disabled = true;
    btnText.style.display = 'none';
    btnLoading.style.display = 'flex';
    
    // 버튼 스타일 변경
    loginButton.style.background = '#d1d5db';
    loginButton.style.cursor = 'not-allowed';
    loginButton.style.transform = 'none';
}

/**
 * 로딩 상태 해제
 */
function hideLoadingState() {
    const loginButton = document.getElementById('loginButton');
    const btnText = loginButton.querySelector('.btn-text');
    const btnLoading = loginButton.querySelector('.btn-loading');
    
    loginButton.disabled = false;
    btnText.style.display = 'inline';
    btnLoading.style.display = 'none';
    
    // 버튼 스타일 복원
    loginButton.style.background = 'linear-gradient(135deg, #B9FF66 0%, #a8f050 100%)';
    loginButton.style.cursor = 'pointer';
}

/**
 * 테스트 계정으로 폼 채우기
 */
function fillLoginForm(username, password) {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    // 애니메이션 효과와 함께 값 설정
    usernameInput.style.transform = 'scale(1.02)';
    passwordInput.style.transform = 'scale(1.02)';
    
    usernameInput.value = username;
    passwordInput.value = password;
    
    // 검증 트리거
    validateUsername(username);
    validatePassword(password);
    updateSubmitButton();
    
    // 애니메이션 복원
    setTimeout(() => {
        usernameInput.style.transform = 'scale(1)';
        passwordInput.style.transform = 'scale(1)';
    }, 200);
    
    // 비밀번호 필드에 포커스
    passwordInput.focus();
    
    // 성공 피드백
    showAlert('테스트 계정 정보가 입력되었습니다.', 'success', 2000);
}

/**
 * 로그인 정보 저장 (로컬 스토리지)
 */
function saveLoginInfo(username) {
    try {
        const loginInfo = {
            username: username,
            timestamp: new Date().getTime()
        };
        localStorage.setItem('clinkLoginInfo', JSON.stringify(loginInfo));
        console.log('로그인 정보 저장됨');
    } catch (e) {
        console.warn('로그인 정보 저장 실패:', e);
    }
}

/**
 * 저장된 로그인 정보 복원
 */
function restoreSavedLoginInfo() {
    try {
        const savedInfo = localStorage.getItem('clinkLoginInfo');
        if (savedInfo) {
            const loginInfo = JSON.parse(savedInfo);
            const now = new Date().getTime();
            const daysDiff = (now - loginInfo.timestamp) / (1000 * 60 * 60 * 24);
            
            // 30일 이내의 정보만 복원
            if (daysDiff <= 30) {
                document.getElementById('username').value = loginInfo.username;
                document.getElementById('rememberMe').checked = true;
                
                // 비밀번호 필드에 포커스
                setTimeout(() => {
                    document.getElementById('password').focus();
                }, 100);
                
                console.log('저장된 로그인 정보 복원됨');
            } else {
                // 오래된 정보는 삭제
                clearSavedLoginInfo();
            }
        }
    } catch (e) {
        console.warn('로그인 정보 복원 실패:', e);
        clearSavedLoginInfo();
    }
}

/**
 * 저장된 로그인 정보 삭제
 */
function clearSavedLoginInfo() {
    try {
        localStorage.removeItem('clinkLoginInfo');
        console.log('저장된 로그인 정보 삭제됨');
    } catch (e) {
        console.warn('로그인 정보 삭제 실패:', e);
    }
}

/**
 * 알림 메시지 표시 (common.js의 showAlert 대신 사용)
 */
function showAlert(message, type = 'info', duration = 3000) {
    // 기존 알림 제거
    const existingAlert = document.querySelector('.login-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} login-alert`;
    alert.textContent = message;
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        max-width: 300px;
        padding: 12px 16px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.3s ease-out;
    `;
    
    // 슬라이드 애니메이션 추가
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(100%);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        @keyframes slideOutRight {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(100%);
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(alert);
    
    // 자동 제거
    setTimeout(() => {
        alert.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
            if (style.parentNode) {
                style.remove();
            }
        }, 300);
    }, duration);
    
    return alert;
}

/**
 * 키보드 단축키 처리
 */
function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl + Enter: 로그인 실행
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('loginForm').dispatchEvent(new Event('submit'));
        }
        
        // ESC: 폼 초기화
        if (e.key === 'Escape') {
            e.preventDefault();
            resetForm();
        }
    });
}

/**
 * 폼 초기화
 */
function resetForm() {
    document.getElementById('loginForm').reset();
    clearAllFieldErrors();
    updateSubmitButton();
    document.getElementById('username').focus();
}

/**
 * 모든 필드 에러 제거
 */
function clearAllFieldErrors() {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    
    clearFieldError(usernameInput, usernameError);
    clearFieldError(passwordInput, passwordError);
}

/**
 * 폼 자동완성 개선
 */
function enhanceFormAutocomplete() {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    // 브라우저 자동완성 감지
    const checkAutofill = () => {
        if (usernameInput.value && passwordInput.value) {
            validateUsername(usernameInput.value);
            validatePassword(passwordInput.value);
            updateSubmitButton();
        }
    };
    
    // 주기적으로 자동완성 체크 (브라우저가 값을 채운 경우)
    setTimeout(checkAutofill, 100);
    setTimeout(checkAutofill, 500);
    setTimeout(checkAutofill, 1000);
}

/**
 * 접근성 개선
 */
function improveAccessibility() {
    // ARIA 라벨 추가
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginButton = document.getElementById('loginButton');
    
    usernameInput.setAttribute('aria-describedby', 'usernameError');
    passwordInput.setAttribute('aria-describedby', 'passwordError');
    
    // 로딩 상태일 때 스크린 리더를 위한 텍스트
    loginButton.setAttribute('aria-live', 'polite');
}

// 페이지 언로드 시 정리
window.addEventListener('beforeunload', function() {
    hideLoadingState();
});

// 초기화 함수들 실행
document.addEventListener('DOMContentLoaded', function() {
    initializeKeyboardShortcuts();
    enhanceFormAutocomplete();
    improveAccessibility();
});