/**
 * 자료게시판 JavaScript
 * 작성일: 2025-01-18
 * 작성자: Clink Team
 * 설명: 자료게시판의 모든 인터랙션 및 동적 기능 관리
 */

// ===== 전역 변수 =====
let currentSort = 'latest'; // 현재 정렬 방식
let isLoading = false; // 로딩 상태
let searchTimeout = null; // 검색 디바운싱용
let popularDataCache = null; // 인기 자료 캐시

// DOM 요소들
const elements = {
    classSelect: null,
    searchType: null,
    searchInput: null,
    searchBtn: null,
    sortSelect: null,
    dataList: null,
    loadingOverlay: null,
    writeBtn: null,
    popularList: null,
    weeklyCount: null,
    totalDownloads: null
};

// ===== 초기화 =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('📁 자료게시판 초기화 시작');
    
    initElements();
    initEventListeners();
    initAnimations();
    initKeyboardShortcuts();
    loadPopularData();
    loadStatistics();
    restoreScrollPosition();
    
    console.log('✅ 자료게시판 초기화 완료');
});

// ===== DOM 요소 초기화 =====
function initElements() {
    elements.classSelect = document.getElementById('classSelect');
    elements.searchType = document.getElementById('searchType');
    elements.searchInput = document.getElementById('searchInput');
    elements.searchBtn = document.querySelector('.search-btn');
    elements.sortSelect = document.getElementById('sortType');
    elements.dataList = document.querySelector('.data-list');
    elements.loadingOverlay = document.getElementById('loadingOverlay');
    elements.writeBtn = document.querySelector('.write-btn');
    elements.popularList = document.querySelector('.popular-list');
    elements.weeklyCount = document.getElementById('weeklyCount');
    elements.totalDownloads = document.getElementById('totalDownloads');
    
    console.log('📋 DOM 요소 초기화 완료');
}

// ===== 이벤트 리스너 초기화 =====
function initEventListeners() {
    // 수업 선택 변경
    if (elements.classSelect) {
        elements.classSelect.addEventListener('change', function() {
            updateUrlAndReload();
        });
    }
    
    // 정렬 방식 변경
    if (elements.sortSelect) {
        elements.sortSelect.addEventListener('change', function() {
            updateUrlAndReload({ sort: this.value });
        });
    }
    
    // 검색 관련 이벤트
    if (elements.searchInput) {
        elements.searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 2 || this.value.length === 0) {
                    performSearch();
                }
            }, 500); // 500ms 디바운싱
        });
        
        elements.searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch();
            }
        });
    }
    
    if (elements.searchBtn) {
        elements.searchBtn.addEventListener('click', performSearch);
    }
    
    // 게시글 행 클릭 이벤트 (이벤트 위임)
    if (elements.dataList) {
        elements.dataList.addEventListener('click', function(e) {
            const listRow = e.target.closest('.list-row');
            if (listRow) {
                const postId = listRow.getAttribute('data-post-id');
                if (postId) {
                    goToPost(postId);
                }
            }
        });
    }
    
    // 파일 아이템 클릭 이벤트 (다운로드)
    document.addEventListener('click', function(e) {
        const fileItem = e.target.closest('.file-item');
        if (fileItem && e.target.closest('.file-preview')) {
            e.stopPropagation(); // 게시글 클릭 이벤트 방지
            handleFileDownload(fileItem);
        }
    });
    
    // 스크롤 이벤트
    window.addEventListener('scroll', throttle(handleScroll, 16)); // ~60fps
    
    // 리사이즈 이벤트
    window.addEventListener('resize', debounce(handleResize, 250));
    
    // 페이지 떠날 때 스크롤 위치 저장
    window.addEventListener('beforeunload', saveScrollPosition);
    
    console.log('🎧 이벤트 리스너 초기화 완료');
}

// ===== 검색 실행 =====
function performSearch() {
    const searchType = elements.searchType ? elements.searchType.value : 'all';
    const keyword = elements.searchInput ? elements.searchInput.value.trim() : '';
    
    // 검색어 길이 검증
    if (keyword.length > 0 && keyword.length < 2) {
        showNotification('검색어는 2글자 이상 입력해주세요.', 'warning');
        return;
    }
    
    console.log(`🔍 검색 실행: ${searchType} - "${keyword}"`);
    
    // URL 업데이트 및 페이지 리로드
    updateUrlAndReload({
        searchType: searchType,
        keyword: keyword,
        page: 1 // 검색 시 첫 페이지로
    });
}

// ===== URL 업데이트 및 페이지 리로드 =====
function updateUrlAndReload(params = {}) {
    const url = new URL(window.location);
    
    // 기본 파라미터 설정
    const defaultParams = {
        classId: elements.classSelect ? elements.classSelect.value : '',
        searchType: elements.searchType ? elements.searchType.value : 'all',
        keyword: elements.searchInput ? elements.searchInput.value.trim() : '',
        sort: elements.sortSelect ? elements.sortSelect.value : 'latest',
        page: 1,
        size: 15
    };
    
    // 파라미터 병합
    const finalParams = { ...defaultParams, ...params };
    
    // URL 파라미터 설정
    Object.keys(finalParams).forEach(key => {
        if (finalParams[key]) {
            url.searchParams.set(key, finalParams[key]);
        } else {
            url.searchParams.delete(key);
        }
    });
    
    showLoading();
    
    // 페이지 이동
    window.location.href = url.toString();
}

// ===== 게시글 상세 페이지로 이동 =====
function goToPost(postId) {
    if (!postId) {
        console.error('게시글 ID가 없습니다.');
        return;
    }
    
    saveScrollPosition();
    showLoading();
    
    const url = `${window.contextPath}/viewPost.do?postId=${postId}&category=data`;
    window.location.href = url;
    
    console.log(`📄 게시글 상세 이동: ${postId}`);
}

// ===== 글쓰기 페이지로 이동 =====
function goToWrite() {
    if (!window.currentUser) {
        showNotification('로그인이 필요합니다.', 'warning');
        setTimeout(() => {
            window.location.href = `${window.contextPath}/login.do`;
        }, 1500);
        return;
    }
    
    const classId = elements.classSelect ? elements.classSelect.value : '';
    let url = `${window.contextPath}/writePost.do?category=data`;
    
    if (classId) {
        url += `&classId=${classId}`;
    }
    
    showLoading();
    window.location.href = url;
    
    console.log('✏️ 글쓰기 페이지 이동');
}

// ===== 파일 다운로드 처리 =====
function handleFileDownload(fileItem) {
    const fileName = fileItem.querySelector('.file-name')?.textContent;
    console.log(`📥 파일 다운로드: ${fileName}`);
    
    // 실제 구현 시에는 FileController의 download API 호출
    showNotification(`${fileName} 다운로드를 시작합니다.`, 'info');
}

// ===== 인기 자료 데이터 로드 =====
function loadPopularData() {
    if (popularDataCache) {
        displayPopularData(popularDataCache);
        return;
    }
    
    // 실제 구현에서는 AJAX로 서버에서 데이터 가져오기
    setTimeout(() => {
        const mockData = [
            {
                postId: 1,
                title: '2025년 웹 개발 트렌드 정리',
                downloads: 156,
                date: '01-15'
            },
            {
                postId: 2,
                title: 'JavaScript ES2025 새 기능',
                downloads: 98,
                date: '01-14'
            },
            {
                postId: 3,
                title: 'React 18 완벽 가이드',
                downloads: 87,
                date: '01-13'
            },
            {
                postId: 4,
                title: 'CSS Grid 마스터하기',
                downloads: 76,
                date: '01-12'
            },
            {
                postId: 5,
                title: 'Node.js 성능 최적화 팁',
                downloads: 65,
                date: '01-11'
            }
        ];
        
        popularDataCache = mockData;
        displayPopularData(mockData);
    }, 800);
}

// ===== 인기 자료 표시 =====
function displayPopularData(data) {
    if (!elements.popularList) return;
    
    const loadingElement = elements.popularList.querySelector('.loading-popular');
    if (loadingElement) {
        loadingElement.remove();
    }
    
    const html = data.map(item => `
        <div class="popular-item" onclick="goToPost(${item.postId})" data-post-id="${item.postId}">
            <div class="popular-title">${item.title}</div>
            <div class="popular-meta">
                <span>${item.date}</span>
                <span>${item.downloads}회 다운로드</span>
            </div>
        </div>
    `).join('');
    
    elements.popularList.innerHTML = html;
    
    console.log('📊 인기 자료 데이터 로드 완료');
}

// ===== 통계 데이터 로드 =====
function loadStatistics() {
    // 실제 구현에서는 AJAX로 서버에서 통계 데이터 가져오기
    setTimeout(() => {
        if (elements.weeklyCount) {
            elements.weeklyCount.textContent = '23개';
        }
        if (elements.totalDownloads) {
            elements.totalDownloads.textContent = '1,847회';
        }
        
        console.log('📈 통계 데이터 로드 완료');
    }, 1000);
}

// ===== 로딩 표시/숨김 =====
function showLoading() {
    if (elements.loadingOverlay) {
        elements.loadingOverlay.classList.add('active');
        isLoading = true;
    }
}

function hideLoading() {
    if (elements.loadingOverlay) {
        elements.loadingOverlay.classList.remove('active');
        isLoading = false;
    }
}

// ===== 알림 메시지 표시 =====
function showNotification(message, type = 'info', duration = 3000) {
    // 기존 알림 제거
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // 새 알림 생성
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // 스타일 설정
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        background: ${type === 'error' ? '#e74c3c' : type === 'warning' ? '#f39c12' : type === 'success' ? '#27ae60' : '#3498db'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.3s ease-out;
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    // 문서에 추가
    document.body.appendChild(notification);
    
    // 자동 제거
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, duration);
    
    console.log(`📢 알림: ${message}`);
}

// ===== 스크롤 위치 저장/복원 =====
function saveScrollPosition() {
    const scrollPosition = window.pageYOffset;
    sessionStorage.setItem('dataPage_scrollPosition', scrollPosition.toString());
}

function restoreScrollPosition() {
    const savedPosition = sessionStorage.getItem('dataPage_scrollPosition');
    if (savedPosition) {
        setTimeout(() => {
            window.scrollTo(0, parseInt(savedPosition));
            sessionStorage.removeItem('dataPage_scrollPosition');
        }, 100);
    }
}

// ===== 스크롤 이벤트 핸들러 =====
function handleScroll() {
    const scrollTop = window.pageYOffset;
    const header = document.querySelector('.header');
    
    // 헤더 스크롤 효과
    if (header) {
        if (scrollTop > 100) {
            header.style.backgroundColor = 'rgba(249, 249, 249, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
            header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.backgroundColor = '#f9f9f9';
            header.style.backdropFilter = 'none';
            header.style.boxShadow = 'none';
        }
    }
}

// ===== 리사이즈 이벤트 핸들러 =====
function handleResize() {
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
        // 모바일에서는 파일 미리보기 숨김
        const filePreviews = document.querySelectorAll('.file-preview');
        filePreviews.forEach(preview => {
            preview.style.display = 'none';
        });
        
        // 검색 입력창 크기 조정
        if (elements.searchInput) {
            elements.searchInput.style.width = '100%';
        }
    } else {
        // 데스크톱에서는 파일 미리보기 표시
        const filePreviews = document.querySelectorAll('.file-preview');
        filePreviews.forEach(preview => {
            preview.style.display = '';
        });
        
        // 검색 입력창 원래 크기로 복원
        if (elements.searchInput) {
            elements.searchInput.style.width = '';
        }
    }
}

// ===== 애니메이션 초기화 =====
function initAnimations() {
    // Intersection Observer를 사용한 스크롤 애니메이션
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        // 관찰할 요소들
        const animatedElements = document.querySelectorAll('.list-row, .popular-item, .stat-item');
        animatedElements.forEach(el => {
            observer.observe(el);
        });
    }
    
    // 파일 아이템 호버 애니메이션
    const fileItems = document.querySelectorAll('.file-item');
    fileItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
            this.style.transition = 'transform 0.2s ease';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
        });
    });
    
    console.log('🎭 애니메이션 초기화 완료');
}

// ===== 키보드 단축키 =====
function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + / : 검색 포커스
        if ((e.ctrlKey || e.metaKey) && e.key === '/') {
            e.preventDefault();
            if (elements.searchInput) {
                elements.searchInput.focus();
                elements.searchInput.select();
            }
        }
        
        // Ctrl/Cmd + Enter : 글쓰기
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            if (elements.writeBtn) {
                elements.writeBtn.click();
            }
        }
        
        // Ctrl/Cmd + K : 검색 타입 순환
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            cycleSearchType();
        }
        
        // Ctrl/Cmd + Shift + S : 정렬 방식 순환
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'S') {
            e.preventDefault();
            cycleSortType();
        }
        
        // ESC 키로 검색 초기화
        if (e.key === 'Escape') {
            if (elements.searchInput && elements.searchInput === document.activeElement) {
                elements.searchInput.blur();
            }
            
            // 검색어가 있다면 초기화
            if (elements.searchInput && elements.searchInput.value) {
                elements.searchInput.value = '';
                performSearch();
            }
        }
        
        // F5 또는 Ctrl/Cmd + R : 새로고침
        if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && e.key === 'r')) {
            saveScrollPosition();
        }
    });
    
    console.log('⌨️ 키보드 단축키 초기화 완료');
}

// ===== 검색 타입 순환 =====
function cycleSearchType() {
    if (!elements.searchType) return;
    
    const options = Array.from(elements.searchType.options);
    const currentIndex = elements.searchType.selectedIndex;
    const nextIndex = (currentIndex + 1) % options.length;
    
    elements.searchType.selectedIndex = nextIndex;
    showNotification(`검색 타입: ${options[nextIndex].text}`, 'info', 1500);
}

// ===== 정렬 방식 순환 =====
function cycleSortType() {
    if (!elements.sortSelect) return;
    
    const options = Array.from(elements.sortSelect.options);
    const currentIndex = elements.sortSelect.selectedIndex;
    const nextIndex = (currentIndex + 1) % options.length;
    
    elements.sortSelect.selectedIndex = nextIndex;
    updateUrlAndReload({ sort: options[nextIndex].value });
    showNotification(`정렬 방식: ${options[nextIndex].text}`, 'info', 1500);
}

// ===== 파일 크기 포맷팅 =====
function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

// ===== 파일 타입 감지 =====
function getFileIcon(filename) {
    const ext = filename.toLowerCase().split('.').pop();
    const iconMap = {
        'pdf': 'pdf-icon.png',
        'doc': 'doc-icon.png',
        'docx': 'doc-icon.png',
        'xls': 'doc-icon.png',
        'xlsx': 'doc-icon.png',
        'ppt': 'doc-icon.png',
        'pptx': 'doc-icon.png',
        'zip': 'zip-icon.png',
        'rar': 'zip-icon.png',
        '7z': 'zip-icon.png',
        'jpg': 'img-icon.png',
        'jpeg': 'img-icon.png',
        'png': 'img-icon.png',
        'gif': 'img-icon.png',
        'webp': 'img-icon.png'
    };
    
    return iconMap[ext] || 'doc-icon.png';
}

// ===== 즐겨찾기 기능 (향후 확장용) =====
function toggleBookmark(postId) {
    if (!window.currentUser) {
        showNotification('로그인이 필요합니다.', 'warning');
        return;
    }
    
    // 실제 구현에서는 서버 API 호출
    console.log(`⭐ 즐겨찾기 토글: ${postId}`);
    showNotification('즐겨찾기에 추가되었습니다.', 'success');
}

// ===== 파일 일괄 다운로드 (향후 확장용) =====
function downloadMultipleFiles(postId) {
    if (!window.currentUser) {
        showNotification('로그인이 필요합니다.', 'warning');
        return;
    }
    
    // 실제 구현에서는 서버에서 ZIP 파일 생성 후 다운로드
    console.log(`📦 일괄 다운로드: ${postId}`);
    showNotification('파일을 압축하여 다운로드합니다.', 'info');
}

// ===== 필터링 기능 =====
function filterByFileType(fileType) {
    const rows = document.querySelectorAll('.list-row');
    
    rows.forEach(row => {
        const fileItems = row.querySelectorAll('.file-item');
        let hasFileType = false;
        
        if (fileType === 'all') {
            hasFileType = true;
        } else {
            fileItems.forEach(item => {
                const fileName = item.querySelector('.file-name')?.textContent || '';
                const ext = fileName.toLowerCase().split('.').pop();
                
                if (fileType === 'document' && ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(ext)) {
                    hasFileType = true;
                }
                if (fileType === 'image' && ['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
                    hasFileType = true;
                }
                if (fileType === 'archive' && ['zip', 'rar', '7z'].includes(ext)) {
                    hasFileType = true;
                }
            });
        }
        
        row.style.display = hasFileType ? '' : 'none';
    });
    
    console.log(`🔍 파일 타입 필터링: ${fileType}`);
}

// ===== 통계 업데이트 =====
function updateStatistics() {
    // 현재 페이지의 게시글 통계 계산
    const rows = document.querySelectorAll('.list-row:not([style*="display: none"])');
    let totalFiles = 0;
    let totalSize = 0;
    let totalDownloads = 0;
    
    rows.forEach(row => {
        const fileCountEl = row.querySelector('.file-count');
        const totalSizeEl = row.querySelector('.total-size');
        const downloadsEl = row.querySelector('.col-downloads');
        
        if (fileCountEl) {
            const fileCount = parseInt(fileCountEl.textContent) || 0;
            totalFiles += fileCount;
        }
        
        if (downloadsEl) {
            const downloads = parseInt(downloadsEl.textContent) || 0;
            totalDownloads += downloads;
        }
    });
    
    // 사이드바 통계 업데이트
    if (elements.totalDownloads) {
        elements.totalDownloads.textContent = totalDownloads.toLocaleString() + '회';
    }
    
    console.log(`📊 통계 업데이트: 파일 ${totalFiles}개, 다운로드 ${totalDownloads}회`);
}

// ===== 무한 스크롤 (향후 확장용) =====
function initInfiniteScroll() {
    let isLoadingMore = false;
    
    window.addEventListener('scroll', function() {
        if (isLoadingMore || isLoading) return;
        
        const scrollTop = window.pageYOffset;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        
        // 페이지 하단에서 200px 위에 도달했을 때
        if (scrollTop + windowHeight >= documentHeight - 200) {
            loadMorePosts();
        }
    });
}

function loadMorePosts() {
    // 향후 AJAX를 통한 무한 스크롤 구현 시 사용
    console.log('📜 더 많은 게시글 로드 (향후 구현)');
}

// ===== 터치 이벤트 (모바일 지원) =====
function initTouchEvents() {
    if ('ontouchstart' in window) {
        // 터치 디바이스에서 호버 효과 대신 터치 효과 적용
        const listRows = document.querySelectorAll('.list-row');
        
        listRows.forEach(row => {
            row.addEventListener('touchstart', function() {
                this.classList.add('touched');
            });
            
            row.addEventListener('touchend', function() {
                setTimeout(() => {
                    this.classList.remove('touched');
                }, 150);
            });
        });
    }
}

// ===== 디바운싱 함수 =====
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===== 쓰로틀링 함수 =====
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ===== 에러 처리 =====
window.addEventListener('error', function(e) {
    console.error('JavaScript 오류 발생:', e.error);
    hideLoading();
    
    if (e.error.message.includes('Failed to fetch')) {
        showNotification('네트워크 연결을 확인해주세요.', 'error');
    }
});

// ===== 브라우저 호환성 검사 =====
function checkBrowserCompatibility() {
    // CSS Grid 지원 확인
    if (!CSS.supports('display', 'grid')) {
        console.warn('CSS Grid를 지원하지 않는 브라우저입니다.');
        showNotification('일부 기능이 제한될 수 있습니다.', 'warning');
        
        // 폴백: 플렉스 레이아웃으로 변경
        const container = document.querySelector('.container');
        if (container) {
            container.style.display = 'block';
        }
    }
    
    // IntersectionObserver 지원 확인
    if (!window.IntersectionObserver) {
        console.warn('IntersectionObserver를 지원하지 않는 브라우저입니다.');
        
        // 폴백: 모든 애니메이션 요소를 즉시 표시
        const animatedElements = document.querySelectorAll('.list-row, .popular-item');
        animatedElements.forEach(element => {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        });
    }
}

// ===== 접근성 향상 =====
function improveAccessibility() {
    // 포커스 관리
    const focusableElements = document.querySelectorAll(
        'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
    );
    
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '3px solid #5dade2';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
    
    // 키보드 네비게이션
    document.addEventListener('keydown', function(e) {
        // Enter 키로 행 클릭
        if (e.key === 'Enter' && e.target.classList.contains('list-row')) {
            e.target.click();
        }
        
        // Space 키로 파일 다운로드
        if (e.key === ' ' && e.target.classList.contains('file-item')) {
            e.preventDefault();
            handleFileDownload(e.target);
        }
    });
}

// ===== 성능 최적화 =====
function optimizePerformance() {
    // 가상 스크롤링 (많은 데이터가 있을 때)
    const listRows = document.querySelectorAll('.list-row');
    if (listRows.length > 100) {
        console.log('⚡ 가상 스크롤링 적용 (많은 데이터 감지)');
        // 실제 가상 스크롤링 구현은 복잡하므로 여기서는 생략
    }
    
    // 이미지 지연 로딩
    const images = document.querySelectorAll('img[data-src]');
    if ('IntersectionObserver' in window && images.length > 0) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    }
}

// ===== 초기화 완료 후 실행 =====
function afterInit() {
    checkBrowserCompatibility();
    improveAccessibility();
    initTouchEvents();
    optimizePerformance();
    updateStatistics();
    
    // 파일 미리보기 개선
    enhanceFilePreviews();
    
    // 키보드 사용자를 위한 안내
    if (window.currentUser) {
        console.log('⌨️ 키보드 단축키:');
        console.log('  Ctrl+/ : 검색 포커스');
        console.log('  Ctrl+Enter : 글쓰기');
        console.log('  Ctrl+K : 검색 타입 변경');
        console.log('  Ctrl+Shift+S : 정렬 방식 변경');
        console.log('  ESC : 검색 초기화');
    }
}

// ===== 파일 미리보기 개선 =====
function enhanceFilePreviews() {
    const fileItems = document.querySelectorAll('.file-item');
    
    fileItems.forEach(item => {
        const fileName = item.querySelector('.file-name')?.textContent;
        if (!fileName) return;
        
        // 파일 확장자에 따른 추가 정보 표시
        const ext = fileName.toLowerCase().split('.').pop();
        const fileInfo = item.querySelector('.file-info');
        
        if (fileInfo) {
            let additionalInfo = '';
            
            switch (ext) {
                case 'pdf':
                    additionalInfo = '<span class="file-type-badge pdf">PDF</span>';
                    break;
                case 'docx':
                case 'doc':
                    additionalInfo = '<span class="file-type-badge doc">문서</span>';
                    break;
                case 'xlsx':
                case 'xls':
                    additionalInfo = '<span class="file-type-badge excel">Excel</span>';
                    break;
                case 'pptx':
                case 'ppt':
                    additionalInfo = '<span class="file-type-badge ppt">PPT</span>';
                    break;
                case 'zip':
                case 'rar':
                    additionalInfo = '<span class="file-type-badge archive">압축</span>';
                    break;
            }
            
            if (additionalInfo) {
                fileInfo.innerHTML += additionalInfo;
            }
        }
    });
}

// ===== 전역 함수 노출 =====
window.goToPost = goToPost;
window.goToWrite = goToWrite;
window.performSearch = performSearch;
window.handleFileDownload = handleFileDownload;
window.toggleBookmark = toggleBookmark;
window.downloadMultipleFiles = downloadMultipleFiles;
window.filterByFileType = filterByFileType;

// 페이지 로드 완료 후 추가 초기화
document.addEventListener('DOMContentLoaded', afterInit);

console.log('📁 DataPage.js 로드 완료 - 모든 기능이 활성화되었습니다! 🚀');

// ===== 성능 모니터링 (개발용) =====
if (console && console.time) {
    console.time('DataPage 초기화 시간');
    
    window.addEventListener('load', function() {
        console.timeEnd('DataPage 초기화 시간');
        console.log('📊 성능 정보:', {
            게시글수: document.querySelectorAll('.list-row').length,
            파일수: document.querySelectorAll('.file-item').length,
            정렬방식: currentSort,
            현재페이지: window.pageInfo ? window.pageInfo.currentPage : 'N/A'
        });
    });
}

// ===== CSS 애니메이션 추가 (JavaScript에서 동적 추가) =====
const additionalStyles = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .notification {
        animation: slideInRight 0.3s ease-out;
    }
    
    .list-row.touched {
        background: #e3f2fd !important;
        transform: translateX(3px);
    }
    
    .file-type-badge {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 600;
        margin-left: 5px;
        color: white;
    }
    
    .file-type-badge.pdf { background: #e74c3c; }
    .file-type-badge.doc { background: #2980b9; }
    .file-type-badge.excel { background: #27ae60; }
    .file-type-badge.ppt { background: #f39c12; }
    .file-type-badge.archive { background: #8e44ad; }
`;

// 스타일 추가
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);