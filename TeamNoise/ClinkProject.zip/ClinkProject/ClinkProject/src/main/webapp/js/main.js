/**
 * main.js - 메인 대시보드 JavaScript
 */

// DOM이 로드된 후 실행
document.addEventListener('DOMContentLoaded', function() {
    console.log('Main 페이지 초기화 시작');
    
    // 초기화 함수들 실행
    initSmoothScroll();
    initCardAnimations();
    initNavigation();
    initLoadingStates();
    
    console.log('Main 페이지 초기화 완료');
});

/**
 * 부드러운 스크롤 효과 초기화
 */
function initSmoothScroll() {
    // 앵커 링크 클릭 시 부드러운 스크롤
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                // 스크롤 애니메이션
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // URL 업데이트 (히스토리에 추가하지 않음)
                history.replaceState(null, null, targetId);
                
                console.log('스크롤 이동:', targetId);
            }
        });
    });
}

/**
 * 카드 애니메이션 효과 초기화
 */
function initCardAnimations() {
    const cards = document.querySelectorAll('.card');
    const memberCards = document.querySelectorAll('.member-card');
    
    // Intersection Observer를 사용한 스크롤 애니메이션
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // 카드들에 관찰자 추가
    [...cards, ...memberCards].forEach(card => {
        observer.observe(card);
    });

    // 카드 호버 효과 강화
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-4px) scale(1.03)';
            
            // 카드 내 이미지 애니메이션
            const cardImage = this.querySelector('.card-image img');
            if (cardImage) {
                cardImage.style.transform = 'scale(1.05)';
            }
            
            // 화살표 애니메이션
            const arrowIcon = this.querySelector('.go-row img');
            if (arrowIcon) {
                arrowIcon.style.transform = 'translateX(4px)';
            }
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(-4px) scale(1.03)';
            
            // 원래 상태로 복원
            const cardImage = this.querySelector('.card-image img');
            if (cardImage) {
                cardImage.style.transform = 'scale(1)';
            }
            
            const arrowIcon = this.querySelector('.go-row img');
            if (arrowIcon) {
                arrowIcon.style.transform = 'translateX(0)';
            }
        });
    });

    // 팀 멤버 카드 호버 효과
    memberCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const memberImage = this.querySelector('img');
            if (memberImage) {
                memberImage.style.transform = 'scale(1.1)';
                memberImage.style.borderColor = '#a8f050';
            }
        });

        card.addEventListener('mouseleave', function() {
            const memberImage = this.querySelector('img');
            if (memberImage) {
                memberImage.style.transform = 'scale(1)';
                memberImage.style.borderColor = '#B9FF66';
            }
        });
    });
}

/**
 * 네비게이션 기능 초기화
 */
function initNavigation() {
    const navLinks = document.querySelectorAll('nav a');
    const cardLinks = document.querySelectorAll('.card-link');
    const heroButton = document.querySelector('.hero button');
    const logoutBtn = document.querySelector('.login-btn');
    const userInfo = document.querySelector('.user-info');

    // 사용자 정보 호버 효과
    if (userInfo) {
        userInfo.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
            this.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
        });

        userInfo.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = 'none';
        });
    }

    // 네비게이션 링크 클릭 이벤트
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // 외부 링크인 경우 기본 동작 유지
            if (href.startsWith('http') || href.endsWith('.do')) {
                console.log('페이지 이동:', href);
                return;
            }
            
            // 앵커 링크인 경우는 이미 initSmoothScroll에서 처리됨
        });
    });

    // 카드 링크 클릭 이벤트
    cardLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // 로딩 효과 추가
            addLoadingState(this);
            
            console.log('게시판 이동:', this.getAttribute('href'));
            
            // 실제 페이지 이동은 href로 자동 처리됨
        });
    });

    // 수업 참여 버튼 클릭 이벤트
    if (heroButton) {
        heroButton.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 로딩 효과
            addLoadingState(this);
            
            console.log('수업 참여 버튼 클릭');
            
            // 페이지 이동
            setTimeout(() => {
                window.location.href = this.parentElement.getAttribute('href');
            }, 300);
        });
    }

    // 로그아웃 버튼 확인
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (confirm('정말 로그아웃하시겠습니까?')) {
                console.log('로그아웃 처리');
                
                // 로딩 효과
                addLoadingState(this);
                
                // 로그아웃 요청
                setTimeout(() => {
                    window.location.href = this.parentElement.getAttribute('href');
                }, 500);
            }
        });
    }
}

/**
 * 로딩 상태 관리
 */
function initLoadingStates() {
    // 페이지 로딩 완료 시 애니메이션 시작
    window.addEventListener('load', function() {
        document.body.classList.remove('loading');
        
        // 헤더 애니메이션
        const header = document.querySelector('header');
        if (header) {
            header.style.opacity = '0';
            header.style.transform = 'translateY(-20px)';
            
            setTimeout(() => {
                header.style.transition = 'all 0.6s ease';
                header.style.opacity = '1';
                header.style.transform = 'translateY(0)';
            }, 100);
        }

        // 히어로 섹션 애니메이션
        const heroText = document.querySelector('.hero-text');
        const heroImage = document.querySelector('.hero-image');
        
        if (heroText && heroImage) {
            heroText.style.opacity = '0';
            heroText.style.transform = 'translateX(-30px)';
            heroImage.style.opacity = '0';
            heroImage.style.transform = 'translateX(30px)';
            
            setTimeout(() => {
                heroText.style.transition = 'all 0.8s ease';
                heroText.style.opacity = '1';
                heroText.style.transform = 'translateX(0)';
                
                heroImage.style.transition = 'all 0.8s ease';
                heroImage.style.opacity = '1';
                heroImage.style.transform = 'translateX(0)';
            }, 200);
        }
    });
}

/**
 * 요소에 로딩 상태 추가
 * @param {Element} element - 로딩 상태를 적용할 요소
 */
function addLoadingState(element) {
    element.classList.add('loading');
    
    // 버튼인 경우 텍스트 변경
    if (element.tagName === 'BUTTON') {
        const originalText = element.textContent;
        element.textContent = '처리중...';
        element.disabled = true;
        
        // 3초 후 원래 상태로 복원 (실제로는 페이지가 이동됨)
        setTimeout(() => {
            element.textContent = originalText;
            element.disabled = false;
            element.classList.remove('loading');
        }, 3000);
    }
}

/**
 * 스크롤 이벤트 처리
 */
window.addEventListener('scroll', function() {
    const scrollTop = window.pageYOffset;
    const header = document.querySelector('header');
    
    // 헤더 스크롤 효과
    if (header) {
        if (scrollTop > 100) {
            header.style.backgroundColor = 'rgba(249, 249, 249, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
            header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.backgroundColor = '#f9f9f9';
            header.style.backdropFilter = 'none';
            header.style.boxShadow = 'none';
        }
    }
});

/**
 * 반응형 처리
 */
window.addEventListener('resize', function() {
    // 화면 크기 변경 시 필요한 처리
    const cards = document.querySelectorAll('.card');
    
    if (window.innerWidth <= 768) {
        // 모바일에서는 카드 애니메이션 단순화
        cards.forEach(card => {
            card.style.transition = 'all 0.2s ease';
        });
    } else {
        // 데스크톱에서는 기본 애니메이션
        cards.forEach(card => {
            card.style.transition = 'all 0.3s ease';
        });
    }
});

/**
 * 에러 처리
 */
window.addEventListener('error', function(e) {
    console.error('JavaScript 오류 발생:', e.error);
    
    // 사용자에게 알림 (선택적)
    if (e.error.message.includes('Failed to fetch')) {
        console.warn('네트워크 오류가 발생했습니다.');
    }
});

/**
 * 브라우저 호환성 검사
 */
function checkBrowserCompatibility() {
    // IntersectionObserver 지원 확인
    if (!window.IntersectionObserver) {
        console.warn('IntersectionObserver를 지원하지 않는 브라우저입니다.');
        
        // 폴백: 모든 애니메이션 요소를 즉시 표시
        const animatedElements = document.querySelectorAll('.card, .member-card');
        animatedElements.forEach(element => {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        });
    }
    
    // CSS Grid 지원 확인
    if (!CSS.supports('display', 'grid')) {
        console.warn('CSS Grid를 지원하지 않는 브라우저입니다.');
        
        // 폴백: Flexbox 레이아웃으로 변경
        const cardsContainer = document.querySelector('.cards');
        if (cardsContainer) {
            cardsContainer.style.display = 'flex';
            cardsContainer.style.flexWrap = 'wrap';
            cardsContainer.style.justifyContent = 'center';
        }
    }
}

// 페이지 로드 시 브라우저 호환성 검사
checkBrowserCompatibility();

/**
 * 유틸리티 함수들
 */

// 디바운싱 함수
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 쓰로틀링 함수
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// 스크롤 이벤트 최적화
const optimizedScrollHandler = throttle(function() {
    const scrollTop = window.pageYOffset;
    const header = document.querySelector('header');
    
    if (header) {
        if (scrollTop > 100) {
            header.style.backgroundColor = 'rgba(249, 249, 249, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
            header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.backgroundColor = '#f9f9f9';
            header.style.backdropFilter = 'none';
            header.style.boxShadow = 'none';
        }
    }
}, 16); // ~60fps

// 기존 스크롤 이벤트를 최적화된 버전으로 교체
window.removeEventListener('scroll', window.addEventListener);
window.addEventListener('scroll', optimizedScrollHandler);

/**
 * 접근성 향상
 */
function improveAccessibility() {
    // 포커스 관리
    const focusableElements = document.querySelectorAll(
        'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
    );
    
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid #B9FF66';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
    
    // 키보드 네비게이션
    document.addEventListener('keydown', function(e) {
        // ESC 키로 모달 닫기 (향후 모달 추가 시 사용)
        if (e.key === 'Escape') {
            console.log('ESC 키 누름');
        }
        
        // Enter 키로 링크 활성화
        if (e.key === 'Enter' && e.target.classList.contains('card-link')) {
            e.target.click();
        }
    });
}

// 접근성 기능 초기화
improveAccessibility();

console.log('Main.js 로드 완료 - 모든 기능이 활성화되었습니다.');