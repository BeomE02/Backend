// find.js - 비밀번호 찾기 페이지 JavaScript (이메일 관련 코드 제거)

document.addEventListener('DOMContentLoaded', function() {
    initFindForm();
});

/**
 * 비밀번호 찾기 폼 초기화
 */
function initFindForm() {
    const findForm = document.querySelector('form[action*="find.do"]');
    if (!findForm) return;
    
    // 필드 참조
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    
    // 실시간 검증 이벤트 리스너
    if (nameInput) {
        nameInput.addEventListener('blur', () => validateName(nameInput));
        nameInput.addEventListener('input', () => clearFieldValidation(nameInput));
    }
    
    if (usernameInput) {
        usernameInput.addEventListener('blur', () => validateUsername(usernameInput));
        usernameInput.addEventListener('input', () => clearFieldValidation(usernameInput));
    }
    
    // 폼 제출 이벤트
    findForm.addEventListener('submit', function(e) {
        if (!validateFindForm()) {
            e.preventDefault();
            showAlert('입력 정보를 다시 확인해주세요.', 'error');
        } else {
            // 폼 제출 시 로딩 표시
            showLoading();
        }
    });
    
    // 초기 포커스 설정
    if (nameInput && !nameInput.value) {
        nameInput.focus();
    }
}

/**
 * 이름 검증
 */
function validateName(nameInput) {
    const name = nameInput.value.trim();
    
    if (!name) {
        setFieldInvalid(nameInput, '이름을 입력해주세요.');
        return false;
    }
    
    if (!validateNameFormat(name)) {
        setFieldInvalid(nameInput, '올바른 이름을 입력해주세요.');
        return false;
    }
    
    setFieldValid(nameInput);
    return true;
}

/**
 * 아이디 검증
 */
function validateUsername(usernameInput) {
    const username = usernameInput.value.trim();
    
    if (!username) {
        setFieldInvalid(usernameInput, '아이디를 입력해주세요.');
        return false;
    }
    
    if (!validateUsernameFormat(username)) {
        setFieldInvalid(usernameInput, '영문자와 숫자만 입력 가능합니다.');
        return false;
    }
    
    setFieldValid(usernameInput);
    return true;
}

/**
 * 전체 폼 검증
 */
function validateFindForm() {
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    
    let isValid = true;
    
    if (!validateName(nameInput)) isValid = false;
    if (!validateUsername(usernameInput)) isValid = false;
    
    return isValid;
}

/**
 * 이름 형식 검증
 */
function validateNameFormat(name) {
    // 한글, 영문, 공백만 허용 (2-20자)
    const namePattern = /^[가-힣a-zA-Z\s]{2,20}$/;
    return namePattern.test(name);
}

/**
 * 아이디 형식 검증
 */
function validateUsernameFormat(username) {
    // 영문자와 숫자만 허용 (3-20자)
    const usernamePattern = /^[a-zA-Z0-9]{3,20}$/;
    return usernamePattern.test(username);
}

/**
 * 입력 필드 유효 상태 설정
 */
function setFieldValid(field) {
    field.style.borderColor = '#10b981';
    field.style.backgroundColor = '#f0fdf4';
    removeFieldMessage(field);
}

/**
 * 입력 필드 무효 상태 설정
 */
function setFieldInvalid(field, message) {
    field.style.borderColor = '#ef4444';
    field.style.backgroundColor = '#fef2f2';
    showFieldMessage(field, message, 'error');
}

/**
 * 입력 필드 검증 상태 초기화
 */
function clearFieldValidation(field) {
    field.style.borderColor = '';
    field.style.backgroundColor = '';
    removeFieldMessage(field);
}

/**
 * 필드별 메시지 표시
 */
function showFieldMessage(field, message, type) {
    removeFieldMessage(field);
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `field-message field-message-${type}`;
    messageDiv.textContent = message;
    messageDiv.style.fontSize = '12px';
    messageDiv.style.marginTop = '4px';
    messageDiv.style.color = type === 'error' ? '#ef4444' : '#10b981';
    
    field.parentNode.appendChild(messageDiv);
}

/**
 * 필드 메시지 제거
 */
function removeFieldMessage(field) {
    const existingMessage = field.parentNode.querySelector('.field-message');
    if (existingMessage) {
        existingMessage.remove();
    }
}

/**
 * 로딩 표시
 */
function showLoading() {
    const submitBtn = document.querySelector('.submit-btn');
    if (submitBtn) {
        submitBtn.textContent = '처리 중...';
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.7';
    }
}

/**
 * 알림 메시지 표시
 */
function showAlert(message, type = 'info', duration = 3000) {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} fade-in`;
    alert.textContent = message;
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        max-width: 300px;
        padding: 12px 16px;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        background: ${type === 'error' ? '#fef2f2' : type === 'success' ? '#f0fdf4' : '#f8fafc'};
        color: ${type === 'error' ? '#dc2626' : type === 'success' ? '#16a34a' : '#475569'};
        border-left: 4px solid ${type === 'error' ? '#dc2626' : type === 'success' ? '#16a34a' : '#3b82f6'};
    `;
    
    document.body.appendChild(alert);
    
    // 자동 제거
    setTimeout(() => {
        alert.classList.add('fade-out');
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 300);
    }, duration);
    
    return alert;
}

/**
 * 도움말 토글
 */
function toggleHelp() {
    const helpSection = document.querySelector('.help-section');
    if (helpSection) {
        helpSection.style.display = helpSection.style.display === 'none' ? 'block' : 'none';
    }
}

/**
 * 입력 필드 자동 포커스 이동
 */
function setupAutoFocus() {
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    
    if (nameInput && usernameInput) {
        nameInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                e.preventDefault();
                usernameInput.focus();
            }
        });
        
        usernameInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                e.preventDefault();
                document.querySelector('.submit-btn').click();
            }
        });
    }
}

// 자동 포커스 설정 실행
setupAutoFocus();