// signup.js - 회원가입 페이지 JavaScript (개선된 버전)

document.addEventListener('DOMContentLoaded', function() {
    initSignupForm();
    handleServerMessages(); // 서버 메시지 처리 추가
});

/**
 * 🔥 교수 인증코드 토글 함수 (전역 함수로 추가)
 */
function toggleAuthCode() {
    console.log('🔥 toggleAuthCode 함수 호출됨!'); // 디버깅
    
    const professorRadio = document.querySelector('input[name="role"][value="professor"]');
    const studentRadio = document.querySelector('input[name="role"][value="student"]');
    const authCodeDiv = document.getElementById('authCodeDiv');
    const authCodeInput = document.getElementById('authCode');
    
    console.log('교수 라디오:', professorRadio ? professorRadio.checked : 'null');
    console.log('학생 라디오:', studentRadio ? studentRadio.checked : 'null');
    console.log('인증코드 영역:', authCodeDiv ? 'exists' : 'null');
    
    if (!authCodeDiv) {
        console.error('❌ authCodeDiv를 찾을 수 없습니다!');
        return;
    }
    
    if (professorRadio && professorRadio.checked) {
        console.log('✅ 교수 선택됨 - 인증코드 필드 표시');
        authCodeDiv.style.display = 'block';
        if (authCodeInput) {
            authCodeInput.required = true;
        }
    } else {
        console.log('✅ 학생 선택됨 - 인증코드 필드 숨김');
        authCodeDiv.style.display = 'none';
        if (authCodeInput) {
            authCodeInput.required = false;
            authCodeInput.value = '';
        }
        clearFieldValidation(authCodeInput);
    }
}

/**
 * 🔥 실시간 비밀번호 확인 함수 (전역 함수로 추가)
 */
function checkPasswordMatch() {
    const password = document.getElementById('password').value;
    const passwordCheck = document.getElementById('passwordCheck').value;
    const msg = document.getElementById('pwMsg');
    
    if (!passwordCheck) {
        msg.innerHTML = '';
        msg.className = '';
        return false;
    }
    
    if (password === passwordCheck) {
        msg.innerHTML = '✓ 비밀번호가 일치합니다.';
        msg.className = 'success';
        return true;
    } else {
        msg.innerHTML = '✗ 비밀번호가 일치하지 않습니다.';
        msg.className = 'error';
        return false;
    }
}

/**
 * 🔥 폼 유효성 검사 함수 (전역 함수로 추가)
 */
function validateForm() {
    console.log('validateForm 호출됨'); // 디버깅
    
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const passwordCheckInput = document.getElementById('passwordCheck');
    const authCodeInput = document.getElementById('authCode');
    const roleInput = document.querySelector('input[name="role"]:checked');
    
    let isValid = true;
    let errorMessages = [];
    
    // 각 필드 검증
    if (!validateName(nameInput)) {
        errorMessages.push('이름을 올바르게 입력해주세요.');
        isValid = false;
    }
    
    if (!validateUsername(usernameInput)) {
        errorMessages.push('아이디를 올바르게 입력해주세요.');
        isValid = false;
    }
    
    if (!validatePassword(passwordInput)) {
        errorMessages.push('비밀번호를 올바르게 입력해주세요.');
        isValid = false;
    }
    
    if (!validatePasswordConfirm(passwordInput, passwordCheckInput)) {
        errorMessages.push('비밀번호가 일치하지 않습니다.');
        isValid = false;
    }
    
    // 역할 선택 체크
    if (!roleInput) {
        errorMessages.push('학생 또는 교수를 선택해주세요.');
        isValid = false;
    }
    
    // 교수 인증코드 체크
    if (roleInput && roleInput.value === 'professor') {
        if (!validateAuthCode(authCodeInput)) {
            errorMessages.push('교수 인증코드를 올바르게 입력해주세요.');
            isValid = false;
        }
    }
    
    if (!isValid) {
        showCustomAlert(errorMessages.join(' '), 'error');
    }
    
    return isValid;
}

/**
 * 서버 메시지 처리
 */
function handleServerMessages() {
    // 기존 에러/성공 메시지를 커스텀 알림창으로 변환
    const errorMsg = document.querySelector('.error-message');
    const successMsg = document.querySelector('.success-message');
    
    if (errorMsg && errorMsg.textContent.trim()) {
        showCustomAlert(errorMsg.textContent.trim(), 'error');
        errorMsg.style.display = 'none';
    }
    
    if (successMsg && successMsg.textContent.trim()) {
        showCustomAlert(successMsg.textContent.trim(), 'success');
        successMsg.style.display = 'none';
    }
}

/**
 * 커스텀 알림창 표시
 */
function showCustomAlert(message, type = 'info', duration = 5000) {
    // 기존 알림창 제거
    const existingAlert = document.querySelector('.custom-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // 새 알림창 생성
    const alertDiv = document.createElement('div');
    alertDiv.className = `custom-alert custom-alert-${type}`;
    
    // 아이콘 선택
    const icons = {
        error: '⚠️',
        success: '✅',
        warning: '⚡',
        info: 'ℹ️'
    };
    
    alertDiv.innerHTML = `
        <div class="alert-content">
            <span class="alert-icon">${icons[type] || icons.info}</span>
            <span class="alert-message">${message}</span>
            <button class="alert-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // 스타일 적용
    alertDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        max-width: 400px;
        padding: 0;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        font-family: inherit;
        backdrop-filter: blur(10px);
    `;
    
    // 타입별 색상 설정
    const colors = {
        error: {
            bg: 'linear-gradient(145deg, #fef2f2, #fee2e2)',
            border: '#fecaca',
            text: '#dc2626'
        },
        success: {
            bg: 'linear-gradient(145deg, #ecfdf5, #d1fae5)',
            border: '#a7f3d0',
            text: '#059669'
        },
        warning: {
            bg: 'linear-gradient(145deg, #fffbeb, #fef3c7)',
            border: '#fcd34d',
            text: '#d97706'
        },
        info: {
            bg: 'linear-gradient(145deg, #f0f9ff, #e0f2fe)',
            border: '#bae6fd',
            text: '#0369a1'
        }
    };
    
    const color = colors[type] || colors.info;
    alertDiv.style.background = color.bg;
    alertDiv.style.border = `2px solid ${color.border}`;
    alertDiv.style.color = color.text;
    
    // 내부 스타일
    const content = alertDiv.querySelector('.alert-content');
    content.style.cssText = `
        display: flex;
        align-items: center;
        padding: 16px 20px;
        gap: 12px;
    `;
    
    const icon = alertDiv.querySelector('.alert-icon');
    icon.style.cssText = `
        font-size: 20px;
        flex-shrink: 0;
    `;
    
    const messageEl = alertDiv.querySelector('.alert-message');
    messageEl.style.cssText = `
        flex: 1;
        font-weight: 500;
        line-height: 1.5;
        font-size: 14px;
    `;
    
    const closeBtn = alertDiv.querySelector('.alert-close');
    closeBtn.style.cssText = `
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        padding: 4px;
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: all 0.2s ease;
        color: inherit;
        opacity: 0.7;
    `;
    
    closeBtn.addEventListener('mouseenter', () => {
        closeBtn.style.opacity = '1';
        closeBtn.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
    });
    
    closeBtn.addEventListener('mouseleave', () => {
        closeBtn.style.opacity = '0.7';
        closeBtn.style.backgroundColor = 'transparent';
    });
    
    // 애니메이션 추가
    if (!document.querySelector('#custom-alert-styles')) {
        const style = document.createElement('style');
        style.id = 'custom-alert-styles';
        style.textContent = `
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            @keyframes slideOutRight {
                from {
                    opacity: 1;
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // 문서에 추가
    document.body.appendChild(alertDiv);
    
    // 자동 닫기
    if (duration > 0) {
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.style.animation = 'slideOutRight 0.3s ease-in';
                setTimeout(() => {
                    if (alertDiv.parentNode) {
                        alertDiv.remove();
                    }
                }, 300);
            }
        }, duration);
    }
}

/**
 * 회원가입 폼 초기화
 */
function initSignupForm() {
    const signupForm = document.forms.signupForm;
    if (!signupForm) return;
    
    console.log('🚀 폼 초기화 시작'); // 디버깅
    
    // 필드 참조
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const passwordCheckInput = document.getElementById('passwordCheck');
    const roleInputs = document.querySelectorAll('input[name="role"]');
    const authCodeInput = document.getElementById('authCode');
    const authCodeDiv = document.getElementById('authCodeDiv');
    
    console.log('라디오 버튼 개수:', roleInputs.length);
    console.log('인증코드 영역:', authCodeDiv ? 'exists' : 'NOT FOUND');
    
    // 🔥 라디오 버튼에 change 이벤트 추가 (onclick과 함께 동작)
    roleInputs.forEach((radio, index) => {
        console.log(`라디오 ${index}: value=${radio.value}, checked=${radio.checked}`);
        
        // change 이벤트 추가
        radio.addEventListener('change', function() {
            console.log(`🔄 라디오 변경됨: ${this.value} (checked: ${this.checked})`);
            toggleAuthCode();
        });
        
        // click 이벤트도 추가 (혹시 몰라서)
        radio.addEventListener('click', function() {
            console.log(`🖱️ 라디오 클릭됨: ${this.value}`);
            setTimeout(toggleAuthCode, 10); // 약간의 지연
        });
    });
    
    // 🔥 페이지 로드 즉시 초기 상태 설정
    console.log('초기 상태 설정 중...');
    setTimeout(toggleAuthCode, 100); // 100ms 후 실행
    
    // 실시간 검증 이벤트 리스너
    if (nameInput) {
        nameInput.addEventListener('input', () => validateName(nameInput));
        nameInput.addEventListener('blur', () => validateName(nameInput));
    }
    
    if (usernameInput) {
        usernameInput.addEventListener('input', () => validateUsername(usernameInput));
        usernameInput.addEventListener('blur', () => validateUsername(usernameInput));
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('input', () => {
            validatePassword(passwordInput);
            if (passwordCheckInput && passwordCheckInput.value) {
                validatePasswordConfirm(passwordInput, passwordCheckInput);
            }
        });
    }
    
    if (passwordCheckInput) {
        passwordCheckInput.addEventListener('input', () => {
            validatePasswordConfirm(passwordInput, passwordCheckInput);
            checkPasswordMatch(); // pwMsg 업데이트
        });
    }
    
    if (authCodeInput) {
        authCodeInput.addEventListener('input', () => validateAuthCode(authCodeInput));
    }
    
    // 🔥 폼 제출 이벤트 추가 (JSP에 onsubmit이 없으므로)
    signupForm.addEventListener('submit', function(e) {
        console.log('📝 폼 제출 시도');
        if (!validateForm()) {
            e.preventDefault();
            console.log('❌ 폼 검증 실패');
        } else {
            console.log('✅ 폼 검증 성공');
        }
    });
    
    console.log('✅ 폼 초기화 완료'); // 디버깅
}

/**
 * 이름 검증
 */
function validateName(nameInput) {
    const name = nameInput.value.trim();
    
    if (!name) {
        setFieldInvalid(nameInput, '이름을 입력해주세요.');
        return false;
    }
    
    if (!validateNameFormat(name)) {
        setFieldInvalid(nameInput, '한글 또는 영문으로 2-20자여야 합니다.');
        return false;
    }
    
    setFieldValid(nameInput);
    return true;
}

/**
 * 아이디 검증
 */
function validateUsername(usernameInput) {
    const username = usernameInput.value.trim();
    
    if (!username) {
        setFieldInvalid(usernameInput, '아이디를 입력해주세요.');
        return false;
    }
    
    if (!validateUsernameFormat(username)) {
        setFieldInvalid(usernameInput, '영문자와 숫자 조합으로 3-20자여야 합니다.');
        return false;
    }
    
    setFieldValid(usernameInput);
    return true;
}

/**
 * 비밀번호 검증 (🔥 길이 제한 강화)
 */
function validatePassword(passwordInput) {
    const password = passwordInput.value;
    
    if (!password) {
        setFieldInvalid(passwordInput, '비밀번호를 입력해주세요.');
        return false;
    }
    
    if (password.length < 4) {
        setFieldInvalid(passwordInput, '⚠️ 비밀번호는 4자 이상 입력해주세요.');
        return false;
    }
    
    if (password.length > 50) {
        setFieldInvalid(passwordInput, '비밀번호는 50자 이하로 입력해주세요.');
        return false;
    }
    
    setFieldValid(passwordInput);
    return true;
}

/**
 * 비밀번호 확인 검증
 */
function validatePasswordConfirm(passwordInput, confirmInput) {
    const password = passwordInput.value;
    const confirm = confirmInput.value;
    
    if (!confirm) {
        setFieldInvalid(confirmInput, '비밀번호 확인을 입력해주세요.');
        return false;
    }
    
    if (password !== confirm) {
        setFieldInvalid(confirmInput, '비밀번호가 일치하지 않습니다.');
        return false;
    }
    
    setFieldValid(confirmInput);
    return true;
}

/**
 * 인증코드 검증 (교수용)
 */
function validateAuthCode(authCodeInput) {
    const authCode = authCodeInput.value.trim();
    const professorRole = document.querySelector('input[name="role"]:checked');
    
    if (professorRole && professorRole.value === 'professor') {
        if (!authCode) {
            setFieldInvalid(authCodeInput, '교수 인증코드를 입력해주세요.');
            return false;
        }
        
        if (authCode.length < 4) {
            setFieldInvalid(authCodeInput, '인증코드는 4자 이상 입력해주세요.');
            return false;
        }
        
        setFieldValid(authCodeInput);
        return true;
    }
    
    clearFieldValidation(authCodeInput);
    return true;
}

/**
 * 전체 폼 검증
 */
function validateSignupForm() {
    const nameInput = document.getElementById('name');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const passwordCheckInput = document.getElementById('passwordCheck');
    const authCodeInput = document.getElementById('authCode');
    const roleInput = document.querySelector('input[name="role"]:checked');
    
    let isValid = true;
    
    // 필수 필드 검증
    if (!validateName(nameInput)) isValid = false;
    if (!validateUsername(usernameInput)) isValid = false;
    if (!validatePassword(passwordInput)) isValid = false;
    if (!validatePasswordConfirm(passwordInput, passwordCheckInput)) isValid = false;
    
    // 역할 선택 검증
    if (!roleInput) {
        showCustomAlert('학생 또는 교수를 선택해주세요.', 'error');
        isValid = false;
    }
    
    // 교수 인증코드 검증
    if (roleInput && roleInput.value === 'professor') {
        if (!validateAuthCode(authCodeInput)) isValid = false;
    }
    
    return isValid;
}

/**
 * 이름 형식 검증
 */
function validateNameFormat(name) {
    // 한글, 영문, 공백만 허용 (2-20자)
    const namePattern = /^[가-힣a-zA-Z\s]{2,20}$/;
    return namePattern.test(name);
}

/**
 * 아이디 형식 검증
 */
function validateUsernameFormat(username) {
    // 영문자와 숫자만 허용 (3-20자)
    const usernamePattern = /^[a-zA-Z0-9]{3,20}$/;
    return usernamePattern.test(username);
}

/**
 * 입력 필드 유효 상태 설정
 */
function setFieldValid(field) {
    field.style.borderColor = '#10b981';
    field.style.backgroundColor = '#f0fdf4';
    removeFieldMessage(field);
}

/**
 * 입력 필드 무효 상태 설정
 */
function setFieldInvalid(field, message) {
    field.style.borderColor = '#ef4444';
    field.style.backgroundColor = '#fef2f2';
    showFieldMessage(field, message, 'error');
}

/**
 * 입력 필드 검증 상태 초기화
 */
function clearFieldValidation(field) {
    if (field) {
        field.style.borderColor = '';
        field.style.backgroundColor = '';
        removeFieldMessage(field);
    }
}

/**
 * 필드별 메시지 표시
 */
function showFieldMessage(field, message, type) {
    removeFieldMessage(field);
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `field-message field-message-${type}`;
    messageDiv.textContent = message;
    messageDiv.style.cssText = `
        font-size: 12px;
        margin-top: 6px;
        padding: 6px 12px;
        border-radius: 6px;
        font-weight: 500;
        animation: slideDown 0.3s ease-out;
        color: ${type === 'error' ? '#dc2626' : '#059669'};
        background: ${type === 'error' ? 'linear-gradient(145deg, #fef2f2, #fee2e2)' : 'linear-gradient(145deg, #ecfdf5, #d1fae5)'};
        border: 1px solid ${type === 'error' ? '#fecaca' : '#a7f3d0'};
    `;
    
    field.parentNode.appendChild(messageDiv);
}

/**
 * 필드 메시지 제거
 */
function removeFieldMessage(field) {
    const existingMessage = field.parentNode.querySelector('.field-message');
    if (existingMessage) {
        existingMessage.remove();
    }
}

/**
 * 알림 메시지 표시 (기존 함수 유지)
 */
function showAlert(message, type = 'info', duration = 3000) {
    showCustomAlert(message, type, duration);
}