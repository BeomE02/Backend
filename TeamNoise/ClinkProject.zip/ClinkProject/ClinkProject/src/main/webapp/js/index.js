// index.js - 메인 페이지 전용 JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Clink 메인 페이지 로드 완료');
    
    // 페이지 로딩 애니메이션
    initPageAnimations();
    
    // 로그인 버튼 이벤트
    initLoginButton();
    
    // Feature 박스 호버 효과
    initFeatureBoxEvents();
    
    // 스크롤 효과
    initScrollEffects();
    
    // 이미지 로딩 에러 처리
    initImageErrorHandling();
});

/**
 * 페이지 로딩 애니메이션 초기화
 */
function initPageAnimations() {
    // 페이지 로드 시 메인 비주얼 애니메이션
    const mainVisual = document.querySelector('.main-visual');
    if (mainVisual) {
        mainVisual.style.opacity = '0';
        mainVisual.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            mainVisual.style.transition = 'all 0.8s ease-out';
            mainVisual.style.opacity = '1';
            mainVisual.style.transform = 'translateY(0)';
        }, 100);
    }
    
    // Feature 박스들 순차 애니메이션
    const featureBoxes = document.querySelectorAll('.feature-box');
    featureBoxes.forEach((box, index) => {
        box.style.opacity = '0';
        box.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            box.style.transition = 'all 0.6s ease-out';
            box.style.opacity = '1';
            box.style.transform = 'translateY(0)';
        }, 300 + (index * 200));
    });
}

/**
 * 로그인 버튼 이벤트 초기화
 */
function initLoginButton() {
    const loginBtn = document.querySelector('.login-btn');
    
    if (loginBtn) {
        // 클릭 이벤트
        loginBtn.addEventListener('click', function(e) {
            // 로딩 효과
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
        
        // 호버 효과 강화
        loginBtn.addEventListener('mouseenter', function() {
            this.style.background = '#333';
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        });
        
        loginBtn.addEventListener('mouseleave', function() {
            this.style.background = '#000';
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    }
}

/**
 * Feature 박스 이벤트 초기화
 */
function initFeatureBoxEvents() {
    const featureBoxes = document.querySelectorAll('.feature-box');
    
    featureBoxes.forEach(box => {
        // 마우스 엔터 이벤트
        box.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 12px 25px rgba(0, 0, 0, 0.15)';
        });
        
        // 마우스 리브 이벤트
        box.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
        });
        
        // 클릭 효과
        box.addEventListener('click', function() {
            this.style.transform = 'translateY(-5px) scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            }, 100);
        });
    });
}

/**
 * 스크롤 효과 초기화
 */
function initScrollEffects() {
    let ticking = false;
    
    function updateScrollEffects() {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        
        // 패럴랙스 효과 (메가폰 이미지)
        const megaphone = document.querySelector('.main-visual img.megaphone');
        if (megaphone) {
            megaphone.style.transform = `translateY(${rate * 0.3}px)`;
        }
        
        // 헤더 투명도 효과
        const header = document.querySelector('header');
        if (header) {
            const opacity = Math.max(0.9, 1 - scrolled / 300);
            header.style.background = `rgba(249, 249, 249, ${opacity})`;
        }
        
        ticking = false;
    }
    
    function requestTick() {
        if (!ticking) {
            requestAnimationFrame(updateScrollEffects);
            ticking = true;
        }
    }
    
    window.addEventListener('scroll', requestTick);
}

/**
 * 이미지 로딩 에러 처리
 */
function initImageErrorHandling() {
    const images = document.querySelectorAll('img');
    
    images.forEach(img => {
        img.addEventListener('error', function() {
            console.warn('이미지 로딩 실패:', this.src);
            
            // 기본 이미지로 대체하거나 숨김 처리
            this.style.display = 'none';
            
            // 대안: 기본 이미지로 교체
            // this.src = '/path/to/default-image.png';
        });
        
        img.addEventListener('load', function() {
            // 이미지 로드 완료 시 페이드인 효과
            this.style.opacity = '0';
            this.style.transition = 'opacity 0.3s ease';
            setTimeout(() => {
                this.style.opacity = '1';
            }, 50);
        });
    });
}

/**
 * 푸터 소셜 링크 이벤트
 */
function initFooterEvents() {
    const socialLinks = document.querySelectorAll('.footer-social a');
    
    socialLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // 외부 링크 클릭 확인
            const confirmed = confirm('외부 사이트로 이동하시겠습니까?');
            if (!confirmed) {
                e.preventDefault();
            }
        });
    });
}

/**
 * 반응형 처리
 */
function handleResponsive() {
    function checkScreenSize() {
        const isMobile = window.innerWidth <= 768;
        
        // 모바일에서 애니메이션 최적화
        if (isMobile) {
            document.body.classList.add('mobile');
            
            // 패럴랙스 효과 비활성화 (성능 최적화)
            window.removeEventListener('scroll', requestTick);
        } else {
            document.body.classList.remove('mobile');
        }
    }
    
    // 초기 체크
    checkScreenSize();
    
    // 리사이즈 이벤트
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(checkScreenSize, 250);
    });
}

// 반응형 처리 초기화
handleResponsive();

// 푸터 이벤트 초기화
initFooterEvents();

// 페이지 언로드 시 정리
window.addEventListener('beforeunload', function() {
    console.log('Clink 메인 페이지 언로드');
});