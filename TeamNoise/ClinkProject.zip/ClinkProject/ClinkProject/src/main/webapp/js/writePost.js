/**
 * writePost.js - 게시글 작성/수정 페이지 전용 JavaScript
 * 🔥 파일 삭제 기능 완전 해결 버전
 * 🚀 JSP 인라인 스크립트와 충돌 해결
 * ✅ 기존 파일 삭제 및 새 파일 업로드 완벽 지원
 */

console.log('📄 writePost.js 로드 시작...');

// 전역 변수 선언
let filesToDelete = []; // 삭제할 기존 파일 ID 목록
let selectedFiles = []; // 새로 선택한 파일 목록
let maxFiles = 5;
let maxFileSize = 10 * 1024 * 1024; // 10MB
let isSubmitting = false; // 중복 제출 방지

/**
 * 🔥 DOM 로드 완료 시 초기화
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 writePost.js DOM 로드 완료');
    
    // 페이지 모드 확인
    const modeElement = document.querySelector('input[name="mode"]');
    const isEditMode = modeElement && modeElement.value === 'edit';
    
    console.log('수정 모드:', isEditMode);
    
    // 기존 파일 초기화 (수정 모드에서만)
    if (isEditMode) {
        initializeExistingFiles();
    }
    
    // 새 파일 업로드 초기화
    initializeFileUpload();
    
    // 에디터 초기화
    initializeEditor();
    
    // 폼 이벤트 초기화
    initializeFormEvents();
    
    // 글자 수 카운터 초기화
    initCharCounters();
    
    // 유효성 검사 초기화
    initFormValidation();
    
    // 이벤트 리스너 초기화
    initEventListeners();
    
    console.log('✅ writePost.js 초기화 완료');
});

/**
 * 🔥 기존 파일 관리 초기화 (수정 모드에서만)
 */
function initializeExistingFiles() {
    console.log('📁 기존 파일 초기화 시작');
    
    // 기존 파일 개수 확인
    const existingFiles = document.querySelectorAll('.existing-file-item');
    console.log('📁 기존 첨부파일:', existingFiles.length + '개');
    
    if (existingFiles.length > 0) {
        // 기존 파일 섹션에 애니메이션 효과
        const existingFilesSection = document.querySelector('.existing-files-section');
        if (existingFilesSection) {
            existingFilesSection.style.opacity = '0';
            existingFilesSection.style.transform = 'translateY(10px)';
            
            setTimeout(function() {
                existingFilesSection.style.transition = 'all 0.3s ease-in-out';
                existingFilesSection.style.opacity = '1';
                existingFilesSection.style.transform = 'translateY(0)';
            }, 100);
        }
        
        // 각 파일 아이템에 호버 효과
        existingFiles.forEach(function(fileItem, index) {
            const fileId = fileItem.getAttribute('data-file-id');
            const fileName = fileItem.querySelector('.file-name').textContent;
            
            console.log('📎 파일 ' + (index + 1) + ': ' + fileName + ' (ID: ' + fileId + ')');
            
            // 파일 아이템에 호버 효과
            fileItem.addEventListener('mouseenter', function() {
                if (!this.classList.contains('marked-for-deletion')) {
                    this.style.backgroundColor = '#f8f9fa';
                }
            });
            
            fileItem.addEventListener('mouseleave', function() {
                if (!this.classList.contains('marked-for-deletion')) {
                    this.style.backgroundColor = '';
                }
            });
        });
    }
    
    // 삭제할 파일 목록 초기화
    filesToDelete = [];
    updateFilesToDeleteInput();
    
    console.log('✅ 기존 파일 초기화 완료');
}

/**
 * 🔥 파일을 삭제 표시 (메인 함수)
 */
function markFileForDeletion(fileId) {
    console.log('🗑️ 파일 삭제 표시:', fileId);
    
    if (!fileId) {
        console.error('❌ 파일 ID가 없습니다.');
        return;
    }
    
    const fileItem = document.querySelector('[data-file-id="' + fileId + '"]');
    if (!fileItem) {
        console.error('❌ 파일 아이템을 찾을 수 없습니다:', fileId);
        return;
    }
    
    const fileName = fileItem.querySelector('.file-name').textContent;
    
    // 확인 대화상자
    if (confirm('"' + fileName + '" 파일을 삭제하시겠습니까?\n\n삭제 표시한 후 \'수정 완료\' 버튼을 눌러야 실제로 삭제됩니다.')) {
        
        // 삭제 목록에 추가 (중복 방지)
        if (filesToDelete.indexOf(fileId.toString()) === -1) {
            filesToDelete.push(fileId.toString());
        }
        
        // UI 업데이트
        fileItem.classList.add('marked-for-deletion');
        fileItem.style.backgroundColor = '#ffe6e6';
        fileItem.style.borderColor = '#dc3545';
        fileItem.style.opacity = '0.7';
        
        // 삭제 오버레이 표시
        const overlay = fileItem.querySelector('.file-delete-overlay');
        if (overlay) {
            overlay.style.display = 'flex';
        }
        
        // 삭제 버튼 숨기기
        const deleteBtn = fileItem.querySelector('.btn-delete');
        if (deleteBtn) {
            deleteBtn.style.display = 'none';
        }
        
        // 숨겨진 입력 필드 업데이트
        updateFilesToDeleteInput();
        
        console.log('✅ 파일 삭제 표시 완료:', fileName);
        console.log('📝 현재 삭제 목록:', filesToDelete);
        
        showNotification('"' + fileName + '" 파일이 삭제 표시되었습니다.');
    }
}

/**
 * 🔥 파일 삭제 표시 취소
 */
function unmarkFileForDeletion(fileId) {
    console.log('↩️ 파일 삭제 표시 취소:', fileId);
    
    if (!fileId) {
        console.error('❌ 파일 ID가 없습니다.');
        return;
    }
    
    const fileItem = document.querySelector('[data-file-id="' + fileId + '"]');
    if (!fileItem) {
        console.error('❌ 파일 아이템을 찾을 수 없습니다:', fileId);
        return;
    }
    
    // 삭제 목록에서 제거
    const index = filesToDelete.indexOf(fileId.toString());
    if (index > -1) {
        filesToDelete.splice(index, 1);
    }
    
    // UI 복원
    fileItem.classList.remove('marked-for-deletion');
    fileItem.style.backgroundColor = '';
    fileItem.style.borderColor = '';
    fileItem.style.opacity = '';
    
    // 삭제 오버레이 숨기기
    const overlay = fileItem.querySelector('.file-delete-overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
    
    // 삭제 버튼 다시 표시
    const deleteBtn = fileItem.querySelector('.btn-delete');
    if (deleteBtn) {
        deleteBtn.style.display = '';
    }
    
    // 숨겨진 입력 필드 업데이트
    updateFilesToDeleteInput();
    
    const fileName = fileItem.querySelector('.file-name').textContent;
    console.log('✅ 파일 삭제 표시 취소 완료:', fileName);
    console.log('📝 현재 삭제 목록:', filesToDelete);
    
    showNotification('"' + fileName + '" 파일 삭제가 취소되었습니다.');
}

/**
 * 🔥 삭제할 파일 목록을 숨겨진 입력 필드에 설정
 */
function updateFilesToDeleteInput() {
    const input = document.getElementById('filesToDelete');
    if (input) {
        const deleteList = filesToDelete.join(',');
        input.value = deleteList;
        console.log('📝 삭제할 파일 목록 업데이트:', deleteList);
    } else {
        console.error('❌ filesToDelete 입력 필드를 찾을 수 없습니다.');
    }
}

/**
 * 🔥 기존 파일 다운로드
 */
function downloadFile(fileId) {
    if (!fileId) {
        showNotification('파일 정보가 없습니다.');
        return;
    }
    
    console.log('📥 파일 다운로드 시작:', fileId);
    
    // 컨텍스트 경로 확인
    const contextPath = window.location.pathname.indexOf('/ClinkProject') !== -1 ? '/ClinkProject' : '';
    const downloadUrl = contextPath + '/file/download/' + fileId;
    
    console.log('📥 다운로드 URL:', downloadUrl);
    
    // 새 창에서 다운로드
    const downloadWindow = window.open(downloadUrl, '_blank');
    
    // 다운로드 윈도우가 차단된 경우 직접 링크 방식 사용
    if (!downloadWindow) {
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.target = '_blank';
        link.style.display = 'none';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    showNotification('파일 다운로드를 시작합니다.');
}

/**
 * 🔥 새 파일 업로드 초기화
 */
function initializeFileUpload() {
    console.log('📁 파일 업로드 초기화 시작');
    
    const fileUploadArea = document.getElementById('fileUploadArea');
    const fileInput = document.getElementById('attachments');
    const selectedFilesContainer = document.getElementById('selectedFiles');
    
    if (!fileUploadArea || !fileInput || !selectedFilesContainer) {
        console.log('⚠️ 파일 업로드 요소를 찾을 수 없습니다. 건너뜁니다.');
        return;
    }
    
    // 파일 업로드 영역 클릭 시 파일 선택
    fileUploadArea.addEventListener('click', function() {
        fileInput.click();
    });
    
    // 드래그 앤 드롭 이벤트
    fileUploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        e.stopPropagation();
        this.classList.add('dragover');
    });
    
    fileUploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        e.stopPropagation();
        this.classList.remove('dragover');
    });
    
    fileUploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        e.stopPropagation();
        this.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        handleFileSelection(files);
    });
    
    // 파일 선택 이벤트
    fileInput.addEventListener('change', function() {
        handleFileSelection(this.files);
    });
    
    console.log('✅ 파일 업로드 초기화 완료');
}

/**
 * 파일 선택 처리
 */
function handleFileSelection(files) {
    console.log('📁 파일 선택:', files.length + '개');
    
    // 파일 배열로 변환
    const fileArray = Array.from(files);
    
    // 기존 선택된 파일과 합치기
    selectedFiles = selectedFiles.concat(fileArray);
    
    // 최대 5개 파일 제한
    if (selectedFiles.length > 5) {
        selectedFiles = selectedFiles.slice(0, 5);
        showNotification('최대 5개 파일까지만 선택할 수 있습니다.');
    }
    
    // UI 업데이트
    updateSelectedFilesUI();
}

/**
 * 선택된 파일 UI 업데이트
 */
function updateSelectedFilesUI() {
    const container = document.getElementById('selectedFiles');
    if (!container) return;
    
    container.innerHTML = '';
    
    selectedFiles.forEach(function(file, index) {
        const fileItem = createFileItemElement(file, index);
        container.appendChild(fileItem);
    });
    
    console.log('📁 선택된 파일 UI 업데이트 완료:', selectedFiles.length + '개');
}

/**
 * 파일 아이템 요소 생성
 */
function createFileItemElement(file, index) {
    const fileItem = document.createElement('div');
    fileItem.className = 'selected-file-item';
    fileItem.innerHTML = `
        <div class="file-icon">
            <i class="fas fa-file"></i>
        </div>
        <div class="file-info">
            <div class="file-name">${escapeHtml(file.name)}</div>
            <div class="file-size">${formatFileSize(file.size)}</div>
        </div>
        <button type="button" class="btn-remove-file" onclick="removeSelectedFile(${index})">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    return fileItem;
}

/**
 * 선택된 파일 제거
 */
function removeSelectedFile(index) {
    const removedFile = selectedFiles[index];
    selectedFiles.splice(index, 1);
    console.log('🗑️ 선택된 파일 제거:', removedFile.name);
    updateSelectedFilesUI();
}

/**
 * 파일 크기 포맷팅
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * HTML 이스케이프
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

/**
 * 🔥 간단한 알림 표시
 */
function showNotification(message) {
    console.log('📢 알림:', message);
    
    // 기존 알림 제거
    const existingAlert = document.querySelector('.notification-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // 새 알림 생성
    const alertDiv = document.createElement('div');
    alertDiv.className = 'notification-alert';
    alertDiv.style.cssText = 
        'position: fixed;' +
        'top: 20px;' +
        'right: 20px;' +
        'z-index: 9999;' +
        'max-width: 300px;' +
        'padding: 10px 15px;' +
        'border-radius: 5px;' +
        'box-shadow: 0 2px 10px rgba(0,0,0,0.1);' +
        'background: #d1ecf1;' +
        'border: 1px solid #bee5eb;' +
        'color: #0c5460;';
    
    alertDiv.textContent = message;
    
    document.body.appendChild(alertDiv);
    
    // 3초 후 자동 제거
    setTimeout(function() {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 3000);
}

/**
 * 에디터 초기화
 */
function initializeEditor() {
    console.log('📝 에디터 초기화 시작');
    
    const editor = document.getElementById('content');
    const titleInput = document.getElementById('title');
    
    if (editor) {
        // 글자 수 카운팅
        function updateContentCount() {
            const content = editor.textContent || editor.innerText || '';
            const count = content.length;
            const counter = document.getElementById('contentCount');
            if (counter) {
                counter.textContent = count;
            }
        }
        
        editor.addEventListener('input', updateContentCount);
        editor.addEventListener('keyup', updateContentCount);
        editor.addEventListener('paste', function() {
            setTimeout(updateContentCount, 100);
        });
        
        // 초기 카운팅
        updateContentCount();
    }
    
    if (titleInput) {
        // 제목 글자 수 카운팅
        function updateTitleCount() {
            const count = titleInput.value.length;
            const counter = document.getElementById('titleCount');
            if (counter) {
                counter.textContent = count;
            }
        }
        
        titleInput.addEventListener('input', updateTitleCount);
        titleInput.addEventListener('keyup', updateTitleCount);
        
        // 초기 카운팅
        updateTitleCount();
    }
    
    console.log('✅ 에디터 초기화 완료');
}

/**
 * 글자 수 카운터 초기화
 */
function initCharCounters() {
    console.log('📊 글자 수 카운터 초기화');
    
    // 제목 글자 수 카운터
    const titleInput = document.getElementById('title');
    const titleCount = document.getElementById('titleCount');
    
    if (titleInput && titleCount) {
        function updateTitleCount() {
            const length = titleInput.value.length;
            titleCount.textContent = length;
            
            // 글자 수에 따른 색상 변경
            if (length >= 450) {
                titleCount.style.color = '#ff5722';
            } else if (length >= 400) {
                titleCount.style.color = '#ff9800';
            } else {
                titleCount.style.color = '#6c757d';
            }
        }
        
        titleInput.addEventListener('input', updateTitleCount);
        titleInput.addEventListener('keyup', updateTitleCount);
        titleInput.addEventListener('paste', function() {
            setTimeout(updateTitleCount, 10);
        });
        
        // 초기 카운트 설정
        updateTitleCount();
        console.log('✅ 제목 글자 수 카운터 설정 완료');
    }
    
    // 내용 글자 수 카운터
    const contentDiv = document.getElementById('content');
    const contentCount = document.getElementById('contentCount');
    
    if (contentDiv && contentCount) {
        function updateContentCount() {
            const length = contentDiv.textContent.length;
            contentCount.textContent = length;
            
            // 글자 수에 따른 색상 변경
            if (length >= 9000) {
                contentCount.style.color = '#ff5722';
            } else if (length >= 8000) {
                contentCount.style.color = '#ff9800';
            } else {
                contentCount.style.color = '#6c757d';
            }
        }
        
        contentDiv.addEventListener('input', updateContentCount);
        contentDiv.addEventListener('keyup', updateContentCount);
        contentDiv.addEventListener('paste', function() {
            setTimeout(updateContentCount, 10);
        });
        
        // 초기 카운트 설정
        updateContentCount();
        console.log('✅ 내용 글자 수 카운터 설정 완료');
    }
}

/**
 * 폼 유효성 검사 초기화
 */
function initFormValidation() {
    console.log('✅ 폼 유효성 검사 초기화');
    
    const form = document.getElementById('writePostForm');
    if (!form) {
        console.error('❌ writePostForm을 찾을 수 없습니다');
        return;
    }
    
    // 실시간 유효성 검사
    const requiredFields = form.querySelectorAll('[required]');
    
    for (let i = 0; i < requiredFields.length; i++) {
        const field = requiredFields[i];
        
        field.addEventListener('blur', function() {
            validateField(this);
        });
        
        field.addEventListener('input', function() {
            removeFieldError(this);
        });
    }
    
    console.log('✅ 폼 유효성 검사 설정 완료');
}

/**
 * 개별 필드 유효성 검사
 */
function validateField(field) {
    let isValid = true;
    let errorMessage = '';
    
    // 필수 입력 확인
    if (field.hasAttribute('required')) {
        const value = field.tagName === 'DIV' ? field.textContent.trim() : field.value.trim();
        if (!value) {
            isValid = false;
            errorMessage = '필수 입력 항목입니다.';
        }
    }
    
    // 필드별 추가 검사
    const fieldName = field.name || field.id;
    switch (fieldName) {
        case 'category':
            if (!field.value) {
                isValid = false;
                errorMessage = '게시판을 선택해주세요.';
            }
            break;
            
        case 'title':
            if (field.value.length > 500) {
                isValid = false;
                errorMessage = '제목은 500자 이하로 입력해주세요.';
            } else if (field.value.length < 2) {
                isValid = false;
                errorMessage = '제목은 2자 이상 입력해주세요.';
            }
            break;
            
        case 'content':
            const contentLength = field.tagName === 'DIV' ? field.textContent.length : field.value.length;
            if (contentLength > 10000) {
                isValid = false;
                errorMessage = '내용은 10,000자 이하로 입력해주세요.';
            } else if (contentLength < 10) {
                isValid = false;
                errorMessage = '내용은 10자 이상 입력해주세요.';
            }
            break;
    }
    
    if (isValid) {
        removeFieldError(field);
    } else {
        showFieldError(field, errorMessage);
    }
    
    return isValid;
}

/**
 * 필드 에러 표시
 */
function showFieldError(field, message) {
    removeFieldError(field);
    
    field.style.borderColor = '#ff5722';
    field.style.boxShadow = '0 0 0 4px rgba(255, 87, 34, 0.1)';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = 'color: #ff5722; font-size: 12px; margin-top: 5px;';
    
    field.parentNode.appendChild(errorDiv);
}

/**
 * 필드 에러 제거
 */
function removeFieldError(field) {
    field.style.borderColor = '#e0e0e0';
    field.style.boxShadow = '';
    
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

/**
 * 폼 이벤트 초기화
 */
function initializeFormEvents() {
    console.log('📝 폼 이벤트 초기화 시작');
    
    const form = document.getElementById('writePostForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            console.log('📤 폼 제출 시작');
            
            if (!validateFormSubmission()) {
                console.log('❌ 폼 검증 실패');
                e.preventDefault();
                return false;
            }
            
            console.log('✅ 폼 검증 성공, 제출 진행');
        });
    }
    
    console.log('✅ 폼 이벤트 초기화 완료');
}

/**
 * 🔥 폼 제출 전 최종 검증
 */
function validateFormSubmission() {
    console.log('🔍 폼 제출 전 검증 시작');
    
    // 삭제할 파일이 있는 경우 확인
    if (filesToDelete.length > 0) {
        const fileNames = [];
        
        filesToDelete.forEach(function(fileId) {
            const fileItem = document.querySelector('[data-file-id="' + fileId + '"]');
            if (fileItem) {
                const fileName = fileItem.querySelector('.file-name').textContent;
                fileNames.push(fileName);
            }
        });
        
        if (fileNames.length > 0) {
            const message = '다음 파일들이 삭제됩니다:\n\n' + fileNames.join('\n') + '\n\n계속 진행하시겠습니까?';
            if (!confirm(message)) {
                console.log('❌ 사용자가 삭제를 취소했습니다.');
                return false;
            }
        }
    }
    
    // 삭제할 파일 목록 최종 업데이트
    updateFilesToDeleteInput();
    
    // 내용을 hidden input으로 복사 (contenteditable div 지원)
    const contentDiv = document.getElementById('content');
    const form = document.getElementById('writePostForm');
    
    if (contentDiv && form) {
        // 기존 content input이 있으면 제거
        const existingContentInput = form.querySelector('input[name="content"]');
        if (existingContentInput) {
            existingContentInput.remove();
        }
        
        // 새로운 hidden input 생성
        const contentInput = document.createElement('input');
        contentInput.type = 'hidden';
        contentInput.name = 'content';
        contentInput.value = contentDiv.innerHTML; // HTML 포함해서 전송
        form.appendChild(contentInput);
        
        console.log('✅ 내용 복사 완료:', contentInput.value.substring(0, 50) + '...');
    }
    
    console.log('✅ 폼 제출 검증 완료');
    console.log('📝 최종 삭제 목록:', filesToDelete);
    
    return true;
}

/**
 * 이벤트 리스너 초기화
 */
function initEventListeners() {
    console.log('🎯 이벤트 리스너 설정');
    
    // 뒤로가기 버튼
    const cancelBtn = document.querySelector('.btn-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', goBack);
    }
    
    // 키보드 단축키
    document.addEventListener('keydown', function(e) {
        // Ctrl + Enter: 폼 제출
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            const form = document.getElementById('writePostForm');
            if (form && validateFormSubmission()) {
                form.submit();
            }
        }
        
        // ESC: 뒤로가기
        if (e.key === 'Escape') {
            goBack();
        }
    });
    
    console.log('✅ 이벤트 리스너 설정 완료');
}

/**
 * 뒤로가기 함수
 */
function goBack() {
    const titleInput = document.getElementById('title');
    const contentDiv = document.getElementById('content');
    
    let hasContent = false;
    if (titleInput && titleInput.value.trim()) hasContent = true;
    if (contentDiv && contentDiv.textContent.trim()) hasContent = true;
    if (selectedFiles.length > 0) hasContent = true;
    
    if (hasContent) {
        if (confirm('작성 중인 내용이 있습니다. 정말 나가시겠습니까?')) {
            window.history.back();
        }
    } else {
        window.history.back();
    }
}

/**
 * 페이지 떠나기 전 경고
 */
window.addEventListener('beforeunload', function(e) {
    if (isSubmitting) {
        // 제출 중이면 경고 표시 안함
        return;
    }
    
    const titleInput = document.getElementById('title');
    const contentDiv = document.getElementById('content');
    
    let hasContent = false;
    if (titleInput && titleInput.value.trim()) hasContent = true;
    if (contentDiv && contentDiv.textContent.trim()) hasContent = true;
    if (selectedFiles.length > 0) hasContent = true;
    
    if (hasContent) {
        e.preventDefault();
        e.returnValue = '작성 중인 내용이 있습니다. 정말 나가시겠습니까?';
    }
});

/**
 * 에러 처리
 */
window.addEventListener('error', function(e) {
    console.error('❌ JavaScript 오류:', e.error);
});

console.log('✅ writePost.js 모든 기능 로드 완료');