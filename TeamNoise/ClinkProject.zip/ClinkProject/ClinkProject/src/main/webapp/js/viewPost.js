/**
 * viewPost.js - 게시글 상세보기 JavaScript (수정 기능 완성 버전)
 * 🔥 기존 모든 기능 유지 + 게시글 수정 기능 완전 추가
 * 댓글 작성, 파일 다운로드, 게시글/댓글 수정/삭제 기능 완성
 */

// ============================================
// 전역 변수 및 초기화
// ============================================

let isSubmitting = false; // 중복 제출 방지
let commentCount = 0;
let isDownloading = false; // 중복 다운로드 방지

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    initializeViewPost();
});

/**
 * 게시글 상세보기 초기화
 */
function initializeViewPost() {
    console.log('게시글 상세보기 초기화 시작');
    
    // 댓글 개수 업데이트
    updateCommentCount();
    
    // 이벤트 리스너 등록
    setupEventListeners();
    
    // 첨부파일 미리보기 설정
    setupFilePreview();
    
    console.log('게시글 상세보기 초기화 완료');
}

/**
 * 이벤트 리스너 설정
 */
function setupEventListeners() {
    // 댓글 폼 제출 이벤트
    const commentForm = document.getElementById('commentForm');
    if (commentForm) {
        commentForm.addEventListener('submit', handleCommentSubmit);
    }
    
    // 키보드 단축키
    document.addEventListener('keydown', handleKeyboardShortcuts);
}

// ============================================
// 🔥 게시글 수정 기능 (핵심 수정)
// ============================================

/**
 * 🚀 게시글 수정 - 카테고리 자동 감지하여 수정 페이지로 이동
 */
function editPost(postId) {
    console.log('🔥 editPost 함수 호출 - postId:', postId);
    
    if (!window.userData || !window.userData.isLoggedIn) {
        showNotification('로그인이 필요합니다.', 'error');
        return;
    }
    
    if (!postId) {
        console.error('❌ postId가 없습니다');
        showNotification('잘못된 요청입니다.', 'error');
        return;
    }
    
    // 권한 확인
    if (window.userData.userId !== window.postData.authorId && window.userData.role !== 'professor') {
        showNotification('수정 권한이 없습니다.', 'error');
        return;
    }
    
    // 🔥 현재 게시판 카테고리 정확히 감지
    let category = getCurrentCategory();
    
    console.log('📝 감지된 카테고리:', category);
    console.log('📝 게시글 정보:', { postId, category, authorId: window.postData.authorId });
    
    // 🚀 수정 페이지로 이동 (컨텍스트 경로 포함)
    const contextPath = window.location.pathname.includes('/ClinkProject') ? '/ClinkProject' : '';
    const editUrl = `${contextPath}/writePost.do?action=edit&postId=${postId}&category=${category}`;
    
    console.log('🔗 수정 페이지 URL:', editUrl);
    
    // 페이지 이동
    window.location.href = editUrl;
}

/**
 * 🔥 현재 게시판 카테고리 정확히 감지하는 헬퍼 함수
 */
function getCurrentCategory() {
    // 1. window.postData에서 우선 확인 (가장 정확)
    if (window.postData && window.postData.categoryCode) {
        console.log('📝 postData에서 카테고리 확인:', window.postData.categoryCode);
        return window.postData.categoryCode;
    }
    
    // 2. URL 파라미터에서 확인
    const urlParams = new URLSearchParams(window.location.search);
    const urlCategory = urlParams.get('category');
    if (urlCategory) {
        console.log('📝 URL 파라미터에서 카테고리 확인:', urlCategory);
        return urlCategory;
    }
    
    // 3. URL 경로에서 추출
    const currentPath = window.location.pathname;
    if (currentPath.includes('freePage') || currentPath.includes('free')) {
        console.log('📝 URL 경로에서 카테고리 확인: free');
        return 'free';
    } else if (currentPath.includes('questionPage') || currentPath.includes('question')) {
        console.log('📝 URL 경로에서 카테고리 확인: question');
        return 'question';
    } else if (currentPath.includes('photoPage') || currentPath.includes('photo')) {
        console.log('📝 URL 경로에서 카테고리 확인: photo');
        return 'photo';
    } else if (currentPath.includes('dataPage') || currentPath.includes('data')) {
        console.log('📝 URL 경로에서 카테고리 확인: data');
        return 'data';
    }
    
    // 4. DOM에서 breadcrumb 확인
    const breadcrumbLinks = document.querySelectorAll('.breadcrumb a');
    for (let link of breadcrumbLinks) {
        const href = link.getAttribute('href');
        if (href && href.includes('freePage')) {
            console.log('📝 breadcrumb에서 카테고리 확인: free');
            return 'free';
        } else if (href && href.includes('questionPage')) {
            console.log('📝 breadcrumb에서 카테고리 확인: question');
            return 'question';
        } else if (href && href.includes('photoPage')) {
            console.log('📝 breadcrumb에서 카테고리 확인: photo');
            return 'photo';
        } else if (href && href.includes('dataPage')) {
            console.log('📝 breadcrumb에서 카테고리 확인: data');
            return 'data';
        }
    }
    
    // 5. 카테고리 배지에서 확인
    const categoryBadge = document.querySelector('.category-badge');
    if (categoryBadge) {
        if (categoryBadge.classList.contains('free')) {
            console.log('📝 카테고리 배지에서 확인: free');
            return 'free';
        } else if (categoryBadge.classList.contains('question')) {
            console.log('📝 카테고리 배지에서 확인: question');
            return 'question';
        } else if (categoryBadge.classList.contains('photo')) {
            console.log('📝 카테고리 배지에서 확인: photo');
            return 'photo';
        } else if (categoryBadge.classList.contains('data')) {
            console.log('📝 카테고리 배지에서 확인: data');
            return 'data';
        }
    }
    
    // 6. 기본값
    console.log('📝 기본값 카테고리 사용: free');
    return 'free';
}

// ============================================
// 게시글 삭제 기능
// ============================================

/**
 * 게시글 삭제 - BoardController 직접 호출
 */
function deletePost(postId) {
    console.log('🔥 deletePost 함수 호출 - postId:', postId);
    
    if (!window.userData || !window.userData.isLoggedIn) {
        showNotification('로그인이 필요합니다.', 'error');
        return;
    }
    
    // 권한 확인
    if (window.userData.userId !== window.postData.authorId && window.userData.role !== 'professor') {
        showNotification('삭제 권한이 없습니다.', 'error');
        return;
    }
    
    // 삭제 확인
    if (!confirm(`정말로 "${window.postData.title}" 게시글을 삭제하시겠습니까?\n\n삭제된 게시글은 복구할 수 없습니다.`)) {
        return;
    }
    
    console.log('🔍 삭제 진행 - 사용자 확인 완료');
    
    // 로딩 표시
    const deleteBtn = document.querySelector(`button[onclick="deletePost(${postId})"]`);
    if (deleteBtn) {
        showLoading(deleteBtn);
    }
    
    // BoardController 직접 호출
    console.log('🔍 AJAX 요청 시작 - BoardController 직접 호출');
    
    fetch('deletePost.do', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `postId=${postId}`
    })
    .then(response => {
        console.log('🔍 응답 상태:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP 오류! 상태: ${response.status}`);
        }
        
        return response.text();
    })
    .then(text => {
        console.log('🔍 서버 응답 텍스트:', text);
        
        try {
            const data = JSON.parse(text);
            console.log('🔍 파싱된 JSON:', data);
            
            if (data.success) {
                console.log('✅ 게시글 삭제 성공');
                showNotification('게시글이 삭제되었습니다.', 'success');
                
                // 게시판 목록으로 이동
                setTimeout(() => {
                    const category = getCurrentCategory();
                    const contextPath = window.location.pathname.includes('/ClinkProject') ? '/ClinkProject' : '';
                    const boardUrl = `${contextPath}/${category}Page.do`;
                    console.log('🔍 리다이렉트 URL:', boardUrl);
                    window.location.href = boardUrl;
                }, 1500);
            } else {
                throw new Error(data.message || '게시글 삭제에 실패했습니다.');
            }
        } catch (parseError) {
            console.error('❌ JSON 파싱 오류:', parseError);
            console.error('❌ 원본 응답:', text);
            throw new Error('서버 응답을 처리할 수 없습니다.');
        }
    })
    .catch(error => {
        console.error('❌ 게시글 삭제 오류:', error);
        showNotification(error.message || '게시글 삭제 중 오류가 발생했습니다.', 'error');
    })
    .finally(() => {
        if (deleteBtn) {
            hideLoading(deleteBtn);
        }
    });
}

// ============================================
// 댓글 삭제 기능
// ============================================

/**
 * 댓글 삭제 - BoardController 직접 호출
 */
function deleteComment(commentId) {
    console.log('🔥 deleteComment 함수 호출 - commentId:', commentId);
    
    if (!window.userData || !window.userData.isLoggedIn) {
        showNotification('로그인이 필요합니다.', 'error');
        return;
    }
    
    if (!confirm('정말로 이 댓글을 삭제하시겠습니까?')) {
        return;
    }
    
    console.log('🔍 댓글 삭제 진행 - 사용자 확인 완료');
    
    // 로딩 표시
    const deleteBtn = document.querySelector(`button[onclick="deleteComment(${commentId})"]`);
    if (deleteBtn) {
        showLoading(deleteBtn);
    }
    
    // BoardController 직접 호출
    console.log('🔍 댓글 삭제 AJAX 요청 시작 - BoardController 직접 호출');
    
    fetch('deleteComment.do', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `commentId=${commentId}`
    })
    .then(response => {
        console.log('🔍 댓글 삭제 응답 상태:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP 오류! 상태: ${response.status}`);
        }
        
        return response.text();
    })
    .then(text => {
        console.log('🔍 댓글 삭제 서버 응답 텍스트:', text);
        
        try {
            const data = JSON.parse(text);
            console.log('🔍 댓글 삭제 파싱된 JSON:', data);
            
            if (data.success) {
                console.log('✅ 댓글 삭제 성공');
                showNotification('댓글이 삭제되었습니다.', 'success');
                
                // 페이지 새로고침
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            } else {
                throw new Error(data.message || '댓글 삭제에 실패했습니다.');
            }
        } catch (parseError) {
            console.error('❌ 댓글 삭제 JSON 파싱 오류:', parseError);
            console.error('❌ 댓글 삭제 원본 응답:', text);
            throw new Error('서버 응답을 처리할 수 없습니다.');
        }
    })
    .catch(error => {
        console.error('❌ 댓글 삭제 오류:', error);
        showNotification(error.message || '댓글 삭제 중 오류가 발생했습니다.', 'error');
    })
    .finally(() => {
        if (deleteBtn) {
            hideLoading(deleteBtn);
        }
    });
}

// ============================================
// 댓글 수정 기능
// ============================================

/**
 * 댓글 수정 모드 전환
 */
function editComment(commentId) {
    console.log('🔥 editComment 함수 호출 - commentId:', commentId);
    
    if (!window.userData || !window.userData.isLoggedIn) {
        showNotification('로그인이 필요합니다.', 'error');
        return;
    }
    
    const commentItem = document.querySelector(`[data-comment-id="${commentId}"]`);
    if (!commentItem) {
        console.error('댓글 요소를 찾을 수 없습니다:', commentId);
        return;
    }
    
    const commentBody = commentItem.querySelector('.comment-body');
    if (!commentBody) {
        console.error('댓글 본문을 찾을 수 없습니다:', commentId);
        return;
    }
    
    const originalContent = commentBody.textContent.trim();
    
    // 이미 수정 모드인 경우 취소
    if (commentItem.querySelector('.edit-form')) {
        cancelEditComment(commentId);
        return;
    }
    
    // 수정 폼 생성
    const editFormHTML = `
        <div class="edit-form">
            <textarea class="comment-edit-input" rows="3" placeholder="댓글을 수정하세요...">${originalContent}</textarea>
            <div class="edit-actions">
                <button type="button" class="btn-secondary btn-small" onclick="cancelEditComment(${commentId})">
                    취소
                </button>
                <button type="button" class="btn-primary btn-small" onclick="saveEditComment(${commentId})">
                    저장
                </button>
            </div>
        </div>
    `;
    
    // 원본 내용 숨기고 수정 폼 표시
    commentBody.style.display = 'none';
    commentBody.insertAdjacentHTML('afterend', editFormHTML);
    
    // 수정 폼에 포커스
    const editInput = commentItem.querySelector('.comment-edit-input');
    if (editInput) {
        editInput.focus();
        editInput.setSelectionRange(editInput.value.length, editInput.value.length);
    }
    
    console.log('✅ 댓글 수정 폼 표시 완료');
}

/**
 * 댓글 수정 저장 - BoardController 직접 호출
 */
function saveEditComment(commentId) {
    console.log('🔥 saveEditComment 함수 호출 - commentId:', commentId);
    
    const commentItem = document.querySelector(`[data-comment-id="${commentId}"]`);
    if (!commentItem) return;
    
    const editInput = commentItem.querySelector('.comment-edit-input');
    if (!editInput) return;
    
    const newContent = editInput.value.trim();
    if (!newContent) {
        showNotification('댓글 내용을 입력해주세요.', 'error');
        editInput.focus();
        return;
    }
    
    if (newContent.length > 1000) {
        showNotification('댓글은 1000자 이하로 입력해주세요.', 'error');
        return;
    }
    
    // 로딩 표시
    const saveBtn = commentItem.querySelector('.edit-actions .btn-primary');
    if (saveBtn) {
        showLoading(saveBtn);
    }
    
    // BoardController 직접 호출
    console.log('🔍 댓글 수정 AJAX 요청 시작 - BoardController 직접 호출');
    
    fetch('editComment.do', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `commentId=${commentId}&content=${encodeURIComponent(newContent)}`
    })
    .then(response => {
        console.log('🔍 댓글 수정 응답 상태:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP 오류! 상태: ${response.status}`);
        }
        return response.text();
    })
    .then(text => {
        console.log('🔍 댓글 수정 서버 응답 텍스트:', text);
        
        try {
            const data = JSON.parse(text);
            console.log('🔍 댓글 수정 파싱된 JSON:', data);
            
            if (data.success) {
                console.log('✅ 댓글 수정 성공');
                showNotification('댓글이 수정되었습니다.', 'success');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            } else {
                throw new Error(data.message || '댓글 수정에 실패했습니다.');
            }
        } catch (parseError) {
            console.error('❌ 댓글 수정 JSON 파싱 오류:', parseError);
            throw new Error('서버 응답을 처리할 수 없습니다.');
        }
    })
    .catch(error => {
        console.error('❌ 댓글 수정 오류:', error);
        showNotification(error.message || '댓글 수정 중 오류가 발생했습니다.', 'error');
    })
    .finally(() => {
        if (saveBtn) {
            hideLoading(saveBtn);
        }
    });
}

/**
 * 댓글 수정 취소
 */
function cancelEditComment(commentId) {
    console.log('🔥 cancelEditComment 함수 호출 - commentId:', commentId);
    
    const commentItem = document.querySelector(`[data-comment-id="${commentId}"]`);
    if (!commentItem) return;
    
    const editForm = commentItem.querySelector('.edit-form');
    const commentBody = commentItem.querySelector('.comment-body');
    
    if (editForm) {
        editForm.remove();
    }
    if (commentBody) {
        commentBody.style.display = '';
    }
    
    console.log('✅ 댓글 수정 취소 완료');
}

// ============================================
// 댓글 작성 기능
// ============================================

/**
 * 댓글 제출 처리
 */
function submitComment(event) {
    event.preventDefault();
    handleCommentSubmit(event);
}

/**
 * 댓글 폼 제출 핸들러 - BoardController 직접 호출
 */
function handleCommentSubmit(event) {
    event.preventDefault();
    
    if (isSubmitting) {
        console.log('⚠️ 이미 처리 중이므로 요청 무시');
        return;
    }
    
    const form = event.target;
    const formData = new FormData(form);
    const content = formData.get('content').trim();
    
    // 유효성 검사
    if (!content) {
        showNotification('댓글 내용을 입력해주세요.', 'error');
        document.getElementById('commentContent').focus();
        return;
    }
    
    if (content.length > 1000) {
        showNotification('댓글은 1000자 이하로 입력해주세요.', 'error');
        return;
    }
    
    // 사용자 로그인 확인
    if (!window.userData || !window.userData.isLoggedIn) {
        showNotification('로그인이 필요합니다.', 'error');
        setTimeout(() => {
            window.location.href = 'login.do';
        }, 1500);
        return;
    }
    
    isSubmitting = true;
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
        showLoading(submitBtn);
    }
    
    console.log('🔍 댓글 작성 요청 시작 - BoardController 직접 호출');
    
    // BoardController 직접 호출
    fetch('writeComment.do', {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(response => {
        console.log('🔍 댓글 작성 응답 상태:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP 오류! 상태: ${response.status}`);
        }
        
        return response.text();
    })
    .then(text => {
        console.log('🔍 댓글 작성 서버 응답 텍스트:', text);
        
        try {
            const data = JSON.parse(text);
            console.log('🔍 댓글 작성 파싱된 JSON:', data);
            
            if (data.success) {
                console.log('✅ 댓글 작성 성공');
                showNotification('댓글이 작성되었습니다.', 'success');
                
                // 폼 초기화
                const form = document.getElementById('commentForm');
                if (form) {
                    form.reset();
                }
                
                // 빠른 새로고침으로 즉시 댓글 표시
                setTimeout(() => {
                    window.location.reload();
                }, 500);
            } else {
                throw new Error(data.message || '댓글 작성에 실패했습니다.');
            }
        } catch (parseError) {
            console.error('❌ 댓글 작성 JSON 파싱 오류:', parseError);
            console.error('❌ 댓글 작성 원본 응답:', text);
            throw new Error('서버 응답을 처리할 수 없습니다.');
        }
    })
    .catch(error => {
        console.error('❌ 댓글 작성 오류:', error);
        showNotification(error.message || '댓글 작성 중 오류가 발생했습니다.', 'error');
    })
    .finally(() => {
        isSubmitting = false;
        if (submitBtn) {
            hideLoading(submitBtn);
        }
    });
}

// ============================================
// 첨부파일 관련 기능
// ============================================

/**
 * 첨부파일 미리보기 설정
 */
function setupFilePreview() {
    const attachmentItems = document.querySelectorAll('.attachment-item');
    attachmentItems.forEach(item => {
        const fileType = item.dataset.fileType;
        const fileName = item.querySelector('.file-name').textContent;
        
        // 파일 타입별 아이콘 설정
        const iconElement = item.querySelector('.file-icon i');
        if (iconElement) {
            iconElement.className = getFileIcon(fileType, fileName);
        }
    });
}

/**
 * 파일 타입별 아이콘 반환
 */
function getFileIcon(fileType, fileName) {
    const ext = fileName.toLowerCase().split('.').pop();
    
    if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext)) {
        return 'fas fa-image';
    } else if (['pdf'].includes(ext)) {
        return 'fas fa-file-pdf';
    } else if (['doc', 'docx'].includes(ext)) {
        return 'fas fa-file-word';
    } else if (['xls', 'xlsx'].includes(ext)) {
        return 'fas fa-file-excel';
    } else if (['ppt', 'pptx'].includes(ext)) {
        return 'fas fa-file-powerpoint';
    } else if (['zip', 'rar', '7z'].includes(ext)) {
        return 'fas fa-file-archive';
    } else if (['txt', 'md'].includes(ext)) {
        return 'fas fa-file-alt';
    } else {
        return 'fas fa-file';
    }
}

/**
 * 🔥 파일 다운로드 - 중복 실행 방지 (JSP onclick에서만 호출)
 */
function downloadFile(fileId) {
    // 중복 다운로드 방지
    if (isDownloading) {
        console.log('⚠️ 이미 다운로드 중입니다.');
        return false;
    }
    
    if (!fileId) {
        showNotification('파일 정보가 없습니다.', 'error');
        return false;
    }
    
    console.log('🔥 파일 다운로드 시작:', fileId);
    
    isDownloading = true;
    
    // 컨텍스트 경로 포함
    const contextPath = window.location.pathname.includes('/ClinkProject') ? '/ClinkProject' : '';
    const downloadUrl = `${contextPath}/file/download/${fileId}`;
    
    console.log('🔍 다운로드 URL:', downloadUrl);
    
    // 다운로드 링크 생성 및 클릭
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.target = '_blank';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('파일 다운로드를 시작합니다.', 'info');
    
    console.log('✅ 다운로드 링크 생성 완료:', downloadUrl);
    
    // 2초 후 플래그 해제
    setTimeout(() => {
        isDownloading = false;
        console.log('🔓 다운로드 플래그 해제');
    }, 2000);
    
    return false;
}

// ============================================
// 유틸리티 함수들
// ============================================

/**
 * 키보드 단축키 처리
 */
function handleKeyboardShortcuts(event) {
    // Ctrl+Enter: 댓글 작성
    if (event.ctrlKey && event.key === 'Enter') {
        const commentForm = document.getElementById('commentForm');
        if (commentForm && document.activeElement.tagName === 'TEXTAREA') {
            event.preventDefault();
            commentForm.querySelector('button[type="submit"]').click();
        }
    }
    
    // ESC: 폼 취소
    if (event.key === 'Escape') {
        const editForm = document.querySelector('.edit-form');
        
        if (editForm) {
            const commentId = editForm.closest('[data-comment-id]').dataset.commentId;
            cancelEditComment(parseInt(commentId));
        }
    }
}

/**
 * 댓글 개수 업데이트
 */
function updateCommentCount() {
    const comments = document.querySelectorAll('[data-comment-id]');
    commentCount = comments.length;
    
    const countElement = document.querySelector('#commentCountTitle');
    if (countElement) {
        countElement.textContent = commentCount;
    }
    
    const countElement2 = document.querySelector('#commentCount');
    if (countElement2) {
        countElement2.textContent = commentCount;
    }
}

/**
 * 댓글 취소 (폼 초기화)
 */
function clearComment() {
    const form = document.getElementById('commentForm');
    if (form) {
        form.reset();
        document.getElementById('commentContent').focus();
    }
}

/**
 * 목록으로 돌아가기
 */
function goBack() {
    const category = getCurrentCategory();
    const contextPath = window.location.pathname.includes('/ClinkProject') ? '/ClinkProject' : '';
    window.location.href = `${contextPath}/${category}Page.do`;
}

/**
 * 댓글로 스크롤 이동
 */
function scrollToComments() {
    const commentsSection = document.getElementById('commentsSection');
    if (commentsSection) {
        commentsSection.scrollIntoView({ behavior: 'smooth' });
    }
}

/**
 * 게시글 공유 (URL 복사)
 */
function sharePost() {
    const currentUrl = window.location.href;
    
    // 클립보드 API 지원 확인
    if (navigator.clipboard && window.isSecureContext) {
        // 최신 브라우저
        navigator.clipboard.writeText(currentUrl)
            .then(() => {
                showNotification('게시글 링크가 복사되었습니다!', 'success');
            })
            .catch(err => {
                console.error('클립보드 복사 실패:', err);
                fallbackCopyToClipboard(currentUrl);
            });
    } else {
        // 구형 브라우저 지원
        fallbackCopyToClipboard(currentUrl);
    }
}

/**
 * 구형 브라우저용 클립보드 복사
 */
function fallbackCopyToClipboard(text) {
    try {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        const successful = document.execCommand('copy');
        document.body.removeChild(textArea);
        
        if (successful) {
            showNotification('게시글 링크가 복사되었습니다!', 'success');
        } else {
            showNotification('링크 복사에 실패했습니다.', 'error');
        }
    } catch (err) {
        console.error('클립보드 복사 실패:', err);
        showNotification('링크 복사를 지원하지 않는 브라우저입니다.', 'error');
    }
}

// ============================================
// 알림 및 로딩 유틸리티
// ============================================

/**
 * 알림 메시지 표시
 */
function showNotification(message, type = 'info', duration = 3000) {
    // common.js의 showAlert 함수가 있으면 사용
    if (window.ClinkApp && window.ClinkApp.showAlert) {
        window.ClinkApp.showAlert(message, type, duration);
        return;
    }
    
    // Fallback: 직접 구현
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // 타입별 스타일
    let backgroundColor, textColor;
    switch (type) {
        case 'error':
            backgroundColor = '#fee2e2';
            textColor = '#dc2626';
            break;
        case 'success':
            backgroundColor = '#dcfce7';
            textColor = '#16a34a';
            break;
        case 'warning':
            backgroundColor = '#fef3c7';
            textColor = '#d97706';
            break;
        default:
            backgroundColor = '#dbeafe';
            textColor = '#2563eb';
    }
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        padding: 12px 20px;
        border-radius: 8px;
        background: ${backgroundColor};
        color: ${textColor};
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        max-width: 300px;
        word-wrap: break-word;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // 자동 제거
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, duration);
}

/**
 * 로딩 스피너 표시 (버튼용)
 */
function showLoading(element) {
    if (!element) return;
    
    element.disabled = true;
    element.dataset.originalText = element.textContent;
    element.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 처리중...';
}

/**
 * 로딩 스피너 숨김 (버튼용)
 */
function hideLoading(element) {
    if (!element) return;
    
    element.disabled = false;
    if (element.dataset.originalText) {
        element.textContent = element.dataset.originalText;
        delete element.dataset.originalText;
    }
}