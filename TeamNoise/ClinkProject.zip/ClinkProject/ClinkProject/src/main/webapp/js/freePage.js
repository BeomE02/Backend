/**
 * freePage.js - 자유게시판 JavaScript 모듈 (완전한 버전)
 * 모든 UI 상호작용, 이벤트 처리, 유틸리티 기능을 담당
 */

(function() {
    'use strict';

    // ===== 전역 변수 =====
    let pageData = window.pageData || {
        currentPage: 1,
        totalPages: 1,
        searchType: '',
        keyword: '',
        contextPath: ''
    };
    
    let autoRefreshTimer = null;
    let searchTimeout = null;
    let isLoading = false;
    let clickedButtons = new Set();

    // ===== DOM 요소들 =====
    const elements = {};

    // ===== DOM이 로드된 후 실행 =====
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🚀 자유게시판 페이지 초기화 시작');
        
        try {
            initElements();
            initEventListeners();
            initKeyboardShortcuts();
            initAnimations();
            initAutoRefresh();
            showMessages();
            restoreScrollPosition();
            highlightSearchKeyword();
            addDynamicStyles();
            
            console.log('✅ 자유게시판 페이지 초기화 완료');
        } catch (error) {
            console.error('❌ 초기화 중 오류:', error);
        }
    });

    // ===== DOM 요소 초기화 =====
    function initElements() {
        elements.searchForm = document.querySelector('.search-form');
        elements.searchInput = document.querySelector('.search-input');
        elements.searchSelect = document.querySelector('.search-select');
        elements.searchBtn = document.querySelector('.search-btn');
        elements.writeButtons = document.querySelectorAll('.write-btn');
        elements.postLinks = document.querySelectorAll('.post-link');
        elements.pageButtons = document.querySelectorAll('.page-btn');
        elements.boardRows = document.querySelectorAll('.board-row');
        elements.boardWrapper = document.querySelector('.board-wrapper');
        elements.newBadges = document.querySelectorAll('.new-badge');
        elements.hotBadges = document.querySelectorAll('.hot-badge');
        elements.attachmentIcons = document.querySelectorAll('.attachment-icon');

        console.log('🔧 DOM 요소 초기화 완료:', {
            postCount: elements.postLinks.length,
            pageButtons: elements.pageButtons.length
        });
    }

    // ===== 이벤트 리스너 초기화 =====
    function initEventListeners() {
        // 검색 폼 이벤트
        if (elements.searchForm) {
            elements.searchForm.addEventListener('submit', handleSearchSubmit);
        }

        // 검색 입력 필드 이벤트
        if (elements.searchInput) {
            elements.searchInput.addEventListener('input', handleSearchInput);
            elements.searchInput.addEventListener('focus', handleSearchFocus);
            elements.searchInput.addEventListener('keypress', handleSearchKeypress);
        }

        // 게시글 링크 이벤트
        elements.postLinks.forEach(function(link) {
            link.addEventListener('click', handlePostClick);
            link.addEventListener('mouseenter', handlePostHover);
        });

        // 페이지 버튼 이벤트
        elements.pageButtons.forEach(function(button) {
            button.addEventListener('click', handlePageClick);
        });

        // 게시글 행 호버 효과
        elements.boardRows.forEach(function(row) {
            row.addEventListener('mouseenter', handleRowHover);
            row.addEventListener('mouseleave', handleRowLeave);
        });

        // 글쓰기 버튼 이벤트
        elements.writeButtons.forEach(function(btn) {
            btn.addEventListener('click', handleWriteClick);
        });

        // 첨부파일 아이콘 이벤트
        elements.attachmentIcons.forEach(function(icon) {
            icon.addEventListener('mouseenter', handleAttachmentHover);
            icon.addEventListener('mouseleave', handleAttachmentLeave);
        });

        // 페이지 언로드 이벤트
        window.addEventListener('beforeunload', handlePageUnload);
        window.addEventListener('popstate', handlePopState);

        console.log('🎯 이벤트 리스너 초기화 완료');
    }

    // ===== 검색 관련 이벤트 =====
    function handleSearchSubmit(e) {
        var keyword = elements.searchInput.value.trim();
        
        if (!keyword) {
            e.preventDefault();
            showToast('검색어를 입력해주세요.', 'warning');
            elements.searchInput.focus();
            return false;
        }
        
        if (keyword.length < 2) {
            e.preventDefault();
            showToast('검색어는 2자 이상 입력해주세요.', 'warning');
            elements.searchInput.focus();
            return false;
        }
        
        if (keyword.length > 100) {
            e.preventDefault();
            showToast('검색어는 100자 이내로 입력해주세요.', 'warning');
            elements.searchInput.focus();
            return false;
        }
        
        // 로딩 상태 표시
        setSearchLoading(true);
        
        // 스크롤 위치 저장
        saveScrollPosition();
    }

    function handleSearchInput(e) {
        clearTimeout(searchTimeout);
        
        var value = e.target.value.trim();
        
        // 시각적 피드백
        if (value.length > 0) {
            e.target.style.borderColor = '#B9FF66';
        } else {
            e.target.style.borderColor = '#ddd';
        }
        
        // 실시간 검색 제안 (300ms 디바운스)
        searchTimeout = setTimeout(function() {
            if (value.length >= 2) {
                console.log('🔍 검색 제안:', value);
            }
        }, 300);
    }

    function handleSearchFocus(e) {
        e.target.select();
    }

    function handleSearchKeypress(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            elements.searchForm.submit();
        }
    }

    function setSearchLoading(loading) {
        if (!elements.searchBtn) return;
        
        var btnText = elements.searchBtn.querySelector('.btn-text');
        var btnIcon = elements.searchBtn.querySelector('.btn-icon');
        
        if (loading) {
            elements.searchBtn.disabled = true;
            if (btnText) btnText.textContent = '검색중...';
            if (btnIcon) btnIcon.textContent = '⏳';
        } else {
            elements.searchBtn.disabled = false;
            if (btnText) btnText.textContent = '검색';
            if (btnIcon) btnIcon.textContent = '🔍';
        }
    }

    // ===== 게시글 관련 이벤트 =====
    function handlePostClick(e) {
        // Ctrl/Cmd + 클릭으로 새 탭에서 열기
        if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            window.open(e.currentTarget.href, '_blank');
            return;
        }
        
        // 로딩 효과
        var row = e.currentTarget.querySelector('.board-row');
        if (row) {
            row.style.opacity = '0.7';
            row.style.transform = 'scale(0.98)';
        }
        
        // 스크롤 위치 저장
        saveScrollPosition();
        
        var postId = e.currentTarget.getAttribute('data-post-id');
        console.log('📄 게시글 클릭:', postId);
    }

    function handlePostHover(e) {
        var title = e.currentTarget.querySelector('.post-title');
        if (title && title.scrollWidth > title.clientWidth) {
            // 제목이 잘린 경우 전체 제목을 툴팁으로 표시
            title.setAttribute('title', title.textContent);
        }
    }

    function handleRowHover(e) {
        e.currentTarget.style.transform = 'translateX(8px)';
        e.currentTarget.style.transition = 'transform 0.2s ease';
    }

    function handleRowLeave(e) {
        e.currentTarget.style.transform = 'translateX(0)';
    }

    // ===== 페이지네이션 이벤트 =====
    function handlePageClick(e) {
        if (e.currentTarget.classList.contains('current')) {
            e.preventDefault();
            return;
        }
        
        // 로딩 효과
        e.currentTarget.style.opacity = '0.7';
        var originalText = e.currentTarget.textContent;
        e.currentTarget.textContent = '⏳';
        
        // 스크롤 위치 저장
        saveScrollPosition();
        
        var page = e.currentTarget.getAttribute('data-page');
        console.log('📄 페이지 이동:', page);
    }

    // ===== 글쓰기 버튼 이벤트 =====
    function handleWriteClick(e) {
        var buttonId = e.currentTarget.getAttribute('data-button-id') || 'write-btn';
        
        // 더블클릭 방지
        if (clickedButtons.has(buttonId)) {
            e.preventDefault();
            return false;
        }
        
        clickedButtons.add(buttonId);
        setTimeout(function() {
            clickedButtons.delete(buttonId);
        }, 2000);
        
        console.log('✏️ 글쓰기 버튼 클릭');
    }

    // ===== 첨부파일 아이콘 이벤트 =====
    function handleAttachmentHover(e) {
        e.currentTarget.style.transform = 'scale(1.2)';
        e.currentTarget.style.transition = 'transform 0.2s ease';
    }

    function handleAttachmentLeave(e) {
        e.currentTarget.style.transform = 'scale(1)';
    }

    // ===== 키보드 단축키 =====
    function initKeyboardShortcuts() {
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + F: 검색창에 포커스
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                if (elements.searchInput) {
                    elements.searchInput.focus();
                    elements.searchInput.select();
                }
                return;
            }
            
            // W: 글쓰기 (검색창에 포커스가 없을 때)
            if (e.key === 'w' && document.activeElement !== elements.searchInput) {
                var writeBtn = document.querySelector('.write-btn');
                if (writeBtn) {
                    var writeLink = writeBtn.closest('a');
                    if (writeLink) {
                        window.location.href = writeLink.href;
                    }
                }
                return;
            }
            
            // ESC: 검색어 클리어
            if (e.key === 'Escape' && elements.searchInput) {
                elements.searchInput.value = '';
                elements.searchInput.blur();
                return;
            }
            
            // Alt + 화살표 키: 페이지 이동
            if (e.altKey) {
                if (e.key === 'ArrowLeft' && pageData.currentPage > 1) {
                    navigateToPage(pageData.currentPage - 1);
                } else if (e.key === 'ArrowRight' && pageData.currentPage < pageData.totalPages) {
                    navigateToPage(pageData.currentPage + 1);
                }
            }
        });
        
        console.log('⌨️ 키보드 단축키 초기화 완료');
    }

    // ===== 애니메이션 초기화 =====
    function initAnimations() {
        // 새 게시글 배지 애니메이션
        elements.newBadges.forEach(function(badge) {
            badge.style.animation = 'pulse 2s infinite';
        });

        // 인기 게시글 배지 애니메이션
        elements.hotBadges.forEach(function(badge) {
            badge.style.animation = 'bounce 1s infinite alternate';
        });

        // 페이지 로드 애니메이션
        if (elements.boardWrapper) {
            elements.boardWrapper.classList.add('fade-in');
        }
        
        console.log('🎨 애니메이션 초기화 완료');
    }

    // ===== 자동 새로고침 =====
    function initAutoRefresh() {
        // 개발 모드에서만 자동 새로고침 활성화
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            startAutoRefresh();
        }
    }

    function startAutoRefresh() {
        // 5분마다 새 글 확인
        autoRefreshTimer = setInterval(function() {
            if (getCurrentPage() === 1 && !hasSearchParams()) {
                checkNewPosts();
            }
        }, 5 * 60 * 1000);
        
        console.log('🔄 자동 새로고침 시작');
    }

    function stopAutoRefresh() {
        if (autoRefreshTimer) {
            clearInterval(autoRefreshTimer);
            autoRefreshTimer = null;
            console.log('🛑 자동 새로고침 중지');
        }
    }

    function checkNewPosts() {
        if (isLoading) return;
        
        var checkUrl = window.location.href + '&ajax=checkNew';
        
        fetch(checkUrl)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.hasNewPosts) {
                    showNewPostNotification(data.newPostCount);
                }
            })
            .catch(function(error) {
                console.log('새 글 확인 실패:', error);
            });
    }

    function showNewPostNotification(count) {
        // 기존 알림 제거
        var existingNotification = document.querySelector('.new-post-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // 새 알림 생성
        var notification = document.createElement('div');
        notification.className = 'new-post-notification';
        notification.innerHTML = 
            '<span>새 글 ' + count + '개가 등록되었습니다.</span>' +
            '<button class="refresh-btn" onclick="location.reload()">새로고침</button>' +
            '<button class="close-btn" onclick="this.parentElement.remove()">×</button>';
        
        // 스타일 적용
        notification.style.cssText = 
            'position: fixed;' +
            'top: 20px;' +
            'right: 20px;' +
            'background: #B9FF66;' +
            'color: #1a1a1a;' +
            'padding: 12px 16px;' +
            'border-radius: 8px;' +
            'box-shadow: 0 4px 12px rgba(0,0,0,0.15);' +
            'z-index: 1000;' +
            'display: flex;' +
            'align-items: center;' +
            'gap: 10px;' +
            'animation: slideInRight 0.3s ease;' +
            'font-size: 14px;' +
            'font-weight: 500;';
        
        document.body.appendChild(notification);
        
        // 5초 후 자동 제거
        setTimeout(function() {
            if (notification.parentElement) {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(function() {
                    notification.remove();
                }, 300);
            }
        }, 5000);
    }

    // ===== 메시지 표시 =====
    function showMessages() {
        // 에러 메시지 표시
        var errorElement = document.getElementById('errorMessage');
        if (errorElement) {
            var message = errorElement.getAttribute('data-message');
            showToast(message, 'error');
        }
        
        // 성공 메시지 표시
        var successElement = document.getElementById('successMessage');
        if (successElement) {
            var message = successElement.getAttribute('data-message');
            showToast(message, 'success');
            
            // URL에서 메시지 파라미터 제거
            if (window.history.replaceState) {
                var url = new URL(window.location);
                url.searchParams.delete('success');
                url.searchParams.delete('message');
                window.history.replaceState({}, document.title, url.toString());
            }
        }
    }

    function showToast(message, type) {
        type = type || 'info';
        
        // 기존 토스트 제거
        var existingToast = document.querySelector('.toast');
        if (existingToast) {
            existingToast.remove();
        }
        
        // 새 토스트 생성
        var toast = document.createElement('div');
        toast.className = 'toast ' + type;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        // 애니메이션 시작
        setTimeout(function() {
            toast.classList.add('show');
        }, 100);
        
        // 3초 후 제거
        setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() {
                toast.remove();
            }, 300);
        }, 3000);
    }

    // ===== 스크롤 위치 관리 =====
    function saveScrollPosition() {
        sessionStorage.setItem('freePageScrollPos', window.scrollY);
    }

    function restoreScrollPosition() {
        var scrollPos = sessionStorage.getItem('freePageScrollPos');
        if (scrollPos) {
            window.scrollTo(0, parseInt(scrollPos));
            sessionStorage.removeItem('freePageScrollPos');
        }
    }

    // ===== 페이지 네비게이션 =====
    function navigateToPage(page) {
        var url = new URL(window.location);
        url.searchParams.set('page', page);
        
        saveScrollPosition();
        window.location.href = url.toString();
    }

    function getCurrentPage() {
        return pageData.currentPage || 1;
    }

    function hasSearchParams() {
        var urlParams = new URLSearchParams(window.location.search);
        return urlParams.has('keyword') || urlParams.has('searchType');
    }

    // ===== 검색어 하이라이트 =====
    function highlightSearchKeyword() {
        var keyword = pageData.keyword;
        if (!keyword) return;
        
        var postTitles = document.querySelectorAll('.post-title');
        postTitles.forEach(function(title) {
            var text = title.textContent;
            var regex = new RegExp('(' + escapeRegex(keyword) + ')', 'gi');
            var highlightedText = text.replace(regex, 
                '<mark style="background: #B9FF66; padding: 2px 4px; border-radius: 3px;">$1</mark>'
            );
            
            if (highlightedText !== text) {
                title.innerHTML = highlightedText;
            }
        });
        
        console.log('🎯 검색어 하이라이트:', keyword);
    }

    function escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    // ===== 페이지 이벤트 =====
    function handlePageUnload() {
        stopAutoRefresh();
        
        // 진행 중인 요청들 정리
        if (searchTimeout) {
            clearTimeout(searchTimeout);
        }
    }

    function handlePopState() {
        // 뒤로가기 시 페이지 새로고침
        location.reload();
    }

    // ===== CSS 애니메이션 동적 추가 =====
    function addDynamicStyles() {
        if (document.getElementById('freePage-dynamic-styles')) {
            return; // 이미 추가됨
        }
        
        var style = document.createElement('style');
        style.id = 'freePage-dynamic-styles';
        style.textContent = 
            '@keyframes slideInRight {' +
                'from { transform: translateX(100%); opacity: 0; }' +
                'to { transform: translateX(0); opacity: 1; }' +
            '}' +
            '@keyframes slideOutRight {' +
                'from { transform: translateX(0); opacity: 1; }' +
                'to { transform: translateX(100%); opacity: 0; }' +
            '}' +
            '.new-post-notification .refresh-btn,' +
            '.new-post-notification .close-btn {' +
                'background: #1a1a1a;' +
                'color: white;' +
                'border: none;' +
                'padding: 4px 8px;' +
                'border-radius: 4px;' +
                'cursor: pointer;' +
                'font-size: 12px;' +
                'transition: background 0.2s ease;' +
            '}' +
            '.new-post-notification .refresh-btn:hover,' +
            '.new-post-notification .close-btn:hover {' +
                'background: #333;' +
            '}' +
            '.new-post-notification .close-btn {' +
                'width: 24px;' +
                'height: 24px;' +
                'border-radius: 50%;' +
                'display: flex;' +
                'align-items: center;' +
                'justify-content: center;' +
                'font-weight: bold;' +
            '}';
        
        document.head.appendChild(style);
    }

    // ===== 에러 처리 =====
    window.addEventListener('error', function(e) {
        console.error('JavaScript 에러:', e.error);
        showToast('페이지에 오류가 발생했습니다.', 'error');
    });

    // ===== 공개 API =====
    window.FreePage = {
        refreshPage: function() { 
            location.reload(); 
        },
        navigateToPage: navigateToPage,
        showToast: showToast,
        getCurrentPage: getCurrentPage,
        saveScrollPosition: saveScrollPosition,
        restoreScrollPosition: restoreScrollPosition
    };

    // ===== 최종 초기화 (페이지 로드 완료 후) =====
    window.addEventListener('load', function() {
        setTimeout(function() {
            // 페이지 로드 완료 이벤트 발생
            var loadEvent = new Event('freePageLoaded');
            document.dispatchEvent(loadEvent);
            
            console.log('🎉 자유게시판 모든 기능 로드 완료');
        }, 100);
    });

})();