/**
 * 사진게시판 JavaScript
 * 작성일: 2025-01-18
 * 작성자: Clink Team
 * 설명: 사진게시판의 모든 인터랙션 및 동적 기능 관리
 */

// ===== 전역 변수 =====
let currentView = 'grid'; // 현재 뷰 모드 (grid/list)
let isLoading = false; // 로딩 상태
let searchTimeout = null; // 검색 디바운싱용

// DOM 요소들
const elements = {
    classSelect: null,
    searchType: null,
    searchInput: null,
    searchBtn: null,
    viewBtns: null,
    photoGrid: null,
    photoList: null,
    loadingOverlay: null,
    writeBtn: null
};

// ===== 초기화 =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎨 사진게시판 초기화 시작');
    
    initElements();
    initEventListeners();
    initView();
    initAnimations();
    initKeyboardShortcuts();
    restoreScrollPosition();
    
    console.log('✅ 사진게시판 초기화 완료');
});

// ===== DOM 요소 초기화 =====
function initElements() {
    elements.classSelect = document.getElementById('classSelect');
    elements.searchType = document.getElementById('searchType');
    elements.searchInput = document.getElementById('searchInput');
    elements.searchBtn = document.querySelector('.search-btn');
    elements.viewBtns = document.querySelectorAll('.view-btn');
    elements.photoGrid = document.querySelector('.photo-grid');
    elements.photoList = document.querySelector('.photo-list');
    elements.loadingOverlay = document.getElementById('loadingOverlay');
    elements.writeBtn = document.querySelector('.write-btn');
    
    console.log('📋 DOM 요소 초기화 완료');
}

// ===== 이벤트 리스너 초기화 =====
function initEventListeners() {
    // 수업 선택 변경
    if (elements.classSelect) {
        elements.classSelect.addEventListener('change', function() {
            updateUrlAndReload();
        });
    }
    
    // 검색 관련 이벤트
    if (elements.searchInput) {
        elements.searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 2 || this.value.length === 0) {
                    performSearch();
                }
            }, 500); // 500ms 디바운싱
        });
        
        elements.searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch();
            }
        });
    }
    
    if (elements.searchBtn) {
        elements.searchBtn.addEventListener('click', performSearch);
    }
    
    // 뷰 모드 전환
    elements.viewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const viewMode = this.getAttribute('data-view');
            changeView(viewMode);
        });
    });
    
    // 사진 카드 클릭 이벤트 (이벤트 위임)
    if (elements.photoGrid) {
        elements.photoGrid.addEventListener('click', function(e) {
            const photoCard = e.target.closest('.photo-card');
            if (photoCard) {
                const postId = photoCard.getAttribute('data-post-id');
                if (postId) {
                    goToPost(postId);
                }
            }
        });
    }
    
    // 리스트 행 클릭 이벤트 (이벤트 위임)
    if (elements.photoList) {
        elements.photoList.addEventListener('click', function(e) {
            const listRow = e.target.closest('.list-row');
            if (listRow) {
                const postId = listRow.getAttribute('data-post-id');
                if (postId) {
                    goToPost(postId);
                }
            }
        });
    }
    
    // 스크롤 이벤트
    window.addEventListener('scroll', throttle(handleScroll, 16)); // ~60fps
    
    // 리사이즈 이벤트
    window.addEventListener('resize', debounce(handleResize, 250));
    
    // 페이지 떠날 때 스크롤 위치 저장
    window.addEventListener('beforeunload', saveScrollPosition);
    
    console.log('🎧 이벤트 리스너 초기화 완료');
}

// ===== 뷰 모드 초기화 =====
function initView() {
    // URL 파라미터에서 뷰 모드 확인
    const urlParams = new URLSearchParams(window.location.search);
    const viewParam = urlParams.get('view');
    
    if (viewParam === 'list') {
        currentView = 'list';
    } else {
        currentView = 'grid';
    }
    
    // 뷰 모드 적용
    updateViewMode();
    
    console.log(`📱 뷰 모드 초기화: ${currentView}`);
}

// ===== 뷰 모드 업데이트 =====
function updateViewMode() {
    // 뷰 버튼 상태 업데이트
    elements.viewBtns.forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-view') === currentView) {
            btn.classList.add('active');
        }
    });
    
    // 컨텐츠 표시/숨김
    if (elements.photoGrid && elements.photoList) {
        if (currentView === 'grid') {
            elements.photoGrid.classList.remove('hidden');
            elements.photoList.classList.add('hidden');
        } else {
            elements.photoGrid.classList.add('hidden');
            elements.photoList.classList.remove('hidden');
        }
    }
}

// ===== 뷰 모드 변경 =====
function changeView(viewMode) {
    if (viewMode === currentView) return;
    
    currentView = viewMode;
    updateViewMode();
    
    // URL 업데이트 (페이지 리로드 없이)
    const url = new URL(window.location);
    url.searchParams.set('view', viewMode);
    window.history.replaceState({}, '', url);
    
    console.log(`🔄 뷰 모드 변경: ${viewMode}`);
}

// ===== 검색 실행 =====
function performSearch() {
    const searchType = elements.searchType ? elements.searchType.value : 'all';
    const keyword = elements.searchInput ? elements.searchInput.value.trim() : '';
    
    // 검색어 길이 검증
    if (keyword.length > 0 && keyword.length < 2) {
        showNotification('검색어는 2글자 이상 입력해주세요.', 'warning');
        return;
    }
    
    console.log(`🔍 검색 실행: ${searchType} - "${keyword}"`);
    
    // URL 업데이트 및 페이지 리로드
    updateUrlAndReload({
        searchType: searchType,
        keyword: keyword,
        page: 1 // 검색 시 첫 페이지로
    });
}

// ===== URL 업데이트 및 페이지 리로드 =====
function updateUrlAndReload(params = {}) {
    const url = new URL(window.location);
    
    // 기본 파라미터 설정
    const defaultParams = {
        classId: elements.classSelect ? elements.classSelect.value : '',
        searchType: elements.searchType ? elements.searchType.value : 'all',
        keyword: elements.searchInput ? elements.searchInput.value.trim() : '',
        view: currentView,
        page: 1,
        size: 12
    };
    
    // 파라미터 병합
    const finalParams = { ...defaultParams, ...params };
    
    // URL 파라미터 설정
    Object.keys(finalParams).forEach(key => {
        if (finalParams[key]) {
            url.searchParams.set(key, finalParams[key]);
        } else {
            url.searchParams.delete(key);
        }
    });
    
    showLoading();
    
    // 페이지 이동
    window.location.href = url.toString();
}

// ===== 게시글 상세 페이지로 이동 =====
function goToPost(postId) {
    if (!postId) {
        console.error('게시글 ID가 없습니다.');
        return;
    }
    
    saveScrollPosition();
    showLoading();
    
    const url = `${window.contextPath}/viewPost.do?postId=${postId}&category=photo`;
    window.location.href = url;
    
    console.log(`📄 게시글 상세 이동: ${postId}`);
}

// ===== 글쓰기 페이지로 이동 =====
function goToWrite() {
    if (!window.currentUser) {
        showNotification('로그인이 필요합니다.', 'warning');
        setTimeout(() => {
            window.location.href = `${window.contextPath}/login.do`;
        }, 1500);
        return;
    }
    
    const classId = elements.classSelect ? elements.classSelect.value : '';
    let url = `${window.contextPath}/writePost.do?category=photo`;
    
    if (classId) {
        url += `&classId=${classId}`;
    }
    
    showLoading();
    window.location.href = url;
    
    console.log('✏️ 글쓰기 페이지 이동');
}

// ===== 로딩 표시/숨김 =====
function showLoading() {
    if (elements.loadingOverlay) {
        elements.loadingOverlay.classList.add('active');
        isLoading = true;
    }
}

function hideLoading() {
    if (elements.loadingOverlay) {
        elements.loadingOverlay.classList.remove('active');
        isLoading = false;
    }
}

// ===== 알림 메시지 표시 =====
function showNotification(message, type = 'info', duration = 3000) {
    // 기존 알림 제거
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // 새 알림 생성
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // 스타일 설정
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        background: ${type === 'error' ? '#ff6b6b' : type === 'warning' ? '#ffa726' : type === 'success' ? '#66bb6a' : '#42a5f5'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.3s ease-out;
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    // 문서에 추가
    document.body.appendChild(notification);
    
    // 자동 제거
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, duration);
    
    console.log(`📢 알림: ${message}`);
}

// ===== 스크롤 위치 저장/복원 =====
function saveScrollPosition() {
    const scrollPosition = window.pageYOffset;
    sessionStorage.setItem('photoPage_scrollPosition', scrollPosition.toString());
}

function restoreScrollPosition() {
    const savedPosition = sessionStorage.getItem('photoPage_scrollPosition');
    if (savedPosition) {
        setTimeout(() => {
            window.scrollTo(0, parseInt(savedPosition));
            sessionStorage.removeItem('photoPage_scrollPosition');
        }, 100);
    }
}

// ===== 스크롤 이벤트 핸들러 =====
function handleScroll() {
    const scrollTop = window.pageYOffset;
    const header = document.querySelector('.header');
    
    // 헤더 스크롤 효과
    if (header) {
        if (scrollTop > 100) {
            header.style.backgroundColor = 'rgba(249, 249, 249, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
            header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.backgroundColor = '#f9f9f9';
            header.style.backdropFilter = 'none';
            header.style.boxShadow = 'none';
        }
    }
}

// ===== 리사이즈 이벤트 핸들러 =====
function handleResize() {
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
        // 모바일에서는 그리드 뷰가 기본
        if (currentView === 'list') {
            changeView('grid');
        }
        
        // 검색 입력창 크기 조정
        if (elements.searchInput) {
            elements.searchInput.style.width = '100%';
        }
    } else {
        // 데스크톱에서는 원래 크기로 복원
        if (elements.searchInput) {
            elements.searchInput.style.width = '';
        }
    }
}

// ===== 애니메이션 초기화 =====
function initAnimations() {
    // Intersection Observer를 사용한 스크롤 애니메이션
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        // 관찰할 요소들
        const animatedElements = document.querySelectorAll('.photo-card, .list-row');
        animatedElements.forEach(el => {
            observer.observe(el);
        });
    }
    
    // 사진 카드 호버 애니메이션
    const photoCards = document.querySelectorAll('.photo-card');
    photoCards.forEach(card => {
        card.addEventListener('mouseenter', handleCardHover);
        card.addEventListener('mouseleave', handleCardLeave);
    });
    
    console.log('🎭 애니메이션 초기화 완료');
}

// ===== 카드 호버 이벤트 =====
function handleCardHover(e) {
    const img = e.currentTarget.querySelector('.photo-thumbnail img');
    if (img) {
        img.style.transform = 'scale(1.05)';
        img.style.transition = 'transform 0.3s ease';
    }
}

function handleCardLeave(e) {
    const img = e.currentTarget.querySelector('.photo-thumbnail img');
    if (img) {
        img.style.transform = 'scale(1)';
    }
}

// ===== 키보드 단축키 =====
function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + / : 검색 포커스
        if ((e.ctrlKey || e.metaKey) && e.key === '/') {
            e.preventDefault();
            if (elements.searchInput) {
                elements.searchInput.focus();
                elements.searchInput.select();
            }
        }
        
        // Ctrl/Cmd + Enter : 글쓰기
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            if (elements.writeBtn) {
                elements.writeBtn.click();
            }
        }
        
        // 1, 2 키로 뷰 모드 전환
        if (e.key === '1' && !e.ctrlKey && !e.metaKey && !e.altKey && !e.target.matches('input, textarea')) {
            e.preventDefault();
            changeView('grid');
        }
        
        if (e.key === '2' && !e.ctrlKey && !e.metaKey && !e.altKey && !e.target.matches('input, textarea')) {
            e.preventDefault();
            changeView('list');
        }
        
        // ESC 키로 검색 초기화
        if (e.key === 'Escape') {
            if (elements.searchInput && elements.searchInput === document.activeElement) {
                elements.searchInput.blur();
            }
            
            // 검색어가 있다면 초기화
            if (elements.searchInput && elements.searchInput.value) {
                elements.searchInput.value = '';
                performSearch();
            }
        }
        
        // F5 또는 Ctrl/Cmd + R : 새로고침
        if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && e.key === 'r')) {
            saveScrollPosition();
        }
    });
    
    console.log('⌨️ 키보드 단축키 초기화 완료');
}

// ===== 이미지 로드 에러 처리 =====
function handleImageError(img) {
    img.src = `${window.contextPath}/image/post-placeholder.jpg`;
    img.alt = '이미지 로드 실패';
    console.warn('이미지 로드 실패:', img.dataset.originalSrc || img.src);
}

// ===== 무한 스크롤 (향후 확장용) =====
function initInfiniteScroll() {
    let isLoadingMore = false;
    
    window.addEventListener('scroll', function() {
        if (isLoadingMore || isLoading) return;
        
        const scrollTop = window.pageYOffset;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        
        // 페이지 하단에서 200px 위에 도달했을 때
        if (scrollTop + windowHeight >= documentHeight - 200) {
            loadMorePosts();
        }
    });
}

function loadMorePosts() {
    // 향후 AJAX를 통한 무한 스크롤 구현 시 사용
    console.log('📜 더 많은 게시글 로드 (향후 구현)');
}

// ===== 이미지 지연 로딩 =====
function initLazyLoading() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    const src = img.dataset.src;
                    
                    if (src) {
                        img.src = src;
                        img.classList.remove('lazy');
                        img.classList.add('loaded');
                        observer.unobserve(img);
                    }
                }
            });
        });
        
        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
}

// ===== 터치 이벤트 (모바일 지원) =====
function initTouchEvents() {
    if ('ontouchstart' in window) {
        // 터치 디바이스에서 호버 효과 대신 터치 효과 적용
        const photoCards = document.querySelectorAll('.photo-card');
        
        photoCards.forEach(card => {
            card.addEventListener('touchstart', function() {
                this.classList.add('touched');
            });
            
            card.addEventListener('touchend', function() {
                setTimeout(() => {
                    this.classList.remove('touched');
                }, 150);
            });
        });
    }
}

// ===== 디바운싱 함수 =====
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===== 쓰로틀링 함수 =====
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ===== 에러 처리 =====
window.addEventListener('error', function(e) {
    console.error('JavaScript 오류 발생:', e.error);
    hideLoading();
    
    if (e.error.message.includes('Failed to fetch')) {
        showNotification('네트워크 연결을 확인해주세요.', 'error');
    }
});

// ===== 브라우저 호환성 검사 =====
function checkBrowserCompatibility() {
    // CSS Grid 지원 확인
    if (!CSS.supports('display', 'grid')) {
        console.warn('CSS Grid를 지원하지 않는 브라우저입니다.');
        showNotification('일부 기능이 제한될 수 있습니다.', 'warning');
        
        // 폴백: Flexbox 레이아웃으로 변경
        if (elements.photoGrid) {
            elements.photoGrid.style.display = 'flex';
            elements.photoGrid.style.flexWrap = 'wrap';
            elements.photoGrid.style.justifyContent = 'center';
        }
    }
    
    // IntersectionObserver 지원 확인
    if (!window.IntersectionObserver) {
        console.warn('IntersectionObserver를 지원하지 않는 브라우저입니다.');
        
        // 폴백: 모든 애니메이션 요소를 즉시 표시
        const animatedElements = document.querySelectorAll('.photo-card, .list-row');
        animatedElements.forEach(element => {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        });
    }
}

// ===== 접근성 향상 =====
function improveAccessibility() {
    // 포커스 관리
    const focusableElements = document.querySelectorAll(
        'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
    );
    
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '3px solid #B9FF66';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
    
    // 키보드 네비게이션
    document.addEventListener('keydown', function(e) {
        // Enter 키로 카드 클릭
        if (e.key === 'Enter' && e.target.classList.contains('photo-card')) {
            e.target.click();
        }
    });
}

// ===== 초기화 완료 후 실행 =====
function afterInit() {
    checkBrowserCompatibility();
    improveAccessibility();
    initTouchEvents();
    
    // 이미지 로드 완료 후 애니메이션 시작
    const images = document.querySelectorAll('.photo-thumbnail img');
    let loadedImages = 0;
    
    images.forEach(img => {
        if (img.complete) {
            loadedImages++;
        } else {
            img.addEventListener('load', () => {
                loadedImages++;
                if (loadedImages === images.length) {
                    startCardAnimations();
                }
            });
        }
    });
    
    if (loadedImages === images.length) {
        startCardAnimations();
    }
}

// ===== 카드 애니메이션 시작 =====
function startCardAnimations() {
    const cards = document.querySelectorAll('.photo-card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

// ===== 전역 함수 노출 =====
window.goToPost = goToPost;
window.goToWrite = goToWrite;
window.changeView = changeView;
window.performSearch = performSearch;
window.handleImageError = handleImageError;

// 페이지 로드 완료 후 추가 초기화
document.addEventListener('DOMContentLoaded', afterInit);

console.log('🎨 PhotoPage.js 로드 완료 - 모든 기능이 활성화되었습니다! 🚀');

// ===== 성능 모니터링 (개발용) =====
if (console && console.time) {
    console.time('PhotoPage 초기화 시간');
    
    window.addEventListener('load', function() {
        console.timeEnd('PhotoPage 초기화 시간');
        console.log('📊 성능 정보:', {
            이미지수: document.querySelectorAll('.photo-thumbnail img').length,
            카드수: document.querySelectorAll('.photo-card').length,
            뷰모드: currentView,
            현재페이지: window.pageInfo ? window.pageInfo.currentPage : 'N/A'
        });
    });
}