/**
 * questionPage.js - 질문게시판 JavaScript 모듈 (완전한 버전)
 * 모든 UI 상호작용, 이벤트 처리, 유틸리티 기능을 담당
 */

(function() {
    'use strict';

    // ===== 전역 변수 =====
    let pageData = window.pageData || {
        currentPage: 1,
        totalPages: 1,
        searchType: '',
        keyword: '',
        contextPath: '',
        category: 'question'
    };
    
    let autoRefreshTimer = null;
    let searchTimeout = null;
    let isLoading = false;
    let clickedButtons = new Set();

    // ===== DOM 요소들 =====
    const elements = {};

    // ===== DOM이 로드된 후 실행 =====
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🚀 질문게시판 페이지 초기화 시작');
        
        try {
            initElements();
            initEventListeners();
            initKeyboardShortcuts();
            initAnimations();
            initAutoRefresh();
            showMessages();
            restoreScrollPosition();
            highlightSearchKeyword();
            addDynamicStyles();
            
            console.log('✅ 질문게시판 페이지 초기화 완료');
        } catch (error) {
            console.error('❌ 초기화 중 오류:', error);
        }
    });

    // ===== DOM 요소 초기화 =====
    function initElements() {
        elements.searchForm = document.querySelector('.search-form');
        elements.searchInput = document.querySelector('.search-input');
        elements.searchSelect = document.querySelector('.search-select');
        elements.searchBtn = document.querySelector('.search-btn');
        elements.writeButtons = document.querySelectorAll('.write-btn');
        elements.postLinks = document.querySelectorAll('.post-link');
        elements.pageButtons = document.querySelectorAll('.page-btn');
        elements.boardRows = document.querySelectorAll('.board-row');
        elements.boardWrapper = document.querySelector('.board-wrapper');
        elements.newBadges = document.querySelectorAll('.new-badge');
        elements.hotBadges = document.querySelectorAll('.hot-badge');
        elements.attachmentIcons = document.querySelectorAll('.attachment-icon');

        console.log('🔧 DOM 요소 초기화 완료:', {
            postCount: elements.postLinks.length,
            pageButtons: elements.pageButtons.length
        });
    }

    // ===== 이벤트 리스너 초기화 =====
    function initEventListeners() {
        // 검색 폼 이벤트
        if (elements.searchForm) {
            elements.searchForm.addEventListener('submit', handleSearchSubmit);
        }

        // 검색 입력 필드 이벤트
        if (elements.searchInput) {
            elements.searchInput.addEventListener('input', handleSearchInput);
            elements.searchInput.addEventListener('focus', handleSearchFocus);
            elements.searchInput.addEventListener('keypress', handleSearchKeypress);
        }

        // 게시글 링크 이벤트
        elements.postLinks.forEach(function(link) {
            link.addEventListener('click', handlePostClick);
            link.addEventListener('mouseenter', handlePostHover);
        });

        // 페이지네이션 이벤트
        elements.pageButtons.forEach(function(btn) {
            btn.addEventListener('click', handlePageClick);
        });

        // 글쓰기 버튼 이벤트
        elements.writeButtons.forEach(function(btn) {
            btn.addEventListener('click', handleWriteClick);
        });

        // 게시판 행 호버 이벤트
        elements.boardRows.forEach(function(row) {
            row.addEventListener('mouseenter', handleRowHover);
            row.addEventListener('mouseleave', handleRowLeave);
        });

        // 첨부파일 아이콘 이벤트
        elements.attachmentIcons.forEach(function(icon) {
            icon.addEventListener('mouseenter', handleAttachmentHover);
            icon.addEventListener('mouseleave', handleAttachmentLeave);
        });

        // 페이지 이벤트
        window.addEventListener('beforeunload', handlePageUnload);
        window.addEventListener('popstate', handlePopState);

        console.log('👂 이벤트 리스너 초기화 완료');
    }

    // ===== 검색 이벤트 처리 =====
    function handleSearchSubmit(e) {
        var keyword = elements.searchInput.value.trim();
        
        if (keyword.length === 0) {
            e.preventDefault();
            showToast('검색어를 입력해주세요.', 'warning');
            elements.searchInput.focus();
            return false;
        }
        
        if (keyword.length > 100) {
            e.preventDefault();
            showToast('검색어는 100자 이하로 입력해주세요.', 'warning');
            return false;
        }
        
        // 로딩 상태 표시
        setSearchLoading(true);
        saveScrollPosition();
        
        console.log('🔍 검색 실행:', keyword);
    }

    function handleSearchInput(e) {
        clearTimeout(searchTimeout);
        
        var keyword = e.target.value.trim();
        
        // 실시간 검색어 유효성 검사
        if (keyword.length > 100) {
            showToast('검색어는 100자 이하로 입력해주세요.', 'warning');
            e.target.value = keyword.substring(0, 100);
            return;
        }
        
        // 디바운싱 적용한 실시간 검색 (선택적)
        if (keyword.length >= 2) {
            searchTimeout = setTimeout(function() {
                console.log('💡 실시간 검색 제안:', keyword);
                // 향후 자동완성 기능 추가 가능
            }, 500);
        }
    }

    function handleSearchFocus(e) {
        e.target.select();
    }

    function handleSearchKeypress(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            elements.searchForm.dispatchEvent(new Event('submit'));
        }
    }

    function setSearchLoading(loading) {
        if (elements.searchBtn) {
            if (loading) {
                elements.searchBtn.disabled = true;
                elements.searchBtn.innerHTML = '<span class="btn-text">검색중...</span>';
            } else {
                elements.searchBtn.disabled = false;
                elements.searchBtn.innerHTML = '<span class="btn-text">검색</span>';
            }
        }
    }

    // ===== 게시글 이벤트 처리 =====
    function handlePostClick(e) {
        // 스크롤 위치 저장
        saveScrollPosition();
        
        var postId = e.currentTarget.getAttribute('data-post-id');
        console.log('📄 게시글 클릭:', postId);
    }

    function handlePostHover(e) {
        var title = e.currentTarget.querySelector('.post-title');
        if (title && title.scrollWidth > title.clientWidth) {
            // 제목이 잘린 경우 전체 제목을 툴팁으로 표시
            title.setAttribute('title', title.textContent);
        }
    }

    function handleRowHover(e) {
        e.currentTarget.style.transform = 'translateX(8px)';
        e.currentTarget.style.transition = 'transform 0.2s ease';
    }

    function handleRowLeave(e) {
        e.currentTarget.style.transform = 'translateX(0)';
    }

    // ===== 페이지네이션 이벤트 =====
    function handlePageClick(e) {
        if (e.currentTarget.classList.contains('current')) {
            e.preventDefault();
            return;
        }
        
        // 로딩 효과
        e.currentTarget.style.opacity = '0.7';
        var originalText = e.currentTarget.textContent;
        e.currentTarget.textContent = '⏳';
        
        // 스크롤 위치 저장
        saveScrollPosition();
        
        var page = e.currentTarget.getAttribute('data-page');
        console.log('📄 페이지 이동:', page);
    }

    // ===== 글쓰기 버튼 이벤트 =====
    function handleWriteClick(e) {
        var buttonId = e.currentTarget.getAttribute('data-button-id') || 'write-btn';
        
        // 더블클릭 방지
        if (clickedButtons.has(buttonId)) {
            e.preventDefault();
            return false;
        }
        
        clickedButtons.add(buttonId);
        setTimeout(function() {
            clickedButtons.delete(buttonId);
        }, 2000);
        
        console.log('❓ 질문하기 버튼 클릭');
    }

    // ===== 첨부파일 아이콘 이벤트 =====
    function handleAttachmentHover(e) {
        e.currentTarget.style.transform = 'scale(1.2)';
        e.currentTarget.style.transition = 'transform 0.2s ease';
    }

    function handleAttachmentLeave(e) {
        e.currentTarget.style.transform = 'scale(1)';
    }

    // ===== 키보드 단축키 =====
    function initKeyboardShortcuts() {
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + / : 검색 포커스
            if ((e.ctrlKey || e.metaKey) && e.key === '/') {
                e.preventDefault();
                if (elements.searchInput) {
                    elements.searchInput.focus();
                    elements.searchInput.select();
                }
            }
            
            // Ctrl/Cmd + Enter : 글쓰기
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                var writeBtn = document.querySelector('.write-btn');
                if (writeBtn) {
                    writeBtn.click();
                }
            }
            
            // F5 또는 Ctrl/Cmd + R : 새로고침
            if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && e.key === 'r')) {
                saveScrollPosition();
            }
        });
        
        console.log('⌨️ 키보드 단축키 초기화 완료');
    }

    // ===== 애니메이션 초기화 =====
    function initAnimations() {
        // 게시글 행 애니메이션
        var rows = document.querySelectorAll('.board-row');
        rows.forEach(function(row, index) {
            row.style.opacity = '0';
            row.style.transform = 'translateY(20px)';
            
            setTimeout(function() {
                row.style.transition = 'all 0.3s ease';
                row.style.opacity = '1';
                row.style.transform = 'translateY(0)';
            }, index * 50);
        });
        
        // 통계 카드 애니메이션
        var stats = document.querySelectorAll('.stats-item');
        stats.forEach(function(stat, index) {
            stat.style.opacity = '0';
            stat.style.transform = 'scale(0.9)';
            
            setTimeout(function() {
                stat.style.transition = 'all 0.4s ease';
                stat.style.opacity = '1';
                stat.style.transform = 'scale(1)';
            }, index * 100 + 200);
        });
        
        console.log('🎭 애니메이션 초기화 완료');
    }

    // ===== 자동 새로고침 =====
    function initAutoRefresh() {
        // 30분마다 자동 새로고침 (선택적)
        autoRefreshTimer = setInterval(function() {
            if (!isLoading && document.visibilityState === 'visible') {
                console.log('🔄 자동 새로고침 실행');
                showToast('새로운 질문을 확인하고 있습니다...', 'info');
                setTimeout(function() {
                    location.reload();
                }, 1000);
            }
        }, 30 * 60 * 1000); // 30분
        
        console.log('🔄 자동 새로고침 초기화 완료');
    }

    function stopAutoRefresh() {
        if (autoRefreshTimer) {
            clearInterval(autoRefreshTimer);
            autoRefreshTimer = null;
        }
    }

    // ===== 메시지 표시 =====
    function showMessages() {
        // 새 질문 알림 (예시)
        if (window.location.search.includes('new=1')) {
            showToast('새로운 질문이 등록되었습니다!', 'success');
        }
        
        // 검색 결과 메시지
        if (pageData.keyword) {
            var totalCount = pageData.totalCount || 0;
            showToast('"' + pageData.keyword + '" 검색 결과: ' + totalCount + '개', 'info');
        }
    }

    // ===== 토스트 메시지 =====
    function showToast(message, type) {
        type = type || 'info';
        
        // 기존 토스트 제거
        var existingToast = document.querySelector('.toast');
        if (existingToast) {
            existingToast.remove();
        }
        
        // 새 토스트 생성
        var toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.textContent = message;
        
        // 스타일 적용
        toast.style.cssText = 
            'position: fixed; top: 20px; right: 20px; z-index: 1000; ' +
            'background: #ff6b35; color: white; padding: 12px 20px; ' +
            'border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); ' +
            'font-weight: 500; max-width: 300px; word-wrap: break-word; ' +
            'transform: translateX(100%); transition: transform 0.3s ease;';
        
        // 타입별 색상
        if (type === 'success') {
            toast.style.background = '#28a745';
        } else if (type === 'warning') {
            toast.style.background = '#ffc107';
            toast.style.color = '#212529';
        } else if (type === 'error') {
            toast.style.background = '#dc3545';
        }
        
        document.body.appendChild(toast);
        
        // 애니메이션
        setTimeout(function() {
            toast.style.transform = 'translateX(0)';
        }, 100);
        
        // 자동 제거
        setTimeout(function() {
            if (toast.parentNode) {
                toast.style.transform = 'translateX(100%)';
                setTimeout(function() {
                    if (toast.parentNode) {
                        toast.remove();
                    }
                }, 300);
            }
        }, 3000);
    }

    // ===== 스크롤 위치 관리 =====
    function saveScrollPosition() {
        try {
            sessionStorage.setItem('questionPageScrollY', window.scrollY.toString());
        } catch (e) {
            console.warn('스크롤 위치 저장 실패:', e);
        }
    }

    function restoreScrollPosition() {
        try {
            var scrollY = sessionStorage.getItem('questionPageScrollY');
            if (scrollY) {
                setTimeout(function() {
                    window.scrollTo(0, parseInt(scrollY));
                    sessionStorage.removeItem('questionPageScrollY');
                }, 100);
            }
        } catch (e) {
            console.warn('스크롤 위치 복원 실패:', e);
        }
    }

    // ===== 검색 키워드 하이라이트 =====
    function highlightSearchKeyword() {
        if (!window.searchKeyword) {
            return;
        }
        
        var keyword = window.searchKeyword.trim();
        if (keyword.length === 0) {
            return;
        }
        
        var postTitles = document.querySelectorAll('.post-title');
        postTitles.forEach(function(title) {
            var text = title.textContent;
            var highlightedText = text.replace(
                new RegExp('(' + escapeRegExp(keyword) + ')', 'gi'),
                '<mark style="background: #ffe066; color: #333; padding: 1px 2px; border-radius: 2px;">$1</mark>'
            );
            
            if (highlightedText !== text) {
                title.innerHTML = highlightedText;
            }
        });
        
        console.log('🎯 검색 키워드 하이라이트 완료:', keyword);
    }

    // ===== 유틸리티 함수들 =====
    function getCurrentPage() {
        return pageData.currentPage || 1;
    }

    function navigateToPage(page) {
        var url = new URL(window.location);
        url.searchParams.set('page', page);
        window.location.href = url.toString();
    }

    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    // ===== 페이지 이벤트 =====
    function handlePageUnload() {
        stopAutoRefresh();
        
        // 진행 중인 요청들 정리
        if (searchTimeout) {
            clearTimeout(searchTimeout);
        }
    }

    function handlePopState() {
        // 뒤로가기 시 페이지 새로고침
        location.reload();
    }

    // ===== CSS 애니메이션 동적 추가 =====
    function addDynamicStyles() {
        if (document.getElementById('questionPage-dynamic-styles')) {
            return; // 이미 추가됨
        }
        
        var style = document.createElement('style');
        style.id = 'questionPage-dynamic-styles';
        style.textContent = 
            '@keyframes slideInRight {' +
                'from { transform: translateX(100%); opacity: 0; }' +
                'to { transform: translateX(0); opacity: 1; }' +
            '}' +
            '@keyframes slideOutRight {' +
                'from { transform: translateX(0); opacity: 1; }' +
                'to { transform: translateX(100%); opacity: 0; }' +
            '}' +
            '.new-question-notification .refresh-btn,' +
            '.new-question-notification .close-btn {' +
                'background: #1a1a1a;' +
                'color: white;' +
                'border: none;' +
                'padding: 4px 8px;' +
                'border-radius: 4px;' +
                'cursor: pointer;' +
                'font-size: 12px;' +
                'transition: background 0.2s ease;' +
            '}' +
            '.new-question-notification .refresh-btn:hover,' +
            '.new-question-notification .close-btn:hover {' +
                'background: #333;' +
            '}' +
            '.new-question-notification .close-btn {' +
                'width: 24px;' +
                'height: 24px;' +
                'border-radius: 50%;' +
                'display: flex;' +
                'align-items: center;' +
                'justify-content: center;' +
                'font-weight: bold;' +
            '}';
        
        document.head.appendChild(style);
    }

    // ===== 에러 처리 =====
    window.addEventListener('error', function(e) {
        console.error('JavaScript 에러:', e.error);
        showToast('페이지에 오류가 발생했습니다.', 'error');
    });

    // ===== 공개 API =====
    window.QuestionPage = {
        refreshPage: function() { 
            location.reload(); 
        },
        navigateToPage: navigateToPage,
        showToast: showToast,
        getCurrentPage: getCurrentPage,
        saveScrollPosition: saveScrollPosition,
        restoreScrollPosition: restoreScrollPosition
    };

    // ===== 최종 초기화 (페이지 로드 완료 후) =====
    window.addEventListener('load', function() {
        setTimeout(function() {
            // 페이지 로드 완료 이벤트 발생
            var loadEvent = new Event('questionPageLoaded');
            document.dispatchEvent(loadEvent);
            
            console.log('🎉 질문게시판 모든 기능 로드 완료');
        }, 100);
    });

})();