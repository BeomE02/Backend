// common.js - 모든 페이지에서 사용하는 공통 JavaScript 기능 (이메일 코드 완전 제거)

// 전역 변수
window.ClinkApp = {
    contextPath: '',
    currentUser: null,
    config: {
        debug: true,
        version: '1.0.0'
    }
};

// DOM 로드 완료 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * 애플리케이션 초기화
 */
function initializeApp() {
    console.log('Clink Application 초기화 시작');
    
    // 컨텍스트 패스 설정
    setContextPath();
    
    // 공통 이벤트 리스너 등록
    initCommonEventListeners();
    
    // 폼 검증 초기화
    initFormValidation();
    
    // 모달 초기화
    initModals();
    
    // 드롭다운 초기화
    initDropdowns();
    
    // 툴팁 초기화
    initTooltips();
    
    // 페이지 로딩 완료 로그
    console.log('Clink Application 초기화 완료');
}

/**
 * 컨텍스트 패스 설정
 */
function setContextPath() {
    const pathArray = window.location.pathname.split('/');
    ClinkApp.contextPath = '/' + pathArray[1];
}

/**
 * 공통 이벤트 리스너 등록
 */
function initCommonEventListeners() {
    // 모든 링크에 로딩 효과
    document.querySelectorAll('a[href]').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.href && !this.href.startsWith('#') && !this.target) {
                showLoading();
            }
        });
    });
    
    // 모든 폼 제출에 로딩 효과
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            showLoading();
        });
    });
    
    // ESC 키로 모달 닫기
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
}

/**
 * 폼 검증 초기화 (이메일 검증 제거)
 */
function initFormValidation() {
    // 필수 입력 필드 검증
    document.querySelectorAll('[required]').forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });
        
        field.addEventListener('input', function() {
            clearFieldError(this);
        });
    });
    
    // 특정 필드별 검증
    document.querySelectorAll('input[name="username"]').forEach(field => {
        field.addEventListener('blur', function() {
            validateUsername(this);
        });
    });
    
    document.querySelectorAll('input[name="name"]').forEach(field => {
        field.addEventListener('blur', function() {
            validateName(this);
        });
    });
    
    document.querySelectorAll('input[name="phone"]').forEach(field => {
        field.addEventListener('blur', function() {
            validatePhone(this);
        });
    });
    
    // 비밀번호 확인 검증
    const passwordFields = document.querySelectorAll('input[type="password"]');
    if (passwordFields.length >= 2) {
        passwordFields[1].addEventListener('input', function() {
            validatePasswordConfirm(passwordFields[0], this);
        });
    }
}

/**
 * 모달 초기화
 */
function initModals() {
    // 모달 열기 버튼
    document.querySelectorAll('[data-modal-target]').forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-modal-target');
            showModal(targetId);
        });
    });
    
    // 모달 닫기 버튼
    document.querySelectorAll('.modal-close').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal-overlay');
            hideModal(modal);
        });
    });
    
    // 모달 오버레이 클릭으로 닫기
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', function(e) {
            if (e.target === this) {
                hideModal(this);
            }
        });
    });
}

/**
 * 드롭다운 초기화
 */
function initDropdowns() {
    document.querySelectorAll('.dropdown').forEach(dropdown => {
        const button = dropdown.querySelector('.dropdown-toggle');
        const content = dropdown.querySelector('.dropdown-content');
        
        if (button && content) {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                toggleDropdown(dropdown);
            });
        }
    });
    
    // 외부 클릭 시 드롭다운 닫기
    document.addEventListener('click', function() {
        closeAllDropdowns();
    });
}

/**
 * 툴팁 초기화
 */
function initTooltips() {
    document.querySelectorAll('[data-tooltip]').forEach(element => {
        const tooltipText = element.getAttribute('data-tooltip');
        
        element.addEventListener('mouseenter', function() {
            showTooltip(this, tooltipText);
        });
        
        element.addEventListener('mouseleave', function() {
            hideTooltip(this);
        });
    });
}

/**
 * 로딩 스피너 표시
 */
function showLoading() {
    if (document.querySelector('.loading-overlay')) return;
    
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = `
        <div class="loading-spinner">
            <div class="spinner"></div>
            <p>로딩 중...</p>
        </div>
    `;
    
    // 스타일 추가
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        flex-direction: column;
    `;
    
    document.body.appendChild(overlay);
    
    // 3초 후 자동 제거 (비상용)
    setTimeout(() => {
        hideLoading();
    }, 3000);
}

/**
 * 로딩 스피너 숨기기
 */
function hideLoading() {
    const overlay = document.querySelector('.loading-overlay');
    if (overlay) {
        overlay.remove();
    }
}

/**
 * 모달 표시
 */
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

/**
 * 모달 숨기기
 */
function hideModal(modal) {
    if (typeof modal === 'string') {
        modal = document.getElementById(modal);
    }
    
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

/**
 * 모든 모달 닫기
 */
function closeAllModals() {
    document.querySelectorAll('.modal-overlay.show').forEach(modal => {
        hideModal(modal);
    });
}

/**
 * 드롭다운 토글
 */
function toggleDropdown(dropdown) {
    const content = dropdown.querySelector('.dropdown-content');
    const isOpen = content.style.display === 'block';
    
    closeAllDropdowns();
    
    if (!isOpen) {
        content.style.display = 'block';
    }
}

/**
 * 모든 드롭다운 닫기
 */
function closeAllDropdowns() {
    document.querySelectorAll('.dropdown-content').forEach(content => {
        content.style.display = 'none';
    });
}

/**
 * 툴팁 표시
 */
function showTooltip(element, text) {
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip-popup';
    tooltip.textContent = text;
    tooltip.style.cssText = `
        position: absolute;
        background: #333;
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 1000;
        pointer-events: none;
        white-space: nowrap;
    `;
    
    document.body.appendChild(tooltip);
    
    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
    
    element._tooltip = tooltip;
}

/**
 * 툴팁 숨기기
 */
function hideTooltip(element) {
    if (element._tooltip) {
        element._tooltip.remove();
        delete element._tooltip;
    }
}

/**
 * 필드 검증 (일반)
 */
function validateField(field) {
    const value = field.value.trim();
    
    if (field.hasAttribute('required') && !value) {
        showFieldError(field, '이 필드는 필수입니다.');
        return false;
    }
    
    // 필드별 특별 검증
    const fieldName = field.name || field.id;
    switch (fieldName) {
        case 'username':
            return validateUsername(field);
        case 'name':
            return validateName(field);
        case 'phone':
            return validatePhone(field);
        default:
            clearFieldError(field);
            return true;
    }
}

/**
 * 아이디 검증
 */
function validateUsername(field) {
    const username = field.value.trim();
    
    if (!username) {
        if (field.hasAttribute('required')) {
            showFieldError(field, '아이디를 입력해주세요.');
            return false;
        }
        clearFieldError(field);
        return true;
    }
    
    // 아이디 형식 검증 (영문자, 숫자만 허용, 3-20자)
    const usernameRegex = /^[a-zA-Z0-9]{3,20}$/;
    
    if (!usernameRegex.test(username)) {
        showFieldError(field, '아이디는 영문자와 숫자 조합으로 3-20자여야 합니다.');
        return false;
    }
    
    clearFieldError(field);
    return true;
}

/**
 * 이름 검증
 */
function validateName(field) {
    const name = field.value.trim();
    
    if (!name) {
        if (field.hasAttribute('required')) {
            showFieldError(field, '이름을 입력해주세요.');
            return false;
        }
        clearFieldError(field);
        return true;
    }
    
    // 이름 형식 검증 (한글, 영문만 허용, 2-20자)
    const nameRegex = /^[가-힣a-zA-Z\s]{2,20}$/;
    
    if (!nameRegex.test(name)) {
        showFieldError(field, '이름은 한글 또는 영문으로 2-20자여야 합니다.');
        return false;
    }
    
    clearFieldError(field);
    return true;
}

/**
 * 전화번호 검증 (선택사항)
 */
function validatePhone(field) {
    const phone = field.value.trim();
    
    if (!phone) {
        clearFieldError(field);
        return true; // 전화번호는 선택사항
    }
    
    // 전화번호 형식 검증
    const phoneRegex = /^[0-9-+\s()]{10,20}$/;
    
    if (!phoneRegex.test(phone)) {
        showFieldError(field, '올바른 전화번호 형식을 입력하세요.');
        return false;
    }
    
    clearFieldError(field);
    return true;
}

/**
 * 비밀번호 확인 검증
 */
function validatePasswordConfirm(passwordField, confirmField) {
    if (passwordField.value !== confirmField.value) {
        showFieldError(confirmField, '비밀번호가 일치하지 않습니다.');
        return false;
    }
    
    clearFieldError(confirmField);
    return true;
}

/**
 * 필드 에러 표시
 */
function showFieldError(field, message) {
    clearFieldError(field);
    
    field.classList.add('error');
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
        color: #ef4444;
        font-size: 12px;
        margin-top: 4px;
    `;
    
    field.parentNode.appendChild(errorDiv);
}

/**
 * 필드 에러 제거
 */
function clearFieldError(field) {
    field.classList.remove('error');
    
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

/**
 * 알림 메시지 표시
 */
function showAlert(message, type = 'info', duration = 3000) {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} fade-in`;
    alert.textContent = message;
    
    // 타입별 스타일 설정
    let backgroundColor, textColor, borderColor;
    switch (type) {
        case 'error':
            backgroundColor = '#fef2f2';
            textColor = '#dc2626';
            borderColor = '#dc2626';
            break;
        case 'success':
            backgroundColor = '#f0fdf4';
            textColor = '#16a34a';
            borderColor = '#16a34a';
            break;
        case 'warning':
            backgroundColor = '#fffbeb';
            textColor = '#d97706';
            borderColor = '#d97706';
            break;
        default:
            backgroundColor = '#f8fafc';
            textColor = '#475569';
            borderColor = '#3b82f6';
    }
    
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        max-width: 300px;
        padding: 12px 16px;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        background: ${backgroundColor};
        color: ${textColor};
        border-left: 4px solid ${borderColor};
        font-size: 14px;
        line-height: 1.4;
    `;
    
    document.body.appendChild(alert);
    
    // 자동 제거
    setTimeout(() => {
        alert.classList.add('fade-out');
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 300);
    }, duration);
    
    return alert;
}

/**
 * 확인 다이얼로그
 */
function confirmDialog(message, callback) {
    if (confirm(message)) {
        if (typeof callback === 'function') {
            callback();
        }
        return true;
    }
    return false;
}

/**
 * AJAX 요청 헬퍼
 */
function ajaxRequest(url, options = {}) {
    const defaultOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    };
    
    const config = { ...defaultOptions, ...options };
    
    return fetch(url, config)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            console.error('AJAX 요청 실패:', error);
            showAlert('요청 처리 중 오류가 발생했습니다.', 'error');
            throw error;
        });
}

/**
 * 디바운스 함수
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * 쓰로틀 함수
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * 유틸리티: 문자열이 비어있는지 확인
 */
function isEmpty(str) {
    return !str || str.trim().length === 0;
}

/**
 * 유틸리티: 전화번호 포맷팅
 */
function formatPhoneNumber(phone) {
    if (!phone) return '';
    
    // 숫자만 추출
    const numbers = phone.replace(/\D/g, '');
    
    // 한국 전화번호 형식으로 포맷팅
    if (numbers.length === 11) {
        return numbers.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
    } else if (numbers.length === 10) {
        return numbers.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
    } else if (numbers.length === 8) {
        return numbers.replace(/(\d{4})(\d{4})/, '$1-$2');
    }
    
    return phone;
}

/**
 * 유틸리티: 날짜 포맷팅
 */
function formatDate(date, format = 'YYYY-MM-DD') {
    if (!date) return '';
    
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    
    switch (format) {
        case 'YYYY-MM-DD':
            return `${year}-${month}-${day}`;
        case 'YYYY-MM-DD HH:mm':
            return `${year}-${month}-${day} ${hours}:${minutes}`;
        case 'MM/DD':
            return `${month}/${day}`;
        default:
            return `${year}-${month}-${day}`;
    }
}

/**
 * 유틸리티: 파일 크기 포맷팅
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * 브라우저 호환성 검사
 */
function checkBrowserCompatibility() {
    // 필수 기능 확인
    const features = {
        fetch: typeof fetch !== 'undefined',
        localStorage: typeof Storage !== 'undefined',
        formData: typeof FormData !== 'undefined'
    };
    
    const unsupported = Object.keys(features).filter(key => !features[key]);
    
    if (unsupported.length > 0) {
        console.warn('지원되지 않는 브라우저 기능:', unsupported);
        showAlert('일부 기능이 제한될 수 있습니다. 최신 브라우저를 사용해주세요.', 'warning');
    }
}

/**
 * 페이지 언로드 시 정리
 */
window.addEventListener('beforeunload', function() {
    hideLoading();
    closeAllModals();
    closeAllDropdowns();
});

// 브라우저 호환성 검사 실행
checkBrowserCompatibility();

// 전역 함수로 노출
window.ClinkApp.showLoading = showLoading;
window.ClinkApp.hideLoading = hideLoading;
window.ClinkApp.showAlert = showAlert;
window.ClinkApp.confirmDialog = confirmDialog;
window.ClinkApp.ajaxRequest = ajaxRequest;
window.ClinkApp.debounce = debounce;
window.ClinkApp.throttle = throttle;
window.ClinkApp.formatPhoneNumber = formatPhoneNumber;
window.ClinkApp.formatDate = formatDate;
window.ClinkApp.formatFileSize = formatFileSize;