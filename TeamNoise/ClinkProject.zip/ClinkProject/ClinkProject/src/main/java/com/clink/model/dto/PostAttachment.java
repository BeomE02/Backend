package com.clink.model.dto;

import java.sql.Timestamp;

/**
 * 게시글 첨부파일 정보를 담는 DTO 클래스 (attachments 테이블 완전 호환)
 */
public class PostAttachment {
    // 데이터베이스 스키마와 정확히 매핑
    private int attachmentId;           // attachment_id (Primary Key)
    private Integer postId;             // post_id (Foreign Key, nullable)
    private String originalFilename;    // original_filename ✅ 수정
    private String storedFilename;      // stored_filename ✅ 수정  
    private String filePath;            // file_path
    private long fileSize;              // file_size (BIGINT)
    private String fileType;            // file_type
    private String mimeType;            // mime_type ✅ 추가
    private int downloadCount;          // download_count ✅ 추가
    private Timestamp uploadedAt;       // uploaded_at
    
    // 기본 생성자
    public PostAttachment() {
        this.downloadCount = 0;
    }
    
    // 파일 업로드용 생성자
    public PostAttachment(Integer postId, String originalFilename, String storedFilename, 
                         String filePath, long fileSize, String fileType, String mimeType) {
        this();
        this.postId = postId;
        this.originalFilename = originalFilename;
        this.storedFilename = storedFilename;
        this.filePath = filePath;
        this.fileSize = fileSize;
        this.fileType = fileType;
        this.mimeType = mimeType;
        this.uploadedAt = new Timestamp(System.currentTimeMillis());
    }
    
    // ===== Getter and Setter methods =====
    
    public int getAttachmentId() { 
        return attachmentId; 
    }
    
    public void setAttachmentId(int attachmentId) { 
        this.attachmentId = attachmentId; 
    }
    
    // JSP 호환성을 위한 id getter/setter
    public int getId() {
        return attachmentId;
    }
    
    public void setId(int id) {
        this.attachmentId = id;
    }
    
    public Integer getPostId() { 
        return postId; 
    }
    
    public void setPostId(Integer postId) { 
        this.postId = postId; 
    }
    
    public String getOriginalFilename() { 
        return originalFilename; 
    }
    
    public void setOriginalFilename(String originalFilename) { 
        this.originalFilename = originalFilename; 
    }
    
    // 기존 코드 호환성을 위한 별칭 메서드
    public String getOriginalName() {
        return originalFilename;
    }
    
    public void setOriginalName(String originalName) {
        this.originalFilename = originalName;
    }
    
    public String getStoredFilename() { 
        return storedFilename; 
    }
    
    public void setStoredFilename(String storedFilename) { 
        this.storedFilename = storedFilename; 
    }
    
    // 기존 코드 호환성을 위한 별칭 메서드
    public String getSavedName() {
        return storedFilename;
    }
    
    public void setSavedName(String savedName) {
        this.storedFilename = savedName;
    }
    
    public String getFilePath() { 
        return filePath; 
    }
    
    public void setFilePath(String filePath) { 
        this.filePath = filePath; 
    }
    
    public long getFileSize() { 
        return fileSize; 
    }
    
    public void setFileSize(long fileSize) { 
        this.fileSize = fileSize; 
    }
    
    public String getFileType() { 
        return fileType; 
    }
    
    public void setFileType(String fileType) { 
        this.fileType = fileType; 
    }
    
    public String getMimeType() { 
        return mimeType; 
    }
    
    public void setMimeType(String mimeType) { 
        this.mimeType = mimeType; 
    }
    
    public int getDownloadCount() { 
        return downloadCount; 
    }
    
    public void setDownloadCount(int downloadCount) { 
        this.downloadCount = downloadCount; 
    }
    
    public Timestamp getUploadedAt() { 
        return uploadedAt; 
    }
    
    public void setUploadedAt(Timestamp uploadedAt) { 
        this.uploadedAt = uploadedAt; 
    }
    
    // ===== 유틸리티 메서드들 =====
    
    /**
     * 파일 크기를 사람이 읽기 쉬운 형태로 반환
     */
    public String getFormattedFileSize() {
        if (fileSize == 0) return "0 Bytes";
        
        final String[] units = {"Bytes", "KB", "MB", "GB"};
        int unitIndex = 0;
        double size = fileSize;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return String.format("%.1f %s", size, units[unitIndex]);
    }
    
    /**
     * 파일 확장자 반환
     */
    public String getFileExtension() {
        if (originalFilename == null) return "";
        
        int lastDotIndex = originalFilename.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < originalFilename.length() - 1) {
            return originalFilename.substring(lastDotIndex + 1).toLowerCase();
        }
        
        return "";
    }
    
    /**
     * 이미지 파일인지 확인
     */
    public boolean isImageFile() {
        String extension = getFileExtension();
        return "jpg".equals(extension) || "jpeg".equals(extension) || 
               "png".equals(extension) || "gif".equals(extension) ||
               "bmp".equals(extension) || "webp".equals(extension);
    }
    
    /**
     * 비디오 파일인지 확인
     */
    public boolean isVideoFile() {
        String extension = getFileExtension();
        return "mp4".equals(extension) || "avi".equals(extension) || 
               "mov".equals(extension) || "wmv".equals(extension) ||
               "flv".equals(extension) || "webm".equals(extension);
    }
    
    /**
     * 오디오 파일인지 확인
     */
    public boolean isAudioFile() {
        String extension = getFileExtension();
        return "mp3".equals(extension) || "wav".equals(extension) || 
               "aac".equals(extension) || "ogg".equals(extension) ||
               "flac".equals(extension) || "m4a".equals(extension);
    }
    
    /**
     * 문서 파일인지 확인
     */
    public boolean isDocumentFile() {
        String extension = getFileExtension();
        return "pdf".equals(extension) || "doc".equals(extension) || 
               "docx".equals(extension) || "xls".equals(extension) ||
               "xlsx".equals(extension) || "ppt".equals(extension) ||
               "pptx".equals(extension) || "txt".equals(extension);
    }
    
    /**
     * 압축 파일인지 확인
     */
    public boolean isArchiveFile() {
        String extension = getFileExtension();
        return "zip".equals(extension) || "rar".equals(extension) || 
               "7z".equals(extension) || "tar".equals(extension) ||
               "gz".equals(extension) || "bz2".equals(extension);
    }
    
    /**
     * 파일 타입별 아이콘 클래스 반환 (CSS용)
     */
    public String getIconClass() {
        if (isImageFile()) return "file-icon-image";
        if (isVideoFile()) return "file-icon-video";
        if (isAudioFile()) return "file-icon-audio";
        if (isDocumentFile()) return "file-icon-document";
        if (isArchiveFile()) return "file-icon-archive";
        return "file-icon-default";
    }
    
    /**
     * 다운로드 수 증가
     */
    public void incrementDownloadCount() {
        this.downloadCount++;
    }
    
    /**
     * 파일 유효성 검증
     */
    public boolean isValid() {
        if (originalFilename == null || originalFilename.trim().isEmpty()) return false;
        if (storedFilename == null || storedFilename.trim().isEmpty()) return false;
        if (filePath == null || filePath.trim().isEmpty()) return false;
        if (fileSize <= 0) return false;
        return true;
    }
    
    /**
     * 파일이 게시글에 속해있는지 확인
     */
    public boolean belongsToPost() {
        return postId != null && postId > 0;
    }
    
    /**
     * 파일명이 안전한지 확인 (보안용)
     */
    public boolean hasSecureFilename() {
        if (originalFilename == null) return false;
        
        // 위험한 문자 체크
        String dangerous = originalFilename.toLowerCase();
        return !dangerous.contains("../") && 
               !dangerous.contains("..\\") &&
               !dangerous.contains("<script") &&
               !dangerous.contains("<?php");
    }
    
    @Override
    public String toString() {
        return "PostAttachment{" +
                "attachmentId=" + attachmentId +
                ", postId=" + postId +
                ", originalFilename='" + originalFilename + '\'' +
                ", storedFilename='" + storedFilename + '\'' +
                ", fileSize=" + fileSize +
                ", fileType='" + fileType + '\'' +
                ", mimeType='" + mimeType + '\'' +
                ", downloadCount=" + downloadCount +
                ", uploadedAt=" + uploadedAt +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        PostAttachment that = (PostAttachment) obj;
        return attachmentId == that.attachmentId;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(attachmentId);
    }
}