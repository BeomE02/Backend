package com.clink.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.clink.model.dao.DataBoardDAO;
import com.clink.model.dao.BoardDAO;
import com.clink.model.dao.FileDAO;
import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;
import com.clink.model.dto.FileInfo;

/**
 * 자료게시판 서비스
 * - 파일 중심 게시판 비즈니스 로직
 * - 다운로드 통계 및 파일 관리
 * - 다양한 파일 형식 지원
 */
public class DataBoardService {
    
    private DataBoardDAO dataBoardDAO;
    private BoardDAO boardDAO;
    private FileDAO fileDAO;
    
    public DataBoardService() {
        this.dataBoardDAO = new DataBoardDAO();
        this.boardDAO = new BoardDAO();
        this.fileDAO = new FileDAO();
    }
    
    /**
     * 자료게시판 게시글 목록 조회 (페이징)
     * @param classId 수업 ID
     * @param page 페이지 번호
     * @param size 페이지당 게시글 수
     * @param searchType 검색 타입
     * @param keyword 검색 키워드
     * @return 페이징된 게시글 목록과 페이지 정보
     */
    public Map<String, Object> getDataPostList(Integer classId, int page, int size, String searchType, String keyword) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (page < 1) page = 1;
            if (size < 1 || size > 100) size = 15; // 자료게시판은 15개씩 표시
            
            // 검색 타입 검증
            if (searchType == null || 
                (!searchType.equals("title") && !searchType.equals("content") && 
                 !searchType.equals("author") && !searchType.equals("filename") && !searchType.equals("all"))) {
                searchType = "all";
            }
            
            // 게시글 목록 조회
            List<Post> posts = dataBoardDAO.getDataPostList(classId, page, size, searchType, keyword);
            
            // 전체 게시글 수 조회
            int totalCount = dataBoardDAO.getTotalDataPostCount(classId, searchType, keyword);
            
            // 페이지 정보 계산
            int totalPages = (int) Math.ceil((double) totalCount / size);
            boolean hasNext = page < totalPages;
            boolean hasPrevious = page > 1;
            
            // 각 게시글에 대한 첨부파일 정보 추가
            for (Post post : posts) {
                List<FileInfo> attachments = dataBoardDAO.getDataAttachments(post.getPostId());
                post.setAttachments(attachments);
                
                // 파일 형식별 분류
                post.setDocumentAttachments(attachments.stream()
                    .filter(file -> isDocumentFile(file.getFileType()))
                    .toList());
                
                post.setImageAttachments(attachments.stream()
                    .filter(file -> file.getFileType() != null && file.getFileType().startsWith("image/"))
                    .toList());
                
                post.setOtherAttachments(attachments.stream()
                    .filter(file -> !isDocumentFile(file.getFileType()) && 
                                   (file.getFileType() == null || !file.getFileType().startsWith("image/")))
                    .toList());
            }
            
            result.put("success", true);
            result.put("posts", posts);
            result.put("currentPage", page);
            result.put("totalPages", totalPages);
            result.put("totalCount", totalCount);
            result.put("hasNext", hasNext);
            result.put("hasPrevious", hasPrevious);
            result.put("size", size);
            
        } catch (Exception e) {
            System.err.println("자료게시판 목록 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 목록을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 자료게시글 상세 조회
     * @param postId 게시글 ID
     * @param userId 현재 사용자 ID (조회수 증가 제어용)
     * @return 게시글 상세 정보
     */
    public Map<String, Object> getDataPostDetail(int postId, Integer userId) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 게시글 정보 조회
            Post post = dataBoardDAO.getDataPostById(postId);
            
            if (post == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 조회수 증가 (본인 글이 아닌 경우에만)
            if (userId == null || !userId.equals(post.getAuthorId())) {
                dataBoardDAO.increaseViewCount(postId);
                post.setViewCount(post.getViewCount() + 1);
            }
            
            // 첨부파일 목록 조회
            List<FileInfo> attachments = dataBoardDAO.getDataAttachments(postId);
            post.setAttachments(attachments);
            
            // 파일 형식별 분류
            post.setDocumentAttachments(attachments.stream()
                .filter(file -> isDocumentFile(file.getFileType()))
                .toList());
            
            post.setImageAttachments(attachments.stream()
                .filter(file -> file.getFileType() != null && file.getFileType().startsWith("image/"))
                .toList());
            
            post.setOtherAttachments(attachments.stream()
                .filter(file -> !isDocumentFile(file.getFileType()) && 
                               (file.getFileType() == null || !file.getFileType().startsWith("image/")))
                .toList());
            
            // 댓글 목록 조회
            List<Comment> comments = boardDAO.getCommentsByPostId(postId);
            
            result.put("success", true);
            result.put("post", post);
            result.put("comments", comments);
            
        } catch (Exception e) {
            System.err.println("자료게시글 상세 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 자료게시글 작성
     * @param post 게시글 정보
     * @return 작성 결과
     */
    public Map<String, Object> createDataPost(Post post) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (post.getTitle() == null || post.getTitle().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "제목을 입력해주세요.");
                return result;
            }
            
            if (post.getContent() == null || post.getContent().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "내용을 입력해주세요.");
                return result;
            }
            
            if (post.getClassId() == null || post.getAuthorId() == null) {
                result.put("success", false);
                result.put("message", "필수 정보가 누락되었습니다.");
                return result;
            }
            
            // 제목과 내용 길이 검증
            if (post.getTitle().length() > 500) {
                result.put("success", false);
                result.put("message", "제목은 500자 이하로 입력해주세요.");
                return result;
            }
            
            if (post.getContent().length() > 10000) {
                result.put("success", false);
                result.put("message", "내용은 10,000자 이하로 입력해주세요.");
                return result;
            }
            
            // 게시글 작성
            int postId = dataBoardDAO.insertDataPost(post);
            
            if (postId > 0) {
                result.put("success", true);
                result.put("message", "자료게시글이 성공적으로 작성되었습니다.");
                result.put("postId", postId);
            } else {
                result.put("success", false);
                result.put("message", "게시글 작성에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("자료게시글 작성 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 작성 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 자료게시글 수정
     * @param post 수정할 게시글 정보
     * @return 수정 결과
     */
    public Map<String, Object> updateDataPost(Post post) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (post.getPostId() == null || post.getAuthorId() == null) {
                result.put("success", false);
                result.put("message", "필수 정보가 누락되었습니다.");
                return result;
            }
            
            if (post.getTitle() == null || post.getTitle().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "제목을 입력해주세요.");
                return result;
            }
            
            if (post.getContent() == null || post.getContent().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "내용을 입력해주세요.");
                return result;
            }
            
            // 기존 게시글 존재 여부 확인
            Post existingPost = dataBoardDAO.getDataPostById(post.getPostId());
            if (existingPost == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 작성자 권한 확인
            if (!existingPost.getAuthorId().equals(post.getAuthorId())) {
                result.put("success", false);
                result.put("message", "게시글을 수정할 권한이 없습니다.");
                return result;
            }
            
            // 게시글 수정
            boolean success = dataBoardDAO.updateDataPost(post);
            
            if (success) {
                result.put("success", true);
                result.put("message", "게시글이 성공적으로 수정되었습니다.");
            } else {
                result.put("success", false);
                result.put("message", "게시글 수정에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("자료게시글 수정 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 수정 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 자료게시글 삭제
     * @param postId 게시글 ID
     * @param userId 사용자 ID
     * @return 삭제 결과
     */
    public Map<String, Object> deleteDataPost(int postId, int userId) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 기존 게시글 존재 여부 확인
            Post existingPost = dataBoardDAO.getDataPostById(postId);
            if (existingPost == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 작성자 권한 확인
            if (!existingPost.getAuthorId().equals(userId)) {
                result.put("success", false);
                result.put("message", "게시글을 삭제할 권한이 없습니다.");
                return result;
            }
            
            // 게시글 삭제 (소프트 삭제)
            boolean success = dataBoardDAO.deleteDataPost(postId, userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "게시글이 성공적으로 삭제되었습니다.");
            } else {
                result.put("success", false);
                result.put("message", "게시글 삭제에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("자료게시글 삭제 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 삭제 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 댓글 작성
     * @param comment 댓글 정보
     * @return 작성 결과
     */
    public Map<String, Object> createComment(Comment comment) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (comment.getContent() == null || comment.getContent().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "댓글 내용을 입력해주세요.");
                return result;
            }
            
            if (comment.getPostId() == null || comment.getAuthorId() == null) {
                result.put("success", false);
                result.put("message", "필수 정보가 누락되었습니다.");
                return result;
            }
            
            // 게시글 존재 여부 확인
            Post post = dataBoardDAO.getDataPostById(comment.getPostId());
            if (post == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 댓글 작성
            int commentId = boardDAO.insertComment(comment);
            
            if (commentId > 0) {
                result.put("success", true);
                result.put("message", "댓글이 성공적으로 작성되었습니다.");
                result.put("commentId", commentId);
            } else {
                result.put("success", false);
                result.put("message", "댓글 작성에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("댓글 작성 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "댓글 작성 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 인기 자료게시글 조회
     * @param classId 수업 ID
     * @param limit 조회할 게시글 수
     * @return 인기 게시글 목록
     */
    public Map<String, Object> getPopularDataPosts(Integer classId, int limit) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            if (limit < 1 || limit > 20) limit = 5;
            
            List<Post> posts = dataBoardDAO.getPopularDataPosts(classId, limit);
            
            // 각 게시글에 대한 첨부파일 정보 추가
            for (Post post : posts) {
                List<FileInfo> attachments = dataBoardDAO.getDataAttachments(post.getPostId());
                post.setAttachments(attachments);
                
                // 파일 형식별 분류
                post.setDocumentAttachments(attachments.stream()
                    .filter(file -> isDocumentFile(file.getFileType()))
                    .toList());
            }
            
            result.put("success", true);
            result.put("posts", posts);
            
        } catch (Exception e) {
            System.err.println("인기 자료게시글 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "인기 게시글을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 인기 파일 조회
     * @param classId 수업 ID
     * @param limit 조회할 파일 수
     * @return 인기 파일 목록
     */
    public Map<String, Object> getPopularFiles(Integer classId, int limit) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            if (limit < 1 || limit > 50) limit = 10;
            
            List<FileInfo> files = dataBoardDAO.getPopularFiles(classId, limit);
            
            result.put("success", true);
            result.put("files", files);
            
        } catch (Exception e) {
            System.err.println("인기 파일 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "인기 파일을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 파일 검증
     * @param fileInfo 파일 정보
     * @return 검증 결과
     */
    public Map<String, Object> validateFile(FileInfo fileInfo) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 파일 크기 검증 (100MB 제한)
            long maxSize = 100 * 1024 * 1024; // 100MB
            if (fileInfo.getFileSize() > maxSize) {
                result.put("success", false);
                result.put("message", "파일 크기는 100MB 이하여야 합니다.");
                return result;
            }
            
            // 위험한 파일 확장자 검증
            String filename = fileInfo.getOriginalFilename().toLowerCase();
            String[] dangerousExtensions = {".exe", ".bat", ".cmd", ".scr", ".vbs", ".js", ".jar"};
            
            for (String ext : dangerousExtensions) {
                if (filename.endsWith(ext)) {
                    result.put("success", false);
                    result.put("message", "보안상 위험한 파일 형식은 업로드할 수 없습니다.");
                    return result;
                }
            }
            
            result.put("success", true);
            result.put("message", "유효한 파일입니다.");
            
        } catch (Exception e) {
            System.err.println("파일 검증 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "파일 검증 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 파일이 문서 파일인지 확인
     * @param mimeType MIME 타입
     * @return 문서 파일 여부
     */
    private boolean isDocumentFile(String mimeType) {
        if (mimeType == null) return false;
        
        return mimeType.startsWith("application/pdf") ||
               mimeType.startsWith("application/msword") ||
               mimeType.startsWith("application/vnd.openxmlformats-officedocument") ||
               mimeType.startsWith("application/vnd.ms-excel") ||
               mimeType.startsWith("application/vnd.ms-powerpoint") ||
               mimeType.startsWith("text/plain") ||
               mimeType.startsWith("application/rtf");
    }
    
    /**
     * 파일 크기를 사람이 읽기 쉬운 형태로 변환
     * @param bytes 바이트 크기
     * @return 변환된 문자열
     */
    public String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }
    
    /**
     * DataBoardDAO 메서드들을 직접 호출하는 헬퍼 메서드들
     * (BoardController에서 직접 사용)
     */
    
    public List<Post> getDataPostList(Integer classId, int page, int size, String searchType, String keyword) {
        return dataBoardDAO.getDataPostList(classId, page, size, searchType, keyword);
    }
    
    public int getDataPostCount(Integer classId, String searchType, String keyword) {
        return dataBoardDAO.getTotalDataPostCount(classId, searchType, keyword);
    }
    
    public Post getDataPostById(int postId) {
        return dataBoardDAO.getDataPostById(postId);
    }
    
    public boolean increaseDataViewCount(int postId) {
        return dataBoardDAO.increaseViewCount(postId);
    }
    
    public int insertDataPost(Post post) {
        return dataBoardDAO.insertDataPost(post);
    }
    
    public boolean updateDataPost(Post post) {
        return dataBoardDAO.updateDataPost(post);
    }
    
    public boolean deleteDataPost(int postId, int authorId) {
        return dataBoardDAO.deleteDataPost(postId, authorId);
    }
}