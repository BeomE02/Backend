package com.clink.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.dao.ClassDAO;
import com.clink.model.service.ClassService;
import com.clink.model.dto.User;

/**
 * 수업 전용 컨트롤러 (입장, 참여, 통계, 아카이브 로직 처리)
 */
//@WebServlet(urlPatterns = {"/class/*"})
public class ClassController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private ClassDAO classDAO;
    private ClassService classService;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            classDAO = new ClassDAO();
            classService = new ClassService();
            System.out.println("ClassController 초기화 완료");
        } catch (Exception e) {
            System.err.println("ClassController 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("ClassController 초기화 실패", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * 수업 관련 요청 처리
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 인코딩 설정
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        // 요청 경로 분석
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String pathInfo = uri.substring(contextPath.length());
        
        // /class/enterRoom.do → /enterRoom.do 추출
        String command = pathInfo.substring(6); // "/class" 제거
        
        System.out.println("ClassController 처리: " + command);

        try {
            // 로그인 체크
            if (!checkLogin(request)) {
                if ("POST".equals(request.getMethod())) {
                    sendJsonResponse(response, false, "로그인이 필요합니다.", null);
                } else {
                    request.setAttribute("errorMessage", "로그인이 필요합니다.");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/login.jsp");
                    dispatcher.forward(request, response);
                }
                return;
            }
            
            if ("POST".equals(request.getMethod())) {
                handlePostRequest(request, response, command);
            } else {
                handleGetRequest(request, response, command);
            }
        } catch (Exception e) {
            System.err.println("ClassController 요청 처리 중 오류: " + e.getMessage());
            e.printStackTrace();
            if ("POST".equals(request.getMethod())) {
                sendJsonResponse(response, false, "수업 요청 처리 중 오류가 발생했습니다.", null);
            } else {
                handleError(request, response, "수업 요청 처리 중 오류가 발생했습니다.");
            }
        }
    }

    /**
     * GET 요청 처리
     */
    private void handleGetRequest(HttpServletRequest request, HttpServletResponse response, String command)
            throws ServletException, IOException {
        
        String viewPage = "";

        switch (command) {
            case "/enterRoom.do":
                viewPage = handleEnterRoom(request);
                break;
            case "/enterClass.do":
                viewPage = handleEnterClass(request);
                break;
            case "/classJoin.do":
                viewPage = handleClassJoin(request);
                break;
            case "/classStatistics.do":
                viewPage = handleClassStatistics(request);
                break;
            case "/classArchive.do":
                viewPage = handleClassArchive(request);
                break;
                
            default:
                System.out.println("알 수 없는 GET 요청: " + command + " -> 수업 입장으로 이동");
                viewPage = handleEnterRoom(request);
                break;
        }

        // JSP로 포워딩
        if (viewPage != null && !viewPage.isEmpty()) {
            RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
            dispatcher.forward(request, response);
        }
    }

    /**
     * POST 요청 처리
     */
    private void handlePostRequest(HttpServletRequest request, HttpServletResponse response, String command)
            throws ServletException, IOException {
        
        switch (command) {
            case "/enterRoom.do":
                handleEnterRoomSubmit(request, response);
                break;
            case "/enterClass.do":
                handleEnterClassSubmit(request, response);
                break;
            case "/classJoin.do":
                handleClassJoinSubmit(request, response);
                break;
            case "/classStatistics.do":
                handleClassStatisticsSubmit(request, response);
                break;
            case "/classArchive.do":
                handleClassArchiveSubmit(request, response);
                break;
                
            default:
                sendJsonResponse(response, false, "지원하지 않는 요청입니다.", null);
                break;
        }
    }
    
    /**
     * 수업 입장 페이지 처리 (학생용)
     */
    private String handleEnterRoom(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            // 학생 전용 기능
            if (user != null && "student".equals(user.getRole())) {
                // 학생이 참여 중인 수업 목록 조회
                // List<Class> enrolledClasses = classService.getEnrolledClasses(user.getId());
                // request.setAttribute("enrolledClasses", enrolledClasses);
                
                System.out.println("수업 입장 페이지 접근: " + user.getName() + " (학생)");
            } else {
                request.setAttribute("errorMessage", "학생만 접근 가능한 페이지입니다.");
                return "/WEB-INF/views/error/error.jsp";
            }
            
            return "/WEB-INF/views/class/enterRoom.jsp";
            
        } catch (Exception e) {
            System.err.println("수업 입장 페이지 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "수업 입장 페이지를 불러오는 중 오류가 발생했습니다.");
            return "/WEB-INF/views/error/error.jsp";
        }
    }
    
    /**
     * 수업 관리 페이지 처리 (교수용)
     */
    private String handleEnterClass(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            // 교수 전용 기능
            if (user != null && "professor".equals(user.getRole())) {
                // 교수가 담당하는 수업 목록 조회
                // List<Class> teachingClasses = classService.getTeachingClasses(user.getId());
                // request.setAttribute("teachingClasses", teachingClasses);
                
                System.out.println("수업 관리 페이지 접근: " + user.getName() + " (교수)");
            } else {
                request.setAttribute("errorMessage", "교수만 접근 가능한 페이지입니다.");
                return "/WEB-INF/views/error/error.jsp";
            }
            
            return "/WEB-INF/views/class/enterClass.jsp";
            
        } catch (Exception e) {
            System.err.println("수업 관리 페이지 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "수업 관리 페이지를 불러오는 중 오류가 발생했습니다.");
            return "/WEB-INF/views/error/error.jsp";
        }
    }
    
    /**
     * 수업 참여 페이지 처리
     */
    private String handleClassJoin(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            System.out.println("수업 참여 페이지 접근: " + user.getName() + " (" + user.getRole() + ")");
            
            // 참여 가능한 수업 목록 조회 로직 추가 가능
            // List<Class> availableClasses = classService.getAvailableClasses();
            // request.setAttribute("availableClasses", availableClasses);
            
            return "/WEB-INF/views/class/classJoin.jsp";
            
        } catch (Exception e) {
            System.err.println("수업 참여 페이지 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "수업 참여 페이지를 불러오는 중 오류가 발생했습니다.");
            return "/WEB-INF/views/error/error.jsp";
        }
    }
    
    /**
     * 수업 통계 페이지 처리
     */
    private String handleClassStatistics(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            // 교수만 접근 가능
            if (user != null && "professor".equals(user.getRole())) {
                String classIdParam = request.getParameter("classId");
                
                if (classIdParam != null && !classIdParam.trim().isEmpty()) {
                    int classId = Integer.parseInt(classIdParam);
                    
                    // 수업 통계 데이터 조회
                    // ClassStatistics stats = classService.getClassStatistics(classId);
                    // request.setAttribute("statistics", stats);
                    request.setAttribute("classId", classId);
                }
                
                System.out.println("수업 통계 페이지 접근: " + user.getName() + " (교수)");
            } else {
                request.setAttribute("errorMessage", "교수만 접근 가능한 페이지입니다.");
                return "/WEB-INF/views/error/error.jsp";
            }
            
            return "/WEB-INF/views/class/classStatistics.jsp";
            
        } catch (Exception e) {
            System.err.println("수업 통계 페이지 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "수업 통계 페이지를 불러오는 중 오류가 발생했습니다.");
            return "/WEB-INF/views/error/error.jsp";
        }
    }
    
    /**
     * 수업 아카이브 페이지 처리
     */
    private String handleClassArchive(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            System.out.println("수업 아카이브 페이지 접근: " + user.getName() + " (" + user.getRole() + ")");
            
            // 아카이브된 수업 목록 조회
            // List<Class> archivedClasses = classService.getArchivedClasses(user.getId(), user.getRole());
            // request.setAttribute("archivedClasses", archivedClasses);
            
            return "/WEB-INF/views/class/classArchive.jsp";
            
        } catch (Exception e) {
            System.err.println("수업 아카이브 페이지 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "수업 아카이브 페이지를 불러오는 중 오류가 발생했습니다.");
            return "/WEB-INF/views/error/error.jsp";
        }
    }
    
    /**
     * 수업 입장 요청 처리
     */
    private void handleEnterRoomSubmit(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            String classCode = request.getParameter("classCode");
            
            if (classCode == null || classCode.trim().isEmpty()) {
                sendJsonResponse(response, false, "수업 코드를 입력해주세요.", null);
                return;
            }
            
            // 수업 입장 로직
            // boolean success = classService.enterClass(user.getId(), classCode);
            boolean success = true; // 임시
            
            if (success) {
                sendJsonResponse(response, true, "수업에 성공적으로 입장했습니다.", null);
            } else {
                sendJsonResponse(response, false, "수업 입장에 실패했습니다. 수업 코드를 확인해주세요.", null);
            }
            
        } catch (Exception e) {
            System.err.println("수업 입장 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 수업 관리 요청 처리
     */
    private void handleEnterClassSubmit(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            String action = request.getParameter("action");
            
            if ("create".equals(action)) {
                // 수업 생성 로직
                String className = request.getParameter("className");
                String description = request.getParameter("description");
                
                if (className == null || className.trim().isEmpty()) {
                    sendJsonResponse(response, false, "수업명을 입력해주세요.", null);
                    return;
                }
                
                // boolean success = classService.createClass(user.getId(), className, description);
                boolean success = true; // 임시
                
                if (success) {
                    sendJsonResponse(response, true, "수업이 성공적으로 생성되었습니다.", null);
                } else {
                    sendJsonResponse(response, false, "수업 생성에 실패했습니다.", null);
                }
            } else {
                sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("수업 관리 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 수업 참여 요청 처리
     */
    private void handleClassJoinSubmit(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        try {
            String classCode = request.getParameter("classCode");
            
            if (classCode == null || classCode.trim().isEmpty()) {
                sendJsonResponse(response, false, "수업 코드를 입력해주세요.", null);
                return;
            }
            
            // 수업 참여 로직
            // boolean success = classService.joinClass(user.getId(), classCode);
            boolean success = true; // 임시
            
            if (success) {
                sendJsonResponse(response, true, "수업에 성공적으로 참여했습니다.", null);
            } else {
                sendJsonResponse(response, false, "수업 참여에 실패했습니다. 수업 코드를 확인해주세요.", null);
            }
            
        } catch (Exception e) {
            System.err.println("수업 참여 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 수업 통계 요청 처리
     */
    private void handleClassStatisticsSubmit(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        try {
            String classIdParam = request.getParameter("classId");
            String action = request.getParameter("action");
            
            if (classIdParam == null || classIdParam.trim().isEmpty()) {
                sendJsonResponse(response, false, "수업 ID가 필요합니다.", null);
                return;
            }
            
            int classId = Integer.parseInt(classIdParam);
            
            if ("getStats".equals(action)) {
                // 통계 데이터 조회 로직
                // Map<String, Object> stats = classService.getDetailedStatistics(classId);
                java.util.Map<String, Object> stats = new java.util.HashMap<>(); // 임시
                stats.put("totalStudents", 25);
                stats.put("attendanceRate", 85.5);
                stats.put("averageScore", 78.3);
                
                sendJsonResponse(response, true, "통계 데이터를 성공적으로 조회했습니다.", stats);
            } else {
                sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("수업 통계 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    /**
     * 수업 아카이브 요청 처리
     */
    private void handleClassArchiveSubmit(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        try {
            String action = request.getParameter("action");
            String classIdParam = request.getParameter("classId");
            
            if ("archive".equals(action)) {
                if (classIdParam == null || classIdParam.trim().isEmpty()) {
                    sendJsonResponse(response, false, "수업 ID가 필요합니다.", null);
                    return;
                }
                
                int classId = Integer.parseInt(classIdParam);
                
                // 수업 아카이브 로직
                // boolean success = classService.archiveClass(classId);
                boolean success = true; // 임시
                
                if (success) {
                    sendJsonResponse(response, true, "수업이 성공적으로 아카이브되었습니다.", null);
                } else {
                    sendJsonResponse(response, false, "수업 아카이브에 실패했습니다.", null);
                }
            } else {
                sendJsonResponse(response, false, "올바르지 않은 요청입니다.", null);
            }
            
        } catch (Exception e) {
            System.err.println("수업 아카이브 처리 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "서버 오류가 발생했습니다.", null);
        }
    }
    
    // ===== 유틸리티 메서드들 =====
    
    /**
     * 로그인 상태 확인
     */
    private boolean checkLogin(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            User user = (User) session.getAttribute("user");
            return user != null;
        }
        return false;
    }
    
    /**
     * JSON 응답 전송
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, String message, Object data) 
            throws IOException {
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(message.replace("\"", "\\\"")).append("\"");
        if (data != null) {
            json.append(",\"data\":").append(convertToJson(data));
        }
        json.append("}");
        
        response.getWriter().write(json.toString());
    }
    
    /**
     * 객체를 JSON 문자열로 변환
     */
    private String convertToJson(Object obj) {
        if (obj instanceof java.util.Map) {
            java.util.Map<?, ?> map = (java.util.Map<?, ?>) obj;
            StringBuilder json = new StringBuilder();
            json.append("{");
            boolean first = true;
            for (java.util.Map.Entry<?, ?> entry : map.entrySet()) {
                if (!first) json.append(",");
                json.append("\"").append(entry.getKey()).append("\":");
                if (entry.getValue() instanceof String) {
                    json.append("\"").append(entry.getValue()).append("\"");
                } else {
                    json.append(entry.getValue());
                }
                first = false;
            }
            json.append("}");
            return json.toString();
        }
        return "null";
    }
    
    /**
     * 에러 처리
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, String errorMessage) 
            throws ServletException, IOException {
        request.setAttribute("errorMessage", errorMessage);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/error/error.jsp");
        dispatcher.forward(request, response);
    }
}