package com.clink.model.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 * 수업 정보를 담는 DTO 클래스 (실제 DB 스키마에 맞춤)
 */
public class Class {
    private Long id;                    // class_id
    private String classCode;           // class_code  
    private String className;           // class_name
    private String description;         // description
    private Long professorId;           // professor_id
    private LocalDate startDate;        // start_date
    private LocalDate endDate;          // end_date
    private LocalTime startTime;        // start_time
    private LocalTime endTime;          // end_time
    private String classDays;           // class_days (DB 필드명과 일치)
    private String status;              // status
    private int maxStudents;            // max_students
    private int currentStudents;        // current_students (조인에서 계산)
    private LocalDateTime createdAt;    // created_at
    private LocalDateTime updatedAt;    // updated_at
    
    // 조인된 데이터
    private String professorName;       // users.name
    private String professorEmail;      // users.email
    private List<String> daysList;      // classDays를 파싱한 리스트
    private int totalClasses;           // 총 수업 횟수
    private int completedClasses;       // 완료된 수업 횟수
    private double attendanceRate;      // 출석률
    
    // 기본 생성자
    public Class() {
        this.maxStudents = 50;
        this.currentStudents = 0;
        this.status = "scheduled";
    }
    
    // 수업 생성용 생성자
    public Class(String className, String description, Long professorId, 
                LocalDate startDate, LocalDate endDate, LocalTime startTime, 
                LocalTime endTime, String classDays) {
        this();
        this.className = className;
        this.description = description;
        this.professorId = professorId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.classDays = classDays;
    }
    
    // Getter 메서드들
    public Long getId() { return id; }
    public String getClassCode() { return classCode; }
    public String getClassName() { return className; }
    public String getDescription() { return description; }
    public Long getProfessorId() { return professorId; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public String getClassDays() { return classDays; }  // DB 필드명과 일치
    public String getStatus() { return status; }
    public int getMaxStudents() { return maxStudents; }
    public int getCurrentStudents() { return currentStudents; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public String getProfessorName() { return professorName; }
    public String getProfessorEmail() { return professorEmail; }
    public List<String> getDaysList() { return daysList; }
    public int getTotalClasses() { return totalClasses; }
    public int getCompletedClasses() { return completedClasses; }
    public double getAttendanceRate() { return attendanceRate; }
    
    // 하위 호환성을 위한 메서드 (기존 코드에서 사용)
    public String getDayOfWeek() { return classDays; }
    public boolean isActive() { return !"deleted".equals(status); }
    
    // Setter 메서드들
    public void setId(Long id) { this.id = id; }
    public void setClassCode(String classCode) { this.classCode = classCode; }
    public void setClassName(String className) { this.className = className; }
    public void setDescription(String description) { this.description = description; }
    public void setProfessorId(Long professorId) { this.professorId = professorId; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
    public void setClassDays(String classDays) { this.classDays = classDays; }  // DB 필드명과 일치
    public void setStatus(String status) { this.status = status; }
    public void setMaxStudents(int maxStudents) { this.maxStudents = maxStudents; }
    public void setCurrentStudents(int currentStudents) { this.currentStudents = currentStudents; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    public void setProfessorName(String professorName) { this.professorName = professorName; }
    public void setProfessorEmail(String professorEmail) { this.professorEmail = professorEmail; }
    public void setDaysList(List<String> daysList) { this.daysList = daysList; }
    public void setTotalClasses(int totalClasses) { this.totalClasses = totalClasses; }
    public void setCompletedClasses(int completedClasses) { this.completedClasses = completedClasses; }
    public void setAttendanceRate(double attendanceRate) { this.attendanceRate = attendanceRate; }
    
    // 하위 호환성을 위한 setter
    public void setDayOfWeek(String dayOfWeek) { this.classDays = dayOfWeek; }
    public void setActive(boolean active) { this.status = active ? "active" : "deleted"; }
    
    // 편의 메서드들
    
    /**
     * 수업 참여 가능 여부 확인
     */
    public boolean canJoin() {
        // 1. 삭제된 수업이 아닌지 확인
        if ("deleted".equals(status)) return false;
        
        // 2. 수업 상태 확인 (scheduled 또는 active만 참여 가능)
        if (!"scheduled".equals(status) && !"active".equals(status)) return false;
        
        // 3. 정원 확인
        if (currentStudents >= maxStudents) return false;
        
        // 4. 수업 시작일 확인 (너무 늦게 참여하는 것 방지)
        if (startDate != null && startDate.isBefore(LocalDate.now().minusDays(7))) {
            // 수업 시작 후 1주일이 지나면 참여 불가
            return false;
        }
        
        return true;
    }
    
    /**
     * 수업 상태를 한국어로 반환
     */
    public String getStatusKorean() {
        switch (status) {
            case "scheduled": return "예정";
            case "active": return "진행중";
            case "ended": return "완료";
            case "completed": return "완료";
            case "cancelled": return "취소";
            case "deleted": return "삭제됨";
            default: return "알 수 없음";
        }
    }
    
    /**
     * 수업 진행률 반환 (0.0 ~ 1.0)
     */
    public double getProgress() {
        if (totalClasses == 0) return 0.0;
        return (double) completedClasses / totalClasses;
    }
    
    /**
     * 수업 진행률을 퍼센트로 반환
     */
    public int getProgressPercent() {
        return (int) Math.round(getProgress() * 100);
    }
    
    /**
     * 정원 대비 현재 인원 비율
     */
    public double getCapacityRatio() {
        if (maxStudents == 0) return 0.0;
        return (double) currentStudents / maxStudents;
    }
    
    /**
     * 정원 대비 현재 인원 비율을 퍼센트로 반환
     */
    public int getCapacityPercent() {
        return (int) Math.round(getCapacityRatio() * 100);
    }
    
    /**
     * 남은 정원 수
     */
    public int getAvailableSlots() {
        return Math.max(0, maxStudents - currentStudents);
    }
    
    /**
     * 수업이 곧 시작되는지 확인 (7일 이내)
     */
    public boolean isStartingSoon() {
        if (startDate == null) return false;
        
        LocalDate now = LocalDate.now();
        LocalDate weekFromNow = now.plusDays(7);
        
        return startDate.isAfter(now) && startDate.isBefore(weekFromNow);
    }
    
    /**
     * 수업이 진행 중인지 확인
     */
    public boolean isOngoing() {
        if (startDate == null || endDate == null) return false;
        
        LocalDate now = LocalDate.now();
        return !now.isBefore(startDate) && !now.isAfter(endDate) && "active".equals(status);
    }
    
    /**
     * 수업이 완료되었는지 확인
     */
    public boolean isCompleted() {
        return "ended".equals(status) || "completed".equals(status) || 
               (endDate != null && LocalDate.now().isAfter(endDate));
    }
    
    /**
     * 수업 시간 정보를 문자열로 반환
     */
    public String getTimeInfo() {
        if (startTime == null || endTime == null) return "";
        return startTime.toString() + " - " + endTime.toString();
    }
    
    /**
     * 수업 기간 정보를 문자열로 반환
     */
    public String getPeriodInfo() {
        if (startDate == null || endDate == null) return "";
        return startDate.toString() + " ~ " + endDate.toString();
    }
    
    /**
     * 수업 요일 정보를 사용자 친화적으로 반환
     */
    public String getFormattedDays() {
        if (classDays == null) return "";
        
        // 'mon,wed,fri' 형태를 '월, 수, 금'으로 변환
        return classDays.replace("mon", "월")
                       .replace("tue", "화")
                       .replace("wed", "수")
                       .replace("thu", "목")
                       .replace("fri", "금")
                       .replace("sat", "토")
                       .replace("sun", "일")
                       .replace(",", ", ");
    }
    
    @Override
    public String toString() {
        return "Class{" +
                "id=" + id +
                ", classCode='" + classCode + '\'' +
                ", className='" + className + '\'' +
                ", professorName='" + professorName + '\'' +
                ", status='" + status + '\'' +
                ", currentStudents=" + currentStudents +
                ", maxStudents=" + maxStudents +
                ", classDays='" + classDays + '\'' +
                '}';
    }
}