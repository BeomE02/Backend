package com.clink.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.clink.model.dto.User;
import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;
import com.clink.model.dto.FileInfo;
import com.clink.model.service.FreeBoardService;
import com.clink.model.service.BoardService;
import com.clink.model.service.FileService;

/**
 * 게시판 전용 컨트롤러 - 파일 업로드 완전 연동 + 기존 파일 삭제 기능 완성 버전
 * URL 패턴: 각 *.do URL이 직접 매핑됨
 * 
 * 🚀 최신화 내용:
 * - 게시글 작성 시 파일 업로드 완전 연동
 * - 게시글 수정 시 기존 파일 삭제 및 새 파일 추가 지원
 * - 게시글 상세보기 시 첨부파일 목록 표시
 * - Multipart 폼 데이터 처리 지원
 * - 파일 업로드와 일반 폼 데이터 동시 처리
 * - 하이브리드 라우팅 완벽 지원
 * - 강화된 에러 처리 및 디버깅
 */
public class BoardController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private FreeBoardService freeBoardService;
    private BoardService boardService;
    private FileService fileService;

    @Override
    public void init() throws ServletException {
        super.init();
        System.out.println("🔄 BoardController 초기화 시작 (파일 업로드 연동)...");
        
        try {
            this.freeBoardService = new FreeBoardService();
            this.boardService = new BoardService();
            this.fileService = new FileService();
            
            // 서비스 상태 확인
            System.out.println("✅ Service 초기화 결과:");
            System.out.println("  - freeBoardService: " + (freeBoardService != null ? "성공" : "실패"));
            System.out.println("  - boardService: " + (boardService != null ? "성공" : "실패"));
            System.out.println("  - fileService: " + (fileService != null ? "성공" : "실패"));
            
            // 데이터베이스 연결 테스트
            try {
                java.sql.Connection testConn = com.clink.util.DBConnection.getConnection();
                if (testConn != null) {
                    System.out.println("✅ 데이터베이스 연결 테스트 성공");
                    testConn.close();
                } else {
                    System.err.println("❌ 데이터베이스 연결 실패");
                }
            } catch (Exception dbException) {
                System.err.println("❌ 데이터베이스 연결 테스트 실패: " + dbException.getMessage());
            }
            
            System.out.println("✅ BoardController 초기화 완료 (파일 업로드 연동)");
            
        } catch (Exception e) {
            System.err.println("❌ BoardController 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("BoardController 초기화 실패", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * 모든 게시판 요청 처리 (직접 처리 방식)
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("===============================================");
        
        // 인코딩 설정
        request.setCharacterEncoding("UTF-8");
        
        // URL에서 명령어 추출
        String requestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        String command = requestURI.substring(contextPath.length());
        
        System.out.println("🔄 BoardController 직접 처리: " + command + " (" + request.getMethod() + ")");
        
        // 요청 정보 디버깅
        debugRequest(request);
        
        // JSON 응답이 필요한 요청인지 확인
        boolean isJsonRequest = command.equals("/deletePost.do") || 
                               command.equals("/deleteComment.do") || 
                               command.equals("/editComment.do") ||
                               command.equals("/writeComment.do");
        
        // 응답 타입 설정
        if (isJsonRequest) {
            response.setContentType("application/json; charset=UTF-8");
        } else {
            response.setContentType("text/html; charset=UTF-8");
        }
        
        try {
            switch (command) {
                // ============================================
                // 게시판 페이지 처리 (Service 사용)
                // ============================================
                case "/freePage.do":
                    handleFreeBoardPage(request, response);
                    break;
                    
                case "/questionPage.do":
                    handleBoardPage(request, response, "question");
                    break;
                    
                case "/photoPage.do":
                    handleBoardPage(request, response, "photo");
                    break;
                    
                case "/dataPage.do":
                    handleBoardPage(request, response, "data");
                    break;
                    
                case "/viewPost.do":
                    handleViewPost(request, response);
                    break;
                    
                case "/writePost.do":
                    handleWritePost(request, response);
                    break;
                    
                // ============================================
                // 댓글 관련 처리 (JSON 응답)
                // ============================================
                case "/writeComment.do":
                    handleWriteComment(request, response);
                    break;
                    
                case "/deleteComment.do":
                    handleDeleteComment(request, response);
                    break;
                    
                case "/editComment.do":
                    handleEditComment(request, response);
                    break;
                    
                case "/deletePost.do":
                    handleDeletePost(request, response);
                    break;
                    
                default:
                    System.out.println("❌ BoardController에서 처리할 수 없는 요청: " + command);
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                    return;
            }
            
        } catch (Exception e) {
            System.err.println("❌ BoardController 오류: " + e.getMessage());
            e.printStackTrace();
            
            if (isJsonRequest) {
                sendJsonResponse(response, false, "처리 중 오류가 발생했습니다: " + e.getMessage(), null);
            } else {
                request.setAttribute("errorMessage", "게시판 처리 중 오류가 발생했습니다.");
                request.getRequestDispatcher("/WEB-INF/views/error/error.jsp").forward(request, response);
            }
        }
        
        System.out.println("===============================================");
    }

    // ============================================
    // 게시판 페이지 처리 메서드들 (Service 사용)
    // ============================================

    /**
     * 자유게시판 목록 페이지 (FreeBoardService 사용)
     */
    private void handleFreeBoardPage(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if (!checkLogin(request, response)) return;
        
        System.out.println("📋 자유게시판 처리 시작 (FreeBoardService 사용)");
        
        // 파라미터 추출
        String pageParam = request.getParameter("page");
        String keyword = request.getParameter("keyword");
        String searchType = request.getParameter("searchType");
        String classIdParam = request.getParameter("classId");
        
        // 안전한 파싱
        int currentPage = parseIntSafely(pageParam, 1);
        Integer classId = parseIntSafelyNullable(classIdParam);
        int pageSize = 10;
        
        try {
            // FreeBoardService 사용
            List<Post> postList = freeBoardService.getFreePostList(classId, currentPage, pageSize, searchType, keyword);
            int totalCount = freeBoardService.getFreePostCount(classId, searchType, keyword);
            int totalPages = (int) Math.ceil((double) totalCount / pageSize);
            
            // 속성 설정
            request.setAttribute("postList", postList);
            request.setAttribute("totalCount", totalCount);
            request.setAttribute("currentPage", currentPage);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("pageSize", pageSize);
            request.setAttribute("category", "free");
            request.setAttribute("keyword", keyword);
            request.setAttribute("searchType", searchType);
            request.setAttribute("classId", classIdParam);
            
            // 로그인 사용자 정보 설정
            User loginUser = getLoginUser(request);
            request.setAttribute("user", loginUser);
            request.setAttribute("loginUser", loginUser);
            
            System.out.println("✅ 자유게시판 데이터 로드 완료 - 게시글: " + postList.size() + "개, 총 개수: " + totalCount);
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 데이터 로드 실패: " + e.getMessage());
            e.printStackTrace();
            
            // 빈 리스트로 초기화
            request.setAttribute("postList", new ArrayList<Post>());
            request.setAttribute("totalCount", 0);
            request.setAttribute("currentPage", 1);
            request.setAttribute("totalPages", 0);
            request.setAttribute("pageSize", pageSize);
            request.setAttribute("category", "free");
        }
        
        request.getRequestDispatcher("/WEB-INF/views/board/freePage.jsp").forward(request, response);
    }

    /**
     * 일반 게시판 목록 페이지 (BoardService 사용)
     */
    private void handleBoardPage(HttpServletRequest request, HttpServletResponse response, String categoryCode) 
            throws ServletException, IOException {
        
        if (!checkLogin(request, response)) return;
        
        System.out.println("📋 " + categoryCode + "게시판 처리 시작 (BoardService 사용)");
        
        // 파라미터 추출
        String pageParam = request.getParameter("page");
        String keyword = request.getParameter("keyword");
        String searchType = request.getParameter("searchType");
        String classIdParam = request.getParameter("classId");
        
        // 안전한 파싱
        int currentPage = parseIntSafely(pageParam, 1);
        Integer classId = parseIntSafelyNullable(classIdParam);
        int pageSize = 10;
        
        try {
            // BoardService 사용
            List<Post> postList = boardService.getPostList(categoryCode, classId, currentPage, pageSize, searchType, keyword);
            int totalCount = boardService.getPostCount(categoryCode, classId, searchType, keyword);
            int totalPages = (int) Math.ceil((double) totalCount / pageSize);
            
            // 속성 설정
            request.setAttribute("postList", postList);
            request.setAttribute("totalCount", totalCount);
            request.setAttribute("currentPage", currentPage);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("pageSize", pageSize);
            request.setAttribute("category", categoryCode);
            request.setAttribute("keyword", keyword);
            request.setAttribute("searchType", searchType);
            request.setAttribute("classId", classIdParam);
            
            // 로그인 사용자 정보 설정
            User loginUser = getLoginUser(request);
            request.setAttribute("user", loginUser);
            request.setAttribute("loginUser", loginUser);
            
            System.out.println("✅ " + categoryCode + "게시판 데이터 로드 완료 - 게시글: " + postList.size() + "개");
            
        } catch (Exception e) {
            System.err.println("❌ " + categoryCode + "게시판 데이터 로드 실패: " + e.getMessage());
            e.printStackTrace();
            
            // 빈 리스트로 초기화
            request.setAttribute("postList", new ArrayList<Post>());
            request.setAttribute("totalCount", 0);
            request.setAttribute("currentPage", 1);
            request.setAttribute("totalPages", 0);
            request.setAttribute("category", categoryCode);
        }
        
        // JSP 경로 결정
        String jspPath = "/WEB-INF/views/board/" + categoryCode + "Page.jsp";
        request.getRequestDispatcher(jspPath).forward(request, response);
    }

    /**
     * 🚀 게시글 상세보기 페이지 (Service 사용 + 첨부파일 목록 추가)
     */
    private void handleViewPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if (!checkLogin(request, response)) return;
        
        String postIdParam = request.getParameter("postId");
        if (postIdParam == null || postIdParam.trim().isEmpty()) {
            System.out.println("❌ 게시글 ID가 없습니다");
            response.sendRedirect(request.getContextPath() + "/freePage.do");
            return;
        }
        
        try {
            int postId = Integer.parseInt(postIdParam);
            
            // 게시글 상세 정보 조회 (Service 사용)
            Post post = null;
            List<Comment> commentList = new ArrayList<>();
            
            // 자유게시판인지 확인 후 적절한 Service 사용
            // 일단 FreeBoardService로 시도
            try {
                post = freeBoardService.getFreePost(postId);
                if (post != null) {
                    // 자유게시판 게시글이면 조회수 증가
                    freeBoardService.increaseViewCount(postId);
                    // 댓글 목록 조회 (올바른 메서드명 사용)
                    commentList = freeBoardService.getFreePostComments(postId);
                }
            } catch (Exception e) {
                System.out.println("FreeBoardService에서 조회 실패, BoardService로 시도");
                // BoardService로 시도 (다른 게시판)
                post = boardService.getPost(postId);
                if (post != null) {
                    boardService.increaseViewCount(postId);
                    // BoardService의 올바른 메서드명 사용
                    commentList = boardService.getCommentList(postId);
                }
            }
            
            if (post == null) {
                System.out.println("❌ 게시글을 찾을 수 없습니다: " + postId);
                response.sendRedirect(request.getContextPath() + "/freePage.do");
                return;
            }
            
            // 🆕 첨부파일 목록 조회
            List<FileInfo> attachments = new ArrayList<>();
            try {
                attachments = fileService.getFilesByPostId(postId);
                System.out.println("📎 첨부파일 목록 조회 완료: " + attachments.size() + "개");
            } catch (Exception e) {
                System.err.println("❌ 첨부파일 목록 조회 실패: " + e.getMessage());
                e.printStackTrace();
            }
            
            // 속성 설정
            request.setAttribute("post", post);
            request.setAttribute("commentList", commentList);
            request.setAttribute("commentCount", commentList.size());
            request.setAttribute("comments", commentList); // JSP에서 사용하는 속성명
            request.setAttribute("attachments", attachments); // 🆕 첨부파일 목록 추가
            
            // 로그인 사용자 정보 설정
            User loginUser = getLoginUser(request);
            request.setAttribute("user", loginUser);
            request.setAttribute("loginUser", loginUser);
            
            System.out.println("✅ 게시글 상세보기 로드 완료 - 제목: " + post.getTitle() + 
                             ", 댓글: " + commentList.size() + "개, 첨부파일: " + attachments.size() + "개");
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 잘못된 게시글 ID: " + postIdParam);
            response.sendRedirect(request.getContextPath() + "/freePage.do");
            return;
        } catch (Exception e) {
            System.err.println("❌ 게시글 상세보기 로드 실패: " + e.getMessage());
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/freePage.do");
            return;
        }
        
        request.getRequestDispatcher("/WEB-INF/views/board/viewPost.jsp").forward(request, response);
    }

    /**
     * 게시글 작성 페이지 및 처리 - GET/POST 구분
     */
    private void handleWritePost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String method = request.getMethod();
        System.out.println("🔍 writePost.do 요청: " + method);
        
        if ("GET".equals(method)) {
            handleWritePostForm(request, response);
        } else if ("POST".equals(method)) {
            handleWritePostSubmit(request, response);
        }
    }
    
    /**
     * 🔥 게시글 작성/수정 폼 처리 - 기존 파일 표시 문제 완전 해결
     */
    private void handleWritePostForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("📝 handleWritePostForm 시작");
        
        // 로그인 확인
        User loginUser = getLoginUser(request);
        if (loginUser == null) {
            System.out.println("❌ 로그인하지 않은 사용자");
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }
        
        // 파라미터 추출
        String action = request.getParameter("action");
        String postIdStr = request.getParameter("postId");
        String category = request.getParameter("category");
        
        System.out.println("🔍 요청 파라미터:");
        System.out.println("   - action: " + action);
        System.out.println("   - postId: " + postIdStr);
        System.out.println("   - category: " + category);
        
        if ("edit".equals(action) && postIdStr != null) {
            // 🔥 수정 모드: 기존 게시글 데이터 + 첨부파일 로드
            try {
                int postId = Integer.parseInt(postIdStr);
                
                // 게시글 데이터 조회
                Post editPost = null;
                if ("free".equals(category)) {
                    editPost = freeBoardService.getFreePost(postId);
                    System.out.println("📄 자유게시판 게시글 조회: " + (editPost != null ? "성공" : "실패"));
                } else {
                    editPost = boardService.getPost(postId);
                    System.out.println("📄 일반게시판 게시글 조회: " + (editPost != null ? "성공" : "실패"));
                }
                
                if (editPost != null) {
                    // 권한 확인 (작성자 또는 교수만)
                    boolean hasPermission = (loginUser.getUserId() == editPost.getAuthorId()) || 
                                           "professor".equals(loginUser.getRole());
                    
                    if (hasPermission) {
                        // 수정 모드 데이터 설정
                        request.setAttribute("mode", "edit");
                        request.setAttribute("editPost", editPost);
                        request.setAttribute("category", category);
                        
                        // 🔥 핵심: 기존 첨부파일 목록 조회 및 설정
                        try {
                            List<FileInfo> existingFiles = fileService.getFilesByPostId(postId);
                            request.setAttribute("existingFiles", existingFiles);
                            
                            System.out.println("📎 기존 첨부파일 조회 결과:");
                            System.out.println("   - 파일 개수: " + existingFiles.size());
                            
                            if (existingFiles.size() > 0) {
                                for (int i = 0; i < existingFiles.size(); i++) {
                                    FileInfo file = existingFiles.get(i);
                                    System.out.println("   - 파일 " + (i+1) + ": " + file.getOriginalFilename() + 
                                                     " (ID: " + file.getAttachmentId() + ")");
                                }
                            } else {
                                System.out.println("   - 첨부파일 없음");
                            }
                            
                        } catch (Exception fileException) {
                            System.err.println("❌ 기존 첨부파일 조회 실패: " + fileException.getMessage());
                            fileException.printStackTrace();
                            request.setAttribute("existingFiles", new ArrayList<FileInfo>());
                        }
                        
                        System.out.println("✅ 수정 모드 데이터 설정 완료");
                        System.out.println("   - 게시글 제목: " + editPost.getTitle());
                        System.out.println("   - 게시글 ID: " + editPost.getPostId());
                        System.out.println("   - 카테고리: " + category);
                        
                    } else {
                        System.out.println("❌ 수정 권한 없음 - userId: " + loginUser.getUserId() + 
                                         ", authorId: " + editPost.getAuthorId() + 
                                         ", role: " + loginUser.getRole());
                        request.setAttribute("errorMessage", "수정 권한이 없습니다.");
                        response.sendRedirect(request.getContextPath() + "/" + category + "Page.do");
                        return;
                    }
                } else {
                    System.out.println("❌ 게시글을 찾을 수 없음 - postId: " + postId + ", category: " + category);
                    request.setAttribute("errorMessage", "게시글을 찾을 수 없습니다.");
                    response.sendRedirect(request.getContextPath() + "/" + category + "Page.do");
                    return;
                }
                
            } catch (NumberFormatException e) {
                System.err.println("❌ 잘못된 게시글 ID: " + postIdStr);
                response.sendRedirect(request.getContextPath() + "/freePage.do");
                return;
            } catch (Exception e) {
                System.err.println("❌ 수정 모드 처리 오류: " + e.getMessage());
                e.printStackTrace();
                request.setAttribute("errorMessage", "오류가 발생했습니다.");
                response.sendRedirect(request.getContextPath() + "/freePage.do");
                return;
            }
        } else {
            // 새 글 작성 모드
            request.setAttribute("mode", "new");
            request.setAttribute("category", category != null ? category : "free");
            request.setAttribute("existingFiles", new ArrayList<FileInfo>()); // 빈 리스트
            
            System.out.println("✅ 새 글 작성 모드 설정");
            System.out.println("   - 카테고리: " + (category != null ? category : "free"));
        }
        
        // 🔥 최종 확인: request에 설정된 속성들 로깅
        System.out.println("🔍 JSP로 전달되는 속성 확인:");
        System.out.println("   - mode: " + request.getAttribute("mode"));
        System.out.println("   - category: " + request.getAttribute("category"));
        System.out.println("   - editPost: " + (request.getAttribute("editPost") != null ? "있음" : "없음"));
        System.out.println("   - existingFiles: " + 
                          ((List<?>) request.getAttribute("existingFiles")).size() + "개");
        
        // writePost.jsp로 포워딩
        System.out.println("📄 writePost.jsp로 포워딩");
        request.getRequestDispatcher("/WEB-INF/views/board/writePost.jsp").forward(request, response);
    }
    
    /**
     * 🚀 글쓰기 실제 처리 (POST) - 파일 업로드 완전 연동
     */
    private void handleWritePostSubmit(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("🚀 게시글 처리 시작 (POST + 파일 업로드)");
        
        // 로그인 확인
        User loginUser = getLoginUser(request);
        if (loginUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }
        
        try {
            // 인코딩 설정
            request.setCharacterEncoding("UTF-8");
            
            // 파라미터 추출
            String mode = getParameter(request, "mode");
            String postIdStr = getParameter(request, "postId");
            String category = getParameter(request, "category");
            String title = getParameter(request, "title");
            String content = getParameter(request, "content");
            String anonymousStr = getParameter(request, "isAnonymous");
            
            System.out.println("📝 처리 파라미터:");
            System.out.println("   - mode: " + mode);
            System.out.println("   - postId: " + postIdStr);
            System.out.println("   - category: " + category);
            System.out.println("   - title: " + (title != null ? title.substring(0, Math.min(title.length(), 20)) + "..." : "null"));
            
            // 필수 값 검증
            if (category == null || title == null || content == null) {
                System.out.println("❌ 필수 정보 누락");
                request.setAttribute("errorMessage", "필수 정보가 누락되었습니다.");
                handleWritePostForm(request, response);
                return;
            }
            
            // 수정 모드 처리
            if ("edit".equals(mode) && postIdStr != null) {
                handlePostUpdate(request, response, loginUser, postIdStr, category, title, content, anonymousStr);
            } else {
                // 새 글 작성 모드 (파일 업로드 포함)
                handlePostCreateWithFiles(request, response, loginUser, category, title, content, anonymousStr);
            }
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "게시글 처리 중 오류가 발생했습니다.");
            handleWritePostForm(request, response);
        }
    }
    
    /**
     * 🔥 게시글 수정 처리 - 기존 파일 삭제 기능 완성
     */
    private void handlePostUpdate(HttpServletRequest request, HttpServletResponse response, 
                                 User loginUser, String postIdStr, String category, 
                                 String title, String content, String anonymousStr) 
            throws ServletException, IOException {
        
        System.out.println("🔄 게시글 수정 처리 시작");
        
        try {
            int postId = Integer.parseInt(postIdStr);
            boolean isAnonymous = "true".equals(anonymousStr);
            
            // 기존 게시글 조회 (권한 확인용)
            Post existingPost = null;
            if ("free".equals(category)) {
                existingPost = freeBoardService.getFreePost(postId);
            } else {
                existingPost = boardService.getPost(postId);
            }
            
            if (existingPost == null) {
                System.out.println("❌ 게시글을 찾을 수 없음");
                request.setAttribute("errorMessage", "게시글을 찾을 수 없습니다.");
                response.sendRedirect(request.getContextPath() + "/" + category + "Page.do");
                return;
            }
            
            // 권한 확인
            if (loginUser.getUserId() != existingPost.getAuthorId() && !"professor".equals(loginUser.getRole())) {
                System.out.println("❌ 수정 권한 없음");
                request.setAttribute("errorMessage", "수정 권한이 없습니다.");
                response.sendRedirect(request.getContextPath() + "/" + category + "Page.do");
                return;
            }
            
            // 🔥 기존 파일 삭제 처리 (게시글 수정 전에 먼저 처리)
            String filesToDeleteStr = getParameter(request, "filesToDelete");
            if (filesToDeleteStr != null && !filesToDeleteStr.trim().isEmpty()) {
                handleExistingFilesDeletion(filesToDeleteStr, loginUser.getUserId());
            }
            
            // 수정할 게시글 객체 생성
            Post updatePost = new Post();
            updatePost.setPostId(postId);
            updatePost.setTitle(title.trim());
            updatePost.setContent(content.trim());
            updatePost.setAnonymous(isAnonymous);
            updatePost.setCategoryCode(category);
            updatePost.setAuthorId(loginUser.getUserId());
            
            // 게시글 수정 실행
            boolean success = false;
            if ("free".equals(category)) {
                success = freeBoardService.updateFreePost(updatePost);
            } else if ("question".equals(category)) {
                success = boardService.updatePost(updatePost);
            } else if ("photo".equals(category)) {
                success = boardService.updatePost(updatePost);
            } else if ("data".equals(category)) {
                success = boardService.updatePost(updatePost);
            } else {
                success = boardService.updatePost(updatePost);
            }
            
            // 새 파일 처리 (게시글 수정이 성공한 후)
            if (success) {
                try {
                    Collection<Part> fileParts = getFileParts(request);
                    if (!fileParts.isEmpty()) {
                        System.out.println("📎 수정 모드에서 새 파일 업로드: " + fileParts.size() + "개");
                        handleFileUpload(fileParts, postId, null, loginUser.getUserId());
                    }
                } catch (Exception e) {
                    System.err.println("❌ 수정 시 파일 업로드 실패: " + e.getMessage());
                    // 파일 업로드 실패는 게시글 수정을 롤백하지 않음
                }
            }
            
            if (success) {
                System.out.println("✅ 게시글 수정 성공 - postId: " + postId);
                response.sendRedirect(request.getContextPath() + "/viewPost.do?postId=" + postId);
            } else {
                System.out.println("❌ 게시글 수정 실패");
                request.setAttribute("errorMessage", "게시글 수정에 실패했습니다.");
                
                // 수정 실패 시 수정 폼으로 다시 이동
                request.setAttribute("mode", "edit");
                request.setAttribute("editPost", existingPost);
                request.setAttribute("category", category);
                
                // 기존 첨부파일 목록 다시 조회
                try {
                    List<FileInfo> existingFiles = fileService.getFilesByPostId(postId);
                    request.setAttribute("existingFiles", existingFiles);
                } catch (Exception e) {
                    System.err.println("❌ 기존 첨부파일 재조회 실패: " + e.getMessage());
                    request.setAttribute("existingFiles", new ArrayList<FileInfo>());
                }
                
                handleWritePostForm(request, response);
            }
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 잘못된 게시글 ID: " + postIdStr);
            request.setAttribute("errorMessage", "잘못된 요청입니다.");
            response.sendRedirect(request.getContextPath() + "/freePage.do");
        } catch (Exception e) {
            System.err.println("❌ 게시글 수정 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "게시글 수정 중 오류가 발생했습니다.");
            
            // 에러 발생 시 해당 게시판으로 이동
            response.sendRedirect(request.getContextPath() + "/" + category + "Page.do");
        }
    }

    /**
     * 🔥 기존 파일 삭제 처리
     */
    private void handleExistingFilesDeletion(String filesToDeleteStr, Integer userId) {
        System.out.println("🗑️ 기존 파일 삭제 처리 시작: " + filesToDeleteStr);
        
        try {
            String[] fileIds = filesToDeleteStr.split(",");
            
            for (String fileIdStr : fileIds) {
                if (fileIdStr != null && !fileIdStr.trim().isEmpty()) {
                    try {
                        int fileId = Integer.parseInt(fileIdStr.trim());
                        
                        // FileService를 통한 파일 삭제
                        boolean deleted = fileService.deleteFile(fileId, userId);
                        
                        if (deleted) {
                            System.out.println("✅ 파일 삭제 성공: " + fileId);
                        } else {
                            System.err.println("❌ 파일 삭제 실패: " + fileId);
                        }
                        
                    } catch (NumberFormatException e) {
                        System.err.println("❌ 잘못된 파일 ID: " + fileIdStr);
                    }
                }
            }
            
            System.out.println("✅ 기존 파일 삭제 처리 완료");
            
        } catch (Exception e) {
            System.err.println("❌ 기존 파일 삭제 처리 중 오류: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 🚀 새 게시글 작성 처리 (파일 업로드 포함)
     */
    private void handlePostCreateWithFiles(HttpServletRequest request, HttpServletResponse response, 
                                          User loginUser, String category, String title, 
                                          String content, String anonymousStr) 
            throws ServletException, IOException {
        
        System.out.println("📝 새 게시글 작성 처리 (파일 업로드 포함)");
        
        try {
            boolean isAnonymous = "true".equals(anonymousStr);
            int categoryId = getCategoryId(category);
            
            if (categoryId == -1) {
                System.out.println("❌ 잘못된 카테고리: " + category);
                request.setAttribute("errorMessage", "잘못된 게시판입니다.");
                handleWritePostForm(request, response);
                return;
            }
            
            // 새 게시글 객체 생성
            Post newPost = new Post();
            newPost.setCategoryId(categoryId);
            newPost.setAuthorId(loginUser.getUserId());
            newPost.setTitle(title.trim());
            newPost.setContent(content.trim());
            newPost.setAnonymous(isAnonymous);
            newPost.setCategoryCode(category);
            
            // 게시글 작성
            boolean postSuccess = false;
            int createdPostId = -1;
            
            if ("free".equals(category)) {
                postSuccess = freeBoardService.createFreePost(newPost);
                if (postSuccess) {
                    createdPostId = newPost.getPostId(); // DAO에서 설정된 ID
                }
            } else {
                postSuccess = boardService.createPost(newPost);
                if (postSuccess) {
                    createdPostId = newPost.getPostId();
                }
            }
            
            if (!postSuccess) {
                System.out.println("❌ 게시글 작성 실패");
                request.setAttribute("errorMessage", "게시글 작성에 실패했습니다.");
                handleWritePostForm(request, response);
                return;
            }
            
            System.out.println("✅ 게시글 작성 성공 - ID: " + createdPostId);
            
            // 🆕 파일 업로드 처리
            try {
                Collection<Part> fileParts = getFileParts(request);
                if (!fileParts.isEmpty()) {
                    System.out.println("📎 첨부파일 업로드 시작: " + fileParts.size() + "개");
                    List<FileInfo> uploadedFiles = handleFileUpload(fileParts, createdPostId, null, loginUser.getUserId());
                    System.out.println("📎 첨부파일 업로드 완료: " + uploadedFiles.size() + "개");
                } else {
                    System.out.println("📎 첨부파일 없음");
                }
            } catch (Exception e) {
                System.err.println("❌ 파일 업로드 실패: " + e.getMessage());
                e.printStackTrace();
                // 파일 업로드 실패는 게시글 작성을 롤백하지 않음
            }
            
            // 성공 시 해당 게시판으로 리다이렉트
            response.sendRedirect(request.getContextPath() + "/" + category + "Page.do");
            
        } catch (Exception e) {
            System.err.println("❌ 게시글 작성 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "게시글 작성 중 오류가 발생했습니다.");
            handleWritePostForm(request, response);
        }
    }
    
    /**
     * 🆕 파일 업로드 처리
     */
    private List<FileInfo> handleFileUpload(Collection<Part> fileParts, Integer postId, Integer classId, Integer userId) {
        List<FileInfo> uploadedFiles = new ArrayList<>();
        
        if (fileService == null) {
            System.err.println("❌ FileService가 초기화되지 않았습니다.");
            return uploadedFiles;
        }
        
        for (Part filePart : fileParts) {
            if (filePart.getSize() == 0) {
                continue; // 빈 파일 무시
            }
            
            try {
                FileInfo uploadedFile = fileService.uploadFile(filePart, postId, classId, userId);
                if (uploadedFile != null) {
                    uploadedFiles.add(uploadedFile);
                    System.out.println("✅ 파일 업로드 성공: " + uploadedFile.getOriginalFilename());
                } else {
                    System.err.println("❌ 파일 업로드 실패: " + getOriginalFilename(filePart));
                }
            } catch (Exception e) {
                System.err.println("❌ 파일 업로드 중 오류: " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        return uploadedFiles;
    }
    
    /**
     * 🆕 요청에서 파일 Part 목록 추출
     */
    private Collection<Part> getFileParts(HttpServletRequest request) throws IOException, ServletException {
        List<Part> fileParts = new ArrayList<>();
        
        try {
            Collection<Part> allParts = request.getParts();
            for (Part part : allParts) {
                // 파일 Part인지 확인
                if (isFilePart(part)) {
                    fileParts.add(part);
                }
            }
        } catch (Exception e) {
            System.err.println("❌ 파일 Part 추출 실패: " + e.getMessage());
        }
        
        return fileParts;
    }
    
    /**
     * 🆕 Part가 파일인지 확인
     */
    private boolean isFilePart(Part part) {
        String contentDisposition = part.getHeader("Content-Disposition");
        if (contentDisposition == null) return false;
        
        // filename이 있고, Content-Type이 null이 아니면 파일
        boolean hasFilename = contentDisposition.contains("filename=");
        String contentType = part.getContentType();
        
        return hasFilename && contentType != null && part.getSize() > 0;
    }
    
    /**
     * 🆕 Part에서 원본 파일명 추출
     */
    private String getOriginalFilename(Part part) {
        String contentDisposition = part.getHeader("Content-Disposition");
        if (contentDisposition == null) return null;
        
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                String filename = token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
                return filename;
            }
        }
        return null;
    }
    
    /**
     * 🔥 파라미터 추출 (Multipart 지원)
     */
    private String getParameter(HttpServletRequest request, String paramName) throws IOException, ServletException {
        String contentType = request.getContentType();
        
        if (contentType != null && contentType.startsWith("multipart/form-data")) {
            // Multipart 폼 데이터에서 추출
            Collection<Part> parts = request.getParts();
            for (Part part : parts) {
                if (paramName.equals(part.getName()) && part.getContentType() == null) {
                    return readPartAsString(part);
                }
            }
            return null;
        } else {
            // 일반 폼 데이터에서 추출
            return request.getParameter(paramName);
        }
    }
    
    /**
     * Part에서 문자열 값을 읽는 헬퍼 메서드
     */
    private String readPartAsString(Part part) throws IOException {
        try (java.io.InputStream inputStream = part.getInputStream();
             java.util.Scanner scanner = new java.util.Scanner(inputStream, "UTF-8")) {
            
            scanner.useDelimiter("\\A");
            String value = scanner.hasNext() ? scanner.next() : "";
            
            // 빈 문자열이나 공백만 있는 경우 null로 처리
            return (value != null && !value.trim().isEmpty()) ? value.trim() : null;
        }
    }
    
    /**
     * 카테고리 코드를 카테고리 ID로 변환
     */
    private int getCategoryId(String categoryCode) {
        switch (categoryCode) {
            case "free": return 1;      // 자유게시판
            case "question": return 2;  // 질문게시판
            case "photo": return 3;     // 사진게시판
            case "data": return 4;      // 자료게시판
            default: return -1;
        }
    }

    // ============================================
    // 댓글 관련 메서드들 (JSON 응답, Service 사용)
    // ============================================

    /**
     * 댓글 작성 처리 (JSON 응답)
     */
    private void handleWriteComment(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("🔥 댓글 작성 처리 시작 (BoardController 직접 처리)");
        
        // 로그인 확인
        User loginUser = getLoginUser(request);
        if (loginUser == null) {
            System.out.println("❌ 댓글 작성: 로그인 필요");
            sendJsonResponse(response, false, "로그인이 필요합니다", null);
            return;
        }
        
        try {
            String postIdStr = request.getParameter("postId");
            String content = request.getParameter("content");
            String parentIdStr = request.getParameter("parentCommentId");
            String anonymousStr = request.getParameter("isAnonymous");
            
            System.out.println("📝 댓글 파라미터 - postId: " + postIdStr + ", content: " + (content != null ? content.substring(0, Math.min(content.length(), 20)) + "..." : "null"));
            
            if (postIdStr == null || content == null || content.trim().isEmpty()) {
                System.out.println("❌ 댓글 작성: 필수 정보 누락");
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다", null);
                return;
            }
            
            int postId = Integer.parseInt(postIdStr);
            boolean isAnonymous = "true".equals(anonymousStr);
            Integer parentId = null;
            
            if (parentIdStr != null && !parentIdStr.trim().isEmpty()) {
                try {
                    parentId = Integer.parseInt(parentIdStr);
                } catch (NumberFormatException e) {
                    // 무시
                }
            }
            
            System.out.println("🔍 댓글 작성 - postId: " + postId + ", authorId: " + loginUser.getUserId() + ", isAnonymous: " + isAnonymous);
            
            // Comment 객체 생성
            Comment comment = new Comment();
            comment.setPostId(postId);
            comment.setAuthorId(loginUser.getUserId());
            comment.setContent(content.trim());
            comment.setAnonymous(isAnonymous);
            comment.setParentId(parentId);
            
            // FreeBoardService 사용 (자유게시판 댓글)
            boolean success = freeBoardService.createFreePostComment(comment);
            
            if (success) {
                System.out.println("✅ 댓글 작성 성공");
                sendJsonResponse(response, true, "댓글이 작성되었습니다", null);
            } else {
                System.out.println("❌ 댓글 작성 실패");
                sendJsonResponse(response, false, "댓글 작성에 실패했습니다", null);
            }
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 댓글 작성 파라미터 오류: " + e.getMessage());
            sendJsonResponse(response, false, "잘못된 요청입니다", null);
        } catch (Exception e) {
            System.err.println("❌ 댓글 작성 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "댓글 작성 중 오류가 발생했습니다", null);
        }
    }

    /**
     * 댓글 삭제 처리 (JSON 응답)
     */
    private void handleDeleteComment(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 로그인 확인
        User loginUser = getLoginUser(request);
        if (loginUser == null) {
            sendJsonResponse(response, false, "로그인이 필요합니다", null);
            return;
        }
        
        try {
            String commentIdStr = request.getParameter("commentId");
            
            if (commentIdStr == null) {
                sendJsonResponse(response, false, "댓글 ID가 필요합니다", null);
                return;
            }
            
            int commentId = Integer.parseInt(commentIdStr);
            
            // FreeBoardService 사용
            boolean success = freeBoardService.deleteFreePostComment(commentId, loginUser.getUserId());
            
            if (success) {
                System.out.println("✅ 댓글 삭제 성공");
                sendJsonResponse(response, true, "댓글이 삭제되었습니다", null);
            } else {
                System.out.println("❌ 댓글 삭제 실패");
                sendJsonResponse(response, false, "댓글 삭제에 실패했습니다", null);
            }
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 댓글 삭제 파라미터 오류: " + e.getMessage());
            sendJsonResponse(response, false, "잘못된 요청입니다", null);
        } catch (Exception e) {
            System.err.println("❌ 댓글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "댓글 삭제 중 오류가 발생했습니다", null);
        }
    }

    /**
     * 댓글 수정 처리 (JSON 응답)
     */
    private void handleEditComment(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 로그인 확인
        User loginUser = getLoginUser(request);
        if (loginUser == null) {
            sendJsonResponse(response, false, "로그인이 필요합니다", null);
            return;
        }
        
        try {
            String commentIdStr = request.getParameter("commentId");
            String content = request.getParameter("content");
            
            if (commentIdStr == null || content == null || content.trim().isEmpty()) {
                sendJsonResponse(response, false, "필수 정보가 누락되었습니다", null);
                return;
            }
            
            int commentId = Integer.parseInt(commentIdStr);
            
            // FreeBoardService 사용
            boolean success = freeBoardService.updateFreePostComment(commentId, loginUser.getUserId(), content.trim());
            
            if (success) {
                System.out.println("✅ 댓글 수정 성공");
                sendJsonResponse(response, true, "댓글이 수정되었습니다", null);
            } else {
                System.out.println("❌ 댓글 수정 실패");
                sendJsonResponse(response, false, "댓글 수정에 실패했습니다", null);
            }
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 댓글 수정 파라미터 오류: " + e.getMessage());
            sendJsonResponse(response, false, "잘못된 요청입니다", null);
        } catch (Exception e) {
            System.err.println("❌ 댓글 수정 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "댓글 수정 중 오류가 발생했습니다", null);
        }
    }

    /**
     * 게시글 삭제 처리 (JSON 응답)
     */
    private void handleDeletePost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 로그인 확인
        User loginUser = getLoginUser(request);
        if (loginUser == null) {
            sendJsonResponse(response, false, "로그인이 필요합니다", null);
            return;
        }
        
        try {
            String postIdStr = request.getParameter("postId");
            
            if (postIdStr == null) {
                sendJsonResponse(response, false, "게시글 ID가 필요합니다", null);
                return;
            }
            
            int postId = Integer.parseInt(postIdStr);
            
            // FreeBoardService 사용
            boolean success = freeBoardService.deleteFreePost(postId, loginUser.getUserId());
            
            if (success) {
                System.out.println("✅ 게시글 삭제 성공");
                sendJsonResponse(response, true, "게시글이 삭제되었습니다", null);
            } else {
                System.out.println("❌ 게시글 삭제 실패");
                sendJsonResponse(response, false, "게시글 삭제에 실패했습니다", null);
            }
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 게시글 삭제 파라미터 오류: " + e.getMessage());
            sendJsonResponse(response, false, "잘못된 요청입니다", null);
        } catch (Exception e) {
            System.err.println("❌ 게시글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonResponse(response, false, "게시글 삭제 중 오류가 발생했습니다", null);
        }
    }

    // ============================================
    // 유틸리티 메서드들
    // ============================================

    /**
     * 로그인 확인
     */
    private boolean checkLogin(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            System.out.println("🔒 로그인 필요 - 로그인 페이지로 리다이렉트");
            response.sendRedirect(request.getContextPath() + "/login.do");
            return false;
        }
        
        return true;
    }

    /**
     * 로그인 사용자 정보 가져오기
     */
    private User getLoginUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return (User) session.getAttribute("loginUser");
        }
        return null;
    }

    /**
     * JSON 응답 전송
     */
    private void sendJsonResponse(HttpServletResponse response, boolean success, String message, Object data) 
            throws IOException {
        
        System.out.println("📤 JSON 응답 전송 - success: " + success + ", message: " + message);
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":").append(success).append(",");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null) {
            json.append(",\"data\":").append(objectToJson(data));
        }
        
        json.append("}");
        
        String jsonResponse = json.toString();
        System.out.println("📤 JSON 응답: " + jsonResponse);
        
        response.getWriter().write(jsonResponse);
        response.getWriter().flush();
    }

    /**
     * JSON 특수문자 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }

    /**
     * 객체를 JSON 문자열로 변환 (수동 구현)
     */
    private String objectToJson(Object obj) {
        if (obj == null) return "null";
        if (obj instanceof String) return "\"" + escapeJson((String)obj) + "\"";
        if (obj instanceof Integer || obj instanceof Long) return obj.toString();
        if (obj instanceof Boolean) return obj.toString();
        
        return "{}";
    }

    /**
     * 안전한 정수 파싱 (기본값 제공)
     */
    private int parseIntSafely(String str, int defaultValue) {
        if (str == null || str.trim().isEmpty()) {
            return defaultValue;
        }
        try {
            int value = Integer.parseInt(str.trim());
            return value > 0 ? value : defaultValue;
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * 안전한 정수 파싱 (null 허용)
     */
    private Integer parseIntSafelyNullable(String str) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        try {
            int value = Integer.parseInt(str.trim());
            return value > 0 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * 요청 정보 디버깅
     */
    private void debugRequest(HttpServletRequest request) {
        System.out.println("🔍 요청 디버깅 정보:");
        System.out.println("  - Method: " + request.getMethod());
        System.out.println("  - URI: " + request.getRequestURI());
        System.out.println("  - Context Path: " + request.getContextPath());
        System.out.println("  - Servlet Path: " + request.getServletPath());
        System.out.println("  - Query String: " + request.getQueryString());
        System.out.println("  - Content-Type: " + request.getContentType());
        
        // Multipart가 아닌 경우에만 파라미터 출력
        String contentType = request.getContentType();
        if (contentType == null || !contentType.startsWith("multipart/form-data")) {
            System.out.println("  - Parameters:");
            java.util.Enumeration<String> paramNames = request.getParameterNames();
            while (paramNames.hasMoreElements()) {
                String paramName = paramNames.nextElement();
                String paramValue = request.getParameter(paramName);
                System.out.println("    * " + paramName + " = " + paramValue);
            }
        } else {
            System.out.println("  - Multipart 요청: 파라미터는 handleWritePostSubmit에서 처리");
        }
    }
}