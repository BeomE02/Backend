package com.clink.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.dto.User;

/**
 * 로그인 체크 필터
 * 인증이 필요한 페이지에 대한 접근 제어
 */
public class LoginCheckFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("LoginCheckFilter 초기화");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // 세션에서 사용자 정보 확인
        HttpSession session = httpRequest.getSession(false);
        User user = null;
        
        if (session != null) {
            user = (User) session.getAttribute("user");
        }
        
        // 로그인되지 않은 경우
        if (user == null) {
            String requestURI = httpRequest.getRequestURI();
            String contextPath = httpRequest.getContextPath();
            
            System.out.println("로그인 필요: " + requestURI);
            
            // AJAX 요청인지 확인
            String ajaxHeader = httpRequest.getHeader("X-Requested-With");
            String contentType = httpRequest.getHeader("Content-Type");
            
            if ("XMLHttpRequest".equals(ajaxHeader) || 
                (contentType != null && contentType.contains("application/json"))) {
                // AJAX 요청인 경우 JSON 응답
                httpResponse.setContentType("application/json; charset=UTF-8");
                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                httpResponse.getWriter().write("{\"success\":false,\"message\":\"로그인이 필요합니다.\",\"redirect\":\"" + 
                                             contextPath + "/login.do\"}");
            } else {
                // 일반 요청인 경우 로그인 페이지로 리다이렉트
                httpResponse.sendRedirect(contextPath + "/login.do");
            }
            
            return;
        }
        
        // 로그인된 경우 요청 계속 진행
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        System.out.println("LoginCheckFilter 종료");
    }
}