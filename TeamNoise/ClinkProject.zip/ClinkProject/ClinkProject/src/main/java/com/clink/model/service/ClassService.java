package com.clink.model.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

import com.clink.model.dao.ClassDAO;
import com.clink.model.dto.Class;

/**
 * 수업 관련 비즈니스 로직 서비스
 */
public class ClassService {
    
    private ClassDAO classDAO;
    
    public ClassService() {
        this.classDAO = new ClassDAO();
    }
    
    /**
     * 새 수업 생성
     */
    public boolean createClass(String className, String description, Long professorId,
                              String startDateStr, String endDateStr, String startTimeStr, 
                              String endTimeStr, String dayOfWeek, String maxStudentsStr) {
        
        // 입력값 검증
        if (!validateClassInput(className, description, professorId, startDateStr, 
                               endDateStr, startTimeStr, endTimeStr, dayOfWeek)) {
            return false;
        }
        
        try {
            // 날짜/시간 파싱
            LocalDate startDate = LocalDate.parse(startDateStr);
            LocalDate endDate = LocalDate.parse(endDateStr);
            LocalTime startTime = LocalTime.parse(startTimeStr);
            LocalTime endTime = LocalTime.parse(endTimeStr);
            
            // 최대 학생 수 파싱
            int maxStudents = 50; // 기본값
            if (maxStudentsStr != null && !maxStudentsStr.trim().isEmpty()) {
                maxStudents = Integer.parseInt(maxStudentsStr);
                if (maxStudents <= 0 || maxStudents > 500) {
                    System.out.println("수업 생성 실패: 최대 학생 수는 1-500명 사이여야 합니다.");
                    return false;
                }
            }
            
            // 날짜/시간 유효성 검증
            if (!validateDateTime(startDate, endDate, startTime, endTime)) {
                return false;
            }
            
            // 수업 객체 생성
            Class newClass = new Class(className.trim(), description.trim(), professorId,
                                     startDate, endDate, startTime, endTime, dayOfWeek);
            newClass.setMaxStudents(maxStudents);
            
            // 수업 상태 결정
            LocalDate today = LocalDate.now();
            if (startDate.isBefore(today) || startDate.isEqual(today)) {
                newClass.setStatus("active");
            } else {
                newClass.setStatus("scheduled");
            }
            
            boolean result = classDAO.createClass(newClass);
            
            if (result) {
                System.out.println("수업 생성 성공: " + className + " (코드: " + newClass.getClassCode() + ")");
            } else {
                System.out.println("수업 생성 실패: 데이터베이스 오류");
            }
            
            return result;
            
        } catch (DateTimeParseException e) {
            System.out.println("수업 생성 실패: 날짜/시간 형식이 올바르지 않습니다.");
            return false;
        } catch (NumberFormatException e) {
            System.out.println("수업 생성 실패: 최대 학생 수는 숫자여야 합니다.");
            return false;
        } catch (Exception e) {
            System.err.println("수업 생성 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 교수의 수업 목록 조회
     */
    public List<Class> getProfessorClasses(Long professorId, String status) {
        if (professorId == null || professorId <= 0) {
            System.out.println("교수 수업 목록 조회 실패: 유효하지 않은 교수 ID");
            return List.of();
        }
        
        List<Class> classList = classDAO.getClassesByProfessor(professorId, status);
        
        // 수업 상태 자동 업데이트
        updateClassStatuses(classList);
        
        System.out.println("교수 수업 목록 조회 성공: " + classList.size() + "개 (교수 ID: " + professorId + ")");
        return classList;
    }
    
    /**
     * 학생의 수업 목록 조회
     */
    public List<Class> getStudentClasses(Long studentId, String status) {
        if (studentId == null || studentId <= 0) {
            System.out.println("학생 수업 목록 조회 실패: 유효하지 않은 학생 ID");
            return List.of();
        }
        
        List<Class> classList = classDAO.getStudentClasses(studentId, status);
        
        // 수업 상태 자동 업데이트
        updateClassStatuses(classList);
        
        System.out.println("학생 수업 목록 조회 성공: " + classList.size() + "개 (학생 ID: " + studentId + ")");
        return classList;
    }
    
    /**
     * 수업 코드로 수업 참여
     */
    public boolean joinClass(String classCode, Long studentId) {
        // 입력값 검증
        if (classCode == null || classCode.trim().isEmpty()) {
            System.out.println("수업 참여 실패: 수업 코드를 입력해주세요.");
            return false;
        }
        
        if (studentId == null || studentId <= 0) {
            System.out.println("수업 참여 실패: 유효하지 않은 학생 ID");
            return false;
        }
        
        // 수업 존재 여부 확인
        Class classInfo = classDAO.getClassByCode(classCode.trim().toUpperCase());
        if (classInfo == null) {
            System.out.println("수업 참여 실패: 존재하지 않는 수업 코드입니다.");
            return false;
        }
        
        // 참여 가능 여부 확인
        if (!classInfo.canJoin()) {
            System.out.println("수업 참여 실패: 참여할 수 없는 수업입니다. (상태: " + classInfo.getStatusKorean() + 
                             ", 인원: " + classInfo.getCurrentStudents() + "/" + classInfo.getMaxStudents() + ")");
            return false;
        }
        
        boolean result = classDAO.enrollStudent(classCode.trim().toUpperCase(), studentId);
        
        if (result) {
            System.out.println("수업 참여 성공: " + classInfo.getClassName() + " (코드: " + classCode + ")");
        } else {
            System.out.println("수업 참여 실패: 이미 참여한 수업이거나 데이터베이스 오류입니다.");
        }
        
        return result;
    }
    
    /**
     * 수업 정보 수정
     */
    public boolean updateClass(Long classId, Long professorId, String className, String description,
                              String startDateStr, String endDateStr, String startTimeStr,
                              String endTimeStr, String dayOfWeek, String maxStudentsStr, String status) {
        
        // 기본 입력값 검증
        if (classId == null || classId <= 0 || professorId == null || professorId <= 0) {
            System.out.println("수업 수정 실패: 유효하지 않은 수업 또는 교수 ID");
            return false;
        }
        
        if (!validateClassInput(className, description, professorId, startDateStr,
                               endDateStr, startTimeStr, endTimeStr, dayOfWeek)) {
            return false;
        }
        
        try {
            // 날짜/시간 파싱
            LocalDate startDate = LocalDate.parse(startDateStr);
            LocalDate endDate = LocalDate.parse(endDateStr);
            LocalTime startTime = LocalTime.parse(startTimeStr);
            LocalTime endTime = LocalTime.parse(endTimeStr);
            
            // 최대 학생 수 파싱
            int maxStudents = 50;
            if (maxStudentsStr != null && !maxStudentsStr.trim().isEmpty()) {
                maxStudents = Integer.parseInt(maxStudentsStr);
                if (maxStudents <= 0 || maxStudents > 500) {
                    System.out.println("수업 수정 실패: 최대 학생 수는 1-500명 사이여야 합니다.");
                    return false;
                }
            }
            
            // 날짜/시간 유효성 검증
            if (!validateDateTime(startDate, endDate, startTime, endTime)) {
                return false;
            }
            
            // 수업 객체 생성
            Class classInfo = new Class();
            classInfo.setId(classId);
            classInfo.setProfessorId(professorId);
            classInfo.setClassName(className.trim());
            classInfo.setDescription(description.trim());
            classInfo.setStartDate(startDate);
            classInfo.setEndDate(endDate);
            classInfo.setStartTime(startTime);
            classInfo.setEndTime(endTime);
            classInfo.setDayOfWeek(dayOfWeek);
            classInfo.setMaxStudents(maxStudents);
            
            // 상태 설정
            if (status != null && !status.trim().isEmpty()) {
                classInfo.setStatus(status);
            } else {
                // 날짜 기반 상태 자동 결정
                LocalDate today = LocalDate.now();
                if (endDate.isBefore(today)) {
                    classInfo.setStatus("completed");
                } else if (startDate.isBefore(today) || startDate.isEqual(today)) {
                    classInfo.setStatus("active");
                } else {
                    classInfo.setStatus("scheduled");
                }
            }
            
            boolean result = classDAO.updateClass(classInfo);
            
            if (result) {
                System.out.println("수업 정보 수정 성공: " + className);
            } else {
                System.out.println("수업 정보 수정 실패: 데이터베이스 오류 또는 권한 없음");
            }
            
            return result;
            
        } catch (DateTimeParseException e) {
            System.out.println("수업 수정 실패: 날짜/시간 형식이 올바르지 않습니다.");
            return false;
        } catch (NumberFormatException e) {
            System.out.println("수업 수정 실패: 최대 학생 수는 숫자여야 합니다.");
            return false;
        } catch (Exception e) {
            System.err.println("수업 수정 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 수업 삭제
     */
    public boolean deleteClass(Long classId, Long professorId) {
        if (classId == null || classId <= 0 || professorId == null || professorId <= 0) {
            System.out.println("수업 삭제 실패: 유효하지 않은 수업 또는 교수 ID");
            return false;
        }
        
        boolean result = classDAO.deleteClass(classId, professorId);
        
        if (result) {
            System.out.println("수업 삭제 성공: " + classId);
        } else {
            System.out.println("수업 삭제 실패: 데이터베이스 오류 또는 권한 없음");
        }
        
        return result;
    }
    
    /**
     * 수업 코드로 수업 정보 조회
     */
    public Class getClassByCode(String classCode) {
        if (classCode == null || classCode.trim().isEmpty()) {
            System.out.println("수업 조회 실패: 수업 코드를 입력해주세요.");
            return null;
        }
        
        Class classInfo = classDAO.getClassByCode(classCode.trim().toUpperCase());
        
        if (classInfo != null) {
            // 수업 상태 업데이트
            updateClassStatus(classInfo);
            System.out.println("수업 조회 성공: " + classInfo.getClassName());
        } else {
            System.out.println("수업 조회 실패: 존재하지 않는 수업 코드");
        }
        
        return classInfo;
    }
    
    /**
     * 수업 통계 정보 조회
     */
    public Class getClassStatistics(Long classId) {
        if (classId == null || classId <= 0) {
            System.out.println("수업 통계 조회 실패: 유효하지 않은 수업 ID");
            return null;
        }
        
        Class classInfo = classDAO.getClassStatistics(classId);
        
        if (classInfo != null) {
            System.out.println("수업 통계 조회 성공: " + classInfo.getClassName());
        } else {
            System.out.println("수업 통계 조회 실패: 존재하지 않는 수업");
        }
        
        return classInfo;
    }
    
    /**
     * 수업 코드 유효성 검사
     */
    public boolean validateClassCode(String classCode) {
        if (classCode == null || classCode.trim().isEmpty()) {
            return false;
        }
        
        String code = classCode.trim().toUpperCase();
        
        // 수업 코드 형식 검증 (영문 3자리 + 숫자 3자리)
        if (!code.matches("^[A-Z]{3}[0-9]{3}$")) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 수업 입력값 검증
     */
    private boolean validateClassInput(String className, String description, Long professorId,
                                     String startDateStr, String endDateStr, String startTimeStr,
                                     String endTimeStr, String dayOfWeek) {
        
        // 필수 입력값 확인
        if (className == null || className.trim().isEmpty()) {
            System.out.println("수업 검증 실패: 수업명을 입력해주세요.");
            return false;
        }
        
        if (className.trim().length() < 2 || className.trim().length() > 100) {
            System.out.println("수업 검증 실패: 수업명은 2자 이상 100자 이하여야 합니다.");
            return false;
        }
        
        if (professorId == null || professorId <= 0) {
            System.out.println("수업 검증 실패: 유효하지 않은 교수 ID입니다.");
            return false;
        }
        
        if (startDateStr == null || startDateStr.trim().isEmpty() ||
            endDateStr == null || endDateStr.trim().isEmpty()) {
            System.out.println("수업 검증 실패: 시작일과 종료일을 입력해주세요.");
            return false;
        }
        
        if (startTimeStr == null || startTimeStr.trim().isEmpty() ||
            endTimeStr == null || endTimeStr.trim().isEmpty()) {
            System.out.println("수업 검증 실패: 시작 시간과 종료 시간을 입력해주세요.");
            return false;
        }
        
        if (dayOfWeek == null || dayOfWeek.trim().isEmpty()) {
            System.out.println("수업 검증 실패: 수업 요일을 선택해주세요.");
            return false;
        }
        
        // 설명 길이 확인
        if (description != null && description.trim().length() > 500) {
            System.out.println("수업 검증 실패: 수업 설명은 500자 이하여야 합니다.");
            return false;
        }
        
        return true;
    }
    
    /**
     * 날짜/시간 유효성 검증
     */
    private boolean validateDateTime(LocalDate startDate, LocalDate endDate, 
                                   LocalTime startTime, LocalTime endTime) {
        
        // 날짜 검증
        if (startDate.isAfter(endDate)) {
            System.out.println("수업 검증 실패: 시작일은 종료일보다 이전이어야 합니다.");
            return false;
        }
        
        // 과거 날짜 확인 (7일 이전까지만 허용)
        LocalDate minDate = LocalDate.now().minusDays(7);
        if (startDate.isBefore(minDate)) {
            System.out.println("수업 검증 실패: 시작일이 너무 과거입니다.");
            return false;
        }
        
        // 너무 먼 미래 확인 (2년 후까지만 허용)
        LocalDate maxDate = LocalDate.now().plusYears(2);
        if (endDate.isAfter(maxDate)) {
            System.out.println("수업 검증 실패: 종료일이 너무 미래입니다.");
            return false;
        }
        
        // 시간 검증
        if (startTime.isAfter(endTime) || startTime.equals(endTime)) {
            System.out.println("수업 검증 실패: 시작 시간은 종료 시간보다 이전이어야 합니다.");
            return false;
        }
        
        // 수업 시간 길이 확인 (최소 30분, 최대 8시간)
        long minutes = java.time.Duration.between(startTime, endTime).toMinutes();
        if (minutes < 30) {
            System.out.println("수업 검증 실패: 수업 시간은 최소 30분 이상이어야 합니다.");
            return false;
        }
        if (minutes > 480) { // 8시간
            System.out.println("수업 검증 실패: 수업 시간은 최대 8시간 이하여야 합니다.");
            return false;
        }
        
        return true;
    }
    
    /**
     * 수업 상태 자동 업데이트 (단일)
     */
    private void updateClassStatus(Class classInfo) {
        if (classInfo == null) return;
        
        LocalDate today = LocalDate.now();
        String currentStatus = classInfo.getStatus();
        String newStatus = currentStatus;
        
        // 상태 자동 결정
        if (classInfo.getEndDate().isBefore(today)) {
            newStatus = "completed";
        } else if (classInfo.getStartDate().isBefore(today) || classInfo.getStartDate().isEqual(today)) {
            if (!"completed".equals(currentStatus)) {
                newStatus = "active";
            }
        } else {
            if (!"completed".equals(currentStatus) && !"active".equals(currentStatus)) {
                newStatus = "scheduled";
            }
        }
        
        // 상태가 변경된 경우에만 업데이트
        if (!currentStatus.equals(newStatus)) {
            classInfo.setStatus(newStatus);
            // 실제 DB 업데이트는 별도 스케줄러에서 처리하거나 필요시 구현
        }
    }
    
    /**
     * 수업 상태 자동 업데이트 (리스트)
     */
    private void updateClassStatuses(List<Class> classList) {
        if (classList == null || classList.isEmpty()) return;
        
        for (Class classInfo : classList) {
            updateClassStatus(classInfo);
        }
    }
    
    /**
     * 수업 검색
     */
    public List<Class> searchClasses(String keyword, String status, Long professorId) {
        // 현재는 기본 구현으로 교수의 수업 목록만 반환
        // 실제로는 제목, 설명 등으로 검색하는 기능 구현 필요
        if (professorId != null) {
            return getProfessorClasses(professorId, status);
        }
        
        return List.of();
    }
    
    /**
     * 인기 수업 목록 조회 (참여율 기준)
     */
    public List<Class> getPopularClasses(int limit) {
        // 현재는 기본 구현
        // 실제로는 참여율, 평점 등을 기준으로 인기 수업을 조회하는 기능 구현 필요
        return List.of();
    }
    
    /**
     * 수업 요일 문자열 검증
     */
    public boolean validateDayOfWeek(String dayOfWeek) {
        if (dayOfWeek == null || dayOfWeek.trim().isEmpty()) {
            return false;
        }
        
        // JSON 배열 형태나 쉼표로 구분된 요일 문자열 검증
        String[] validDays = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};
        
        try {
            // 간단한 검증 (실제로는 JSON 파싱 등 더 정교한 검증 필요)
            for (String validDay : validDays) {
                if (dayOfWeek.toUpperCase().contains(validDay)) {
                    return true;
                }
            }
        } catch (Exception e) {
            System.err.println("요일 검증 중 오류: " + e.getMessage());
        }
        
        return false;
    }
}