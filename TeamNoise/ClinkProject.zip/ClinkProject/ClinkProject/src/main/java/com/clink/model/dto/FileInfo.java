package com.clink.model.dto;

import java.time.LocalDateTime;
import java.sql.Timestamp;

/**
 * 파일 정보 DTO 클래스 - 완전한 버전
 * FileController, FileDAO, FileService와 완전 호환
 * attachments 테이블과 정확히 매핑
 */
public class FileInfo {
    
    // 기본 속성 (attachments 테이블과 매핑)
    private Integer attachmentId;          // attachment_id (Primary Key)
    private Integer postId;                // post_id (Foreign Key, nullable)
    private String originalName;           // original_filename
    private String savedName;              // stored_filename
    private String filePath;               // file_path
    private Long fileSize;                 // file_size
    private String fileType;               // file_type
    private String mimeType;               // mime_type
    private Integer downloadCount;         // download_count
    private LocalDateTime uploadDate;      // uploaded_at을 LocalDateTime으로 변환
    
    // 추가 속성 (비즈니스 로직용)
    private String status;                 // 파일 상태 (active, deleted 등)
    private String description;            // 파일 설명
    
    // 조인 결과용 추가 정보
    private String uploaderName;           // 업로더 이름 (users 테이블 조인)
    private String className;              // 수업 이름 (classes 테이블 조인)
    
    /**
     * 기본 생성자
     */
    public FileInfo() {
        this.downloadCount = 0;
        this.status = "active";
        this.uploadDate = LocalDateTime.now();
    }
    
    /**
     * 필수 정보 생성자 (파일 업로드용)
     */
    public FileInfo(String originalName, String savedName, String filePath, 
                   Long fileSize, String fileType) {
        this();
        this.originalName = originalName;
        this.savedName = savedName;
        this.filePath = filePath;
        this.fileSize = fileSize;
        this.fileType = fileType;
        this.mimeType = determineMimeType(fileType);
    }
    
    // ===== 기본 Getters and Setters =====
    
    /**
     * 파일 ID (Primary Key)
     */
    public Integer getId() {
        return attachmentId;
    }
    
    public void setId(Integer id) {
        this.attachmentId = id;
    }
    
    /**
     * FileController 호환: getAttachmentId()
     */
    public Integer getAttachmentId() {
        return attachmentId;
    }
    
    public void setAttachmentId(Integer attachmentId) {
        this.attachmentId = attachmentId;
    }
    
    /**
     * 게시글 ID
     */
    public Integer getPostId() {
        return postId;
    }
    
    public void setPostId(Integer postId) {
        this.postId = postId;
    }
    
    /**
     * 원본 파일명
     */
    public String getOriginalName() {
        return originalName;
    }
    
    public void setOriginalName(String originalName) {
        this.originalName = originalName;
    }
    
    /**
     * FileController 호환: getOriginalFilename()
     */
    public String getOriginalFilename() {
        return originalName;
    }
    
    public void setOriginalFilename(String originalFilename) {
        this.originalName = originalFilename;
    }
    
    /**
     * 저장된 파일명
     */
    public String getSavedName() {
        return savedName;
    }
    
    public void setSavedName(String savedName) {
        this.savedName = savedName;
    }
    
    /**
     * FileController 호환: getStoredFilename()
     */
    public String getStoredFilename() {
        return savedName;
    }
    
    public void setStoredFilename(String storedFilename) {
        this.savedName = storedFilename;
    }
    
    /**
     * 파일 저장 경로
     */
    public String getFilePath() {
        return filePath;
    }
    
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    /**
     * 파일 크기 (바이트)
     */
    public Long getFileSize() {
        return fileSize;
    }
    
    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }
    
    /**
     * 파일 확장자
     */
    public String getFileType() {
        return fileType;
    }
    
    public void setFileType(String fileType) {
        this.fileType = fileType;
        // 파일 타입이 설정되면 MIME 타입도 자동 업데이트
        if (this.mimeType == null) {
            this.mimeType = determineMimeType(fileType);
        }
    }
    
    /**
     * MIME 타입
     */
    public String getMimeType() {
        if (mimeType == null && fileType != null) {
            mimeType = determineMimeType(fileType);
        }
        return mimeType;
    }
    
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }
    
    /**
     * 다운로드 횟수
     */
    public Integer getDownloadCount() {
        return downloadCount;
    }
    
    public void setDownloadCount(Integer downloadCount) {
        this.downloadCount = downloadCount;
    }
    
    /**
     * 업로드 일시 (LocalDateTime)
     */
    public LocalDateTime getUploadDate() {
        return uploadDate;
    }
    
    public void setUploadDate(LocalDateTime uploadDate) {
        this.uploadDate = uploadDate;
    }
    
    /**
     * FileController 호환: getUploadedAt() - Timestamp 반환
     */
    public Timestamp getUploadedAt() {
        if (uploadDate != null) {
            return Timestamp.valueOf(uploadDate);
        }
        return null;
    }
    
    public void setUploadedAt(Timestamp uploadedAt) {
        if (uploadedAt != null) {
            this.uploadDate = uploadedAt.toLocalDateTime();
        }
    }
    
    /**
     * 파일 상태
     */
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * 파일 설명
     */
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    /**
     * 업로더 이름 (조인 결과)
     */
    public String getUploaderName() {
        return uploaderName;
    }
    
    public void setUploaderName(String uploaderName) {
        this.uploaderName = uploaderName;
    }
    
    /**
     * 수업 이름 (조인 결과)
     */
    public String getClassName() {
        return className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }
    
    // ===== 유틸리티 메서드 =====
    
    /**
     * 파일 크기를 사람이 읽기 쉬운 형태로 반환
     */
    public String getFormattedFileSize() {
        if (fileSize == null) return "0 B";
        
        if (fileSize < 1024) return fileSize + " B";
        if (fileSize < 1024 * 1024) return String.format("%.1f KB", fileSize / 1024.0);
        if (fileSize < 1024 * 1024 * 1024) return String.format("%.1f MB", fileSize / (1024.0 * 1024.0));
        return String.format("%.1f GB", fileSize / (1024.0 * 1024.0 * 1024.0));
    }
    
    /**
     * 파일이 이미지인지 확인
     */
    public boolean isImage() {
        if (fileType == null) return false;
        String type = fileType.toLowerCase();
        return type.equals("jpg") || type.equals("jpeg") || type.equals("png") || 
               type.equals("gif") || type.equals("bmp") || type.equals("webp");
    }
    
    /**
     * 파일이 문서인지 확인
     */
    public boolean isDocument() {
        if (fileType == null) return false;
        String type = fileType.toLowerCase();
        return type.equals("pdf") || type.equals("doc") || type.equals("docx") || 
               type.equals("ppt") || type.equals("pptx") || type.equals("xls") || 
               type.equals("xlsx") || type.equals("hwp") || type.equals("txt");
    }
    
    /**
     * 파일이 압축파일인지 확인
     */
    public boolean isArchive() {
        if (fileType == null) return false;
        String type = fileType.toLowerCase();
        return type.equals("zip") || type.equals("rar") || type.equals("7z") || 
               type.equals("tar") || type.equals("gz");
    }
    
    /**
     * 파일 타입에 따른 CSS 클래스 반환 (UI용)
     */
    public String getFileTypeClass() {
        if (isImage()) return "file-image";
        if (isDocument()) return "file-document";
        if (isArchive()) return "file-archive";
        return "file-other";
    }
    
    /**
     * 파일 타입에 따른 아이콘 이름 반환 (UI용)
     */
    public String getFileIcon() {
        if (fileType == null) return "file-o";
        
        String type = fileType.toLowerCase();
        switch (type) {
            case "pdf": return "file-pdf-o";
            case "doc": case "docx": return "file-word-o";
            case "ppt": case "pptx": return "file-powerpoint-o";
            case "xls": case "xlsx": return "file-excel-o";
            case "jpg": case "jpeg": case "png": case "gif": return "file-image-o";
            case "zip": case "rar": case "7z": return "file-archive-o";
            case "txt": return "file-text-o";
            case "hwp": return "file-o";
            default: return "file-o";
        }
    }
    
    /**
     * 파일 확장자를 기반으로 MIME 타입 결정
     */
    private String determineMimeType(String fileType) {
        if (fileType == null) return "application/octet-stream";
        
        String type = fileType.toLowerCase();
        switch (type) {
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "ppt": return "application/vnd.ms-powerpoint";
            case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "hwp": return "application/x-hwp";
            case "zip": return "application/zip";
            case "rar": return "application/x-rar-compressed";
            case "7z": return "application/x-7z-compressed";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "bmp": return "image/bmp";
            case "webp": return "image/webp";
            case "txt": return "text/plain";
            case "html": return "text/html";
            case "css": return "text/css";
            case "js": return "application/javascript";
            case "json": return "application/json";
            case "xml": return "application/xml";
            default: return "application/octet-stream";
        }
    }
    
    // ===== Object 메서드 오버라이드 =====
    
    @Override
    public String toString() {
        return "FileInfo{" +
                "attachmentId=" + attachmentId +
                ", originalName='" + originalName + '\'' +
                ", savedName='" + savedName + '\'' +
                ", fileSize=" + fileSize +
                ", fileType='" + fileType + '\'' +
                ", downloadCount=" + downloadCount +
                ", uploadDate=" + uploadDate +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        FileInfo fileInfo = (FileInfo) obj;
        return attachmentId != null ? attachmentId.equals(fileInfo.attachmentId) : fileInfo.attachmentId == null;
    }
    
    @Override
    public int hashCode() {
        return attachmentId != null ? attachmentId.hashCode() : 0;
    }
}