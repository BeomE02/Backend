package com.clink.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 데이터베이스 연결 유틸리티 클래스 (MariaDB 전용) - UTF-8 인코딩 강화 버전
 * 기존 모든 기능 유지 + 한글 파일명 완전 지원
 */
public class DBConnection {
    
    // 🔥 핵심 수정: UTF-8 인코딩 매개변수 추가
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/clink_db" +
            "?useUnicode=true" +                    // 유니코드 사용
            "&characterEncoding=UTF-8" +            // 문자 인코딩 UTF-8
            "&serverTimezone=Asia/Seoul" +          // 서버 타임존
            "&allowMultiQueries=true" +             // 다중 쿼리 허용
            "&autoReconnect=true" +                 // 자동 재연결
            "&useSSL=false" +                       // SSL 비활성화 (로컬 개발)
            "&allowPublicKeyRetrieval=true" +       // 공개키 검색 허용
            "&connectionCollation=utf8mb4_unicode_ci" + // 🆕 연결 콜레이션
            "&characterSetResults=utf8mb4" +        // 🆕 결과 문자셋
            "&zeroDateTimeBehavior=convertToNull";  // 🆕 날짜 처리
    
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1111";
    private static final String DB_DRIVER = "org.mariadb.jdbc.Driver";
    
    // 드라이버 로딩 (static 블록에서 한 번만 실행)
    static {
        try {
            // MariaDB JDBC 드라이버 로드
            Class.forName(DB_DRIVER);
            System.out.println("✅ MariaDB JDBC 드라이버 로드 성공");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ MariaDB JDBC 드라이버 로드 실패: " + e.getMessage());
            System.err.println("해결방법: MariaDB JDBC 드라이버 JAR 파일을 WEB-INF/lib 폴더에 추가하세요");
            System.err.println("파일명: mariadb-java-client-3.x.x.jar");
            e.printStackTrace();
        }
    }
    
    /**
     * 데이터베이스 연결 객체 반환 (UTF-8 인코딩 완전 지원)
     */
    public static Connection getConnection() throws SQLException {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            conn.setAutoCommit(true);  // 기본적으로 자동 커밋 사용
            
            // 🔥 핵심 추가: 연결 생성 후 즉시 UTF-8 설정 적용
            try (Statement stmt = conn.createStatement()) {
                // MariaDB/MySQL UTF-8 설정 완전 적용
                stmt.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                stmt.execute("SET CHARACTER SET utf8mb4");
                stmt.execute("SET character_set_client = utf8mb4");
                stmt.execute("SET character_set_results = utf8mb4");
                stmt.execute("SET character_set_connection = utf8mb4");
                stmt.execute("SET collation_connection = utf8mb4_unicode_ci");
                
                System.out.println("✅ MariaDB 연결 성공 (UTF-8 인코딩 완전 적용)");
            }
            
            return conn;
        } catch (SQLException e) {
            System.err.println("❌ MariaDB 연결 실패");
            System.err.println("에러 코드: " + e.getErrorCode());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("메시지: " + e.getMessage());
            
            // MariaDB 특화 오류 해결책
            switch (e.getErrorCode()) {
                case 0:
                    if (e.getMessage().contains("Connection refused")) {
                        System.err.println("🔧 해결책: MariaDB 서버를 시작하세요");
                        System.err.println("   명령어: sudo systemctl start mariadb");
                    } else if (e.getMessage().contains("Unknown database")) {
                        System.err.println("🔧 해결책: clink_db 데이터베이스를 생성하세요");
                        System.err.println("   명령어: CREATE DATABASE clink_db;");
                    }
                    break;
                case 1045:
                    System.err.println("🔧 해결책: MariaDB 사용자명/비밀번호를 확인하세요");
                    System.err.println("   테스트: mysql -u root -p");
                    break;
                case 1049:
                    System.err.println("🔧 해결책: clink_db 데이터베이스를 생성하세요");
                    break;
                default:
                    System.err.println("🔧 해결책: MariaDB 설정을 확인하세요");
            }
            throw e;
        }
    }
    
    /**
     * 트랜잭션용 연결 (자동 커밋 비활성화)
     */
    public static Connection getTransactionConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        conn.setAutoCommit(false);
        
        // 🔥 트랜잭션 연결에도 UTF-8 설정 적용
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
            stmt.execute("SET CHARACTER SET utf8mb4");
            System.out.println("✅ 트랜잭션 연결 생성 (UTF-8 인코딩 적용)");
        }
        
        return conn;
    }
    
    /**
     * 트랜잭션 커밋
     */
    public static void commit(Connection conn) {
        if (conn != null) {
            try {
                conn.commit();
                System.out.println("트랜잭션 커밋 완료");
            } catch (SQLException e) {
                System.err.println("트랜잭션 커밋 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 트랜잭션 롤백
     */
    public static void rollback(Connection conn) {
        if (conn != null) {
            try {
                conn.rollback();
                System.out.println("트랜잭션 롤백 완료");
            } catch (SQLException e) {
                System.err.println("트랜잭션 롤백 실패: " + e.getMessage());
            }
        }
    }
    
    /**
     * 연결 닫기
     */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                if (!conn.isClosed()) {
                    conn.close();
                    System.out.println("데이터베이스 연결 종료");
                }
            } catch (SQLException e) {
                System.err.println("연결 종료 오류: " + e.getMessage());
            }
        }
    }
    
    /**
     * PreparedStatement 닫기
     */
    public static void close(PreparedStatement pstmt) {
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                System.err.println("PreparedStatement 닫기 오류: " + e.getMessage());
            }
        }
    }
    
    /**
     * ResultSet 닫기
     */
    public static void close(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("ResultSet 닫기 오류: " + e.getMessage());
            }
        }
    }
    
    /**
     * 모든 리소스 닫기
     */
    public static void closeAll(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        close(rs);
        close(pstmt);
        closeConnection(conn);
    }
    
    /**
     * 연결 테스트 (UTF-8 인코딩 확인 추가)
     */
    public static boolean testConnection() {
        System.out.println("=== MariaDB 연결 테스트 시작 ===");
        
        try (Connection conn = getConnection()) {
            System.out.println("데이터베이스 제품: " + conn.getMetaData().getDatabaseProductName());
            System.out.println("데이터베이스 버전: " + conn.getMetaData().getDatabaseProductVersion());
            System.out.println("현재 데이터베이스: " + conn.getCatalog());
            System.out.println("JDBC 드라이버: " + conn.getMetaData().getDriverName());
            System.out.println("드라이버 버전: " + conn.getMetaData().getDriverVersion());
            
            // 🆕 UTF-8 설정 확인
            System.out.println("\n🔤 현재 문자셋 설정 확인:");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SHOW VARIABLES LIKE 'character_set_%'")) {
                while (rs.next()) {
                    System.out.println("  " + rs.getString(1) + " = " + rs.getString(2));
                }
            }
            
            // 테이블 존재 확인
            String[] tables = {"users", "classes", "posts", "comments", "board_categories", 
                             "professor_auth_codes", "attachments"};
            System.out.println("\n📋 테이블 존재 확인:");
            for (String table : tables) {
                if (tableExists(conn, table)) {
                    System.out.println("✅ " + table + " 테이블 존재");
                } else {
                    System.out.println("❌ " + table + " 테이블 누락");
                }
            }
            
            // 🆕 attachments 테이블 인코딩 확인
            System.out.println("\n🔤 attachments 테이블 인코딩 확인:");
            String encodingQuery = """
                SELECT COLUMN_NAME, CHARACTER_SET_NAME, COLLATION_NAME
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = 'clink_db' 
                  AND TABLE_NAME = 'attachments' 
                  AND COLUMN_NAME IN ('original_filename', 'stored_filename')
                """;
            
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(encodingQuery)) {
                while (rs.next()) {
                    System.out.println("  " + rs.getString("COLUMN_NAME") + 
                                     " - " + rs.getString("CHARACTER_SET_NAME") + 
                                     " / " + rs.getString("COLLATION_NAME"));
                }
            }
            
            System.out.println("\n=== 연결 테스트 완료: 성공 ===");
            return true;
            
        } catch (SQLException e) {
            System.err.println("\n=== 연결 테스트 완료: 실패 ===");
            System.err.println("오류: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 테이블 존재 여부 확인
     */
    private static boolean tableExists(Connection conn, String tableName) {
        try {
            String sql = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, "clink_db");
                pstmt.setString(2, tableName);
                try (ResultSet rs = pstmt.executeQuery()) {
                    return rs.next() && rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            return false;
        }
    }
    
    /**
     * 데이터베이스 초기 설정 확인
     */
    public static boolean checkDatabaseSetup() {
        System.out.println("\n📊 데이터베이스 초기 설정 확인 중...");
        
        try (Connection conn = getConnection()) {
            // 기본 카테고리 데이터 확인
            String sql = "SELECT COUNT(*) FROM board_categories WHERE is_active = TRUE";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                rs.next();
                int categoryCount = rs.getInt(1);
                
                if (categoryCount == 0) {
                    System.out.println("⚠️ 게시판 카테고리 데이터가 없습니다. 초기 데이터를 삽입하세요.");
                    return false;
                } else {
                    System.out.println("✅ 게시판 카테고리: " + categoryCount + "개");
                }
            }
            
            // 교수 인증 코드 확인
            sql = "SELECT COUNT(*) FROM professor_auth_codes WHERE is_active = TRUE";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                rs.next();
                int authCodeCount = rs.getInt(1);
                
                if (authCodeCount == 0) {
                    System.out.println("⚠️ 교수 인증 코드가 없습니다. 초기 데이터를 삽입하세요.");
                    return false;
                } else {
                    System.out.println("✅ 교수 인증 코드: " + authCodeCount + "개");
                }
            }
            
            // 🆕 attachments 테이블 확인
            sql = "SELECT COUNT(*) FROM attachments";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                rs.next();
                int attachmentCount = rs.getInt(1);
                System.out.println("✅ 첨부파일: " + attachmentCount + "개");
            }
            
            System.out.println("✅ 데이터베이스 초기 설정이 완료되었습니다.");
            return true;
            
        } catch (SQLException e) {
            System.err.println("데이터베이스 설정 확인 실패: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 🆕 데이터베이스 인코딩 설정 확인 및 가이드
     */
    public static void checkDatabaseEncoding() {
        System.out.println("\n🔤 데이터베이스 인코딩 설정 확인 중...");
        
        try (Connection conn = getConnection()) {
            // 데이터베이스 인코딩 확인
            String sql = "SELECT DEFAULT_CHARACTER_SET_NAME, DEFAULT_COLLATION_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = 'clink_db'";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                
                if (rs.next()) {
                    String charset = rs.getString(1);
                    String collation = rs.getString(2);
                    System.out.println("현재 데이터베이스 인코딩: " + charset + " / " + collation);
                    
                    if (!"utf8mb4".equals(charset)) {
                        System.out.println("⚠️ UTF8MB4가 아닙니다. 다음 SQL을 실행하세요:");
                        System.out.println("   ALTER DATABASE clink_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
                        System.out.println("   ALTER TABLE attachments CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
                    } else {
                        System.out.println("✅ UTF8MB4 인코딩이 올바르게 설정되어 있습니다.");
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("인코딩 확인 실패: " + e.getMessage());
        }
    }
    
    /**
     * 연결 정보 출력
     */
    public static void printConnectionInfo() {
        System.out.println("=== MariaDB 연결 정보 ===");
        System.out.println("URL: " + DB_URL);
        System.out.println("사용자: " + DB_USER);
        System.out.println("드라이버: " + DB_DRIVER);
        System.out.println("========================");
    }
    
    /**
     * 메인 메서드 (이클립스에서 우클릭 → Run As → Java Application)
     */
    public static void main(String[] args) {
        System.out.println("🚀 Clink MariaDB 연결 테스트 시작 (UTF-8 인코딩 강화 버전)...\n");
        
        printConnectionInfo();
        
        if (testConnection()) {
            checkDatabaseEncoding();  // 🆕 인코딩 확인 추가
            
            if (checkDatabaseSetup()) {
                System.out.println("\n🎉 모든 설정이 완료되었습니다! 애플리케이션을 시작할 수 있습니다.");
            } else {
                System.out.println("\n⚠️ 기본 데이터 설정이 필요합니다.");
            }
        } else {
            System.out.println("\n❌ 설정을 다시 확인해주세요.");
            System.out.println("\n📋 해결 체크리스트:");
            System.out.println("1. MariaDB 서버 실행: sudo systemctl start mariadb");
            System.out.println("2. MariaDB 접속 테스트: mysql -u root -p");
            System.out.println("3. clink_db 데이터베이스 생성: CREATE DATABASE clink_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
            System.out.println("4. MariaDB JDBC 드라이버 JAR 파일 추가 (mariadb-java-client-3.x.x.jar)");
            System.out.println("5. 비밀번호 확인");
            System.out.println("6. UTF8MB4 인코딩 설정 확인");
        }
    }
}