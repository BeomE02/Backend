package com.clink.model.dto;

import java.sql.Timestamp;

/**
 * 댓글 데이터 전송 객체 (실제 DB 스키마에 맞춤)
 * 🔥 JSP 호환성을 위한 commentId getter 추가
 * 🔥 JSP fmt:formatDate 호환성을 위해 Timestamp 사용
 */
public class Comment {
    
    // 기본 필드 (comments 테이블)
    private int id;                    // comment_id
    private int postId;                // post_id
    private int authorId;              // author_id
    private String content;            // content
    private Integer parentId;          // parent_comment_id (nullable)
    private boolean isAnonymous;       // is_anonymous
    private String status;             // status
    private Timestamp createdAt;       // created_at (JSP 호환을 위해 Timestamp 사용)
    private Timestamp updatedAt;       // updated_at (JSP 호환을 위해 Timestamp 사용)
    
    // 조인된 추가 정보
    private String authorName;         // users.name (익명 처리됨)
    private String authorRole;         // users.role (BoardDAO 연동용)
    private String postTitle;          // posts.title (사용자 댓글 목록용)
    
    // 기본 생성자
    public Comment() {
        this.isAnonymous = false;
        this.status = "active";
    }
    
    // 주요 필드 생성자 (일반 댓글)
    public Comment(int postId, int authorId, String content) {
        this();
        this.postId = postId;
        this.authorId = authorId;
        this.content = content;
    }
    
    // 대댓글 생성자
    public Comment(int postId, int authorId, String content, Integer parentId) {
        this();
        this.postId = postId;
        this.authorId = authorId;
        this.content = content;
        this.parentId = parentId;
    }
    
    // ===== 기본 Getter 메서드들 =====
    
    public int getId() { 
        return id; 
    }
    
    /**
     * 🔥 JSP 호환성을 위한 commentId getter 추가
     * ${comment.commentId} 접근을 위해 필요
     */
    public int getCommentId() { 
        return id; 
    }
    
    public int getPostId() { 
        return postId; 
    }
    
    public int getAuthorId() { 
        return authorId; 
    }
    
    public String getContent() { 
        return content; 
    }
    
    public Integer getParentId() { 
        return parentId; 
    }
    
    public boolean isAnonymous() { 
        return isAnonymous; 
    }
    
    public String getStatus() { 
        return status; 
    }
    
    public Timestamp getCreatedAt() { 
        return createdAt; 
    }
    
    public Timestamp getUpdatedAt() { 
        return updatedAt; 
    }
    
    // ===== 조인된 정보 Getter =====
    
    public String getAuthorName() { 
        return authorName; 
    }
    
    public String getAuthorRole() { 
        return authorRole; 
    }
    
    public String getPostTitle() { 
        return postTitle; 
    }
    
    // ===== 기본 Setter 메서드들 =====
    
    public void setId(int id) { 
        this.id = id; 
    }
    
    /**
     * 🔥 JSP 호환성을 위한 commentId setter 추가
     */
    public void setCommentId(int commentId) { 
        this.id = commentId; 
    }
    
    public void setPostId(int postId) { 
        this.postId = postId; 
    }
    
    public void setAuthorId(int authorId) { 
        this.authorId = authorId; 
    }
    
    public void setContent(String content) { 
        this.content = content; 
    }
    
    public void setParentId(Integer parentId) { 
        this.parentId = parentId; 
    }
    
    public void setAnonymous(boolean anonymous) { 
        this.isAnonymous = anonymous; 
    }
    
    public void setStatus(String status) { 
        this.status = status; 
    }
    
    public void setCreatedAt(Timestamp createdAt) { 
        this.createdAt = createdAt; 
    }
    
    public void setUpdatedAt(Timestamp updatedAt) { 
        this.updatedAt = updatedAt; 
    }
    
    // ===== 조인된 정보 Setter =====
    
    public void setAuthorName(String authorName) { 
        this.authorName = authorName; 
    }
    
    public void setAuthorRole(String authorRole) { 
        this.authorRole = authorRole; 
    }
    
    public void setPostTitle(String postTitle) { 
        this.postTitle = postTitle; 
    }
    
    // ===== 유틸리티 메서드들 =====
    
    /**
     * 현재 사용자가 이 댓글의 작성자인지 확인
     */
    public boolean isAuthor(int userId) {
        return this.authorId == userId;
    }
    
    /**
     * 대댓글인지 확인
     */
    public boolean isReply() {
        return this.parentId != null && this.parentId > 0;
    }
    
    /**
     * 삭제된 댓글인지 확인
     */
    public boolean isDeleted() {
        return "deleted".equals(this.status);
    }
    
    /**
     * 활성 댓글인지 확인
     */
    public boolean isActive() {
        return "active".equals(this.status);
    }
    
    /**
     * 댓글 내용 요약 (미리보기용)
     */
    public String getSummary(int maxLength) {
        if (this.content == null) return "";
        
        String plainContent = getPlainContent();
        if (plainContent.length() <= maxLength) {
            return plainContent;
        }
        return plainContent.substring(0, maxLength) + "...";
    }
    
    /**
     * 댓글 표시용 제목 (댓글 관리용)
     */
    public String getDisplayTitle() {
        String type = isReply() ? "대댓글" : "댓글";
        return String.format("[%s %d] %s (작성자: %s)", 
                           type, this.id, getSummary(50), this.authorName);
    }
    
    /**
     * 댓글 깊이 반환 (0: 일반 댓글, 1: 대댓글)
     */
    public int getDepth() {
        return isReply() ? 1 : 0;
    }
    
    /**
     * 댓글 유효성 검증
     */
    public boolean isValid() {
        if (this.postId <= 0) return false;
        if (this.authorId <= 0) return false;
        if (this.content == null || this.content.trim().isEmpty()) return false;
        if (this.content.length() > 1000) return false;
        
        // 대댓글의 경우 부모 댓글 ID가 유효해야 함
        if (this.parentId != null && this.parentId <= 0) return false;
        
        return true;
    }
    
    /**
     * 댓글 내용에서 HTML 태그 제거 (보안용)
     */
    public String getPlainContent() {
        if (this.content == null) return "";
        
        // 기본적인 HTML 태그 제거 (실제로는 더 정교한 필터링 필요)
        return this.content
                .replaceAll("<[^>]+>", "")
                .replaceAll("&nbsp;", " ")
                .replaceAll("&lt;", "<")
                .replaceAll("&gt;", ">")
                .replaceAll("&amp;", "&")
                .trim();
    }
    
    /**
     * 댓글 내용의 글자 수 반환 (HTML 태그 제외)
     */
    public int getContentLength() {
        return getPlainContent().length();
    }
    
    /**
     * 댓글이 비어있는지 확인
     */
    public boolean isEmpty() {
        return getPlainContent().isEmpty();
    }
    
    /**
     * 댓글이 수정되었는지 확인
     */
    public boolean isModified() {
        if (this.createdAt == null || this.updatedAt == null) {
            return false;
        }
        
        // 1초 이상 차이나면 수정된 것으로 간주
        long diffInMs = this.updatedAt.getTime() - this.createdAt.getTime();
        return diffInMs > 1000; // 1초 = 1000ms
    }
    
    /**
     * 댓글 표시용 타입 반환
     */
    public String getDisplayType() {
        if (isReply()) {
            return "대댓글";
        } else {
            return "댓글";
        }
    }
    
    /**
     * 댓글 들여쓰기 레벨 반환 (CSS 클래스용)
     */
    public String getIndentClass() {
        return isReply() ? "reply-indent" : "comment-indent";
    }
    
    /**
     * 작성자 정보 요약 (역할 포함)
     */
    public String getAuthorInfo() {
        if (isAnonymous) {
            return "익명";
        }
        
        String name = authorName != null ? authorName : "알 수 없음";
        String role = "";
        
        if ("professor".equals(authorRole)) {
            role = " (교수)";
        } else if ("student".equals(authorRole)) {
            role = " (학생)";
        }
        
        return name + role;
    }
    
    /**
     * 댓글 권한 체크 (수정/삭제 가능 여부)
     */
    public boolean canModify(int userId, String userRole) {
        // 본인이 작성한 댓글은 수정 가능
        if (isAuthor(userId)) {
            return true;
        }
        
        // 교수는 모든 댓글 삭제 가능 (수정은 불가)
        if ("professor".equals(userRole)) {
            return false; // 수정은 본인만 가능
        }
        
        return false;
    }
    
    /**
     * 댓글 삭제 권한 체크
     */
    public boolean canDelete(int userId, String userRole) {
        // 본인이 작성한 댓글은 삭제 가능
        if (isAuthor(userId)) {
            return true;
        }
        
        // 교수는 모든 댓글 삭제 가능
        if ("professor".equals(userRole)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 디버깅용 toString 메서드
     */
    @Override
    public String toString() {
        return String.format("Comment{id=%d, postId=%d, authorId=%d, parentId=%s, " +
                           "isAnonymous=%b, status='%s', content='%s', authorRole='%s', createdAt=%s}",
                           id, postId, authorId, parentId, isAnonymous, status, 
                           getSummary(30), authorRole, createdAt);
    }
    
    /**
     * 객체 비교 메서드
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Comment comment = (Comment) obj;
        return id == comment.id;
    }
    
    /**
     * 해시코드 메서드
     */
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
    
    /**
     * 댓글 복사 메서드 (수정용)
     */
    public Comment copy() {
        Comment copy = new Comment();
        copy.setId(this.id);
        copy.setPostId(this.postId);
        copy.setAuthorId(this.authorId);
        copy.setContent(this.content);
        copy.setParentId(this.parentId);
        copy.setAnonymous(this.isAnonymous);
        copy.setStatus(this.status);
        copy.setCreatedAt(this.createdAt);
        copy.setUpdatedAt(this.updatedAt);
        copy.setAuthorName(this.authorName);
        copy.setAuthorRole(this.authorRole);
        copy.setPostTitle(this.postTitle);
        
        return copy;
    }
}