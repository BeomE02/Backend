package com.clink.controller;

import java.io.*;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.clink.model.dto.FileInfo;
import com.clink.model.service.FileService;

/**
 * 파일 업로드/다운로드 처리 서블릿 - 한글 파일명 완전 해결 버전
 * 게시글 첨부파일과 강의자료 파일 관리
 * Jackson 라이브러리 없이 수동 JSON 처리
 * 
 * URL 패턴:
 * /file/upload      ← 파일 업로드 (POST)
 * /file/download/1  ← 파일 다운로드 (GET)
 * /file/info/1      ← 파일 정보 조회 (GET)
 * /file/list/post/1 ← 게시글별 파일 목록 (GET)
 * /file/delete/1    ← 파일 삭제 (DELETE)
 */
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,    // 1MB
    maxFileSize = 1024 * 1024 * 10,     // 10MB
    maxRequestSize = 1024 * 1024 * 50   // 50MB
)
public class FileController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private FileService fileService;
    
    // 파일 저장 경로 (실제 환경에서는 설정 파일에서 읽어오기)
    private static final String UPLOAD_PATH = "/uploads";
    
    // 최대 파일 크기 (10MB)
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;
    
    // 허용 파일 확장자
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
        "pdf", "doc", "docx", "ppt", "pptx", "hwp", "zip", "rar", 
        "jpg", "jpeg", "png", "gif", "txt", "xls", "xlsx"
    );

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            this.fileService = new FileService();
            System.out.println("✅ FileController 초기화 완료 - 한글 파일명 완전 해결 버전");
            System.out.println("✅ FileService 연동 성공");
        } catch (Exception e) {
            System.err.println("❌ FileController 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("FileController 초기화 실패", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("🔍 FileController.doGet 호출됨");
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 PathInfo: " + pathInfo);
        
        if (pathInfo == null) {
            System.err.println("❌ PathInfo가 null입니다");
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 요청입니다.");
            return;
        }
        
        // URL 패턴 분석
        String[] pathParts = pathInfo.split("/");
        System.out.println("🔍 PathParts: " + Arrays.toString(pathParts));
        
        if (pathParts.length < 2) {
            System.err.println("❌ URL 형식이 잘못됨: " + pathInfo);
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 URL 형식입니다.");
            return;
        }
        
        String action = pathParts[1];
        System.out.println("🔍 Action: " + action);
        
        switch (action) {
            case "download":
                if (pathParts.length >= 3) {
                    System.out.println("📥 파일 다운로드 요청 - fileId: " + pathParts[2]);
                    handleDownload(request, response, pathParts[2]);
                } else {
                    System.err.println("❌ 파일 ID가 없음");
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "파일 ID가 필요합니다.");
                }
                break;
                
            case "info":
                if (pathParts.length >= 3) {
                    System.out.println("ℹ️ 파일 정보 조회 요청 - fileId: " + pathParts[2]);
                    handleFileInfo(request, response, pathParts[2]);
                } else {
                    sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "파일 ID가 필요합니다.");
                }
                break;
                
            case "list":
                if (pathParts.length >= 4 && "post".equals(pathParts[2])) {
                    System.out.println("📋 파일 목록 조회 요청 - postId: " + pathParts[3]);
                    handleFileList(request, response, pathParts[3]);
                } else {
                    sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "게시글 ID가 필요합니다.");
                }
                break;
                
            default:
                System.err.println("❌ 알 수 없는 액션: " + action);
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "알 수 없는 요청입니다.");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("📤 FileController.doPost 호출됨");
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 POST PathInfo: " + pathInfo);
        
        if (pathInfo == null) {
            sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 요청입니다.");
            return;
        }
        
        String[] pathParts = pathInfo.split("/");
        
        if (pathParts.length >= 2 && "upload".equals(pathParts[1])) {
            System.out.println("📤 파일 업로드 요청");
            handleUpload(request, response);
        } else {
            sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 업로드 요청입니다.");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("🗑️ FileController.doDelete 호출됨");
        
        String pathInfo = request.getPathInfo();
        String[] pathParts = pathInfo.split("/");
        
        if (pathParts.length >= 3 && "delete".equals(pathParts[1])) {
            System.out.println("🗑️ 파일 삭제 요청 - fileId: " + pathParts[2]);
            handleDelete(request, response, pathParts[2]);
        } else {
            sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 삭제 요청입니다.");
        }
    }

    /**
     * 파일 업로드 처리
     */
    private void handleUpload(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("📤 handleUpload 시작");
        
        try {
            // 세션에서 사용자 정보 확인
            HttpSession session = request.getSession();
            Integer userId = (Integer) session.getAttribute("userId");
            if (userId == null) {
                System.err.println("❌ 로그인되지 않은 사용자");
                sendJsonError(response, HttpServletResponse.SC_UNAUTHORIZED, "로그인이 필요합니다.");
                return;
            }
            
            System.out.println("✅ 사용자 확인됨 - userId: " + userId);
            
            // 파라미터 추출
            String postIdStr = request.getParameter("postId");
            String classIdStr = request.getParameter("classId");
            
            Integer postId = null;
            Integer classId = null;
            
            try {
                if (postIdStr != null && !postIdStr.trim().isEmpty()) {
                    postId = Integer.parseInt(postIdStr);
                }
                if (classIdStr != null && !classIdStr.trim().isEmpty()) {
                    classId = Integer.parseInt(classIdStr);
                }
            } catch (NumberFormatException e) {
                sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 ID 형식입니다.");
                return;
            }
            
            System.out.println("🔍 업로드 파라미터 - postId: " + postId + ", classId: " + classId);
            
            // 업로드된 파일들 처리
            List<FileInfo> uploadedFiles = new ArrayList<>();
            
            for (Part part : request.getParts()) {
                if (part.getName().equals("file") && part.getSize() > 0) {
                    
                    System.out.println("📁 파일 처리 중 - 크기: " + part.getSize());
                    
                    // 파일 유효성 검증
                    String validationError = validateFile(part);
                    if (validationError != null) {
                        System.err.println("❌ 파일 검증 실패: " + validationError);
                        sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, validationError);
                        return;
                    }
                    
                    // FileService를 통해 업로드 처리
                    FileInfo uploadedFile = fileService.uploadFile(part, postId, classId, userId);
                    
                    if (uploadedFile != null) {
                        uploadedFiles.add(uploadedFile);
                        System.out.println("✅ 파일 업로드 성공: " + uploadedFile.getOriginalName());
                    } else {
                        System.err.println("❌ 파일 업로드 실패");
                        sendJsonError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                                     "파일 업로드에 실패했습니다.");
                        return;
                    }
                }
            }
            
            if (uploadedFiles.isEmpty()) {
                System.err.println("❌ 업로드할 파일이 없음");
                sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "업로드할 파일이 없습니다.");
                return;
            }
            
            System.out.println("✅ 파일 업로드 완료 - " + uploadedFiles.size() + "개");
            sendJsonSuccess(response, "파일 업로드가 완료되었습니다.", uploadedFiles);
            
        } catch (Exception e) {
            System.err.println("❌ 파일 업로드 중 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                         "파일 업로드 중 오류가 발생했습니다: " + e.getMessage());
        }
    }

    /**
     * 🔥 파일 다운로드 처리 - 한글 파일명 완전 해결 버전
     */
    private void handleDownload(HttpServletRequest request, HttpServletResponse response, String fileIdStr) 
            throws ServletException, IOException {
        
        System.out.println("📥 handleDownload 시작 - fileId: " + fileIdStr);
        
        try {
            Integer fileId = Integer.parseInt(fileIdStr);
            
            // 파일 정보 조회
            FileInfo fileInfo = fileService.getFileById(fileId);
            if (fileInfo == null) {
                System.err.println("❌ 파일을 찾을 수 없습니다. fileId: " + fileId);
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "파일을 찾을 수 없습니다.");
                return;
            }
            
            System.out.println("✅ 파일 정보 조회 성공: " + fileInfo.getOriginalName());
            
            // 🔥 핵심 수정: FileInfo에 저장된 전체 경로 사용
            String fullPath = fileInfo.getFilePath();
            if (fullPath == null || fullPath.trim().isEmpty()) {
                System.err.println("❌ 파일 경로가 없습니다. fileId: " + fileId);
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "파일 경로를 찾을 수 없습니다.");
                return;
            }
            
            System.out.println("🔍 파일 경로: " + fullPath);
            
            File file = new File(fullPath);
            
            if (!file.exists()) {
                System.err.println("❌ 실제 파일이 존재하지 않습니다. 경로: " + fullPath);
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "파일이 존재하지 않습니다.");
                return;
            }
            
            System.out.println("✅ 실제 파일 존재 확인됨 - 크기: " + file.length());
            
            // 다운로드 카운트 증가
            fileService.incrementDownloadCount(fileId);
            
            // 응답 헤더 설정
            String mimeType = fileInfo.getMimeType();
            if (mimeType == null) {
                mimeType = "application/octet-stream";
            }
            response.setContentType(mimeType);
            response.setContentLengthLong(file.length());
            
            // 🔥 한글 파일명 완전 지원 처리 (가장 호환성 높은 방식)
            String originalFilename = fileInfo.getOriginalName();
            if (originalFilename == null) {
                originalFilename = "download";
            }
            
            System.out.println("🔍 원본 파일명: " + originalFilename);
            
            try {
                // 🔥 모든 브라우저 호환 방식 - RFC 2231 표준
                String encodedFilename = URLEncoder.encode(originalFilename, "UTF-8").replaceAll("\\+", "%20");
                
                // 🔥 여러 방식을 동시에 지원 (가장 호환성 높음)
                response.setHeader("Content-Disposition", 
                    "attachment; " +
                    "filename=\"" + originalFilename.replaceAll("[^\\x00-\\x7F]", "_") + "\"; " +
                    "filename*=UTF-8''" + encodedFilename
                );
                
                System.out.println("🔍 Content-Disposition 헤더 설정 완료");
                System.out.println("🔍 인코딩된 파일명: " + encodedFilename);
                
            } catch (Exception e) {
                System.err.println("⚠️ 파일명 인코딩 실패: " + e.getMessage());
                // 완전 fallback - 안전한 기본값
                String safeFilename = "download." + getFileExtension(originalFilename);
                response.setHeader("Content-Disposition", "attachment; filename=" + safeFilename);
                System.out.println("🔍 Fallback 파일명 사용: " + safeFilename);
            }
            
            // 🔥 추가 헤더 설정 (한글 지원 강화)
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            
            System.out.println("📤 파일 전송 시작: " + originalFilename);
            
            // 파일 전송
            try (FileInputStream fis = new FileInputStream(file);
                 BufferedInputStream bis = new BufferedInputStream(fis);
                 OutputStream os = response.getOutputStream()) {
                
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = bis.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
                os.flush();
            }
            
            System.out.println("✅ 파일 다운로드 성공: " + originalFilename + " (fileId: " + fileId + ")");
            
        } catch (NumberFormatException e) {
            System.err.println("❌ 잘못된 파일 ID: " + fileIdStr);
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 파일 ID입니다.");
        } catch (Exception e) {
            System.err.println("❌ 파일 다운로드 중 오류: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                              "파일 다운로드 중 오류가 발생했습니다.");
        }
    }

    /**
     * 파일 정보 조회
     */
    private void handleFileInfo(HttpServletRequest request, HttpServletResponse response, String fileIdStr) 
            throws IOException {
        
        System.out.println("ℹ️ handleFileInfo 시작 - fileId: " + fileIdStr);
        
        try {
            Integer fileId = Integer.parseInt(fileIdStr);
            FileInfo fileInfo = fileService.getFileById(fileId);
            
            if (fileInfo == null) {
                System.err.println("❌ 파일 정보를 찾을 수 없음: " + fileId);
                sendJsonError(response, HttpServletResponse.SC_NOT_FOUND, "파일을 찾을 수 없습니다.");
                return;
            }
            
            System.out.println("✅ 파일 정보 조회 성공: " + fileInfo.getOriginalName());
            sendJsonSuccess(response, "파일 정보 조회 성공", fileInfo);
            
        } catch (NumberFormatException e) {
            sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 파일 ID입니다.");
        } catch (Exception e) {
            System.err.println("❌ 파일 정보 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                         "파일 정보 조회 중 오류가 발생했습니다.");
        }
    }

    /**
     * 게시글별 첨부파일 목록 조회
     */
    private void handleFileList(HttpServletRequest request, HttpServletResponse response, String postIdStr) 
            throws IOException {
        
        System.out.println("📋 handleFileList 시작 - postId: " + postIdStr);
        
        try {
            Integer postId = Integer.parseInt(postIdStr);
            List<FileInfo> fileList = fileService.getFilesByPostId(postId);
            
            System.out.println("✅ 파일 목록 조회 성공 - " + fileList.size() + "개");
            sendJsonSuccess(response, "파일 목록 조회 성공", fileList);
            
        } catch (NumberFormatException e) {
            sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 게시글 ID입니다.");
        } catch (Exception e) {
            System.err.println("❌ 파일 목록 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                         "파일 목록 조회 중 오류가 발생했습니다.");
        }
    }

    /**
     * 파일 삭제 처리
     */
    private void handleDelete(HttpServletRequest request, HttpServletResponse response, String fileIdStr) 
            throws IOException {
        
        System.out.println("🗑️ handleDelete 시작 - fileId: " + fileIdStr);
        
        try {
            Integer fileId = Integer.parseInt(fileIdStr);
            
            // 세션에서 사용자 정보 확인
            HttpSession session = request.getSession();
            Integer userId = (Integer) session.getAttribute("userId");
            if (userId == null) {
                sendJsonError(response, HttpServletResponse.SC_UNAUTHORIZED, "로그인이 필요합니다.");
                return;
            }
            
            // 파일 정보 조회
            FileInfo fileInfo = fileService.getFileById(fileId);
            if (fileInfo == null) {
                sendJsonError(response, HttpServletResponse.SC_NOT_FOUND, "파일을 찾을 수 없습니다.");
                return;
            }
            
            // 권한 확인 (업로더 본인이거나 관리자만 삭제 가능)
            if (!userId.equals(fileInfo.getUploaderId())) {
                sendJsonError(response, HttpServletResponse.SC_FORBIDDEN, "파일을 삭제할 권한이 없습니다.");
                return;
            }
            
            // 파일 삭제
            boolean result = fileService.deleteFile(fileId);
            
            if (result) {
                System.out.println("✅ 파일 삭제 성공: " + fileId);
                sendJsonSuccess(response, "파일이 삭제되었습니다.", null);
            } else {
                System.err.println("❌ 파일 삭제 실패: " + fileId);
                sendJsonError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "파일 삭제에 실패했습니다.");
            }
            
        } catch (NumberFormatException e) {
            sendJsonError(response, HttpServletResponse.SC_BAD_REQUEST, "잘못된 파일 ID입니다.");
        } catch (Exception e) {
            System.err.println("❌ 파일 삭제 중 오류: " + e.getMessage());
            e.printStackTrace();
            sendJsonError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                         "파일 삭제 중 오류가 발생했습니다.");
        }
    }

    /**
     * 파일 유효성 검증
     */
    private String validateFile(Part filePart) {
        if (filePart == null || filePart.getSize() == 0) {
            return "파일이 비어있습니다.";
        }
        
        if (filePart.getSize() > MAX_FILE_SIZE) {
            return "파일 크기가 너무 큽니다. (최대 10MB)";
        }
        
        // 파일명 추출
        String originalFilename = getOriginalFilename(filePart);
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            return "파일명이 유효하지 않습니다.";
        }
        
        // 확장자 검증
        String extension = getFileExtension(originalFilename).toLowerCase();
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            return "허용되지 않는 파일 형식입니다. 허용 형식: " + ALLOWED_EXTENSIONS;
        }
        
        return null; // 유효함
    }

    /**
     * Part 객체에서 원본 파일명 추출
     */
    private String getOriginalFilename(Part part) {
        String contentDisposition = part.getHeader("Content-Disposition");
        if (contentDisposition == null) return null;
        
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                String filename = token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
                // UTF-8 디코딩 처리
                try {
                    return new String(filename.getBytes("ISO-8859-1"), "UTF-8");
                } catch (Exception e) {
                    return filename;
                }
            }
        }
        return null;
    }

    /**
     * 파일 확장자 추출
     */
    private String getFileExtension(String filename) {
        if (filename == null || !filename.contains(".")) {
            return "";
        }
        return filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
    }

    /**
     * 저장할 파일명 생성 (중복 방지)
     */
    private String generateSavedFilename(String originalFilename) {
        String extension = getFileExtension(originalFilename);
        String nameWithoutExt = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
        
        // 타임스탬프 + UUID로 고유 파일명 생성
        String timestamp = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String uuid = UUID.randomUUID().toString().substring(0, 8);
        
        return timestamp + "_" + uuid + "_" + nameWithoutExt + "." + extension;
    }

    /**
     * MIME 타입 결정
     */
    private String determineContentType(String filename) {
        String extension = getFileExtension(filename).toLowerCase();
        
        switch (extension) {
            case "pdf": return "application/pdf";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "ppt": return "application/vnd.ms-powerpoint";
            case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "zip": return "application/zip";
            case "rar": return "application/x-rar-compressed";
            case "jpg":
            case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "txt": return "text/plain";
            case "hwp": return "application/x-hwp";
            default: return "application/octet-stream";
        }
    }

    /**
     * JSON 성공 응답 전송 (Jackson 없이 수동 구현)
     */
    private void sendJsonSuccess(HttpServletResponse response, String message, Object data) 
            throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":true,");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        
        if (data != null) {
            json.append(",\"data\":").append(objectToJson(data));
        }
        
        json.append("}");
        
        System.out.println("📤 JSON 응답 전송: " + json.toString());
        response.getWriter().write(json.toString());
    }

    /**
     * JSON 오류 응답 전송 (Jackson 없이 수동 구현)
     */
    private void sendJsonError(HttpServletResponse response, int statusCode, String message) 
            throws IOException {
        
        response.setStatus(statusCode);
        response.setContentType("application/json; charset=UTF-8");
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\":false,");
        json.append("\"message\":\"").append(escapeJson(message)).append("\"");
        json.append("}");
        
        System.out.println("❌ JSON 오류 응답 전송: " + json.toString());
        response.getWriter().write(json.toString());
    }

    /**
     * JSON 특수문자 이스케이프
     */
    private String escapeJson(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }

    /**
     * 객체를 JSON 문자열로 변환 (수동 구현)
     */
    private String objectToJson(Object obj) {
        if (obj == null) return "null";
        if (obj instanceof String) return "\"" + escapeJson((String)obj) + "\"";
        if (obj instanceof Integer || obj instanceof Long) return obj.toString();
        if (obj instanceof Boolean) return obj.toString();
        
        // FileInfo 객체의 경우
        if (obj instanceof FileInfo) {
            return fileInfoToJson((FileInfo) obj);
        }
        
        // List<FileInfo>의 경우
        if (obj instanceof List) {
            @SuppressWarnings("unchecked")
            List<FileInfo> list = (List<FileInfo>) obj;
            StringBuilder json = new StringBuilder();
            json.append("[");
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) json.append(",");
                json.append(fileInfoToJson(list.get(i)));
            }
            json.append("]");
            return json.toString();
        }
        
        return "{}";
    }

    /**
     * FileInfo 객체를 JSON으로 변환
     */
    private String fileInfoToJson(FileInfo file) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"id\":").append(file.getId()).append(",");
        json.append("\"postId\":").append(file.getPostId()).append(",");
        json.append("\"originalName\":\"").append(escapeJson(file.getOriginalName())).append("\",");
        json.append("\"savedName\":\"").append(escapeJson(file.getSavedName())).append("\",");
        json.append("\"fileSize\":").append(file.getFileSize()).append(",");
        json.append("\"fileType\":\"").append(escapeJson(file.getFileType())).append("\",");
        json.append("\"mimeType\":\"").append(escapeJson(file.getMimeType())).append("\",");
        json.append("\"downloadCount\":").append(file.getDownloadCount()).append(",");
        json.append("\"uploadDate\":\"").append(file.getUploadDate() != null ? file.getUploadDate().toString() : "").append("\"");
        json.append("}");
        return json.toString();
    }
}