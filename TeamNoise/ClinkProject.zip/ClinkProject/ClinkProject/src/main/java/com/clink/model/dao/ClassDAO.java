package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Class;
import com.clink.util.DBConnection;

/**
 * 수업 관련 데이터베이스 접근 클래스 (완전 수정된 버전)
 */
public class ClassDAO {
    
    /**
     * 새 수업 생성
     */
    public boolean createClass(Class classInfo) {
        String sql = "INSERT INTO classes (class_code, class_name, description, professor_id, " +
                    "start_date, end_date, start_time, end_time, class_days, " +
                    "max_students, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection()) {
            
            // 고유한 수업 코드 생성
            String classCode = generateUniqueClassCode(conn);
            classInfo.setClassCode(classCode);
            
            try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, classInfo.getClassCode());
                pstmt.setString(2, classInfo.getClassName());
                pstmt.setString(3, classInfo.getDescription());
                pstmt.setLong(4, classInfo.getProfessorId());
                pstmt.setDate(5, java.sql.Date.valueOf(classInfo.getStartDate()));
                pstmt.setDate(6, java.sql.Date.valueOf(classInfo.getEndDate()));
                pstmt.setTime(7, java.sql.Time.valueOf(classInfo.getStartTime()));
                pstmt.setTime(8, java.sql.Time.valueOf(classInfo.getEndTime()));
                pstmt.setString(9, classInfo.getClassDays());
                pstmt.setInt(10, classInfo.getMaxStudents());
                pstmt.setString(11, classInfo.getStatus());
                
                int result = pstmt.executeUpdate();
                
                if (result > 0) {
                    try (ResultSet rs = pstmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            classInfo.setId(rs.getLong(1));
                        }
                    }
                    
                    System.out.println("수업 생성 성공: " + classInfo.getClassName() + " (코드: " + classCode + ")");
                    return true;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("수업 생성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 교수의 수업 목록 조회
     */
    public List<Class> getClassesByProfessor(Long professorId, String status) {
        List<Class> classList = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, ");
        sql.append("c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, ");
        sql.append("c.max_students, c.status, c.created_at, c.updated_at, ");
        sql.append("u.name as professor_name, ");
        sql.append("(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students ");
        sql.append("FROM classes c ");
        sql.append("JOIN users u ON c.professor_id = u.user_id ");
        sql.append("WHERE c.professor_id = ? ");
        
        if (status != null && !status.isEmpty()) {
            sql.append("AND c.status = ? ");
        }
        
        sql.append("ORDER BY c.created_at DESC");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setLong(1, professorId);
            
            if (status != null && !status.isEmpty()) {
                pstmt.setString(2, status);
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Class classInfo = mapResultSetToClass(rs);
                    classList.add(classInfo);
                }
            }
            
            System.out.println("교수 수업 목록 조회 성공: " + classList.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("교수 수업 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return classList;
    }
    
    /**
     * 수업 코드로 수업 정보 조회
     */
    public Class getClassByCode(String classCode) {
        String sql = "SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, " +
                    "c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, " +
                    "c.max_students, c.status, c.created_at, c.updated_at, " +
                    "u.name as professor_name, " +
                    "(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students " +
                    "FROM classes c " +
                    "JOIN users u ON c.professor_id = u.user_id " +
                    "WHERE c.class_code = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, classCode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("수업 코드 조회 성공: " + classCode);
                    return mapResultSetToClass(rs);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("수업 코드 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * 학생이 참여한 수업 목록 조회
     */
    public List<Class> getStudentClasses(Long studentId, String status) {
        List<Class> classList = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, ");
        sql.append("c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, ");
        sql.append("c.max_students, c.status, c.created_at, c.updated_at, ");
        sql.append("u.name as professor_name, ce.enrolled_at, ");
        sql.append("(SELECT COUNT(*) FROM class_enrollments ce2 WHERE ce2.class_id = c.class_id AND ce2.is_active = TRUE) as current_students ");
        sql.append("FROM classes c ");
        sql.append("JOIN users u ON c.professor_id = u.user_id ");
        sql.append("JOIN class_enrollments ce ON c.class_id = ce.class_id ");
        sql.append("WHERE ce.student_id = ? AND ce.is_active = TRUE ");
        
        if (status != null && !status.isEmpty()) {
            sql.append("AND c.status = ? ");
        }
        
        sql.append("ORDER BY ce.enrolled_at DESC");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setLong(1, studentId);
            
            if (status != null && !status.isEmpty()) {
                pstmt.setString(2, status);
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Class classInfo = mapResultSetToClass(rs);
                    classList.add(classInfo);
                }
            }
            
            System.out.println("학생 수업 목록 조회 성공: " + classList.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("학생 수업 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return classList;
    }
    
    /**
     * 수업 참여 (학생 등록)
     */
    public boolean enrollStudent(String classCode, Long studentId) {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false); // 트랜잭션 시작
            
            // 수업 정보 조회 및 참여 가능 여부 확인
            Class classInfo = getClassByCodeInternal(classCode, conn);
            if (classInfo == null) {
                System.out.println("수업 참여 실패: 존재하지 않는 수업 코드");
                return false;
            }
            
            // 이미 참여했는지 확인
            if (isStudentEnrolled(classInfo.getId(), studentId, conn)) {
                System.out.println("수업 참여 실패: 이미 참여한 수업");
                return false;
            }
            
            // 학생 등록
            String enrollSql = "INSERT INTO class_enrollments (class_id, student_id, enrolled_at, is_active) " +
                              "VALUES (?, ?, NOW(), TRUE)";
            
            try (PreparedStatement pstmt = conn.prepareStatement(enrollSql)) {
                pstmt.setLong(1, classInfo.getId());
                pstmt.setLong(2, studentId);
                
                int enrollResult = pstmt.executeUpdate();
                
                if (enrollResult > 0) {
                    conn.commit(); // 트랜잭션 커밋
                    System.out.println("수업 참여 성공: " + classCode + " (학생 ID: " + studentId + ")");
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("수업 참여 실패: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 수업 정보 수정
     */
    public boolean updateClass(Class classInfo) {
        String sql = "UPDATE classes SET " +
                    "class_name = ?, description = ?, start_date = ?, end_date = ?, " +
                    "start_time = ?, end_time = ?, class_days = ?, max_students = ?, " +
                    "status = ?, updated_at = NOW() " +
                    "WHERE class_id = ? AND professor_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, classInfo.getClassName());
            pstmt.setString(2, classInfo.getDescription());
            pstmt.setDate(3, java.sql.Date.valueOf(classInfo.getStartDate()));
            pstmt.setDate(4, java.sql.Date.valueOf(classInfo.getEndDate()));
            pstmt.setTime(5, java.sql.Time.valueOf(classInfo.getStartTime()));
            pstmt.setTime(6, java.sql.Time.valueOf(classInfo.getEndTime()));
            pstmt.setString(7, classInfo.getClassDays());
            pstmt.setInt(8, classInfo.getMaxStudents());
            pstmt.setString(9, classInfo.getStatus());
            pstmt.setLong(10, classInfo.getId());
            pstmt.setLong(11, classInfo.getProfessorId());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("수업 정보 수정 성공: " + classInfo.getClassName());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("수업 정보 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 수업 삭제 (status를 'ended'로 변경)
     */
    public boolean deleteClass(Long classId, Long professorId) {
        String sql = "UPDATE classes SET status = 'ended', updated_at = NOW() " +
                    "WHERE class_id = ? AND professor_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            pstmt.setLong(2, professorId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("수업 삭제 성공: " + classId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("수업 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 수업 통계 정보 조회
     */
    public Class getClassStatistics(Long classId) {
        String sql = "SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, " +
                    "c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, " +
                    "c.max_students, c.status, c.created_at, c.updated_at, " +
                    "u.name as professor_name, " +
                    "(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students, " +
                    "(SELECT COUNT(*) FROM posts p WHERE p.class_id = c.class_id AND p.status = 'active') as total_posts, " +
                    "(SELECT COUNT(*) FROM questions q WHERE q.class_id = c.class_id) as total_questions " +
                    "FROM classes c " +
                    "JOIN users u ON c.professor_id = u.user_id " +
                    "WHERE c.class_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, classId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Class classInfo = mapResultSetToClass(rs);
                    // 추가 통계 정보 설정
                    try {
                        classInfo.setTotalClasses(rs.getInt("total_posts"));
                        classInfo.setCompletedClasses(rs.getInt("total_questions"));
                    } catch (SQLException e) {
                        // 컬럼이 없는 경우 기본값
                        classInfo.setTotalClasses(0);
                        classInfo.setCompletedClasses(0);
                    }
                    return classInfo;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("수업 통계 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    // ===== PRIVATE 헬퍼 메서드들 =====
    
    /**
     * 고유한 수업 코드 생성
     */
    private String generateUniqueClassCode(Connection conn) throws SQLException {
        String classCode;
        
        do {
            // 3자리 영문 + 3자리 숫자 형태의 코드 생성
            String letters = generateRandomLetters(3);
            String numbers = generateRandomNumbers(3);
            classCode = letters + numbers;
            
            // 중복 체크
            String checkSql = "SELECT COUNT(*) FROM classes WHERE class_code = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setString(1, classCode);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    rs.next();
                    int count = rs.getInt(1);
                    
                    if (count == 0) {
                        break;
                    }
                }
            }
        } while (true);
        
        return classCode;
    }
    
    /**
     * 랜덤 영문자 생성
     */
    private String generateRandomLetters(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = (char) ('A' + (int) (Math.random() * 26));
            sb.append(c);
        }
        return sb.toString();
    }
    
    /**
     * 랜덤 숫자 생성
     */
    private String generateRandomNumbers(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int n = (int) (Math.random() * 10);
            sb.append(n);
        }
        return sb.toString();
    }
    
    /**
     * Connection을 포함한 수업 정보 조회 (내부용)
     */
    private Class getClassByCodeInternal(String classCode, Connection conn) throws SQLException {
        String sql = "SELECT c.class_id, c.class_code, c.class_name, c.description, c.professor_id, " +
                    "c.start_date, c.end_date, c.start_time, c.end_time, c.class_days, " +
                    "c.max_students, c.status, c.created_at, c.updated_at, " +
                    "u.name as professor_name, " +
                    "(SELECT COUNT(*) FROM class_enrollments ce WHERE ce.class_id = c.class_id AND ce.is_active = TRUE) as current_students " +
                    "FROM classes c " +
                    "JOIN users u ON c.professor_id = u.user_id " +
                    "WHERE c.class_code = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, classCode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToClass(rs);
                }
            }
        }
        
        return null;
    }
    
    /**
     * 학생 등록 여부 확인
     */
    private boolean isStudentEnrolled(Long classId, Long studentId, Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM class_enrollments WHERE class_id = ? AND student_id = ? AND is_active = TRUE";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, classId);
            pstmt.setLong(2, studentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }
    
    /**
     * ResultSet을 Class 객체로 매핑
     */
    private Class mapResultSetToClass(ResultSet rs) throws SQLException {
        Class classInfo = new Class();
        
        classInfo.setId(rs.getLong("class_id"));
        classInfo.setClassCode(rs.getString("class_code"));
        classInfo.setClassName(rs.getString("class_name"));
        classInfo.setDescription(rs.getString("description"));
        classInfo.setProfessorId(rs.getLong("professor_id"));
        
        // 날짜/시간 변환
        if (rs.getDate("start_date") != null) {
            classInfo.setStartDate(rs.getDate("start_date").toLocalDate());
        }
        if (rs.getDate("end_date") != null) {
            classInfo.setEndDate(rs.getDate("end_date").toLocalDate());
        }
        if (rs.getTime("start_time") != null) {
            classInfo.setStartTime(rs.getTime("start_time").toLocalTime());
        }
        if (rs.getTime("end_time") != null) {
            classInfo.setEndTime(rs.getTime("end_time").toLocalTime());
        }
        
        classInfo.setClassDays(rs.getString("class_days"));
        classInfo.setMaxStudents(rs.getInt("max_students"));
        classInfo.setStatus(rs.getString("status"));
        
        // 현재 학생 수 설정
        try {
            classInfo.setCurrentStudents(rs.getInt("current_students"));
        } catch (SQLException e) {
            // current_students 컬럼이 없는 경우 기본값 0
            classInfo.setCurrentStudents(0);
        }
        
        // 타임스탬프 변환
        if (rs.getTimestamp("created_at") != null) {
            classInfo.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        if (rs.getTimestamp("updated_at") != null) {
            classInfo.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
        }
        
        // 조인된 데이터
        classInfo.setProfessorName(rs.getString("professor_name"));
        
        return classInfo;
    }
}