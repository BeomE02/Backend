package com.clink.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.dto.User;
import com.clink.model.service.UserService;

/**
 * 메인 컨트롤러 - 사용자 관리 및 기본 페이지만 처리
 * ✅ 게시판 기능은 BoardController가 직접 처리 (위임 제거)
 * ✅ 파일 기능은 FileController가 직접 처리
 */
public class MainController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UserService userService;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            this.userService = new UserService();
            System.out.println("✅ MainController 초기화 완료 (UserService 연동)");
        } catch (Exception e) {
            System.err.println("❌ MainController 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("MainController 초기화 실패", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * 요청 처리 - 사용자 관리 및 기본 페이지만
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("===============================================");
        
        // 인코딩 설정
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        // 요청 URI에서 명령어 추출
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String command = uri.substring(contextPath.length());

        System.out.println("🔄 MainController 처리: " + command);

        // 세션 정보 로깅
        HttpSession session = request.getSession(false);
        if (session != null) {
            User loginUser = (User) session.getAttribute("loginUser");
            if (loginUser != null) {
                System.out.println("👤 로그인 사용자: " + loginUser.getUsername() + " (" + loginUser.getName() + ")");
            }
        }

        try {
            // 🎯 MainController가 직접 처리하는 요청들만
            switch (command) {
                
                // ========================================
                // 사용자 관련 요청 - 직접 처리
                // ========================================
                case "/index.do":
                    System.out.println("🏠 인덱스 페이지");
                    request.getRequestDispatcher("/WEB-INF/views/user/index.jsp").forward(request, response);
                    break;
                    
                case "/login.do":
                    System.out.println("🔑 로그인 처리");
                    handleLogin(request, response);
                    break;
                    
                case "/logout.do":
                    System.out.println("🚪 로그아웃 처리");
                    handleLogout(request, response);
                    break;
                    
                case "/signup.do":
                    System.out.println("👤 회원가입 페이지");
                    request.getRequestDispatcher("/WEB-INF/views/user/signup.jsp").forward(request, response);
                    break;
                    
                case "/find.do":
                    System.out.println("🔍 비밀번호 찾기 페이지");
                    request.getRequestDispatcher("/WEB-INF/views/user/find.jsp").forward(request, response);
                    break;
                    
                case "/main.do":
                    System.out.println("🏠 메인 페이지");
                    handleMain(request, response);
                    break;

                // ========================================
                // 수업 관련 요청 - 직접 처리
                // ========================================
                case "/enterRoom.do":
                    System.out.println("🚪 강의실 입장");
                    checkLoginAndForward(request, response, "/WEB-INF/views/class/enterRoom.jsp");
                    break;
                    
                case "/enterClass.do":
                    System.out.println("🏫 수업 입장");
                    checkLoginAndForward(request, response, "/WEB-INF/views/class/enterClass.jsp");
                    break;
                    
                case "/classJoin.do":
                    System.out.println("📚 수업 참여");
                    checkLoginAndForward(request, response, "/WEB-INF/views/class/classJoin.jsp");
                    break;
                    
                case "/classStatistics.do":
                    System.out.println("📊 수업 통계");
                    checkLoginAndForward(request, response, "/WEB-INF/views/class/classStatistics.jsp");
                    break;
                    
                case "/classArchive.do":
                    System.out.println("📚 수업 아카이브");
                    checkLoginAndForward(request, response, "/WEB-INF/views/class/classArchive.jsp");
                    break;

                default:
                    System.out.println("❌ MainController에서 처리할 수 없는 요청: " + command);
                    System.out.println("   → 게시판 요청은 BoardController가 직접 처리");
                    System.out.println("   → 파일 요청은 FileController가 직접 처리");
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "페이지를 찾을 수 없습니다.");
                    return;
            }
            
        } catch (Exception e) {
            System.err.println("❌ MainController 오류: " + e.getMessage());
            e.printStackTrace();
            
            request.setAttribute("errorMessage", "요청 처리 중 오류가 발생했습니다: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/error/error.jsp").forward(request, response);
        }
        
        System.out.println("===============================================");
    }

    // ========================================
    // 사용자 관리 메서드들
    // ========================================

    /**
     * 로그인 처리
     */
    private void handleLogin(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if ("GET".equals(request.getMethod())) {
            // 로그인 폼 표시
            System.out.println("🔑 로그인 폼 표시");
            request.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(request, response);
            return;
        }
        
        // POST 요청 - 로그인 처리
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        System.out.println("🔑 로그인 시도 - 사용자: " + username);
        
        // 입력값 검증
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            
            System.out.println("❌ 로그인 실패: 입력값 누락");
            request.setAttribute("errorMessage", "사용자명과 비밀번호를 입력해주세요.");
            request.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(request, response);
            return;
        }
        
        try {
            // UserService를 통한 로그인 처리
            User user = userService.login(username.trim(), password);
            
            if (user != null) {
                // 로그인 성공
                System.out.println("✅ 로그인 성공: " + user.getName() + " (" + user.getRole() + ")");
                
                HttpSession session = request.getSession();
                session.setAttribute("loginUser", user);
                session.setMaxInactiveInterval(30 * 60); // 30분
                
                // 메인 페이지로 이동
                response.sendRedirect(request.getContextPath() + "/main.do");
            } else {
                // 로그인 실패
                System.out.println("❌ 로그인 실패: 인증 정보 불일치");
                request.setAttribute("errorMessage", "사용자명 또는 비밀번호가 올바르지 않습니다.");
                request.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            System.err.println("❌ 로그인 처리 중 오류: " + e.getMessage());
            e.printStackTrace();
            
            request.setAttribute("errorMessage", "로그인 처리 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.");
            request.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(request, response);
        }
    }

    /**
     * 로그아웃 처리
     */
    private void handleLogout(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session != null) {
            User loginUser = (User) session.getAttribute("loginUser");
            if (loginUser != null) {
                System.out.println("🚪 로그아웃: " + loginUser.getUsername() + " (" + loginUser.getName() + ")");
            }
            session.invalidate();
        }
        
        System.out.println("🔄 인덱스 페이지로 리다이렉트");
        response.sendRedirect(request.getContextPath() + "/index.do");
    }

    /**
     * 메인 페이지 처리
     */
    private void handleMain(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            System.out.println("🔒 메인 페이지 접근 - 로그인 필요");
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }
        
        User loginUser = (User) session.getAttribute("loginUser");
        System.out.println("🏠 메인 페이지 접근: " + loginUser.getName() + " (" + loginUser.getRole() + ")");
        
        request.getRequestDispatcher("/WEB-INF/views/main/main.jsp").forward(request, response);
    }

    /**
     * 로그인 확인 및 페이지 포워딩
     */
    private void checkLoginAndForward(HttpServletRequest request, HttpServletResponse response, String jspPath) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginUser") == null) {
            System.out.println("🔒 로그인 필요: " + jspPath);
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }
        
        User loginUser = (User) session.getAttribute("loginUser");
        System.out.println("✅ 페이지 접근 허용: " + loginUser.getName() + " → " + jspPath);
        
        request.getRequestDispatcher(jspPath).forward(request, response);
    }
}