package com.clink.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.clink.model.dao.UserDAO;
import com.clink.model.service.UserService;
import com.clink.model.dto.User;

/**
 * 사용자 전용 컨트롤러 (로그인, 회원가입, 비밀번호 찾기 로직 처리)
 */
public class UserController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UserDAO userDAO;
    private UserService userService;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            userDAO = new UserDAO();
            userService = new UserService();
            System.out.println("UserController 초기화 완료");
        } catch (Exception e) {
            System.err.println("UserController 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("UserController 초기화 실패", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    /**
     * 사용자 관련 요청 처리
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 인코딩 설정
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        // 요청 경로 분석
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String pathInfo = uri.substring(contextPath.length());
        
        // /user/login.do → /login.do 추출
        String command = "";
        if (pathInfo.startsWith("/user")) {
            command = pathInfo.substring(5); // "/user" 제거
        } else {
            command = pathInfo; // AJAX 요청 (/checkUsername, /validateAuthCode)
        }
        
        System.out.println("UserController 처리 경로: " + pathInfo + " → 명령어: " + command);

        try {
            if ("POST".equals(request.getMethod())) {
                handlePostRequest(request, response, command);
            } else {
                handleGetRequest(request, response, command);
            }
        } catch (Exception e) {
            System.err.println("UserController 요청 처리 중 오류: " + e.getMessage());
            e.printStackTrace();
            handleError(request, response, "사용자 요청 처리 중 오류가 발생했습니다.");
        }
    }

    /**
     * GET 요청 처리
     */
    private void handleGetRequest(HttpServletRequest request, HttpServletResponse response, String command)
            throws ServletException, IOException {
        
        String viewPage = "";

        switch (command) {
            case "/":
            case "/index.do":
                viewPage = "/WEB-INF/views/user/index.jsp";
                break;
                
            case "/login.do":
                viewPage = "/WEB-INF/views/user/login.jsp";
                break;
                
            case "/signup.do":
                viewPage = "/WEB-INF/views/user/signup.jsp";
                break;
                
            case "/find.do":
                viewPage = "/WEB-INF/views/user/find.jsp";
                break;
                
            case "/main.do":
                viewPage = handleMainPage(request, response);
                break;
                
            case "/logout.do":
                handleLogout(request, response);
                return;
                
            default:
                System.out.println("알 수 없는 GET 요청: " + command + " -> index로 이동");
                viewPage = "/WEB-INF/views/user/index.jsp";
                break;
        }

        // JSP로 포워딩
        if (viewPage != null && !viewPage.isEmpty()) {
            RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
            dispatcher.forward(request, response);
        }
    }

    /**
     * POST 요청 처리
     */
    private void handlePostRequest(HttpServletRequest request, HttpServletResponse response, String command)
            throws ServletException, IOException {
        
        switch (command) {
            case "/login.do":
                handleLogin(request, response);
                break;
            case "/signup.do":
                handleSignup(request, response);
                break;
            case "/find.do":
                handleFindPassword(request, response);
                break;
                
            // AJAX 요청들
            case "/checkUsername":
                handleUsernameCheck(request, response);
                break;
            case "/validateAuthCode":
                handleAuthCodeValidation(request, response);
                break;
                
            default:
                // POST 요청도 GET으로 처리
                handleGetRequest(request, response, command);
                break;
        }
    }
    
    /**
     * 메인 페이지 처리 (수정됨)
     */
    private String handleMainPage(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession(false);
        User loginUser = null;
        
        if (session != null) {
            loginUser = (User) session.getAttribute("loginUser");  // 수정: 일관된 속성명
        }
        
        System.out.println("메인 페이지 접근 - 세션 확인: " + (session != null ? "있음" : "없음"));
        System.out.println("로그인 사용자: " + (loginUser != null ? loginUser.getName() : "없음"));
        
        if (loginUser == null) {
            System.out.println("로그인되지 않은 사용자 - 로그인 페이지로 이동");
            request.setAttribute("errorMessage", "로그인이 필요합니다.");
            return "/WEB-INF/views/user/login.jsp";
        } else {
            request.setAttribute("user", loginUser);
            System.out.println("메인 페이지 접근 성공: " + loginUser.getName() + " (" + loginUser.getRole() + ")");
            return "/WEB-INF/views/main/main.jsp";
        }
    }
    
    /**
     * 로그인 처리 (수정됨)
     */
    private void handleLogin(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        System.out.println("로그인 시도: 사용자명=" + username);
        
        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            System.out.println("로그인 실패: 빈 입력값");
            request.setAttribute("errorMessage", "아이디와 비밀번호를 입력해주세요.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/login.jsp");
            dispatcher.forward(request, response);
            return;
        }
        
        try {
            // UserService의 login 메서드 사용 (통일)
            User user = userService.login(username.trim(), password.trim());
            
            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("loginUser", user);  // 수정: 일관된 속성명
                session.setMaxInactiveInterval(30 * 60); // 30분
                
                System.out.println("로그인 성공: " + user.getName() + " (" + user.getRole() + ")");
                System.out.println("세션 ID: " + session.getId());
                
                // 메인 페이지로 리다이렉트
                String contextPath = request.getContextPath();
                String redirectUrl = contextPath + "/main.do";
                System.out.println("리다이렉트 URL: " + redirectUrl);
                response.sendRedirect(redirectUrl);
            } else {
                System.out.println("로그인 실패: 인증 실패");
                request.setAttribute("errorMessage", "아이디 또는 비밀번호가 잘못되었습니다.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/login.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.err.println("로그인 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "로그인 처리 중 오류가 발생했습니다.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/login.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    /**
     * 회원가입 처리
     */
    private void handleSignup(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String role = request.getParameter("role");
        String authCode = request.getParameter("authCode");
        
        System.out.println("회원가입 시도: " + username + " (" + role + ")");
        
        try {
            boolean success = userService.register(username, password, name, role, authCode);
            
            if (success) {
                request.setAttribute("successMessage", "회원가입이 완료되었습니다. 로그인해주세요.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/login.jsp");
                dispatcher.forward(request, response);
            } else {
                request.setAttribute("errorMessage", "회원가입에 실패했습니다. 입력 정보를 확인해주세요.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/signup.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.err.println("회원가입 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "회원가입 처리 중 오류가 발생했습니다.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/signup.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    /**
     * 비밀번호 찾기 처리
     */
    private void handleFindPassword(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        
        System.out.println("비밀번호 찾기 시도: " + name + " / " + username);
        
        try {
            User user = userService.findPassword(name, username);
            
            if (user != null) {
                request.setAttribute("foundUser", user);
                request.setAttribute("successMessage", "사용자 정보를 찾았습니다. 비밀번호: " + user.getPassword());
            } else {
                request.setAttribute("errorMessage", "해당 정보로 등록된 사용자를 찾을 수 없습니다.");
            }
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/find.jsp");
            dispatcher.forward(request, response);
            
        } catch (Exception e) {
            System.err.println("비밀번호 찾기 처리 오류: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "비밀번호 찾기 처리 중 오류가 발생했습니다.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/user/find.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    /**
     * 사용자명 중복 체크 AJAX
     */
    private void handleUsernameCheck(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        String username = request.getParameter("username");
        System.out.println("사용자명 중복 체크: " + username);
        
        try {
            boolean exists = userService.checkUsernameExists(username);
            String jsonResponse = "{\"exists\":" + exists + "}";
            response.getWriter().write(jsonResponse);
        } catch (Exception e) {
            System.err.println("사용자명 중복 체크 오류: " + e.getMessage());
            String jsonResponse = "{\"exists\":true}"; // 오류 시 중복으로 처리
            response.getWriter().write(jsonResponse);
        }
    }
    
    /**
     * 교수 인증 코드 검증 AJAX
     */
    private void handleAuthCodeValidation(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json; charset=UTF-8");
        
        String authCode = request.getParameter("authCode");
        System.out.println("교수 인증 코드 검증: " + authCode);
        
        try {
            boolean valid = userService.validateProfessorAuthCode(authCode);
            String jsonResponse = "{\"valid\":" + valid + "}";
            response.getWriter().write(jsonResponse);
        } catch (Exception e) {
            System.err.println("교수 인증 코드 검증 오류: " + e.getMessage());
            String jsonResponse = "{\"valid\":false}"; // 오류 시 무효로 처리
            response.getWriter().write(jsonResponse);
        }
    }
    
    /**
     * 로그아웃 처리
     */
    private void handleLogout(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            User user = (User) session.getAttribute("loginUser");  // 수정: 일관된 속성명
            if (user != null) {
                System.out.println("사용자 로그아웃: " + user.getName());
            }
            session.invalidate();
        }
        
        response.sendRedirect(request.getContextPath() + "/index.do");
    }
    
    /**
     * 에러 처리
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, String errorMessage)
            throws ServletException, IOException {
        
        System.err.println("UserController 에러: " + errorMessage);
        request.setAttribute("errorMessage", errorMessage);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/error/error.jsp");
        dispatcher.forward(request, response);
    }
}