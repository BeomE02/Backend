package com.clink.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;
import com.clink.util.DBConnection;

/**
 * 질문게시판 전용 DAO 클래스 (질문게시판 카테고리 ID: 2)
 * FreeBoardDAO 기반으로 질문게시판에 특화된 기능 제공
 */
public class QuestionBoardDAO {
    
    private int questionBoardCategoryId;  // 질문게시판 카테고리 ID
    
    /**
     * 생성자 - 질문게시판 카테고리 ID 동적 조회
     */
    public QuestionBoardDAO() {
        this.questionBoardCategoryId = getCategoryIdByCode("question");
        if (this.questionBoardCategoryId > 0) {
            System.out.println("✅ QuestionBoardDAO 초기화 성공 - 질문게시판 ID: " + this.questionBoardCategoryId);
        } else {
            System.err.println("❌ QuestionBoardDAO 초기화 실패 - 질문게시판 카테고리를 찾을 수 없음");
        }
    }
    
    /**
     * 카테고리 코드로 카테고리 ID 조회
     */
    private int getCategoryIdByCode(String categoryCode) {
        String sql = "SELECT category_id FROM board_categories WHERE category_code = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, categoryCode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int categoryId = rs.getInt("category_id");
                    System.out.println("📍 카테고리 '" + categoryCode + "' ID: " + categoryId);
                    return categoryId;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 카테고리 ID 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1; // 실패 시
    }
    
    /**
     * 질문게시판 게시글 작성
     */
    public boolean insertQuestionPost(Post post) {
        if (questionBoardCategoryId <= 0) {
            System.err.println("❌ 질문게시판 카테고리 ID가 유효하지 않음");
            return false;
        }
        
        String sql = "INSERT INTO posts (category_id, class_id, author_id, title, content, " +
                    "is_anonymous, is_pinned, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, questionBoardCategoryId);
            pstmt.setObject(2, post.getClassId(), Types.INTEGER);
            pstmt.setInt(3, post.getAuthorId());
            pstmt.setString(4, post.getTitle());
            pstmt.setString(5, post.getContent());
            pstmt.setBoolean(6, post.isAnonymous());
            pstmt.setBoolean(7, post.isPinned() != null ? post.isPinned() : false);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        post.setPostId(rs.getInt(1));
                        System.out.println("✅ 질문게시판 게시글 작성 성공: ID=" + post.getPostId());
                        return true;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 게시글 작성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 질문게시판 게시글 목록 조회 (페이징, 검색 지원)
     */
    public List<Post> getQuestionPostList(Integer classId, int page, int pageSize, String searchType, String keyword) {
        List<Post> posts = new ArrayList<>();
        
        if (questionBoardCategoryId <= 0) {
            return posts;
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, ");
        sql.append("p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, ");
        sql.append("u.name AS author_name, u.role AS author_role, ");
        sql.append("(SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id AND c.status = 'active') AS comment_count, ");
        sql.append("(SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.post_id) AS attachment_count ");
        sql.append("FROM posts p ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND p.category_id = ? ");
        
        List<Object> params = new ArrayList<>();
        params.add(questionBoardCategoryId);
        
        // 수업 필터링
        if (classId != null && classId > 0) {
            sql.append("AND p.class_id = ? ");
            params.add(classId);
        }
        
        // 검색 조건 추가
        if (keyword != null && !keyword.trim().isEmpty()) {
            keyword = keyword.trim();
            if ("title".equals(searchType)) {
                sql.append("AND p.title LIKE ? ");
                params.add("%" + keyword + "%");
            } else if ("content".equals(searchType)) {
                sql.append("AND p.content LIKE ? ");
                params.add("%" + keyword + "%");
            } else if ("author".equals(searchType)) {
                sql.append("AND u.name LIKE ? ");
                params.add("%" + keyword + "%");
            } else {
                // 전체 검색
                sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR u.name LIKE ?) ");
                params.add("%" + keyword + "%");
                params.add("%" + keyword + "%");
                params.add("%" + keyword + "%");
            }
        }
        
        sql.append("ORDER BY p.is_pinned DESC, p.created_at DESC ");
        sql.append("LIMIT ? OFFSET ?");
        params.add(pageSize);
        params.add((page - 1) * pageSize);
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    posts.add(post);
                }
            }
            
            System.out.println("✅ 질문게시판 목록 조회 성공: " + posts.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return posts;
    }
    
    /**
     * 질문게시판 게시글 개수 조회
     */
    public int getQuestionPostCount(Integer classId, String searchType, String keyword) {
        if (questionBoardCategoryId <= 0) {
            return 0;
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM posts p ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND p.category_id = ? ");
        
        List<Object> params = new ArrayList<>();
        params.add(questionBoardCategoryId);
        
        // 수업 필터링
        if (classId != null && classId > 0) {
            sql.append("AND p.class_id = ? ");
            params.add(classId);
        }
        
        // 검색 조건 추가
        if (keyword != null && !keyword.trim().isEmpty()) {
            keyword = keyword.trim();
            if ("title".equals(searchType)) {
                sql.append("AND p.title LIKE ? ");
                params.add("%" + keyword + "%");
            } else if ("content".equals(searchType)) {
                sql.append("AND p.content LIKE ? ");
                params.add("%" + keyword + "%");
            } else if ("author".equals(searchType)) {
                sql.append("AND u.name LIKE ? ");
                params.add("%" + keyword + "%");
            } else {
                sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR u.name LIKE ?) ");
                params.add("%" + keyword + "%");
                params.add("%" + keyword + "%");
                params.add("%" + keyword + "%");
            }
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 게시글 개수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    /**
     * 질문게시판 게시글 상세 조회
     */
    public Post getQuestionPost(int postId) {
        if (questionBoardCategoryId <= 0) {
            return null;
        }
        
        String sql = "SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, " +
                    "p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, " +
                    "u.name AS author_name, u.role AS author_role, " +
                    "(SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id AND c.status = 'active') AS comment_count, " +
                    "(SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.post_id) AS attachment_count " +
                    "FROM posts p " +
                    "LEFT JOIN users u ON p.author_id = u.user_id " +
                    "WHERE p.post_id = ? AND p.status = 'active' AND p.category_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, questionBoardCategoryId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    System.out.println("✅ 질문게시판 게시글 조회 성공: " + post.getTitle());
                    return post;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 게시글 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * 질문게시판 게시글 수정
     */
    public boolean updateQuestionPost(Post post) {
        if (questionBoardCategoryId <= 0) {
            return false;
        }
        
        String sql = "UPDATE posts SET title = ?, content = ?, is_anonymous = ?, " +
                    "is_pinned = COALESCE(?, is_pinned), updated_at = NOW() " +
                    "WHERE post_id = ? AND author_id = ? AND category_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, post.getTitle());
            pstmt.setString(2, post.getContent());
            pstmt.setBoolean(3, post.isAnonymous());
            pstmt.setObject(4, post.isPinned(), Types.BOOLEAN);
            pstmt.setInt(5, post.getPostId());
            pstmt.setInt(6, post.getAuthorId());
            pstmt.setInt(7, questionBoardCategoryId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 질문게시판 게시글 수정 성공: " + post.getPostId());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 게시글 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 질문게시판 게시글 삭제 (상태 변경)
     */
    public boolean deleteQuestionPost(int postId, int authorId) {
        if (questionBoardCategoryId <= 0) {
            return false;
        }
        
        String sql = "UPDATE posts SET status = 'deleted', updated_at = NOW() " +
                    "WHERE post_id = ? AND author_id = ? AND category_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, authorId);
            pstmt.setInt(3, questionBoardCategoryId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 질문게시판 게시글 삭제 성공: " + postId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 게시글 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 질문게시판 조회수 증가
     */
    public void increaseViewCount(int postId) {
        if (questionBoardCategoryId <= 0) {
            return;
        }
        
        String sql = "UPDATE posts SET view_count = view_count + 1 " +
                    "WHERE post_id = ? AND category_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, questionBoardCategoryId);
            
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 조회수 증가 실패: " + e.getMessage());
        }
    }
    
    /**
     * 질문게시판 댓글 목록 조회
     */
    public List<Comment> getQuestionPostComments(int postId) {
        List<Comment> comments = new ArrayList<>();
        
        if (questionBoardCategoryId <= 0) {
            return comments;
        }
        
        String sql = "SELECT c.comment_id, c.post_id, c.author_id, c.content, c.parent_comment_id, " +
                    "c.is_anonymous, c.status, c.created_at, c.updated_at, " +
                    "u.name AS author_name, u.role AS author_role " +
                    "FROM comments c " +
                    "LEFT JOIN users u ON c.author_id = u.user_id " +
                    "JOIN posts p ON c.post_id = p.post_id " +
                    "WHERE c.post_id = ? " +
                    "AND c.status = 'active' " +
                    "AND p.category_id = ? " +
                    "ORDER BY c.parent_comment_id IS NULL DESC, c.parent_comment_id ASC, c.created_at ASC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, questionBoardCategoryId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Comment comment = createCommentFromResultSet(rs);
                    comments.add(comment);
                }
            }
            
            System.out.println("✅ 질문게시판 댓글 목록 조회 성공: " + comments.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 댓글 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return comments;
    }
    
    /**
     * 질문게시판 댓글 작성
     */
    public boolean insertQuestionPostComment(Comment comment) {
        String sql = "INSERT INTO comments (post_id, author_id, content, parent_comment_id, " +
                    "is_anonymous, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, 'active', NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, comment.getPostId());
            pstmt.setInt(2, comment.getAuthorId());
            pstmt.setString(3, comment.getContent());
            pstmt.setObject(4, comment.getParentId(), Types.INTEGER);
            pstmt.setBoolean(5, comment.isAnonymous());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        comment.setId(rs.getInt(1));
                        System.out.println("✅ 질문게시판 댓글 작성 성공: ID=" + comment.getId());
                        return true;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 댓글 작성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 질문게시판 전체 게시글 수 조회
     */
    public int getTotalQuestionPostCount() {
        if (questionBoardCategoryId <= 0) {
            return 0;
        }
        
        String sql = "SELECT COUNT(*) FROM posts WHERE status = 'active' AND category_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, questionBoardCategoryId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 질문게시판 전체 게시글 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    /**
     * ResultSet에서 Post 객체 생성
     */
    private Post createPostFromResultSet(ResultSet rs) throws SQLException {
        Post post = new Post();
        post.setPostId(rs.getInt("post_id"));
        post.setCategoryId(rs.getInt("category_id"));
        post.setClassId(rs.getObject("class_id") != null ? rs.getInt("class_id") : null);
        post.setAuthorId(rs.getInt("author_id"));
        post.setTitle(rs.getString("title"));
        post.setContent(rs.getString("content"));
        post.setViewCount(rs.getInt("view_count"));
        post.setAnonymous(rs.getBoolean("is_anonymous"));
        post.setPinned(rs.getBoolean("is_pinned"));
        post.setStatus(rs.getString("status"));
        post.setCreatedAt(rs.getTimestamp("created_at"));
        post.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        // 작성자 정보
        post.setAuthorName(rs.getString("author_name"));
        post.setAuthorRole(rs.getString("author_role"));
        
        // 추가 정보
        post.setCommentCount(rs.getInt("comment_count"));
        post.setAttachmentCount(rs.getInt("attachment_count"));
        
        // 카테고리 코드 설정
        post.setCategoryCode("question");
        
        return post;
    }
    
    /**
     * ResultSet에서 Comment 객체 생성
     */
    private Comment createCommentFromResultSet(ResultSet rs) throws SQLException {
        Comment comment = new Comment();
        comment.setId(rs.getInt("comment_id"));
        comment.setPostId(rs.getInt("post_id"));
        comment.setAuthorId(rs.getInt("author_id"));
        comment.setContent(rs.getString("content"));
        comment.setParentId(rs.getObject("parent_comment_id") != null ? rs.getInt("parent_comment_id") : null);
        comment.setAnonymous(rs.getBoolean("is_anonymous"));
        comment.setStatus(rs.getString("status"));
        comment.setCreatedAt(rs.getTimestamp("created_at"));
        comment.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        // 작성자 정보
        comment.setAuthorName(rs.getString("author_name"));
        comment.setAuthorRole(rs.getString("author_role"));
        
        return comment;
    }
}