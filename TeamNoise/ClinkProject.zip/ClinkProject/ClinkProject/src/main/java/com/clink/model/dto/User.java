package com.clink.model.dto;

import java.sql.Timestamp;

/**
 * 사용자 DTO 클래스
 * 데이터베이스 스키마에 맞춰 email 필드 제거
 */
public class User {
    private int userId;
    private String username;
    private String password;
    private String name;
    private String role;           // 'student' 또는 'professor'
    private String phone;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private boolean isActive;
    
    // 기본 생성자
    public User() {}
    
    // 로그인용 생성자
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
    
    // 회원가입용 생성자
    public User(String username, String password, String name, String role) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.role = role;
        this.isActive = true;
    }
    
    // 완전한 생성자
    public User(int userId, String username, String password, String name, 
                String role, String phone, Timestamp createdAt, Timestamp updatedAt, boolean isActive) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.name = name;
        this.role = role;
        this.phone = phone;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.isActive = isActive;
    }
    
    // Getter & Setter 메서드들
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    // 유틸리티 메서드들
    public boolean isProfessor() {
        return "professor".equals(this.role);
    }
    
    public boolean isStudent() {
        return "student".equals(this.role);
    }
    
    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                ", phone='" + phone + '\'' +
                ", isActive=" + isActive +
                '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        User user = (User) obj;
        return userId == user.userId;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(userId);
    }
}