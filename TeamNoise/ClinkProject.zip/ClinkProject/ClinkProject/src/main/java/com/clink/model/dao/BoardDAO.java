package com.clink.model.dao;

import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;
import com.clink.util.DBConnection;

import java.sql.*;
import java.util.*;

/**
 * BoardDAO - 완전 호환 버전 + FreeBoardService 연동
 * ✅ 기존 메서드 유지 (호환성)
 * ✅ categoryId 기반 메서드 추가 (Service 연동)
 * ✅ FreeBoardService, BoardService 모두 지원
 */
public class BoardDAO {
    
    // ========================================
    // 🚀 categoryId 기반 메서드들 (Service 연동용)
    // ========================================
    
    /**
     * 카테고리 ID로 게시글 목록 조회 (Service 연동용)
     */
    public List<Post> getPostList(int categoryId, int page, int pageSize, String searchType, String keyword) {
        List<Post> posts = new ArrayList<>();
        
        // 기본값 설정
        if (page <= 0) page = 1;
        if (pageSize <= 0) pageSize = 10;
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, ");
        sql.append("p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, ");
        sql.append("bc.category_name, bc.category_code, ");
        sql.append("c.class_name, c.class_code, ");
        sql.append("CASE WHEN p.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, ");
        sql.append("u.role as author_role, ");
        sql.append("(SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.post_id AND cm.status = 'active') as comment_count ");
        sql.append("FROM posts p ");
        sql.append("JOIN board_categories bc ON p.category_id = bc.category_id ");
        sql.append("LEFT JOIN classes c ON p.class_id = c.class_id ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND p.category_id = ? ");
        
        List<Object> params = new ArrayList<>();
        params.add(categoryId);
        
        // 검색 조건
        if (keyword != null && !keyword.trim().isEmpty()) {
            switch (searchType != null ? searchType.toLowerCase() : "all") {
                case "title":
                    sql.append("AND p.title LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "content":
                    sql.append("AND p.content LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "author":
                    sql.append("AND u.name LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                default: // "all"
                    sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR u.name LIKE ?) ");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    break;
            }
        }
        
        // 정렬 및 페이징
        sql.append("ORDER BY p.is_pinned DESC, p.created_at DESC ");
        sql.append("LIMIT ? OFFSET ?");
        params.add(pageSize);
        params.add((page - 1) * pageSize);
        
        System.out.println("🔍 SQL (categoryId): " + sql.toString());
        System.out.println("🔍 파라미터: " + params);
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            // 파라미터 설정
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    posts.add(post);
                }
            }
            
            System.out.println("✅ 게시글 조회 성공 (categoryId=" + categoryId + "): " + posts.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return posts;
    }
    
    /**
     * 카테고리 ID로 게시글 총 개수 조회 (Service 연동용)
     */
    public int getTotalPostCount(int categoryId, String searchType, String keyword) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM posts p ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND p.category_id = ? ");
        
        List<Object> params = new ArrayList<>();
        params.add(categoryId);
        
        // 검색 조건
        if (keyword != null && !keyword.trim().isEmpty()) {
            switch (searchType != null ? searchType.toLowerCase() : "all") {
                case "title":
                    sql.append("AND p.title LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "content":
                    sql.append("AND p.content LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "author":
                    sql.append("AND u.name LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                default: // "all"
                    sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR u.name LIKE ?) ");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    break;
            }
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            // 파라미터 설정
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    System.out.println("✅ 게시글 개수 (categoryId=" + categoryId + "): " + count + "개");
                    return count;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 개수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🚀 기존 categoryCode 기반 메서드들 (호환성 유지)
    // ========================================
    
    /**
     * 게시글 목록 조회 (페이징) - 완전 호환 버전
     */
    public List<Post> getPostList(String categoryCode, Integer classId, int page, int pageSize, String searchType, String keyword) {
        List<Post> posts = new ArrayList<>();
        
        // 기본값 설정
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            categoryCode = "free";
        }
        if (page <= 0) page = 1;
        if (pageSize <= 0) pageSize = 10;
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, ");
        sql.append("p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, ");
        sql.append("bc.category_name, bc.category_code, ");
        sql.append("c.class_name, c.class_code, ");
        sql.append("CASE WHEN p.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, ");
        sql.append("u.role as author_role, ");
        sql.append("(SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.post_id AND cm.status = 'active') as comment_count ");
        sql.append("FROM posts p ");
        sql.append("JOIN board_categories bc ON p.category_id = bc.category_id ");
        sql.append("LEFT JOIN classes c ON p.class_id = c.class_id ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' ");
        
        List<Object> params = new ArrayList<>();
        
        // 카테고리 필터
        sql.append("AND bc.category_code = ? ");
        params.add(categoryCode);
        
        // 수업 필터
        if (classId != null) {
            sql.append("AND p.class_id = ? ");
            params.add(classId);
        }
        
        // 검색 조건
        if (keyword != null && !keyword.trim().isEmpty()) {
            switch (searchType != null ? searchType.toLowerCase() : "all") {
                case "title":
                    sql.append("AND p.title LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "content":
                    sql.append("AND p.content LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "author":
                    sql.append("AND u.name LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                default: // "all"
                    sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR u.name LIKE ?) ");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    break;
            }
        }
        
        // 정렬 및 페이징
        sql.append("ORDER BY p.is_pinned DESC, p.created_at DESC ");
        sql.append("LIMIT ? OFFSET ?");
        params.add(pageSize);
        params.add((page - 1) * pageSize);
        
        System.out.println("🔍 SQL (categoryCode): " + sql.toString());
        System.out.println("🔍 파라미터: " + params);
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            // 파라미터 설정
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    posts.add(post);
                }
            }
            
            System.out.println("✅ 게시글 조회 성공: " + posts.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return posts;
    }
    
    /**
     * 게시글 총 개수 조회
     */
    public int getPostCount(String categoryCode, Integer classId, String searchType, String keyword) {
        // 기본값 설정
        if (categoryCode == null || categoryCode.trim().isEmpty()) {
            categoryCode = "free";
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM posts p ");
        sql.append("JOIN board_categories bc ON p.category_id = bc.category_id ");
        sql.append("LEFT JOIN classes c ON p.class_id = c.class_id ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' ");
        
        List<Object> params = new ArrayList<>();
        
        // 카테고리 필터
        sql.append("AND bc.category_code = ? ");
        params.add(categoryCode);
        
        // 수업 필터
        if (classId != null) {
            sql.append("AND p.class_id = ? ");
            params.add(classId);
        }
        
        // 검색 조건
        if (keyword != null && !keyword.trim().isEmpty()) {
            switch (searchType != null ? searchType.toLowerCase() : "all") {
                case "title":
                    sql.append("AND p.title LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "content":
                    sql.append("AND p.content LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                case "author":
                    sql.append("AND u.name LIKE ? ");
                    params.add("%" + keyword + "%");
                    break;
                default: // "all"
                    sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR u.name LIKE ?) ");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    params.add("%" + keyword + "%");
                    break;
            }
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            // 파라미터 설정
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    System.out.println("✅ 게시글 개수: " + count + "개");
                    return count;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 개수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🚀 공통 CRUD 메서드들
    // ========================================
    
    /**
     * 게시글 상세 조회
     */
    public Post getPost(int postId) {
        String sql = "SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, " +
                    "p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, " +
                    "bc.category_name, bc.category_code, " +
                    "c.class_name, c.class_code, " +
                    "CASE WHEN p.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, " +
                    "u.role as author_role, " +
                    "(SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.post_id AND cm.status = 'active') as comment_count " +
                    "FROM posts p " +
                    "JOIN board_categories bc ON p.category_id = bc.category_id " +
                    "LEFT JOIN classes c ON p.class_id = c.class_id " +
                    "LEFT JOIN users u ON p.author_id = u.user_id " +
                    "WHERE p.post_id = ? AND p.status = 'active'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    System.out.println("✅ 게시글 조회 성공: " + post.getTitle());
                    return post;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * 조회수 증가
     */
    public boolean increaseViewCount(int postId) {
        String sql = "UPDATE posts SET view_count = view_count + 1 WHERE post_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 조회수 증가: " + postId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 조회수 증가 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 게시글 작성
     */
    public boolean createPost(Post post) {
        String sql = "INSERT INTO posts (category_id, class_id, author_id, title, content, " +
                    "is_anonymous, is_pinned, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, post.getCategoryId());
            pstmt.setObject(2, post.getClassId(), Types.INTEGER);
            pstmt.setInt(3, post.getAuthorId());
            pstmt.setString(4, post.getTitle());
            pstmt.setString(5, post.getContent());
            pstmt.setBoolean(6, post.isAnonymous() != null ? post.isAnonymous() : false);
            pstmt.setBoolean(7, post.isPinned() != null ? post.isPinned() : false);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        post.setPostId(rs.getInt(1));
                        System.out.println("✅ 게시글 작성 성공: ID=" + post.getPostId());
                        return true;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 작성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 게시글 수정
     */
    public boolean updatePost(Post post) {
        String sql = "UPDATE posts SET title = ?, content = ?, is_anonymous = ?, " +
                    "is_pinned = ?, updated_at = NOW() " +
                    "WHERE post_id = ? AND author_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, post.getTitle());
            pstmt.setString(2, post.getContent());
            pstmt.setBoolean(3, post.isAnonymous() != null ? post.isAnonymous() : false);
            pstmt.setBoolean(4, post.isPinned() != null ? post.isPinned() : false);
            pstmt.setInt(5, post.getPostId());
            pstmt.setInt(6, post.getAuthorId());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 게시글 수정 성공: ID=" + post.getPostId());
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 게시글 삭제 (학생용 - 본인 글만)
     */
    public boolean deletePost(int postId, int authorId) {
        String sql = "UPDATE posts SET status = 'deleted', updated_at = NOW() " +
                    "WHERE post_id = ? AND author_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, authorId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 게시글 삭제 성공: ID=" + postId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 게시글 삭제 (교수용 - 모든 글)
     */
    public boolean deletePostByAdmin(int postId) {
        String sql = "UPDATE posts SET status = 'deleted', updated_at = NOW() " +
                    "WHERE post_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 게시글 삭제 성공 (관리자): ID=" + postId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 관리자 게시글 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ========================================
    // 🚀 댓글 관련 메서드들
    // ========================================
    
    /**
     * 댓글 목록 조회
     */
    public List<Comment> getCommentList(int postId) {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT c.comment_id, c.post_id, c.author_id, c.content, " +
                    "c.parent_comment_id, c.is_anonymous, c.status, c.created_at, c.updated_at, " +
                    "CASE WHEN c.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, " +
                    "u.role as author_role " +
                    "FROM comments c " +
                    "LEFT JOIN users u ON c.author_id = u.user_id " +
                    "WHERE c.post_id = ? AND c.status = 'active' " +
                    "ORDER BY c.parent_comment_id ASC, c.created_at ASC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Comment comment = createCommentFromResultSet(rs);
                    comments.add(comment);
                }
            }
            
            System.out.println("✅ 댓글 조회 성공: " + comments.size() + "개");
            
        } catch (SQLException e) {
            System.err.println("❌ 댓글 목록 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return comments;
    }
    
    /**
     * 댓글 작성
     */
    public boolean createComment(Comment comment) {
        String sql = "INSERT INTO comments (post_id, author_id, content, parent_comment_id, " +
                    "is_anonymous, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, 'active', NOW(), NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, comment.getPostId());
            pstmt.setInt(2, comment.getAuthorId());
            pstmt.setString(3, comment.getContent());
            pstmt.setObject(4, comment.getParentId(), Types.INTEGER);
            pstmt.setBoolean(5, comment.isAnonymous()); // ✅ null 체크 제거 (boolean primitive)
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        comment.setId(rs.getInt(1));
                        System.out.println("✅ 댓글 작성 성공: ID=" + comment.getId());
                        return true;
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 댓글 작성 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 댓글 수정
     */
    public boolean updateComment(int commentId, int authorId, String content) {
        String sql = "UPDATE comments SET content = ?, updated_at = NOW() " +
                    "WHERE comment_id = ? AND author_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, content);
            pstmt.setInt(2, commentId);
            pstmt.setInt(3, authorId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 댓글 수정 성공: ID=" + commentId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 댓글 수정 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 댓글 삭제 (학생용 - 본인 댓글만)
     */
    public boolean deleteComment(int commentId, int authorId) {
        String sql = "UPDATE comments SET status = 'deleted', updated_at = NOW() " +
                    "WHERE comment_id = ? AND author_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, commentId);
            pstmt.setInt(2, authorId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 댓글 삭제 성공: ID=" + commentId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 댓글 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 댓글 삭제 (교수용 - 모든 댓글)
     */
    public boolean deleteCommentByAdmin(int commentId) {
        String sql = "UPDATE comments SET status = 'deleted', updated_at = NOW() " +
                    "WHERE comment_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, commentId);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                System.out.println("✅ 댓글 삭제 성공 (관리자): ID=" + commentId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 관리자 댓글 삭제 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    // ========================================
    // 🚀 기타 유틸리티 메서드들
    // ========================================
    
    /**
     * 카테고리 ID를 카테고리 코드로 조회
     */
    public int getCategoryIdByCode(String categoryCode) {
        String sql = "SELECT category_id FROM board_categories WHERE category_code = ? AND is_active = 1";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, categoryCode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("category_id");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 카테고리 ID 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1;
    }
    
    /**
     * 게시글 작성자 ID 조회
     */
    public int getPostAuthorId(int postId) {
        String sql = "SELECT author_id FROM posts WHERE post_id = ? AND status = 'active'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("author_id");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 게시글 작성자 ID 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1;
    }
    
    /**
     * 댓글 작성자 ID 조회
     */
    public int getCommentAuthorId(int commentId) {
        String sql = "SELECT author_id FROM comments WHERE comment_id = ? AND status = 'active'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, commentId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("author_id");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 댓글 작성자 ID 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1;
    }
    
    /**
     * 최근 게시글 조회
     */
    public List<Post> getRecentPosts(String categoryCode, int limit) {
        List<Post> posts = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        
        sql.append("SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, ");
        sql.append("p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, ");
        sql.append("bc.category_name, bc.category_code, ");
        sql.append("c.class_name, c.class_code, ");
        sql.append("CASE WHEN p.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, ");
        sql.append("u.role as author_role, ");
        sql.append("(SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.post_id AND cm.status = 'active') as comment_count ");
        sql.append("FROM posts p ");
        sql.append("JOIN board_categories bc ON p.category_id = bc.category_id ");
        sql.append("LEFT JOIN classes c ON p.class_id = c.class_id ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND bc.category_code = ? ");
        sql.append("ORDER BY p.created_at DESC LIMIT ?");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setString(1, categoryCode);
            pstmt.setInt(2, limit);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    posts.add(post);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 최근 게시글 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return posts;
    }
    
    /**
     * 인기 게시글 조회
     */
    public List<Post> getPopularPosts(String categoryCode, int limit) {
        List<Post> posts = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        
        sql.append("SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, ");
        sql.append("p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, ");
        sql.append("bc.category_name, bc.category_code, ");
        sql.append("c.class_name, c.class_code, ");
        sql.append("CASE WHEN p.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, ");
        sql.append("u.role as author_role, ");
        sql.append("(SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.post_id AND cm.status = 'active') as comment_count ");
        sql.append("FROM posts p ");
        sql.append("JOIN board_categories bc ON p.category_id = bc.category_id ");
        sql.append("LEFT JOIN classes c ON p.class_id = c.class_id ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND bc.category_code = ? ");
        sql.append("ORDER BY p.view_count DESC, p.created_at DESC LIMIT ?");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setString(1, categoryCode);
            pstmt.setInt(2, limit);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    posts.add(post);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 인기 게시글 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return posts;
    }
    
    /**
     * 공지사항 조회
     */
    public List<Post> getNotices(String categoryCode, int limit) {
        List<Post> posts = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        
        sql.append("SELECT p.post_id, p.category_id, p.class_id, p.author_id, p.title, p.content, ");
        sql.append("p.view_count, p.is_anonymous, p.is_pinned, p.status, p.created_at, p.updated_at, ");
        sql.append("bc.category_name, bc.category_code, ");
        sql.append("c.class_name, c.class_code, ");
        sql.append("CASE WHEN p.is_anonymous = TRUE THEN '익명' ELSE u.name END as author_name, ");
        sql.append("u.role as author_role, ");
        sql.append("(SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.post_id AND cm.status = 'active') as comment_count ");
        sql.append("FROM posts p ");
        sql.append("JOIN board_categories bc ON p.category_id = bc.category_id ");
        sql.append("LEFT JOIN classes c ON p.class_id = c.class_id ");
        sql.append("LEFT JOIN users u ON p.author_id = u.user_id ");
        sql.append("WHERE p.status = 'active' AND bc.category_code = ? AND p.is_pinned = TRUE ");
        sql.append("ORDER BY p.created_at DESC LIMIT ?");
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            pstmt.setString(1, categoryCode);
            pstmt.setInt(2, limit);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = createPostFromResultSet(rs);
                    posts.add(post);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 공지사항 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return posts;
    }
    
    /**
     * 카테고리별 게시글 수 조회
     */
    public int getCategoryPostCount(String categoryCode) {
        String sql = "SELECT COUNT(*) FROM posts p " +
                    "JOIN board_categories bc ON p.category_id = bc.category_id " +
                    "WHERE p.status = 'active' AND bc.category_code = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, categoryCode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ 카테고리별 게시글 수 조회 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ========================================
    // 🚀 헬퍼 메서드들
    // ========================================
    
    /**
     * ResultSet에서 Post 객체 생성 - 완전 호환 버전
     */
    private Post createPostFromResultSet(ResultSet rs) throws SQLException {
        Post post = new Post();
        
        // 기본 필드들
        post.setPostId(rs.getInt("post_id"));
        post.setCategoryId(rs.getInt("category_id"));
        post.setClassId(rs.getObject("class_id", Integer.class));
        post.setAuthorId(rs.getInt("author_id"));
        post.setTitle(rs.getString("title"));
        post.setContent(rs.getString("content"));
        post.setViewCount(rs.getInt("view_count"));
        post.setAnonymous(rs.getBoolean("is_anonymous"));
        post.setPinned(rs.getBoolean("is_pinned"));
        post.setStatus(rs.getString("status"));
        post.setCreatedAt(rs.getTimestamp("created_at"));
        post.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        // 추가 정보들 (안전하게 설정)
        try {
            post.setCategoryName(rs.getString("category_name"));
            post.setCategoryCode(rs.getString("category_code"));
            post.setAuthorName(rs.getString("author_name"));
            post.setAuthorRole(rs.getString("author_role"));
            post.setCommentCount(rs.getInt("comment_count"));
            
            // 수업 정보 (nullable)
            String className = rs.getString("class_name");
            if (className != null) {
                post.setClassName(className);
                post.setClassCode(rs.getString("class_code"));
            }
        } catch (SQLException e) {
            // 컬럼이 없는 경우 무시 (안전 처리)
            System.out.println("일부 컬럼 누락 (정상): " + e.getMessage());
        }
        
        return post;
    }
    
    /**
     * ResultSet에서 Comment 객체 생성
     */
    private Comment createCommentFromResultSet(ResultSet rs) throws SQLException {
        Comment comment = new Comment();
        comment.setId(rs.getInt("comment_id"));
        comment.setPostId(rs.getInt("post_id"));
        comment.setAuthorId(rs.getInt("author_id"));
        comment.setContent(rs.getString("content"));
        comment.setParentId(rs.getObject("parent_comment_id", Integer.class));
        comment.setAnonymous(rs.getBoolean("is_anonymous"));
        comment.setStatus(rs.getString("status"));
        comment.setCreatedAt(rs.getTimestamp("created_at")); // ✅ Timestamp 직접 설정
        comment.setUpdatedAt(rs.getTimestamp("updated_at")); // ✅ Timestamp 직접 설정
        comment.setAuthorName(rs.getString("author_name"));
        
        // 추가 정보 (안전하게 설정)
        try {
            comment.setAuthorRole(rs.getString("author_role"));
        } catch (SQLException e) {
            // 컬럼이 없는 경우 무시
        }
        
        return comment;
    }
    
    /**
     * 데이터베이스 연결 테스트
     */
    public boolean testConnection() {
        try (Connection conn = DBConnection.getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("❌ DB 연결 테스트 실패: " + e.getMessage());
            return false;
        }
    }
    
    // ========================================
    // 🚀 별칭 메서드들 (기존 코드 호환성)
    // ========================================
    
    public boolean insertComment(Comment comment) {
        return createComment(comment);
    }
    
    public boolean insertPost(Post post) {
        return createPost(post);
    }
}