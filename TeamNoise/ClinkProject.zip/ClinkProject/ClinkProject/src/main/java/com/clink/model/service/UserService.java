package com.clink.model.service;

import com.clink.model.dao.UserDAO;
import com.clink.model.dto.User;

public class UserService {
    
    private UserDAO userDAO;
    
    public UserService() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * 사용자 로그인 처리
     * @param username 사용자명
     * @param password 비밀번호
     * @return 로그인 성공시 사용자 객체, 실패시 null
     */
    public User login(String username, String password) {
        // 입력값 검증
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            System.out.println("로그인 실패: 아이디와 비밀번호를 입력해주세요.");
            return null;
        }
        
        // 데이터베이스에서 사용자 인증
        User user = userDAO.authenticateUser(username.trim(), password);
        
        if (user != null) {
            System.out.println("로그인 성공: " + user.getName() + " (" + user.getRole() + ")");
            // 비밀번호는 보안상 null로 설정
            user.setPassword(null);
        } else {
            System.out.println("로그인 실패: 아이디 또는 비밀번호가 올바르지 않습니다.");
        }
        
        return user;
    }
    
    /**
     * 사용자 회원가입 처리
     * @param username 사용자명
     * @param password 비밀번호
     * @param name 이름
     * @param role 역할 (student/professor)
     * @param authCode 교수 인증 코드 (교수인 경우)
     * @return 회원가입 성공시 true, 실패시 false
     */
    public boolean register(String username, String password, String name, String role, String authCode) {
        // 입력값 검증
        if (!validateRegistrationInput(username, password, name, role)) {
            return false;
        }
        
        // 교수인 경우 인증 코드 검증
        if ("professor".equals(role)) {
            if (authCode == null || authCode.trim().isEmpty()) {
                System.out.println("회원가입 실패: 교수 인증 코드를 입력해주세요.");
                return false;
            }
            
            if (!userDAO.validateProfessorAuthCode(authCode.trim())) {
                System.out.println("회원가입 실패: 올바르지 않은 교수 인증 코드입니다.");
                return false;
            }
        }
        
        // 사용자명 중복 체크
        if (userDAO.isUsernameExists(username.trim())) {
            System.out.println("회원가입 실패: 이미 존재하는 아이디입니다.");
            return false;
        }
        
        // 사용자 객체 생성 및 등록
        User newUser = new User(username.trim(), password, name.trim(), role);
        boolean isSuccess = userDAO.registerUser(newUser);
        
        if (isSuccess) {
            System.out.println("회원가입 성공: " + name + " (" + role + ")");
        } else {
            System.out.println("회원가입 실패: 데이터베이스 오류가 발생했습니다.");
        }
        
        return isSuccess;
    }
    
    /**
     * 비밀번호 찾기
     * @param name 이름
     * @param username 사용자명
     * @return 찾은 사용자 정보, 없으면 null
     */
    public User findPassword(String name, String username) {
        // 입력값 검증
        if (name == null || name.trim().isEmpty() || 
            username == null || username.trim().isEmpty()) {
            System.out.println("비밀번호 찾기 실패: 이름과 아이디를 입력해주세요.");
            return null;
        }
        
        User user = userDAO.findUserByNameAndUsername(name.trim(), username.trim());
        
        if (user != null) {
            System.out.println("사용자 찾기 성공: " + user.getName());
            // 보안상 실제 비밀번호는 마스킹 처리
            String maskedPassword = maskPassword(user.getPassword());
            user.setPassword(maskedPassword);
        } else {
            System.out.println("사용자 찾기 실패: 해당 정보로 등록된 계정을 찾을 수 없습니다.");
        }
        
        return user;
    }
    
    /**
     * 사용자 정보 조회
     * @param userId 사용자 ID
     * @return 사용자 정보
     */
    public User getUserInfo(int userId) {
        User user = userDAO.getUserById(userId);
        if (user != null) {
            // 비밀번호는 보안상 null로 설정
            user.setPassword(null);
        }
        return user;
    }
    
    /**
     * 사용자 정보 업데이트
     * @param user 업데이트할 사용자 정보
     * @return 성공시 true, 실패시 false
     */
    public boolean updateUserInfo(User user) {
        if (user == null || user.getUserId() <= 0) {
            System.out.println("사용자 정보 업데이트 실패: 올바르지 않은 사용자 정보입니다.");
            return false;
        }
        
        boolean isSuccess = userDAO.updateUser(user);
        
        if (isSuccess) {
            System.out.println("사용자 정보 업데이트 성공: " + user.getName());
        } else {
            System.out.println("사용자 정보 업데이트 실패");
        }
        
        return isSuccess;
    }
    
    /**
     * 비밀번호 변경
     * @param userId 사용자 ID
     * @param currentPassword 현재 비밀번호
     * @param newPassword 새 비밀번호
     * @return 성공시 true, 실패시 false
     */
    public boolean changePassword(int userId, String currentPassword, String newPassword) {
        // 입력값 검증
        if (currentPassword == null || currentPassword.trim().isEmpty() ||
            newPassword == null || newPassword.trim().isEmpty()) {
            System.out.println("비밀번호 변경 실패: 현재 비밀번호와 새 비밀번호를 입력해주세요.");
            return false;
        }
        
        if (newPassword.length() < 6) {
            System.out.println("비밀번호 변경 실패: 새 비밀번호는 6자 이상이어야 합니다.");
            return false;
        }
        
        // 현재 비밀번호 확인
        User user = userDAO.getUserById(userId);
        if (user == null || !user.getPassword().equals(currentPassword)) {
            System.out.println("비밀번호 변경 실패: 현재 비밀번호가 올바르지 않습니다.");
            return false;
        }
        
        boolean isSuccess = userDAO.changePassword(userId, newPassword);
        
        if (isSuccess) {
            System.out.println("비밀번호 변경 성공");
        } else {
            System.out.println("비밀번호 변경 실패");
        }
        
        return isSuccess;
    }
    
    /**
     * 사용자명 중복 체크
     * @param username 확인할 사용자명
     * @return 중복시 true, 사용가능시 false
     */
    public boolean checkUsernameExists(String username) {
        if (username == null || username.trim().isEmpty()) {
            return true; // 빈 값은 중복으로 처리
        }
        
        return userDAO.isUsernameExists(username.trim());
    }
    
    /**
     * 교수 인증 코드 검증
     * @param authCode 인증 코드
     * @return 유효하면 true, 아니면 false
     */
    public boolean validateProfessorAuthCode(String authCode) {
        if (authCode == null || authCode.trim().isEmpty()) {
            return false;
        }
        
        return userDAO.validateProfessorAuthCode(authCode.trim());
    }
    
    /**
     * 회원가입 입력값 검증
     * @param username 사용자명
     * @param password 비밀번호
     * @param name 이름
     * @param role 역할
     * @return 유효하면 true, 아니면 false
     */
    private boolean validateRegistrationInput(String username, String password, String name, String role) {
        // 필수 입력값 체크
        if (username == null || username.trim().isEmpty()) {
            System.out.println("회원가입 실패: 아이디를 입력해주세요.");
            return false;
        }
        
        if (password == null || password.trim().isEmpty()) {
            System.out.println("회원가입 실패: 비밀번호를 입력해주세요.");
            return false;
        }
        
        if (name == null || name.trim().isEmpty()) {
            System.out.println("회원가입 실패: 이름을 입력해주세요.");
            return false;
        }
        
        if (role == null || (!role.equals("student") && !role.equals("professor"))) {
            System.out.println("회원가입 실패: 올바른 역할을 선택해주세요.");
            return false;
        }
        
        // 사용자명 길이 체크
        if (username.trim().length() < 3 || username.trim().length() > 20) {
            System.out.println("회원가입 실패: 아이디는 3자 이상 20자 이하여야 합니다.");
            return false;
        }
        
        // 비밀번호 길이 체크
        if (password.length() < 6) {
            System.out.println("회원가입 실패: 비밀번호는 6자 이상이어야 합니다.");
            return false;
        }
        
        // 이름 길이 체크
        if (name.trim().length() < 2 || name.trim().length() > 20) {
            System.out.println("회원가입 실패: 이름은 2자 이상 20자 이하여야 합니다.");
            return false;
        }
        
        return true;
    }
    
    /**
     * 비밀번호 마스킹 처리
     * @param password 원본 비밀번호
     * @return 마스킹된 비밀번호
     */
    private String maskPassword(String password) {
        if (password == null || password.length() == 0) {
            return "";
        }
        
        if (password.length() <= 2) {
            return "*".repeat(password.length());
        }
        
        // 앞의 2자리만 보여주고 나머지는 * 처리
        return password.substring(0, 2) + "*".repeat(password.length() - 2);
    }
}