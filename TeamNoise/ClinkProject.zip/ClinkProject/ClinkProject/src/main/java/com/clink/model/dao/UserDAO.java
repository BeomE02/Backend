package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.User;
import com.clink.util.DBConnection;

/**
 * 사용자 데이터 접근 객체 (DAO)
 */
public class UserDAO {
    
    /**
     * 사용자 인증 (로그인)
     * @param username 아이디
     * @param password 비밀번호
     * @return 인증된 User 객체, 실패시 null
     */
    public User authenticateUser(String username, String password) {
        String sql = "SELECT user_id, username, password, name, role, phone, created_at, updated_at, is_active " +
                    "FROM users WHERE username = ? AND password = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserId(rs.getInt("user_id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                    user.setPhone(rs.getString("phone"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                    user.setUpdatedAt(rs.getTimestamp("updated_at"));
                    user.setActive(rs.getBoolean("is_active"));
                    
                    System.out.println("DB 인증 성공: " + user.getName() + " (" + user.getRole() + ")");
                    return user;
                }
            }
        } catch (SQLException e) {
            System.err.println("사용자 인증 중 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("DB 인증 실패: " + username);
        return null;
    }
    
    /**
     * 사용자 회원가입
     * @param user 등록할 사용자 정보
     * @return 성공시 true, 실패시 false
     */
    public boolean registerUser(User user) {
        String sql = "INSERT INTO users (username, password, name, role, phone) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getRole());
            pstmt.setString(5, user.getPhone());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("회원가입 DB 저장 성공: " + user.getName());
                return true;
            }
        } catch (SQLException e) {
            System.err.println("회원가입 DB 저장 실패: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔥 누락된 메서드: 사용자명 중복 체크
     * @param username 확인할 사용자명
     * @return 중복시 true, 사용가능시 false
     */
    public boolean isUsernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    boolean exists = rs.getInt(1) > 0;
                    System.out.println("사용자명 중복 체크: " + username + " → " + (exists ? "중복" : "사용가능"));
                    return exists;
                }
            }
        } catch (SQLException e) {
            System.err.println("사용자명 중복 체크 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        return true; // 오류 시 중복으로 처리
    }
    
    /**
     * 🔥 누락된 메서드: 교수 인증 코드 검증
     * @param authCode 인증 코드
     * @return 유효하면 true, 아니면 false
     */
    public boolean validateProfessorAuthCode(String authCode) {
        String sql = "SELECT COUNT(*) FROM professor_auth_codes WHERE auth_code = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, authCode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    boolean valid = rs.getInt(1) > 0;
                    System.out.println("교수 인증 코드 검증: " + authCode + " → " + (valid ? "유효" : "무효"));
                    return valid;
                }
            }
        } catch (SQLException e) {
            System.err.println("교수 인증 코드 검증 DB 오류: " + e.getMessage());
            e.printStackTrace();
            
            // 🔧 테이블이 없을 경우를 대비한 임시 처리
            if (e.getMessage().contains("doesn't exist")) {
                System.out.println("professor_auth_codes 테이블이 없음 - 임시로 기본 코드 체크");
                return "PROF2025".equals(authCode) || "TEACHER01".equals(authCode) || "ADMIN2025".equals(authCode);
            }
        }
        
        return false; // 오류 시 무효로 처리
    }
    
    /**
     * 🔥 누락된 메서드: 이름과 아이디로 사용자 찾기 (비밀번호 찾기용)
     * @param name 이름
     * @param username 사용자명
     * @return 찾은 사용자 정보, 없으면 null
     */
    public User findUserByNameAndUsername(String name, String username) {
        String sql = "SELECT user_id, username, password, name, role, phone, created_at, updated_at, is_active " +
                    "FROM users WHERE name = ? AND username = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, name);
            pstmt.setString(2, username);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserId(rs.getInt("user_id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                    user.setPhone(rs.getString("phone"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                    user.setUpdatedAt(rs.getTimestamp("updated_at"));
                    user.setActive(rs.getBoolean("is_active"));
                    
                    System.out.println("사용자 찾기 성공: " + user.getName());
                    return user;
                }
            }
        } catch (SQLException e) {
            System.err.println("사용자 찾기 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("사용자 찾기 실패: " + name + " / " + username);
        return null;
    }
    
    /**
     * 🔥 누락된 메서드: 사용자 ID로 정보 조회
     * @param userId 사용자 ID
     * @return 사용자 정보, 없으면 null
     */
    public User getUserById(int userId) {
        String sql = "SELECT user_id, username, password, name, role, phone, created_at, updated_at, is_active " +
                    "FROM users WHERE user_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserId(rs.getInt("user_id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                    user.setPhone(rs.getString("phone"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                    user.setUpdatedAt(rs.getTimestamp("updated_at"));
                    user.setActive(rs.getBoolean("is_active"));
                    
                    return user;
                }
            }
        } catch (SQLException e) {
            System.err.println("사용자 조회 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * 🔥 누락된 메서드: 사용자 정보 업데이트
     * @param user 업데이트할 사용자 정보
     * @return 성공시 true, 실패시 false
     */
    public boolean updateUser(User user) {
        String sql = "UPDATE users SET name = ?, phone = ?, updated_at = CURRENT_TIMESTAMP " +
                    "WHERE user_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getPhone());
            pstmt.setInt(3, user.getUserId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("사용자 정보 업데이트 성공: " + user.getName());
                return true;
            }
        } catch (SQLException e) {
            System.err.println("사용자 정보 업데이트 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 🔥 누락된 메서드: 비밀번호 변경
     * @param userId 사용자 ID
     * @param newPassword 새 비밀번호
     * @return 성공시 true, 실패시 false
     */
    public boolean changePassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP " +
                    "WHERE user_id = ? AND is_active = TRUE";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, newPassword);
            pstmt.setInt(2, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("비밀번호 변경 성공: userId=" + userId);
                return true;
            }
        } catch (SQLException e) {
            System.err.println("비밀번호 변경 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * 모든 사용자 목록 조회 (관리자용)
     * @return 사용자 목록
     */
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, name, role, phone, created_at, updated_at, is_active " +
                    "FROM users ORDER BY created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setName(rs.getString("name"));
                user.setRole(rs.getString("role"));
                user.setPhone(rs.getString("phone"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                user.setUpdatedAt(rs.getTimestamp("updated_at"));
                user.setActive(rs.getBoolean("is_active"));
                
                users.add(user);
            }
            
            System.out.println("전체 사용자 목록 조회 완료: " + users.size() + "명");
            
        } catch (SQLException e) {
            System.err.println("전체 사용자 조회 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        return users;
    }
    
    /**
     * 역할별 사용자 목록 조회
     * @param role 역할 (student/professor)
     * @return 해당 역할의 사용자 목록
     */
    public List<User> getUsersByRole(String role) {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, name, role, phone, created_at, updated_at, is_active " +
                    "FROM users WHERE role = ? AND is_active = TRUE ORDER BY name";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, role);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    User user = new User();
                    user.setUserId(rs.getInt("user_id"));
                    user.setUsername(rs.getString("username"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                    user.setPhone(rs.getString("phone"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                    user.setUpdatedAt(rs.getTimestamp("updated_at"));
                    user.setActive(rs.getBoolean("is_active"));
                    
                    users.add(user);
                }
            }
            
            System.out.println(role + " 사용자 목록 조회 완료: " + users.size() + "명");
            
        } catch (SQLException e) {
            System.err.println(role + " 사용자 조회 DB 오류: " + e.getMessage());
            e.printStackTrace();
        }
        
        return users;
    }
}