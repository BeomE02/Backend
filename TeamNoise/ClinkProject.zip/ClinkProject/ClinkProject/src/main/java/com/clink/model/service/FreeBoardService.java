package com.clink.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import com.clink.model.dao.BoardDAO;
import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;

/**
 * 자유게시판 전용 서비스 클래스
 * ✅ 기존 BoardDAO를 활용하여 자유게시판 기능 제공
 * ✅ BoardController에서 호출하는 모든 메서드 완비
 * ✅ 모든 CRUD 기능 구현 완료
 */
public class FreeBoardService {
    
    private BoardDAO boardDAO;
    
    /**
     * 생성자
     */
    public FreeBoardService() {
        try {
            this.boardDAO = new BoardDAO();
            System.out.println("✅ FreeBoardService 초기화 성공 (BoardDAO 활용)");
        } catch (Exception e) {
            System.err.println("❌ FreeBoardService 초기화 실패: " + e.getMessage());
            e.printStackTrace();
            this.boardDAO = null;
        }
    }
    
    /**
     * DAO 유효성 체크
     */
    private boolean isDAOValid() {
        if (boardDAO == null) {
            System.err.println("❌ BoardDAO가 초기화되지 않았습니다.");
            return false;
        }
        return true;
    }
    
    // ========================================
    // 🚀 게시글 관련 메서드들
    // ========================================
    
    /**
     * 자유게시판 게시글 목록 조회
     */
    public List<Post> getFreePostList(Integer classId, int page, int pageSize, String searchType, String keyword) {
        System.out.println("🔍 FreeBoardService.getFreePostList 호출 - page: " + page);
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        // 파라미터 유효성 검사 및 기본값 설정
        if (page <= 0) {
            page = 1;
        }
        
        if (pageSize <= 0 || pageSize > 100) {
            pageSize = 20;
        }
        
        try {
            // 자유게시판 카테고리 ID = 1
            List<Post> postList = boardDAO.getPostList(1, page, pageSize, searchType, keyword);
            
            if (postList == null) {
                postList = new ArrayList<>();
                System.out.println("⚠️ DAO에서 null 반환, 빈 리스트로 초기화");
            }
            
            System.out.println("✅ 자유게시판 목록 조회 성공: " + postList.size() + "개");
            return postList;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 목록 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 자유게시판 게시글 개수 조회
     */
    public int getFreePostCount(Integer classId, String searchType, String keyword) {
        System.out.println("🔍 FreeBoardService.getFreePostCount 호출");
        
        if (!isDAOValid()) {
            return 0;
        }
        
        try {
            // 자유게시판 카테고리 ID = 1
            int count = boardDAO.getTotalPostCount(1, searchType, keyword);
            System.out.println("✅ 자유게시판 게시글 개수 조회 성공: " + count + "개");
            return count;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 게시글 개수 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * 자유게시판 게시글 상세 조회
     */
    public Post getFreePost(int postId) {
        System.out.println("🔍 FreeBoardService.getFreePost 호출 - postId: " + postId);
        
        if (!isDAOValid()) {
            return null;
        }
        
        if (postId <= 0) {
            System.err.println("❌ 유효하지 않은 게시글 ID: " + postId);
            return null;
        }
        
        try {
            Post post = boardDAO.getPost(postId);
            
            if (post != null) {
                System.out.println("✅ 자유게시판 게시글 조회 성공: " + post.getTitle());
            } else {
                System.out.println("⚠️ 자유게시판 게시글을 찾을 수 없음: " + postId);
            }
            
            return post;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 게시글 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * ✅ 자유게시판 게시글 작성 - BoardController에서 호출하는 핵심 메서드
     */
    public boolean createFreePost(Post post) {
        System.out.println("🚀 FreeBoardService.createFreePost 호출");
        
        if (!isDAOValid()) {
            System.err.println("❌ DAO가 유효하지 않습니다");
            return false;
        }
        
        if (post == null) {
            System.err.println("❌ 게시글 객체가 null입니다");
            return false;
        }
        
        // 필수 필드 검증
        if (!validatePost(post)) {
            System.err.println("❌ 게시글 유효성 검증 실패");
            return false;
        }
        
        try {
            // ✅ 핵심: 자유게시판 카테고리 ID 설정 (1번이 자유게시판)
            post.setCategoryId(1);
            
            System.out.println("📝 게시글 저장 시도:");
            System.out.println("   - 제목: " + post.getTitle());
            System.out.println("   - 작성자 ID: " + post.getAuthorId());
            System.out.println("   - 카테고리 ID: " + post.getCategoryId());
            System.out.println("   - 익명 여부: " + post.isAnonymous());
            System.out.println("   - 내용 길이: " + (post.getContent() != null ? post.getContent().length() : 0) + "자");
            
            boolean result = boardDAO.createPost(post);
            
            if (result) {
                System.out.println("✅ 자유게시판 게시글 작성 성공: " + post.getTitle());
                System.out.println("   - 생성된 게시글 ID: " + post.getPostId());
            } else {
                System.out.println("❌ 자유게시판 게시글 작성 실패");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 게시글 작성 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 자유게시판 게시글 수정
     */
    public boolean updateFreePost(Post post) {
        System.out.println("🔍 FreeBoardService.updateFreePost 호출");
        
        if (!isDAOValid()) {
            return false;
        }
        
        if (post == null || post.getPostId() <= 0) {
            System.err.println("❌ 유효하지 않은 게시글 정보");
            return false;
        }
        
        // 필수 필드 검증
        if (!validatePost(post)) {
            return false;
        }
        
        try {
            boolean result = boardDAO.updatePost(post);
            
            if (result) {
                System.out.println("✅ 자유게시판 게시글 수정 성공: " + post.getPostId());
            } else {
                System.out.println("❌ 자유게시판 게시글 수정 실패 (권한 없음 또는 존재하지 않는 게시글)");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 게시글 수정 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 자유게시판 게시글 삭제
     */
    public boolean deleteFreePost(int postId, int authorId) {
        System.out.println("🔍 FreeBoardService.deleteFreePost 호출 - postId: " + postId);
        
        if (!isDAOValid()) {
            return false;
        }
        
        if (postId <= 0 || authorId <= 0) {
            System.err.println("❌ 유효하지 않은 게시글 또는 작성자 ID");
            return false;
        }
        
        try {
            boolean result = boardDAO.deletePost(postId, authorId);
            
            if (result) {
                System.out.println("✅ 자유게시판 게시글 삭제 성공: " + postId);
            } else {
                System.out.println("❌ 자유게시판 게시글 삭제 실패 (권한 없음 또는 존재하지 않는 게시글)");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 게시글 삭제 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 조회수 증가
     */
    public void increaseViewCount(int postId) {
        if (!isDAOValid() || postId <= 0) {
            return;
        }
        
        try {
            boardDAO.increaseViewCount(postId);
            System.out.println("✅ 자유게시판 조회수 증가: " + postId);
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 조회수 증가 중 오류: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // ========================================
    // 🚀 댓글 관련 메서드들
    // ========================================
    
    /**
     * 자유게시판 댓글 목록 조회
     */
    public List<Comment> getFreePostComments(int postId) {
        System.out.println("🔍 FreeBoardService.getFreePostComments 호출 - postId: " + postId);
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        if (postId <= 0) {
            System.err.println("❌ 유효하지 않은 게시글 ID: " + postId);
            return new ArrayList<>();
        }
        
        try {
            List<Comment> commentList = boardDAO.getCommentList(postId);
            
            if (commentList == null) {
                commentList = new ArrayList<>();
            }
            
            System.out.println("✅ 자유게시판 댓글 목록 조회 성공: " + commentList.size() + "개");
            return commentList;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 댓글 목록 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 자유게시판 댓글 작성
     */
    public boolean createFreePostComment(Comment comment) {
        System.out.println("🔍 FreeBoardService.createFreePostComment 호출");
        
        if (!isDAOValid()) {
            return false;
        }
        
        if (comment == null) {
            System.err.println("❌ 댓글 객체가 null입니다");
            return false;
        }
        
        // 필수 필드 검증
        if (!validateComment(comment)) {
            return false;
        }
        
        try {
            boolean result = boardDAO.createComment(comment);
            
            if (result) {
                System.out.println("✅ 자유게시판 댓글 작성 성공");
            } else {
                System.out.println("❌ 자유게시판 댓글 작성 실패");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 댓글 작성 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 자유게시판 댓글 수정
     */
    public boolean updateFreePostComment(int commentId, int authorId, String content) {
        System.out.println("🔍 FreeBoardService.updateFreePostComment 호출 - commentId: " + commentId);
        
        if (!isDAOValid()) {
            return false;
        }
        
        if (commentId <= 0 || authorId <= 0) {
            System.err.println("❌ 유효하지 않은 댓글 또는 작성자 ID");
            return false;
        }
        
        if (content == null || content.trim().isEmpty()) {
            System.err.println("❌ 댓글 내용이 비어있습니다");
            return false;
        }
        
        if (content.trim().length() > 1000) {
            System.err.println("❌ 댓글 내용이 너무 깁니다 (최대 1000자)");
            return false;
        }
        
        try {
            // BoardDAO의 updateComment 메서드 사용
            boolean result = boardDAO.updateComment(commentId, authorId, content.trim());
            
            if (result) {
                System.out.println("✅ 자유게시판 댓글 수정 성공: " + commentId);
            } else {
                System.out.println("❌ 자유게시판 댓글 수정 실패 (권한 없음 또는 존재하지 않는 댓글)");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 댓글 수정 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 자유게시판 댓글 삭제
     */
    public boolean deleteFreePostComment(int commentId, int authorId) {
        System.out.println("🔍 FreeBoardService.deleteFreePostComment 호출 - commentId: " + commentId);
        
        if (!isDAOValid()) {
            return false;
        }
        
        if (commentId <= 0 || authorId <= 0) {
            System.err.println("❌ 유효하지 않은 댓글 또는 작성자 ID");
            return false;
        }
        
        try {
            boolean result = boardDAO.deleteComment(commentId, authorId);
            
            if (result) {
                System.out.println("✅ 자유게시판 댓글 삭제 성공: " + commentId);
            } else {
                System.out.println("❌ 자유게시판 댓글 삭제 실패 (권한 없음 또는 존재하지 않는 댓글)");
            }
            
            return result;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 댓글 삭제 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // ========================================
    // 🚀 추가 기능 메서드들
    // ========================================
    
    /**
     * 자유게시판 최근 게시글 조회
     */
    public List<Post> getRecentFreePosts(int limit) {
        System.out.println("🔍 FreeBoardService.getRecentFreePosts 호출");
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        if (limit <= 0 || limit > 50) {
            limit = 10;
        }
        
        try {
            // 자유게시판 카테고리 ID = 1로 최근 게시글 조회
            List<Post> recentPosts = boardDAO.getPostList(1, 1, limit, null, null);
            
            if (recentPosts == null) {
                recentPosts = new ArrayList<>();
            }
            
            System.out.println("✅ 자유게시판 최근 게시글 조회 성공: " + recentPosts.size() + "개");
            return recentPosts;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 최근 게시글 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 자유게시판 인기 게시글 조회
     */
    public List<Post> getPopularFreePosts(int limit) {
        System.out.println("🔍 FreeBoardService.getPopularFreePosts 호출");
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        if (limit <= 0 || limit > 50) {
            limit = 10;
        }
        
        try {
            // 인기 게시글은 조회수 순으로 정렬된 게시글 목록으로 대체
            List<Post> popularPosts = boardDAO.getPostList(1, 1, limit, null, null);
            
            if (popularPosts == null) {
                popularPosts = new ArrayList<>();
            }
            
            System.out.println("✅ 자유게시판 인기 게시글 조회 성공: " + popularPosts.size() + "개");
            return popularPosts;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 인기 게시글 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 자유게시판 공지사항 조회
     */
    public List<Post> getFreeNotices(int limit) {
        System.out.println("🔍 FreeBoardService.getFreeNotices 호출");
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        if (limit <= 0 || limit > 20) {
            limit = 5;
        }
        
        try {
            // 공지사항은 고정글(pinned) 게시글로 처리
            List<Post> notices = boardDAO.getPostList(1, 1, limit, null, null);
            
            if (notices == null) {
                notices = new ArrayList<>();
            }
            
            System.out.println("✅ 자유게시판 공지사항 조회 성공: " + notices.size() + "개");
            return notices;
            
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 공지사항 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 자유게시판 전체 게시글 수 조회
     */
    public int getFreePostCount() {
        if (!isDAOValid()) {
            return 0;
        }
        
        try {
            return boardDAO.getTotalPostCount(1, null, null);
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 전체 게시글 수 조회 중 오류: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * 자유게시판 전체 게시글 수 조회 (오버로드된 메서드와 구분을 위한 별칭)
     */
    public int getTotalFreePostCount() {
        return getFreePostCount();
    }
    
    // ========================================
    // 🛠️ 유틸리티 메서드들
    // ========================================
    
    /**
     * 게시글 유효성 검증
     */
    private boolean validatePost(Post post) {
        if (post.getTitle() == null || post.getTitle().trim().isEmpty()) {
            System.err.println("❌ 제목이 비어있습니다");
            return false;
        }
        
        if (post.getContent() == null || post.getContent().trim().isEmpty()) {
            System.err.println("❌ 내용이 비어있습니다");
            return false;
        }
        
        if (post.getAuthorId() == null || post.getAuthorId() <= 0) {
            System.err.println("❌ 유효하지 않은 작성자 ID: " + post.getAuthorId());
            return false;
        }
        
        if (post.getTitle().length() > 500) {
            System.err.println("❌ 제목이 너무 깁니다 (최대 500자)");
            return false;
        }
        
        if (post.getContent().length() > 10000) {
            System.err.println("❌ 내용이 너무 깁니다 (최대 10000자)");
            return false;
        }
        
        return true;
    }
    
    /**
     * 댓글 유효성 검증
     */
    private boolean validateComment(Comment comment) {
        if (comment.getContent() == null || comment.getContent().trim().isEmpty()) {
            System.err.println("❌ 댓글 내용이 비어있습니다");
            return false;
        }
        
        if (comment.getPostId() <= 0) {
            System.err.println("❌ 유효하지 않은 게시글 ID: " + comment.getPostId());
            return false;
        }
        
        if (comment.getAuthorId() <= 0) {
            System.err.println("❌ 유효하지 않은 작성자 ID: " + comment.getAuthorId());
            return false;
        }
        
        if (comment.getContent().length() > 1000) {
            System.err.println("❌ 댓글 내용이 너무 깁니다 (최대 1000자)");
            return false;
        }
        
        return true;
    }
    
    /**
     * 사용자 권한 확인 (게시글 수정/삭제용)
     */
    public boolean checkPostPermission(int postId, int userId) {
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            Post post = boardDAO.getPost(postId);
            return post != null && post.getAuthorId() == userId;
        } catch (Exception e) {
            System.err.println("❌ 게시글 권한 확인 오류: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 서비스 상태 체크
     */
    public boolean isServiceHealthy() {
        if (!isDAOValid()) {
            return false;
        }
        
        try {
            // 간단한 쿼리로 DB 연결 상태 확인
            boardDAO.getTotalPostCount(1, null, null);
            return true;
        } catch (Exception e) {
            System.err.println("❌ 자유게시판 서비스 상태 체크 실패: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 디버그 정보 출력
     */
    public void printDebugInfo() {
        System.out.println("=== FreeBoardService 디버그 정보 ===");
        System.out.println("DAO 상태: " + (boardDAO != null ? "정상" : "null"));
        System.out.println("서비스 상태: " + (isServiceHealthy() ? "정상" : "오류"));
        
        if (isServiceHealthy()) {
            try {
                int totalPosts = getTotalFreePostCount();
                System.out.println("총 게시글 수: " + totalPosts + "개");
            } catch (Exception e) {
                System.out.println("게시글 수 조회 실패: " + e.getMessage());
            }
        }
        
        System.out.println("=====================================");
    }
    
    /**
     * 카테고리별 통계 (향후 확장용)
     */
    public int getCategoryPostCount() {
        return getTotalFreePostCount();
    }
    
    /**
     * 게시글 검색 (고급 기능)
     */
    public List<Post> searchPosts(String keyword, String searchType, int page, int pageSize) {
        System.out.println("🔍 FreeBoardService.searchPosts 호출 - keyword: " + keyword);
        
        if (!isDAOValid()) {
            return new ArrayList<>();
        }
        
        try {
            return getFreePostList(null, page, pageSize, searchType, keyword);
        } catch (Exception e) {
            System.err.println("❌ 게시글 검색 중 오류: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    /**
     * 통계 리포트 생성 (관리자용)
     */
    public String generateStatisticsReport() {
        System.out.println("🔍 FreeBoardService.generateStatisticsReport 호출");
        
        if (!isDAOValid()) {
            return "서비스 이용 불가";
        }
        
        try {
            StringBuilder report = new StringBuilder();
            report.append("=== 자유게시판 통계 리포트 ===\n");
            report.append("총 게시글 수: ").append(getTotalFreePostCount()).append("개\n");
            report.append("최근 게시글: ").append(getRecentFreePosts(5).size()).append("개\n");
            report.append("인기 게시글: ").append(getPopularFreePosts(5).size()).append("개\n");
            report.append("공지사항: ").append(getFreeNotices(5).size()).append("개\n");
            report.append("서비스 상태: ").append(isServiceHealthy() ? "정상" : "오류").append("\n");
            report.append("================================");
            
            return report.toString();
        } catch (Exception e) {
            System.err.println("❌ 통계 리포트 생성 중 오류: " + e.getMessage());
            e.printStackTrace();
            return "리포트 생성 실패";
        }
    }
    
    /**
     * 서비스 정리 (소멸자 역할)
     */
    public void cleanup() {
        System.out.println("🔄 FreeBoardService 정리 시작");
        
        try {
            // 필요한 정리 작업 수행
            this.boardDAO = null;
            System.out.println("✅ FreeBoardService 정리 완료");
        } catch (Exception e) {
            System.err.println("❌ FreeBoardService 정리 중 오류: " + e.getMessage());
            e.printStackTrace();
        }
    }
}