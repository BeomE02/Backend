package com.clink.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.clink.model.dao.PhotoBoardDAO;
import com.clink.model.dao.BoardDAO;
import com.clink.model.dao.FileDAO;
import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;
import com.clink.model.dto.FileInfo;

/**
 * 사진게시판 서비스
 * - 이미지 중심 게시판 비즈니스 로직
 * - 파일 업로드/다운로드 연동
 * - 썸네일 처리 및 이미지 최적화
 */
public class PhotoBoardService {
    
    private PhotoBoardDAO photoBoardDAO;
    private BoardDAO boardDAO;
    private FileDAO fileDAO;
    
    public PhotoBoardService() {
        this.photoBoardDAO = new PhotoBoardDAO();
        this.boardDAO = new BoardDAO();
        this.fileDAO = new FileDAO();
    }
    
    /**
     * 사진게시판 게시글 목록 조회 (페이징)
     * @param classId 수업 ID
     * @param page 페이지 번호
     * @param size 페이지당 게시글 수
     * @param searchType 검색 타입
     * @param keyword 검색 키워드
     * @return 페이징된 게시글 목록과 페이지 정보
     */
    public Map<String, Object> getPhotoPostList(Integer classId, int page, int size, String searchType, String keyword) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (page < 1) page = 1;
            if (size < 1 || size > 100) size = 12; // 사진게시판은 12개씩 그리드로 표시
            
            // 검색 타입 검증
            if (searchType == null || 
                (!searchType.equals("title") && !searchType.equals("content") && 
                 !searchType.equals("author") && !searchType.equals("all"))) {
                searchType = "all";
            }
            
            // 게시글 목록 조회
            List<Post> posts = photoBoardDAO.getPhotoPostList(classId, page, size, searchType, keyword);
            
            // 전체 게시글 수 조회
            int totalCount = photoBoardDAO.getTotalPhotoPostCount(classId, searchType, keyword);
            
            // 페이지 정보 계산
            int totalPages = (int) Math.ceil((double) totalCount / size);
            boolean hasNext = page < totalPages;
            boolean hasPrevious = page > 1;
            
            // 각 게시글에 대한 첨부파일 정보 추가
            for (Post post : posts) {
                List<FileInfo> attachments = photoBoardDAO.getPhotoAttachments(post.getPostId());
                post.setAttachments(attachments);
                
                // 이미지 파일만 필터링
                post.setImageAttachments(attachments.stream()
                    .filter(file -> file.getFileType() != null && file.getFileType().startsWith("image/"))
                    .toList());
            }
            
            result.put("success", true);
            result.put("posts", posts);
            result.put("currentPage", page);
            result.put("totalPages", totalPages);
            result.put("totalCount", totalCount);
            result.put("hasNext", hasNext);
            result.put("hasPrevious", hasPrevious);
            result.put("size", size);
            
        } catch (Exception e) {
            System.err.println("사진게시판 목록 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 목록을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 사진게시글 상세 조회
     * @param postId 게시글 ID
     * @param userId 현재 사용자 ID (조회수 증가 제어용)
     * @return 게시글 상세 정보
     */
    public Map<String, Object> getPhotoPostDetail(int postId, Integer userId) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 게시글 정보 조회
            Post post = photoBoardDAO.getPhotoPostById(postId);
            
            if (post == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 조회수 증가 (본인 글이 아닌 경우에만)
            if (userId == null || !userId.equals(post.getAuthorId())) {
                photoBoardDAO.increaseViewCount(postId);
                post.setViewCount(post.getViewCount() + 1);
            }
            
            // 첨부파일 목록 조회
            List<FileInfo> attachments = photoBoardDAO.getPhotoAttachments(postId);
            post.setAttachments(attachments);
            
            // 이미지 파일과 일반 파일 분리
            post.setImageAttachments(attachments.stream()
                .filter(file -> file.getFileType() != null && file.getFileType().startsWith("image/"))
                .toList());
            
            post.setOtherAttachments(attachments.stream()
                .filter(file -> file.getFileType() == null || !file.getFileType().startsWith("image/"))
                .toList());
            
            // 댓글 목록 조회
            List<Comment> comments = boardDAO.getCommentsByPostId(postId);
            
            result.put("success", true);
            result.put("post", post);
            result.put("comments", comments);
            
        } catch (Exception e) {
            System.err.println("사진게시글 상세 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 사진게시글 작성
     * @param post 게시글 정보
     * @return 작성 결과
     */
    public Map<String, Object> createPhotoPost(Post post) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (post.getTitle() == null || post.getTitle().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "제목을 입력해주세요.");
                return result;
            }
            
            if (post.getContent() == null || post.getContent().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "내용을 입력해주세요.");
                return result;
            }
            
            if (post.getClassId() == null || post.getAuthorId() == null) {
                result.put("success", false);
                result.put("message", "필수 정보가 누락되었습니다.");
                return result;
            }
            
            // 제목과 내용 길이 검증
            if (post.getTitle().length() > 500) {
                result.put("success", false);
                result.put("message", "제목은 500자 이하로 입력해주세요.");
                return result;
            }
            
            if (post.getContent().length() > 10000) {
                result.put("success", false);
                result.put("message", "내용은 10,000자 이하로 입력해주세요.");
                return result;
            }
            
            // 게시글 작성
            int postId = photoBoardDAO.insertPhotoPost(post);
            
            if (postId > 0) {
                result.put("success", true);
                result.put("message", "사진게시글이 성공적으로 작성되었습니다.");
                result.put("postId", postId);
            } else {
                result.put("success", false);
                result.put("message", "게시글 작성에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("사진게시글 작성 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 작성 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 사진게시글 수정
     * @param post 수정할 게시글 정보
     * @return 수정 결과
     */
    public Map<String, Object> updatePhotoPost(Post post) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (post.getPostId() == null || post.getAuthorId() == null) {
                result.put("success", false);
                result.put("message", "필수 정보가 누락되었습니다.");
                return result;
            }
            
            if (post.getTitle() == null || post.getTitle().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "제목을 입력해주세요.");
                return result;
            }
            
            if (post.getContent() == null || post.getContent().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "내용을 입력해주세요.");
                return result;
            }
            
            // 기존 게시글 존재 여부 확인
            Post existingPost = photoBoardDAO.getPhotoPostById(post.getPostId());
            if (existingPost == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 작성자 권한 확인
            if (!existingPost.getAuthorId().equals(post.getAuthorId())) {
                result.put("success", false);
                result.put("message", "게시글을 수정할 권한이 없습니다.");
                return result;
            }
            
            // 게시글 수정
            boolean success = photoBoardDAO.updatePhotoPost(post);
            
            if (success) {
                result.put("success", true);
                result.put("message", "게시글이 성공적으로 수정되었습니다.");
            } else {
                result.put("success", false);
                result.put("message", "게시글 수정에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("사진게시글 수정 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 수정 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 사진게시글 삭제
     * @param postId 게시글 ID
     * @param userId 사용자 ID
     * @return 삭제 결과
     */
    public Map<String, Object> deletePhotoPost(int postId, int userId) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 기존 게시글 존재 여부 확인
            Post existingPost = photoBoardDAO.getPhotoPostById(postId);
            if (existingPost == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 작성자 권한 확인
            if (!existingPost.getAuthorId().equals(userId)) {
                result.put("success", false);
                result.put("message", "게시글을 삭제할 권한이 없습니다.");
                return result;
            }
            
            // 게시글 삭제 (소프트 삭제)
            boolean success = photoBoardDAO.deletePhotoPost(postId, userId);
            
            if (success) {
                result.put("success", true);
                result.put("message", "게시글이 성공적으로 삭제되었습니다.");
            } else {
                result.put("success", false);
                result.put("message", "게시글 삭제에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("사진게시글 삭제 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "게시글 삭제 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 댓글 작성
     * @param comment 댓글 정보
     * @return 작성 결과
     */
    public Map<String, Object> createComment(Comment comment) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 입력값 검증
            if (comment.getContent() == null || comment.getContent().trim().isEmpty()) {
                result.put("success", false);
                result.put("message", "댓글 내용을 입력해주세요.");
                return result;
            }
            
            if (comment.getPostId() == null || comment.getAuthorId() == null) {
                result.put("success", false);
                result.put("message", "필수 정보가 누락되었습니다.");
                return result;
            }
            
            // 게시글 존재 여부 확인
            Post post = photoBoardDAO.getPhotoPostById(comment.getPostId());
            if (post == null) {
                result.put("success", false);
                result.put("message", "존재하지 않는 게시글입니다.");
                return result;
            }
            
            // 댓글 작성
            int commentId = boardDAO.insertComment(comment);
            
            if (commentId > 0) {
                result.put("success", true);
                result.put("message", "댓글이 성공적으로 작성되었습니다.");
                result.put("commentId", commentId);
            } else {
                result.put("success", false);
                result.put("message", "댓글 작성에 실패했습니다.");
            }
            
        } catch (Exception e) {
            System.err.println("댓글 작성 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "댓글 작성 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 인기 사진게시글 조회
     * @param classId 수업 ID
     * @param limit 조회할 게시글 수
     * @return 인기 게시글 목록
     */
    public Map<String, Object> getPopularPhotoPosts(Integer classId, int limit) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            if (limit < 1 || limit > 20) limit = 5;
            
            List<Post> posts = photoBoardDAO.getPopularPhotoPosts(classId, limit);
            
            // 각 게시글에 대한 첨부파일 정보 추가
            for (Post post : posts) {
                List<FileInfo> attachments = photoBoardDAO.getPhotoAttachments(post.getPostId());
                post.setAttachments(attachments);
                
                // 이미지 파일만 필터링
                post.setImageAttachments(attachments.stream()
                    .filter(file -> file.getFileType() != null && file.getFileType().startsWith("image/"))
                    .toList());
            }
            
            result.put("success", true);
            result.put("posts", posts);
            
        } catch (Exception e) {
            System.err.println("인기 사진게시글 조회 서비스 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "인기 게시글을 불러오는 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * 이미지 파일 검증
     * @param fileInfo 파일 정보
     * @return 검증 결과
     */
    public Map<String, Object> validateImageFile(FileInfo fileInfo) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 파일 크기 검증 (10MB 제한)
            long maxSize = 10 * 1024 * 1024; // 10MB
            if (fileInfo.getFileSize() > maxSize) {
                result.put("success", false);
                result.put("message", "이미지 파일 크기는 10MB 이하여야 합니다.");
                return result;
            }
            
            // 파일 확장자 검증
            String filename = fileInfo.getOriginalFilename().toLowerCase();
            if (!filename.endsWith(".jpg") && !filename.endsWith(".jpeg") && 
                !filename.endsWith(".png") && !filename.endsWith(".gif") && 
                !filename.endsWith(".webp")) {
                result.put("success", false);
                result.put("message", "지원하지 않는 이미지 형식입니다. (JPG, PNG, GIF, WebP만 지원)");
                return result;
            }
            
            // MIME 타입 검증
            String mimeType = fileInfo.getMimeType();
            if (mimeType == null || !mimeType.startsWith("image/")) {
                result.put("success", false);
                result.put("message", "올바르지 않은 이미지 파일입니다.");
                return result;
            }
            
            result.put("success", true);
            result.put("message", "유효한 이미지 파일입니다.");
            
        } catch (Exception e) {
            System.err.println("이미지 파일 검증 오류: " + e.getMessage());
            e.printStackTrace();
            
            result.put("success", false);
            result.put("message", "파일 검증 중 오류가 발생했습니다.");
        }
        
        return result;
    }
    
    /**
     * PhotoBoardDAO 메서드들을 직접 호출하는 헬퍼 메서드들
     * (BoardController에서 직접 사용)
     */
    
    public List<Post> getPhotoPostList(Integer classId, int page, int size, String searchType, String keyword) {
        return photoBoardDAO.getPhotoPostList(classId, page, size, searchType, keyword);
    }
    
    public int getPhotoPostCount(Integer classId, String searchType, String keyword) {
        return photoBoardDAO.getTotalPhotoPostCount(classId, searchType, keyword);
    }
    
    public Post getPhotoPostById(int postId) {
        return photoBoardDAO.getPhotoPostById(postId);
    }
    
    public boolean increasePhotoViewCount(int postId) {
        return photoBoardDAO.increaseViewCount(postId);
    }
    
    public int insertPhotoPost(Post post) {
        return photoBoardDAO.insertPhotoPost(post);
    }
    
    public boolean updatePhotoPost(Post post) {
        return photoBoardDAO.updatePhotoPost(post);
    }
    
    public boolean deletePhotoPost(int postId, int authorId) {
        return photoBoardDAO.deletePhotoPost(postId, authorId);
    }
}