package com.clink.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.clink.model.dto.Post;
import com.clink.model.dto.Comment;
import com.clink.model.dto.FileInfo;
import com.clink.util.DBConnection;

/**
 * 자료게시판 전용 DAO
 * - 파일 중심의 게시글 관리
 * - 다운로드 통계 및 파일 정보 우선 처리
 * - 다양한 파일 형식 지원
 */
public class DataBoardDAO {
    
    // 게시판 카테고리 ID (data)
    private static final int DATA_CATEGORY_ID = 4;
    
    /**
     * 자료게시판 게시글 목록 조회 (페이징)
     * @param classId 수업 ID
     * @param page 페이지 번호 (1부터 시작)
     * @param size 페이지당 게시글 수
     * @param searchType 검색 타입 (title, content, author)
     * @param keyword 검색 키워드
     * @return 게시글 목록
     */
    public List<Post> getDataPostList(Integer classId, int page, int size, String searchType, String keyword) {
        List<Post> posts = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT p.*, u.name as author_name, u.role, ");
            sql.append("       (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id AND c.status = 'active') as comment_count, ");
            sql.append("       (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.post_id) as file_count, ");
            sql.append("       (SELECT SUM(a.file_size) FROM attachments a WHERE a.post_id = p.post_id) as total_file_size, ");
            sql.append("       (SELECT SUM(a.download_count) FROM attachments a WHERE a.post_id = p.post_id) as total_downloads ");
            sql.append("FROM posts p ");
            sql.append("JOIN users u ON p.author_id = u.user_id ");
            sql.append("WHERE p.category_id = ? AND p.status = 'active' ");
            
            if (classId != null) {
                sql.append("AND p.class_id = ? ");
            }
            
            // 검색 조건 추가
            if (keyword != null && !keyword.trim().isEmpty()) {
                switch (searchType) {
                    case "title":
                        sql.append("AND p.title LIKE ? ");
                        break;
                    case "content":
                        sql.append("AND p.content LIKE ? ");
                        break;
                    case "author":
                        sql.append("AND u.name LIKE ? ");
                        break;
                    case "filename":
                        sql.append("AND EXISTS (SELECT 1 FROM attachments a WHERE a.post_id = p.post_id AND a.original_filename LIKE ?) ");
                        break;
                    default:
                        sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR EXISTS (SELECT 1 FROM attachments a WHERE a.post_id = p.post_id AND a.original_filename LIKE ?)) ");
                        break;
                }
            }
            
            sql.append("ORDER BY p.is_pinned DESC, p.created_at DESC ");
            sql.append("LIMIT ? OFFSET ?");
            
            pstmt = conn.prepareStatement(sql.toString());
            
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, DATA_CATEGORY_ID);
            
            if (classId != null) {
                pstmt.setInt(paramIndex++, classId);
            }
            
            if (keyword != null && !keyword.trim().isEmpty()) {
                String searchKeyword = "%" + keyword + "%";
                switch (searchType) {
                    case "all":
                        pstmt.setString(paramIndex++, searchKeyword);
                        pstmt.setString(paramIndex++, searchKeyword);
                        pstmt.setString(paramIndex++, searchKeyword);
                        break;
                    default:
                        pstmt.setString(paramIndex++, searchKeyword);
                        break;
                }
            }
            
            pstmt.setInt(paramIndex++, size);
            pstmt.setInt(paramIndex++, (page - 1) * size);
            
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Post post = new Post();
                post.setPostId(rs.getInt("post_id"));
                post.setCategoryId(rs.getInt("category_id"));
                post.setClassId(rs.getInt("class_id"));
                post.setAuthorId(rs.getInt("author_id"));
                post.setTitle(rs.getString("title"));
                post.setContent(rs.getString("content"));
                post.setViewCount(rs.getInt("view_count"));
                post.setIsAnonymous(rs.getBoolean("is_anonymous"));
                post.setIsPinned(rs.getBoolean("is_pinned"));
                post.setStatus(rs.getString("status"));
                post.setCreatedAt(rs.getTimestamp("created_at"));
                post.setUpdatedAt(rs.getTimestamp("updated_at"));
                
                // 작성자 정보
                post.setAuthorName(rs.getString("author_name"));
                post.setAuthorRole(rs.getString("role"));
                
                // 댓글 수
                post.setCommentCount(rs.getInt("comment_count"));
                
                // 파일 정보
                post.setFileCount(rs.getInt("file_count"));
                post.setTotalFileSize(rs.getLong("total_file_size"));
                post.setTotalDownloads(rs.getInt("total_downloads"));
                
                posts.add(post);
            }
            
        } catch (SQLException e) {
            System.err.println("자료게시판 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return posts;
    }
    
    /**
     * 자료게시판 전체 게시글 수 조회
     * @param classId 수업 ID
     * @param searchType 검색 타입
     * @param keyword 검색 키워드
     * @return 총 게시글 수
     */
    public int getTotalDataPostCount(Integer classId, String searchType, String keyword) {
        int count = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT COUNT(*) FROM posts p ");
            sql.append("JOIN users u ON p.author_id = u.user_id ");
            sql.append("WHERE p.category_id = ? AND p.status = 'active' ");
            
            if (classId != null) {
                sql.append("AND p.class_id = ? ");
            }
            
            if (keyword != null && !keyword.trim().isEmpty()) {
                switch (searchType) {
                    case "title":
                        sql.append("AND p.title LIKE ? ");
                        break;
                    case "content":
                        sql.append("AND p.content LIKE ? ");
                        break;
                    case "author":
                        sql.append("AND u.name LIKE ? ");
                        break;
                    case "filename":
                        sql.append("AND EXISTS (SELECT 1 FROM attachments a WHERE a.post_id = p.post_id AND a.original_filename LIKE ?) ");
                        break;
                    default:
                        sql.append("AND (p.title LIKE ? OR p.content LIKE ? OR EXISTS (SELECT 1 FROM attachments a WHERE a.post_id = p.post_id AND a.original_filename LIKE ?)) ");
                        break;
                }
            }
            
            pstmt = conn.prepareStatement(sql.toString());
            
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, DATA_CATEGORY_ID);
            
            if (classId != null) {
                pstmt.setInt(paramIndex++, classId);
            }
            
            if (keyword != null && !keyword.trim().isEmpty()) {
                String searchKeyword = "%" + keyword + "%";
                switch (searchType) {
                    case "all":
                        pstmt.setString(paramIndex++, searchKeyword);
                        pstmt.setString(paramIndex++, searchKeyword);
                        pstmt.setString(paramIndex++, searchKeyword);
                        break;
                    default:
                        pstmt.setString(paramIndex++, searchKeyword);
                        break;
                }
            }
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
            
        } catch (SQLException e) {
            System.err.println("자료게시판 게시글 수 조회 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return count;
    }
    
    /**
     * 자료게시글 상세 조회
     * @param postId 게시글 ID
     * @return 게시글 정보
     */
    public Post getDataPostById(int postId) {
        Post post = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            String sql = "SELECT p.*, u.name as author_name, u.role, " +
                        "       (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id AND c.status = 'active') as comment_count, " +
                        "       (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.post_id) as file_count, " +
                        "       (SELECT SUM(a.file_size) FROM attachments a WHERE a.post_id = p.post_id) as total_file_size, " +
                        "       (SELECT SUM(a.download_count) FROM attachments a WHERE a.post_id = p.post_id) as total_downloads " +
                        "FROM posts p " +
                        "JOIN users u ON p.author_id = u.user_id " +
                        "WHERE p.post_id = ? AND p.category_id = ? AND p.status = 'active'";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, postId);
            pstmt.setInt(2, DATA_CATEGORY_ID);
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                post = new Post();
                post.setPostId(rs.getInt("post_id"));
                post.setCategoryId(rs.getInt("category_id"));
                post.setClassId(rs.getInt("class_id"));
                post.setAuthorId(rs.getInt("author_id"));
                post.setTitle(rs.getString("title"));
                post.setContent(rs.getString("content"));
                post.setViewCount(rs.getInt("view_count"));
                post.setIsAnonymous(rs.getBoolean("is_anonymous"));
                post.setIsPinned(rs.getBoolean("is_pinned"));
                post.setStatus(rs.getString("status"));
                post.setCreatedAt(rs.getTimestamp("created_at"));
                post.setUpdatedAt(rs.getTimestamp("updated_at"));
                
                // 작성자 정보
                post.setAuthorName(rs.getString("author_name"));
                post.setAuthorRole(rs.getString("role"));
                
                // 댓글 수
                post.setCommentCount(rs.getInt("comment_count"));
                
                // 파일 정보
                post.setFileCount(rs.getInt("file_count"));
                post.setTotalFileSize(rs.getLong("total_file_size"));
                post.setTotalDownloads(rs.getInt("total_downloads"));
            }
            
        } catch (SQLException e) {
            System.err.println("자료게시글 상세 조회 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return post;
    }
    
    /**
     * 자료게시글 조회수 증가
     * @param postId 게시글 ID
     * @return 성공 여부
     */
    public boolean increaseViewCount(int postId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            
            String sql = "UPDATE posts SET view_count = view_count + 1 WHERE post_id = ? AND category_id = ?";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, postId);
            pstmt.setInt(2, DATA_CATEGORY_ID);
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("조회수 증가 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * 자료게시글 첨부파일 목록 조회
     * @param postId 게시글 ID
     * @return 첨부파일 목록
     */
    public List<FileInfo> getDataAttachments(int postId) {
        List<FileInfo> files = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            String sql = "SELECT * FROM attachments WHERE post_id = ? ORDER BY attachment_id";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, postId);
            
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                FileInfo file = new FileInfo();
                file.setAttachmentId(rs.getInt("attachment_id"));
                file.setPostId(rs.getInt("post_id"));
                file.setOriginalFilename(rs.getString("original_filename"));
                file.setStoredFilename(rs.getString("stored_filename"));
                file.setFilePath(rs.getString("file_path"));
                file.setFileSize(rs.getLong("file_size"));
                file.setFileType(rs.getString("file_type"));
                file.setMimeType(rs.getString("mime_type"));
                file.setDownloadCount(rs.getInt("download_count"));
                file.setUploadedAt(rs.getTimestamp("uploaded_at"));
                
                files.add(file);
            }
            
        } catch (SQLException e) {
            System.err.println("첨부파일 목록 조회 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return files;
    }
    
    /**
     * 자료게시글 작성
     * @param post 게시글 정보
     * @return 생성된 게시글 ID
     */
    public int insertDataPost(Post post) {
        int generatedId = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            String sql = "INSERT INTO posts (category_id, class_id, author_id, title, content, is_anonymous, is_pinned, created_at) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            
            pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, DATA_CATEGORY_ID);
            pstmt.setInt(2, post.getClassId());
            pstmt.setInt(3, post.getAuthorId());
            pstmt.setString(4, post.getTitle());
            pstmt.setString(5, post.getContent());
            pstmt.setBoolean(6, post.getIsAnonymous() != null ? post.getIsAnonymous() : false);
            pstmt.setBoolean(7, post.getIsPinned() != null ? post.getIsPinned() : false);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    generatedId = rs.getInt(1);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("자료게시글 작성 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return generatedId;
    }
    
    /**
     * 자료게시글 수정
     * @param post 게시글 정보
     * @return 성공 여부
     */
    public boolean updateDataPost(Post post) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            
            String sql = "UPDATE posts SET title = ?, content = ?, is_anonymous = ?, is_pinned = ?, updated_at = NOW() " +
                        "WHERE post_id = ? AND category_id = ? AND author_id = ?";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, post.getTitle());
            pstmt.setString(2, post.getContent());
            pstmt.setBoolean(3, post.getIsAnonymous() != null ? post.getIsAnonymous() : false);
            pstmt.setBoolean(4, post.getIsPinned() != null ? post.getIsPinned() : false);
            pstmt.setInt(5, post.getPostId());
            pstmt.setInt(6, DATA_CATEGORY_ID);
            pstmt.setInt(7, post.getAuthorId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("자료게시글 수정 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * 자료게시글 삭제
     * @param postId 게시글 ID
     * @param authorId 작성자 ID
     * @return 성공 여부
     */
    public boolean deleteDataPost(int postId, int authorId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            
            String sql = "UPDATE posts SET status = 'deleted', updated_at = NOW() " +
                        "WHERE post_id = ? AND category_id = ? AND author_id = ?";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, postId);
            pstmt.setInt(2, DATA_CATEGORY_ID);
            pstmt.setInt(3, authorId);
            
            int result = pstmt.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("자료게시글 삭제 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * 자료게시판 인기 게시글 조회 (다운로드 수 기준)
     * @param classId 수업 ID
     * @param limit 조회할 게시글 수
     * @return 인기 게시글 목록
     */
    public List<Post> getPopularDataPosts(Integer classId, int limit) {
        List<Post> posts = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT p.*, u.name as author_name, u.role, ");
            sql.append("       (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id AND c.status = 'active') as comment_count, ");
            sql.append("       (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.post_id) as file_count, ");
            sql.append("       (SELECT SUM(a.file_size) FROM attachments a WHERE a.post_id = p.post_id) as total_file_size, ");
            sql.append("       (SELECT SUM(a.download_count) FROM attachments a WHERE a.post_id = p.post_id) as total_downloads ");
            sql.append("FROM posts p ");
            sql.append("JOIN users u ON p.author_id = u.user_id ");
            sql.append("WHERE p.category_id = ? AND p.status = 'active' ");
            
            if (classId != null) {
                sql.append("AND p.class_id = ? ");
            }
            
            sql.append("AND p.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) ");
            sql.append("ORDER BY total_downloads DESC, p.view_count DESC, p.created_at DESC ");
            sql.append("LIMIT ?");
            
            pstmt = conn.prepareStatement(sql.toString());
            
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, DATA_CATEGORY_ID);
            
            if (classId != null) {
                pstmt.setInt(paramIndex++, classId);
            }
            
            pstmt.setInt(paramIndex++, limit);
            
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Post post = new Post();
                post.setPostId(rs.getInt("post_id"));
                post.setCategoryId(rs.getInt("category_id"));
                post.setClassId(rs.getInt("class_id"));
                post.setAuthorId(rs.getInt("author_id"));
                post.setTitle(rs.getString("title"));
                post.setContent(rs.getString("content"));
                post.setViewCount(rs.getInt("view_count"));
                post.setIsAnonymous(rs.getBoolean("is_anonymous"));
                post.setIsPinned(rs.getBoolean("is_pinned"));
                post.setStatus(rs.getString("status"));
                post.setCreatedAt(rs.getTimestamp("created_at"));
                post.setUpdatedAt(rs.getTimestamp("updated_at"));
                
                // 작성자 정보
                post.setAuthorName(rs.getString("author_name"));
                post.setAuthorRole(rs.getString("role"));
                
                // 댓글 수
                post.setCommentCount(rs.getInt("comment_count"));
                
                // 파일 정보
                post.setFileCount(rs.getInt("file_count"));
                post.setTotalFileSize(rs.getLong("total_file_size"));
                post.setTotalDownloads(rs.getInt("total_downloads"));
                
                posts.add(post);
            }
            
        } catch (SQLException e) {
            System.err.println("인기 자료게시글 조회 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return posts;
    }
    
    /**
     * 파일별 다운로드 통계 조회
     * @param classId 수업 ID
     * @param limit 조회할 파일 수
     * @return 인기 파일 목록
     */
    public List<FileInfo> getPopularFiles(Integer classId, int limit) {
        List<FileInfo> files = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT a.*, p.title as post_title ");
            sql.append("FROM attachments a ");
            sql.append("JOIN posts p ON a.post_id = p.post_id ");
            sql.append("WHERE p.category_id = ? AND p.status = 'active' ");
            
            if (classId != null) {
                sql.append("AND p.class_id = ? ");
            }
            
            sql.append("ORDER BY a.download_count DESC, a.uploaded_at DESC ");
            sql.append("LIMIT ?");
            
            pstmt = conn.prepareStatement(sql.toString());
            
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, DATA_CATEGORY_ID);
            
            if (classId != null) {
                pstmt.setInt(paramIndex++, classId);
            }
            
            pstmt.setInt(paramIndex++, limit);
            
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                FileInfo file = new FileInfo();
                file.setAttachmentId(rs.getInt("attachment_id"));
                file.setPostId(rs.getInt("post_id"));
                file.setOriginalFilename(rs.getString("original_filename"));
                file.setStoredFilename(rs.getString("stored_filename"));
                file.setFilePath(rs.getString("file_path"));
                file.setFileSize(rs.getLong("file_size"));
                file.setFileType(rs.getString("file_type"));
                file.setMimeType(rs.getString("mime_type"));
                file.setDownloadCount(rs.getInt("download_count"));
                file.setUploadedAt(rs.getTimestamp("uploaded_at"));
                
                // 추가 정보
                file.setPostTitle(rs.getString("post_title"));
                
                files.add(file);
            }
            
        } catch (SQLException e) {
            System.err.println("인기 파일 조회 오류: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return files;
    }
}