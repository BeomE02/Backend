package com.clink.model.dto;

import java.sql.Timestamp;

/**
 * Post DTO - 완전한 버전 (모든 필드 포함 + JSP 호환성 개선)
 * 데이터베이스 posts 테이블과 연동
 */
public class Post {
    
    // 기본 필드들 (posts 테이블)
    private Integer postId;           // post_id
    private Integer categoryId;       // category_id
    private Integer classId;          // class_id (nullable)
    private Integer authorId;         // author_id
    private String title;             // title
    private String content;           // content
    private Integer viewCount;        // view_count
    private Boolean isAnonymous;      // is_anonymous
    private Boolean isPinned;         // is_pinned
    private String status;            // status ('active', 'deleted', 'blocked')
    private Timestamp createdAt;      // created_at
    private Timestamp updatedAt;      // updated_at
    
    // 추가 정보 필드들 (JOIN으로 가져오는 정보)
    private String categoryCode;      // board_categories.category_code
    private String categoryName;      // board_categories.category_name
    private String authorName;        // users.name (익명인 경우 '익명')
    private String authorRole;        // users.role
    private Integer commentCount;     // comments 테이블 COUNT
    private String className;         // classes.class_name (nullable)
    private String classCode;         // classes.class_code (nullable)
    
    // ========================================
    // 생성자들
    // ========================================
    
    /**
     * 기본 생성자
     */
    public Post() {
        this.viewCount = 0;
        this.isAnonymous = false;
        this.isPinned = false;
        this.status = "active";
        this.commentCount = 0;
    }
    
    /**
     * 기본 정보 생성자
     */
    public Post(Integer categoryId, Integer authorId, String title, String content) {
        this();
        this.categoryId = categoryId;
        this.authorId = authorId;
        this.title = title;
        this.content = content;
    }
    
    /**
     * 완전한 생성자
     */
    public Post(Integer categoryId, Integer classId, Integer authorId, String title, String content, 
                Boolean isAnonymous, Boolean isPinned) {
        this(categoryId, authorId, title, content);
        this.classId = classId;
        this.isAnonymous = isAnonymous;
        this.isPinned = isPinned;
    }
    
    // ========================================
    // 기본 Getter/Setter 메서드들
    // ========================================
    
    public Integer getPostId() {
        return postId;
    }
    
    public void setPostId(Integer postId) {
        this.postId = postId;
    }
    
    public Integer getCategoryId() {
        return categoryId;
    }
    
    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }
    
    public Integer getClassId() {
        return classId;
    }
    
    public void setClassId(Integer classId) {
        this.classId = classId;
    }
    
    public Integer getAuthorId() {
        return authorId;
    }
    
    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public Integer getViewCount() {
        return viewCount;
    }
    
    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }
    
    // ========================================
    // Boolean 필드의 JSP 호환성 개선
    // ========================================
    
    /**
     * JSP에서 ${post.anonymous} 형태로 접근하기 위한 메서드
     */
    public Boolean getAnonymous() {
        return isAnonymous;
    }
    
    /**
     * 전통적인 isAnonymous() 메서드 (기존 코드 호환성)
     */
    public Boolean isAnonymous() {
        return isAnonymous;
    }
    
    public void setAnonymous(Boolean anonymous) {
        this.isAnonymous = anonymous;
    }
    
    /**
     * JSP에서 ${post.pinned} 형태로 접근하기 위한 메서드
     */
    public Boolean getPinned() {
        return isPinned;
    }
    
    /**
     * 전통적인 isPinned() 메서드 (기존 코드 호환성)
     */
    public Boolean isPinned() {
        return isPinned;
    }
    
    public void setPinned(Boolean pinned) {
        this.isPinned = pinned;
    }
    
    // ========================================
    // 나머지 기본 필드 Getter/Setter
    // ========================================
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // ========================================
    // 추가 정보 Getter/Setter
    // ========================================
    
    public String getCategoryCode() {
        return categoryCode;
    }
    
    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }
    
    public String getCategoryName() {
        return categoryName;
    }
    
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    
    public String getAuthorName() {
        return authorName;
    }
    
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    
    public String getAuthorRole() {
        return authorRole;
    }
    
    public void setAuthorRole(String authorRole) {
        this.authorRole = authorRole;
    }
    
    public Integer getCommentCount() {
        return commentCount;
    }
    
    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }
    
    public String getClassName() {
        return className;
    }
    
    public void setClassName(String className) {
        this.className = className;
    }
    
    public String getClassCode() {
        return classCode;
    }
    
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }
    
    // ========================================
    // JSP 호환성을 위한 추가 메서드들 (선택사항)
    // ========================================
    
    /**
     * JSP에서 ${post.post_id} 형태로도 접근 가능하도록 (기존 JSP 코드 호환성)
     */
    public Integer getPost_id() {
        return postId;
    }
    
    public Integer getCategory_id() {
        return categoryId;
    }
    
    public Integer getClass_id() {
        return classId;
    }
    
    public Integer getAuthor_id() {
        return authorId;
    }
    
    public Integer getView_count() {
        return viewCount;
    }
    
    public Boolean getIs_anonymous() {
        return isAnonymous;
    }
    
    public Boolean getIs_pinned() {
        return isPinned;
    }
    
    public Timestamp getCreated_at() {
        return createdAt;
    }
    
    public Timestamp getUpdated_at() {
        return updatedAt;
    }
    
    public String getCategory_code() {
        return categoryCode;
    }
    
    public String getCategory_name() {
        return categoryName;
    }
    
    public String getAuthor_name() {
        return authorName;
    }
    
    public String getAuthor_role() {
        return authorRole;
    }
    
    public Integer getComment_count() {
        return commentCount;
    }
    
    public String getClass_name() {
        return className;
    }
    
    public String getClass_code() {
        return classCode;
    }
    
    // ========================================
    // 유틸리티 메서드들
    // ========================================
    
    /**
     * 게시글이 유효한지 검증
     */
    public boolean isValid() {
        return title != null && !title.trim().isEmpty() && 
               content != null && !content.trim().isEmpty() &&
               authorId != null && authorId > 0 &&
               categoryId != null && categoryId > 0;
    }
    
    /**
     * 게시글이 활성 상태인지 확인
     */
    public boolean isActive() {
        return "active".equals(status);
    }
    
    /**
     * 게시글이 삭제된 상태인지 확인
     */
    public boolean isDeleted() {
        return "deleted".equals(status);
    }
    
    /**
     * 수업과 연관된 게시글인지 확인
     */
    public boolean hasClass() {
        return classId != null && classId > 0;
    }
    
    /**
     * 댓글이 있는지 확인
     */
    public boolean hasComments() {
        return commentCount != null && commentCount > 0;
    }
    
    /**
     * 새로운 글인지 확인 (24시간 이내)
     */
    public boolean isNew() {
        if (createdAt == null) return false;
        long diffHours = (System.currentTimeMillis() - createdAt.getTime()) / (1000 * 60 * 60);
        return diffHours <= 24;
    }
    
    /**
     * 인기 글인지 확인 (조회수 100 이상)
     */
    public boolean isPopular() {
        return viewCount != null && viewCount >= 100;
    }
    
    /**
     * 제목 요약 (긴 제목 줄이기)
     */
    public String getTitleSummary(int maxLength) {
        if (title == null) return "";
        if (title.length() <= maxLength) return title;
        return title.substring(0, maxLength - 3) + "...";
    }
    
    /**
     * 내용 요약 (긴 내용 줄이기)
     */
    public String getContentSummary(int maxLength) {
        if (content == null) return "";
        // HTML 태그 제거
        String plainText = content.replaceAll("<[^>]*>", "");
        if (plainText.length() <= maxLength) return plainText;
        return plainText.substring(0, maxLength - 3) + "...";
    }
    
    /**
     * 작성 시간 포맷팅 (상대 시간)
     */
    public String getRelativeCreatedTime() {
        if (createdAt == null) return "";
        
        long diffMillis = System.currentTimeMillis() - createdAt.getTime();
        long diffMinutes = diffMillis / (60 * 1000);
        long diffHours = diffMinutes / 60;
        long diffDays = diffHours / 24;
        
        if (diffMinutes < 1) {
            return "방금 전";
        } else if (diffMinutes < 60) {
            return diffMinutes + "분 전";
        } else if (diffHours < 24) {
            return diffHours + "시간 전";
        } else if (diffDays < 7) {
            return diffDays + "일 전";
        } else {
            return createdAt.toString().substring(0, 10); // YYYY-MM-DD
        }
    }
    
    // ========================================
    // Object 메서드 오버라이드
    // ========================================
    
    @Override
    public String toString() {
        return "Post{" +
                "postId=" + postId +
                ", categoryCode='" + categoryCode + '\'' +
                ", title='" + title + '\'' +
                ", authorName='" + authorName + '\'' +
                ", viewCount=" + viewCount +
                ", commentCount=" + commentCount +
                ", isAnonymous=" + isAnonymous +
                ", isPinned=" + isPinned +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        Post post = (Post) o;
        return postId != null && postId.equals(post.postId);
    }
    
    @Override
    public int hashCode() {
        return postId != null ? postId.hashCode() : 0;
    }
}